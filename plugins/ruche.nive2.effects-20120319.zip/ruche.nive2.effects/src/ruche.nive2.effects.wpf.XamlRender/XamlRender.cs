﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Threading;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using NiVE2.Utils;
using NiVE2.Utils.Cache;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// XAMLの描画を行うNiVE2エフェクトクラス。
    /// </summary>
    public class XamlRender : EffectBase
    {
        /// <summary>
        /// Page タグ文字列ペア。
        /// </summary>
        private static readonly string[] PageTagPair =
            {
                "<Page" +
                " xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"" +
                " xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                " x:Name=\"page\">",
                "</Page>",
            };

        /// <summary>
        /// XAMLプロパティ初期値。
        /// </summary>
        private const string DefaultXaml =
            "<UniformGrid>\r\n" +
            "  <Ellipse>\r\n" +
            "    <Ellipse.Fill>\r\n" +
            "      <LinearGradientBrush StartPoint=\"0,0\" EndPoint=\"1,1\">\r\n" +
            "        <GradientStop Color=\"Red\" Offset=\"0.0\" />\r\n" +
            "        <GradientStop Color=\"Blue\" Offset=\"1.0\" />\r\n" +
            "      </LinearGradientBrush>\r\n" +
            "    </Ellipse.Fill>\r\n" +
            "  </Ellipse>\r\n" +
            "</UniformGrid>\r\n";

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        ILayer _layer;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public XamlRender()
        {
            // ベーススレッド通知
            SafeInvoker.NotifyBaseThread();
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "描画"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            var rect = _layer.GetImageBounds(0);
            var center = new Drawing::PointF(
                rect.X + rect.Width / 2,
                rect.Y + rect.Height / 2);

            return new PropertyBase[]
                {
                    new BooleanProperty("Pageタグ付与", true),
                    new StringProperty("XAML", DefaultXaml),
                    new VertexProperty("位置", center, double.MaxValue, double.MinValue),
                    new VertexProperty("サイズ", rect.Size, double.MaxValue, 0),
                    new RadianProperty("角度", 0, 0),
                    new BooleanProperty("補間処理", true),

                    // 以下はエクスプレッション用
                    new UIElementDelegateProperty("Delegate"),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            return new PropertyEditControlBase[]
                {
                    new BooleanPropertyEditControl("Pageタグ付与"),
                    new TextPropertyEditControl<StringProperty>("XAML", true),
                    new VertexPropertyEditControl(
                        "位置", 1, VertexPropertyEditControlType.PointFOrSizeF),
                    new VertexPropertyEditControl(
                        "サイズ", 1, VertexPropertyEditControlType.PointFOrSizeF),
                    new RadianPropertyEditControl("角度"),
                    new BooleanPropertyEditControl("補間処理"),
                };
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            var page = ((BooleanProperty)property["Pageタグ付与"]).Boolean;
            var xaml = ((StringProperty)property["XAML"]).Text;
            var pos = ((VertexProperty)property["位置"]).PointFValue;
            var size = ((VertexProperty)property["サイズ"]).SizeFValue;
            var angle = ((RadianProperty)property["角度"]).Angle;
            var interpolate = ((BooleanProperty)property["補間処理"]).Boolean;
            var post = ((UIElementDelegateProperty)property["Delegate"]).Delegate;

            // 描画不要なら何もしない
            if (size.Width <= 0 || size.Height <= 0)
            {
                return image;
            }

            // XAML作成
            if (page)
            {
                xaml = PageTagPair[0] + xaml + PageTagPair[1];
            }

            // UIElement 取得＆ポスト処理
            UIElement ui = null;
            SafeInvoker.Call(() =>
            {
                try
                {
                    // 取得
                    ui = XamlSerializable<UIElement>.FromXaml(xaml);

                    // パラメータ設定
                    Size s = new Size(size.Width, size.Height);
                    ui.Measure(s);
                    ui.Arrange(new Rect(s));

                    // ポスト処理
                    if (post != null)
                    {
                        post(ui);
                    }
                    ui.UpdateLayout();
                }
                catch
                {
                    ui = null;
                }
            });

            // ROIによる位置調整
            float resoRate = (float)_layer.ResolutionRate;
            pos.X += roi.ImageX / resoRate;
            pos.Y += roi.ImageY / resoRate;

            // マトリクス設定
            Matrix3D matrix = new Matrix3D();
            matrix.Translate(-size.Width / 2, -size.Height / 2);
            matrix.Rotate((float)angle);
            matrix.Translate(pos.X, pos.Y);
            matrix.Scale(resoRate, resoRate);

            // 一時キャッシュサイズ計算
            long oneSize = BitmapUtil.Calc32bppSize(size.Width, size.Height);

            if (ui != null)
            {
                SafeInvoker.Call(ui, () =>
                {
                    // UIElement からイメージ生成
                    CacheManager.Manager.DemandTemporalMemory(oneSize);
                    var bmp = BitmapUtil.CreateRenderTargetBitmap(
                        size.Width, size.Height, ui);
                    CacheManager.Manager.AddWeakCache(bmp, oneSize);
                    if (bmp.CanFreeze)
                    {
                        bmp.Freeze();
                    }

                    // NBitmap に変換して描画
                    using (CacheLocker cacheLock = new CacheLocker(oneSize))
                    using (NBitmap src = BitmapUtil.ConvertToNBitmap(bmp))
                    {
                        ImageUtil.BlendImage(
                            image,
                            src,
                            Drawing::PointF.Empty,
                            BlendType.Normal,
                            roi.Interest,
                            matrix,
                            interpolate,
                            false);
                    }
                });
            }
            else if (!string.IsNullOrEmpty(xaml.Trim()))
            {
                // 失敗時描画
                using (CacheLocker cacheLock = new CacheLocker(oneSize * 2))
                using (var bmp = new Drawing::Bitmap((int)size.Width, (int)size.Height))
                {
                    // 赤い×を作成
                    using (var g = Drawing::Graphics.FromImage(bmp))
                    using (var pen = new Drawing::Pen(Drawing::Color.Red, 2))
                    {
                        g.DrawRectangle(pen, 0, 0, size.Width, size.Height);
                        g.DrawLine(pen, 0, 0, size.Width, size.Height);
                        g.DrawLine(pen, 0, size.Height, size.Width, 0);
                    }

                    // 描画
                    using (NBitmap src = new NBitmap(bmp))
                    {
                        ImageUtil.BlendImage(
                            image,
                            src,
                            Drawing::PointF.Empty,
                            BlendType.Normal,
                            roi.Interest,
                            matrix,
                            interpolate,
                            false);
                    }
                }
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 何もしない
            return audio;
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "XAML描画"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "XAMLを描画します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
