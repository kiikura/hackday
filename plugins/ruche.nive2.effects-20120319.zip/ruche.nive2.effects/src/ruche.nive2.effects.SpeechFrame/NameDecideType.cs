﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 名前の決定方法を表す列挙。
    /// </summary>
    internal enum NameDecideType
    {
        /// <summary>
        /// 表示しない。
        /// </summary>
        [Description("表示しない")]
        Hidden,

        /// <summary>
        /// 顔レイヤー名を使う。
        /// </summary>
        [Description("顔レイヤー名を使う")]
        [EnumDefaultValue]
        LayerName,

        /// <summary>
        /// 直接指定。
        /// </summary>
        [Description("直接指定")]
        DirectName,
    };
}
