﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// セリフ枠への描画を行うNiVE2エフェクトクラス。
    /// </summary>
    [SimulationEffect]
    [UseLayer]
    public class SpeechFrame : EffectBase
    {
        /// <summary>
        /// 反転種別配列。
        /// </summary>
        private static readonly FlipType[] FlipTypes;

        /// <summary>
        /// 反転種別名配列。
        /// </summary>
        private static readonly string[] FlipTypeNames;

        /// <summary>
        /// 名前決定方法配列。
        /// </summary>
        private static readonly NameDecideType[] NameDecideTypes;

        /// <summary>
        /// 名前決定方法名配列。
        /// </summary>
        private static readonly string[] NameDecideTypeNames;

        /// <summary>
        /// 縦横基準に対応するテキストアラインメント配列。
        /// </summary>
        private static readonly StringAlignment[] TextAlignments =
            new StringAlignment[]
                {
                    StringAlignment.Near,
                    StringAlignment.Center,
                    StringAlignment.Far,
                };

        /// <summary>
        /// 複合品質レベル配列。
        /// </summary>
        private static readonly CompositingQuality[] CompositingQualities =
            new CompositingQuality[]
                {
                    CompositingQuality.Default,
                    CompositingQuality.HighSpeed,
                    CompositingQuality.HighQuality,
                    CompositingQuality.AssumeLinear,
                    CompositingQuality.GammaCorrected,
                };

        /// <summary>
        /// 複合品質レベル名配列。
        /// </summary>
        private static readonly string[] CompositingQualityNames =
            new string[]
                {
                    "デフォルト",
                    "低品質",
                    "高品質",
                    "線形",
                    "ガンマ補正",
                };

        /// <summary>
        /// 基準点に対する配置の配列。
        /// </summary>
        private static readonly BaseAlignment[] BaseAlignments =
            new BaseAlignment[]
                {
                    BaseAlignment.Near,
                    BaseAlignment.Center,
                    BaseAlignment.Far,
                };

        /// <summary>
        /// 回転の基準点種別配列。直接指定の場合は null 。
        /// </summary>
        private static RectangleAlignment?[] RotateBaseTypes;

        /// <summary>
        /// 回転の基準点種別名配列。
        /// </summary>
        private static readonly string[] RotateBaseTypeNames;

        /// <summary>
        /// グラデーション方向配列。
        /// </summary>
        private static readonly GradientDirection[] GradientDirs;

        /// <summary>
        /// グラデーション方向名配列。
        /// </summary>
        private static readonly string[] GradientDirNames;

        /// <summary>
        /// 非会話中表示種別配列。
        /// </summary>
        private static readonly SilentDisplayType[] SilentDispTypes;

        /// <summary>
        /// 非会話中表示種別名配列。
        /// </summary>
        private static readonly string[] SilentDispTypeNames;

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer = null;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static SpeechFrame()
        {
            // 反転の種別配列とその名前配列初期化
            Util.GetEnumDescriptions(out FlipTypes, out FlipTypeNames);

            // 名前決定方法配列とその名前配列初期化
            Util.GetEnumDescriptions(
                out NameDecideTypes, out NameDecideTypeNames);

            // 回転の基準点種別配列とその名前配列初期化
            {
                IDictionary<RectangleAlignment, string> dict =
                    Util.GetEnumDescriptions<RectangleAlignment>();

                List<RectangleAlignment?> types =
                    new List<RectangleAlignment?>(dict.Count + 1);
                List<string> names = new List<string>(types.Capacity);

                types.Add(null);
                names.Add("直接指定");
                foreach (KeyValuePair<RectangleAlignment, string> v in dict)
                {
                    types.Add(v.Key);
                    names.Add("元レイヤーの" + v.Value);
                }

                RotateBaseTypes = types.ToArray();
                RotateBaseTypeNames = names.ToArray();
            }

            // グラデーションの配列とその名前配列初期化
            Util.GetEnumDescriptions(out GradientDirs, out GradientDirNames);

            // 非会話中の表示種別配列とその名前配列初期化
            Util.GetEnumDescriptions(
                out SilentDispTypes, out SilentDispTypeNames);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public SpeechFrame()
        {
        }

        /// <summary>
        /// 顔レイヤー画像の描画を行う。
        /// </summary>
        /// <param name="image">描画先イメージ。</param>
        /// <param name="property">プロパティリスト。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="time">時間。</param>
        /// <param name="alpha">不透明度。 0.0 ～ 1.0 。</param>
        /// <param name="brightness">明度。 0.0 ～ 1.0 。</param>
        /// <param name="saturation">彩度。 0.0 ～ 1.0 。</param>
        public void ProcessingFaceImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time,
            double alpha,
            double brightness,
            double saturation)
        {
            if (alpha <= 0.0) { return; }

            // プロパティ取得
            int itemCode = ((LayerSelectableProperty)property["顔レイヤー"]).ItemCode;
            double faceAlpha = ((NumberProperty)property["顔:不透明度"]).DoubleValue;
            bool negaPosi = ((BooleanProperty)property["顔:ネガポジ"]).Boolean;
            FlipType flipType =
                FlipTypes[((SelectableProperty)property["顔:反転"]).Selected];
            PointF basePos = ((VertexProperty)property["顔:配:基準点"]).PointFValue;
            BaseAlignment horzAlign =
                BaseAlignments[((SelectableProperty)property["顔:配:横基準"]).Selected];
            BaseAlignment vertAlign =
                BaseAlignments[((SelectableProperty)property["顔:配:縦基準"]).Selected];
            SizeF scale = ((VertexProperty)property["顔:配:スケール"]).SizeFValue;
            RectangleAlignment? rotateType =
                RotateBaseTypes[((SelectableProperty)property["顔:回:基準点"]).Selected];
            PointF rotatePos = ((VertexProperty)property["顔:回:基準点指定"]).PointFValue;
            double rotateAngle = ((RadianProperty)property["顔:回:回転量"]).Angle;
            bool fillEnabled = ((BooleanProperty)property["顔:塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["顔:塗:色"]).Color;
            double fillAlpha = ((NumberProperty)property["顔:塗:不透明度"]).DoubleValue;
            bool fillGradEnabled = ((BooleanProperty)property["顔:塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["顔:塗:グ:色"]).Color;
            double fillGradAlpha =
                ((NumberProperty)property["顔:塗:グ:不透明度"]).DoubleValue;
            GradientDirection fillGradDir =
                GradientDirs[((SelectableProperty)property["顔:塗:グ:方向"]).Selected];
            bool interEnabled = ((BooleanProperty)property["顔:品:補間処理"]).Boolean;
            bool filterEnabled =
                ((BooleanProperty)property["顔:品:縮小フィルタ"]).Boolean;

            // 描画不要ならばそのまま返す
            if (
                alpha <= 0.0 ||
                faceAlpha <= 0.0 ||
                scale.Width == 0.0 ||
                scale.Height == 0.0)
            {
                return;
            }

            // ソースレイヤー取得
            ILayer srcLayer =
                Util.FindLayer(_layer.Composition, itemCode);
            if (srcLayer == null) { return; }

            // 取得時間設定
            double t = srcLayer.ToLocalTime(_layer.ToWorldTime(time));

            // イメージバッファサイズを算出(小数点以下を考慮してちょっと大きめに)
            SizeF bmpSize = srcLayer.GetImageBounds(t).Size;
            long bmpBufLen =
                (long)((bmpSize.Width + 1.0) * 4 * (bmpSize.Height + 1.0));

            // キャッシュを確保してイメージを取得
            using (CacheLocker cacheLock = new CacheLocker(bmpBufLen))
            using (NBitmap srcBmp = srcLayer.GetSourceImage(t))
            {
                // 色変換
                ImageUtil.ConvertImageColor(
                    srcBmp, alpha, brightness, saturation);

                // ネガポジ反転
                if (negaPosi)
                {
                    ImageUtil.InvertImageColor(srcBmp);
                }

                // 描画パラメータ作成
                ImageBlendingParam param;
                param.blendType = BlendType.Normal;
                param.alpha = faceAlpha / 100.0;
                param.flipType = flipType;
                param.basePos = basePos;
                param.horzAlign = horzAlign;
                param.vertAlign = vertAlign;
                param.scale =
                    new SizeF(scale.Width / 100.0F, scale.Height / 100.0F);
                param.rotateBaseAlign = rotateType;
                param.rotateBasePos = rotatePos;
                param.rotateAngle = rotateAngle;
                param.fillEnabled = fillEnabled;
                param.fillColor = fillColor;
                param.fillAlpha = fillAlpha / 100.0;
                param.fillGradientEnabled = fillGradEnabled;
                param.fillGradientColor = fillGradColor;
                param.fillGradientAlpha = fillGradAlpha / 100.0;
                param.fillGradientDirection = fillGradDir;
                param.interpolateEnabled = interEnabled;
                param.filterEnabled = filterEnabled;

                // 描画
                ImageUtil.BlendImage(
                    image, srcBmp, param, roi, _layer.ResolutionRate);
            }
        }

        /// <summary>
        /// 名前テキストの描画を行う。
        /// </summary>
        /// <param name="image">描画先イメージ。</param>
        /// <param name="property">プロパティリスト。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="time">時間。</param>
        public void ProcessingNameText(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            int itemCode = ((LayerSelectableProperty)property["顔レイヤー"]).ItemCode;
            NameDecideType decideType =
                NameDecideTypes[((SelectableProperty)property["名:設定方法"]).Selected];
            string directName = ((StringProperty)property["名:直接指定"]).Text;
            string splitter = ((StringProperty)property["名:区切り"]).Text;
            FontProperty fontProp = (FontProperty)property["名:フォント"];
            PointF basePos = ((VertexProperty)property["名:配:基準点"]).PointFValue;
            int horzIndex = ((SelectableProperty)property["名:配:横基準"]).Selected;
            int vertIndex = ((SelectableProperty)property["名:配:縦基準"]).Selected;
            double heightRate = ((NumberProperty)property["名:配:行間"]).DoubleValue;
            bool fillEnabled = ((BooleanProperty)property["名:塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["名:塗:色"]).Color;
            bool fillGradEnabled = ((BooleanProperty)property["名:塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["名:塗:グ:色"]).Color;
            bool edgeEnabled = ((BooleanProperty)property["名:縁:有効"]).Boolean;
            double edgeWidth = ((NumberProperty)property["名:縁:太さ"]).DoubleValue;
            Color edgeColor = ((ColorProperty)property["名:縁:色"]).Color;
            bool edgeGradEnabled = ((BooleanProperty)property["名:縁:グ:有効"]).Boolean;
            Color edgeGradColor = ((ColorProperty)property["名:縁:グ:色"]).Color;
            bool antiAlias = ((BooleanProperty)property["名:品:アンチエイリアス"]).Boolean;
            int compoIndex = ((SelectableProperty)property["名:品:複合品質"]).Selected;

            // 描画する必要が無いならそのまま返す
            if (
                decideType == NameDecideType.Hidden ||
                (!fillEnabled && !edgeEnabled))
            {
                return;
            }

            // 名前設定
            string name = directName;
            if (decideType == NameDecideType.LayerName)
            {
                // ソースレイヤー名取得
                ILayer srcLayer =
                    Util.FindLayer(_layer.Composition, itemCode);
                name = (srcLayer == null) ? "" : srcLayer.ItemName;
            }
            if (splitter.Length > 0)
            {
                // 区切り文字列で区切る
                int spIndex = name.IndexOf(splitter);
                if (spIndex >= 0)
                {
                    name = name.Substring(0, spIndex);
                }
            }

            // 描画パラメータ作成
            TextRenderingParam param;
            param.fontFamily = fontProp.FontFamily;
            param.fontEmSize = fontProp.Size;
            param.fontStyle = fontProp.Style;
            param.alpha = 1.0;
            param.basePos = basePos;
            param.horzAlign = TextAlignments[horzIndex];
            param.vertAlign = TextAlignments[vertIndex];
            param.heightRate = heightRate;
            param.fillEnabled = fillEnabled;
            param.fillColor = fillColor;
            param.fillGradientEnabled = fillGradEnabled;
            param.fillGradientColor = fillGradColor;
            param.edgeEnabled = edgeEnabled;
            param.edgeWidth = edgeWidth;
            param.edgeColor = edgeColor;
            param.edgeGradientEnabled = edgeGradEnabled;
            param.edgeGradientColor = edgeGradColor;
            param.antiAliasEnabled = antiAlias;
            param.compoQuality = CompositingQualities[compoIndex];

            // 描画
            TextUtil.RenderText(
                image, name, param, roi, _layer.ResolutionRate);
        }

        /// <summary>
        /// セリフテキストの描画を行う。
        /// </summary>
        /// <param name="image">描画先イメージ。</param>
        /// <param name="property">プロパティリスト。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="time">時間。</param>
        public void ProcessingSpeechText(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            FontProperty fontProp = (FontProperty)property["セ:フォント"];
            PointF basePos = ((VertexProperty)property["セ:配:基準点"]).PointFValue;
            int horzIndex = ((SelectableProperty)property["セ:配:横基準"]).Selected;
            int vertIndex = ((SelectableProperty)property["セ:配:縦基準"]).Selected;
            double heightRate = ((NumberProperty)property["セ:配:行間"]).DoubleValue;
            bool fillEnabled = ((BooleanProperty)property["セ:塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["セ:塗:色"]).Color;
            bool fillGradEnabled = ((BooleanProperty)property["セ:塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["セ:塗:グ:色"]).Color;
            bool edgeEnabled = ((BooleanProperty)property["セ:縁:有効"]).Boolean;
            double edgeWidth = ((NumberProperty)property["セ:縁:太さ"]).DoubleValue;
            Color edgeColor = ((ColorProperty)property["セ:縁:色"]).Color;
            bool edgeGradEnabled = ((BooleanProperty)property["セ:縁:グ:有効"]).Boolean;
            Color edgeGradColor = ((ColorProperty)property["セ:縁:グ:色"]).Color;
            double letterMs = ((NumberProperty)property["セ:字:文字間隔[ms]"]).DoubleValue;
            double lineMs = ((NumberProperty)property["セ:字:改行間隔[ms]"]).DoubleValue;
            int skipLine = ((NumberProperty)property["セ:字:スキップ行数"]).Int32Value;
            int skipLetter = ((NumberProperty)property["セ:字:スキップ文字数"]).Int32Value;
            bool skipBlank = ((BooleanProperty)property["セ:字:前後余白スキップ"]).Boolean;
            bool antiAlias = ((BooleanProperty)property["セ:品:アンチエイリアス"]).Boolean;
            int compoIndex = ((SelectableProperty)property["セ:品:複合品質"]).Selected;

            // 描画する必要が無いならそのまま返す
            if (!fillEnabled && !edgeEnabled) { return; }

            // 字送り処理を施した文字列取得
            string text = TextUtil.MakeEffectedTextPropertyValue(
                _layer,
                this,
                "セリフテキスト",
                time,
                letterMs,
                lineMs,
                skipLine,
                skipLetter,
                skipBlank);
            if (text.Trim().Length == 0) { return; }

            // 描画パラメータ作成
            TextRenderingParam param;
            param.fontFamily = fontProp.FontFamily;
            param.fontEmSize = fontProp.Size;
            param.fontStyle = fontProp.Style;
            param.alpha = 1.0;
            param.basePos = basePos;
            param.horzAlign = TextAlignments[horzIndex];
            param.vertAlign = TextAlignments[vertIndex];
            param.heightRate = heightRate / 100.0;
            param.fillEnabled = fillEnabled;
            param.fillColor = fillColor;
            param.fillGradientEnabled = fillGradEnabled;
            param.fillGradientColor = fillGradColor;
            param.edgeEnabled = edgeEnabled;
            param.edgeWidth = edgeWidth;
            param.edgeColor = edgeColor;
            param.edgeGradientEnabled = edgeGradEnabled;
            param.edgeGradientColor = edgeGradColor;
            param.antiAliasEnabled = antiAlias;
            param.compoQuality = CompositingQualities[compoIndex];

            // 描画
            TextUtil.RenderText(
                image, text, param, roi, _layer.ResolutionRate);
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "テキスト"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            SizeF size = _layer.GetImageBounds(0.0).Size;
            PointF textBasePos =
                new PointF(size.Width * 0.25F, size.Height * 0.25F);
            PointF faceBasePos = new PointF(0, size.Height * 0.5F);
            PointF nameBasePos = new PointF(size.Width * 0.25F, 0);

            return new PropertyBase[]
                {
                    new BooleanProperty("会話中", false),
                    new StringProperty("セリフテキスト", ""),
                    new LayerSelectableProperty("顔レイヤー"),
                    // 名前テキスト
                        new SelectableProperty(
                            "名:設定方法",
                            Util.FindEnumDefaultValue(NameDecideTypes),
                            NameDecideTypeNames),
                        new StringProperty("名:直接指定", ""),
                        new StringProperty("名:区切り", "_"),
                    // 詳細設定
                        new BooleanProperty("テキスト非表示", false),
                        // セリフ
                            new FontProperty(
                                "セ:フォント",
                                new Font(FontFamily.GenericSansSerif, 14.0F)),
                            // 配置
                                new VertexProperty(
                                    "セ:配:基準点",
                                    textBasePos,
                                    double.MaxValue,
                                    double.MinValue),
                                new SelectableProperty(
                                    "セ:配:横基準", 0, new string[]{ "左", "中央", "右" }),
                                new SelectableProperty(
                                    "セ:配:縦基準", 0, new string[]{ "上", "中央", "下" }),
                                new NumberProperty("セ:配:行間", 100.0, 1000.0, 0.0),
                            // 塗り潰し
                                new BooleanProperty("セ:塗:有効", true),
                                new ColorProperty("セ:塗:色", Color.Black),
                                // グラデーション
                                    new BooleanProperty("セ:塗:グ:有効", false),
                                    new ColorProperty("セ:塗:グ:色", Color.Black),
                            // 縁取り
                                new BooleanProperty("セ:縁:有効", false),
                                new NumberProperty("セ:縁:太さ", 1.0, double.MaxValue, 0.0),
                                new ColorProperty("セ:縁:色", Color.White),
                                // グラデーション
                                    new BooleanProperty("セ:縁:グ:有効", false),
                                    new ColorProperty("セ:縁:グ:色", Color.Black),
                            // 字送り
                                new NumberProperty("セ:字:文字間隔[ms]", 0.0, 10000.0, 0.0),
                                new NumberProperty("セ:字:改行間隔[ms]", 0.0, 10000.0, 0.0),
                                new NumberProperty("セ:字:スキップ行数", 0, 100, 0),
                                new NumberProperty("セ:字:スキップ文字数", 0, 1000, 0),
                                new BooleanProperty("セ:字:前後余白スキップ", true),
                            // 品質
                                new BooleanProperty("セ:品:アンチエイリアス", true),
                                new SelectableProperty(
                                    "セ:品:複合品質", 0, CompositingQualityNames),
                        // 顔レイヤー
                            new NumberProperty("顔:不透明度", 100.0, 100.0, 0.0),
                            new BooleanProperty("顔:ネガポジ", false),
                            new SelectableProperty(
                                "顔:反転",
                                Util.FindEnumDefaultValue(FlipTypes),
                                FlipTypeNames),
                            // 配置
                                new VertexProperty(
                                    "顔:配:基準点",
                                    faceBasePos,
                                    double.MaxValue,
                                    double.MinValue),
                                new SelectableProperty(
                                    "顔:配:横基準", 0, new string[]{ "左", "中央", "右" }),
                                new SelectableProperty(
                                    "顔:配:縦基準", 1, new string[]{ "上", "中央", "下" }),
                                new VertexProperty(
                                    "顔:配:スケール",
                                    new Size(100, 100),
                                    double.MaxValue,
                                    double.MinValue),
                            // 回転
                                new SelectableProperty(
                                    "顔:回:基準点",
                                    Util.FindEnumDefaultValue(RotateBaseTypes),
                                    RotateBaseTypeNames),
                                new VertexProperty(
                                    "顔:回:基準点指定",
                                    faceBasePos,
                                    double.MaxValue,
                                    double.MinValue),
                                new RadianProperty("顔:回:回転量", 0, 0.0),
                            // 塗り潰し
                                new BooleanProperty("顔:塗:有効", false),
                                new ColorProperty("顔:塗:色", Color.Black),
                                new NumberProperty("顔:塗:不透明度", 100.0, 100.0, 0.0),
                                // グラデーション
                                    new BooleanProperty("顔:塗:グ:有効", false),
                                    new ColorProperty("顔:塗:グ:色", Color.Black),
                                    new NumberProperty(
                                        "顔:塗:グ:不透明度", 100.0, 100.0, 0.0),
                                    new SelectableProperty(
                                        "顔:塗:グ:方向",
                                        Util.FindEnumDefaultValue(GradientDirs),
                                        GradientDirNames),
                            // 品質
                                new BooleanProperty("顔:品:補間処理", true),
                                new BooleanProperty("顔:品:縮小フィルタ", false),
                        // 名前
                            new FontProperty(
                                "名:フォント",
                                new Font(FontFamily.GenericSansSerif, 14.0F)),
                            // 配置
                                new VertexProperty(
                                    "名:配:基準点",
                                    nameBasePos,
                                    double.MaxValue,
                                    double.MinValue),
                                new SelectableProperty(
                                    "名:配:横基準", 0, new string[]{ "左", "中央", "右" }),
                                new SelectableProperty(
                                    "名:配:縦基準", 0, new string[]{ "上", "中央", "下" }),
                                new NumberProperty("名:配:行間", 100.0, 1000.0, 0.0),
                            // 塗り潰し
                                new BooleanProperty("名:塗:有効", true),
                                new ColorProperty("名:塗:色", Color.Black),
                                // グラデーション
                                    new BooleanProperty("名:塗:グ:有効", false),
                                    new ColorProperty("名:塗:グ:色", Color.Black),
                            // 縁取り
                                new BooleanProperty("名:縁:有効", false),
                                new NumberProperty("名:縁:太さ", 1.0, double.MaxValue, 0.0),
                                new ColorProperty("名:縁:色", Color.White),
                                // グラデーション
                                    new BooleanProperty("名:縁:グ:有効", false),
                                    new ColorProperty("名:縁:グ:色", Color.Black),
                            // 品質
                                new BooleanProperty("名:品:アンチエイリアス", true),
                                new SelectableProperty(
                                    "名:品:複合品質", 0, CompositingQualityNames),
                        // 非会話中表示
                            new SelectableProperty(
                                "非:表示方法",
                                Util.FindEnumDefaultValue(SilentDispTypes),
                                SilentDispTypeNames),
                            new NumberProperty("非:不透明度", 75.0, 100.0, 0.0),
                            new NumberProperty("非:明度", 100.0, 100.0, 0.0),
                            new NumberProperty("非:彩度", 100.0, 100.0, 0.0),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // コントロール配列作成
            PropertyEditControlBase[] controls = new PropertyEditControlBase[]
                {
                    new BooleanPropertyEditControl("会話中"),
                    new TextPropertyEditControl<StringProperty>("セリフテキスト", true),
                    new LayerSelectablePropertyEditControl(
                        "顔レイヤー", _layer.Composition, true, false, true, false),
                    new PropertyNestBeginControl("名前テキスト"),
                        new SelectablePropertyEditControl("名:設定方法"),
                        new TextPropertyEditControl<StringProperty>("名:直接指定", true),
                        new TextPropertyEditControl<StringProperty>("名:区切り", false),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("詳細設定"),
                        new BooleanPropertyEditControl("テキスト非表示"),
                        new PropertyNestBeginControl("セリフ"),
                            new FontPropertyEditControl("セ:フォント"),
                            new PropertyNestBeginControl("配置"),
                                new VertexPropertyEditControl(
                                    "セ:配:基準点",
                                    1.0,
                                    VertexPropertyEditControlType.PointFOrSizeF),
                                new SelectablePropertyEditControl("セ:配:横基準"),
                                new SelectablePropertyEditControl("セ:配:縦基準"),
                                new NumberPropertyEditControl(
                                    "セ:配:行間", 1.0, NumberPropertyEditControlType.Double),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("塗り潰し"),
                                new BooleanPropertyEditControl("セ:塗:有効"),
                                new ColorPropertyEditControl("セ:塗:色"),
                                new PropertyNestBeginControl("グラデーション"),
                                    new BooleanPropertyEditControl("セ:塗:グ:有効"),
                                    new ColorPropertyEditControl("セ:塗:グ:色"),
                                new PropertyNestEndControl(),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("縁取り"),
                                new BooleanPropertyEditControl("セ:縁:有効"),
                                new NumberPropertyEditControl(
                                    "セ:縁:太さ", 1.0, NumberPropertyEditControlType.Double),
                                new ColorPropertyEditControl("セ:縁:色"),
                                new PropertyNestBeginControl("グラデーション"),
                                    new BooleanPropertyEditControl("セ:縁:グ:有効"),
                                    new ColorPropertyEditControl("セ:縁:グ:色"),
                                new PropertyNestEndControl(),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("字送り"),
                                new NumberPropertyEditControl(
                                    "セ:字:文字間隔[ms]",
                                    1.0,
                                    NumberPropertyEditControlType.Double),
                                new NumberPropertyEditControl(
                                    "セ:字:改行間隔[ms]",
                                    1.0,
                                    NumberPropertyEditControlType.Double),
                                new NumberPropertyEditControl(
                                    "セ:字:スキップ行数",
                                    1,
                                    NumberPropertyEditControlType.Int),
                                new NumberPropertyEditControl(
                                    "セ:字:スキップ文字数",
                                    1,
                                    NumberPropertyEditControlType.Int),
                                new BooleanPropertyEditControl("セ:字:前後余白スキップ"),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("品質"),
                                new BooleanPropertyEditControl("セ:品:アンチエイリアス"),
                                new SelectablePropertyEditControl("セ:品:複合品質"),
                            new PropertyNestEndControl(),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("顔レイヤー"),
                            new NumberPropertyEditControl(
                                "顔:不透明度", 1.0, NumberPropertyEditControlType.Double),
                            new BooleanPropertyEditControl("顔:ネガポジ"),
                            new SelectablePropertyEditControl("顔:反転"),
                            new PropertyNestBeginControl("配置"),
                                new VertexPropertyEditControl(
                                    "顔:配:基準点",
                                    1.0,
                                    VertexPropertyEditControlType.PointFOrSizeF),
                                new SelectablePropertyEditControl("顔:配:横基準"),
                                new SelectablePropertyEditControl("顔:配:縦基準"),
                                new VertexPropertyEditControl(
                                    "顔:配:スケール",
                                    1.0,
                                    VertexPropertyEditControlType.PointFOrSizeF),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("回転"),
                                new SelectablePropertyEditControl("顔:回:基準点"),
                                new VertexPropertyEditControl(
                                    "顔:回:基準点指定",
                                    1.0,
                                    VertexPropertyEditControlType.PointFOrSizeF),
                                new RadianPropertyEditControl("顔:回:回転量"),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("塗り潰し"),
                                new BooleanPropertyEditControl("顔:塗:有効"),
                                new ColorPropertyEditControl("顔:塗:色"),
                                new NumberPropertyEditControl(
                                    "顔:塗:不透明度",
                                    1.0,
                                    NumberPropertyEditControlType.Double),
                                new PropertyNestBeginControl("グラデーション"),
                                    new BooleanPropertyEditControl("顔:塗:グ:有効"),
                                    new ColorPropertyEditControl("顔:塗:グ:色"),
                                    new NumberPropertyEditControl(
                                        "顔:塗:グ:不透明度",
                                        1.0,
                                        NumberPropertyEditControlType.Double),
                                    new SelectablePropertyEditControl("顔:塗:グ:方向"),
                                new PropertyNestEndControl(),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("品質"),
                                new BooleanPropertyEditControl("顔:品:補間処理"),
                                new BooleanPropertyEditControl("顔:品:縮小フィルタ"),
                            new PropertyNestEndControl(),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("名前"),
                            new FontPropertyEditControl("名:フォント"),
                            new PropertyNestBeginControl("配置"),
                                new VertexPropertyEditControl(
                                    "名:配:基準点",
                                    1.0,
                                    VertexPropertyEditControlType.PointFOrSizeF),
                                new SelectablePropertyEditControl("名:配:横基準"),
                                new SelectablePropertyEditControl("名:配:縦基準"),
                                new NumberPropertyEditControl(
                                    "名:配:行間", 1.0, NumberPropertyEditControlType.Double),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("塗り潰し"),
                                new BooleanPropertyEditControl("名:塗:有効"),
                                new ColorPropertyEditControl("名:塗:色"),
                                new PropertyNestBeginControl("グラデーション"),
                                    new BooleanPropertyEditControl("名:塗:グ:有効"),
                                    new ColorPropertyEditControl("名:塗:グ:色"),
                                new PropertyNestEndControl(),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("縁取り"),
                                new BooleanPropertyEditControl("名:縁:有効"),
                                new NumberPropertyEditControl(
                                    "名:縁:太さ", 1.0, NumberPropertyEditControlType.Double),
                                new ColorPropertyEditControl("名:縁:色"),
                                new PropertyNestBeginControl("グラデーション"),
                                    new BooleanPropertyEditControl("名:縁:グ:有効"),
                                    new ColorPropertyEditControl("名:縁:グ:色"),
                                new PropertyNestEndControl(),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("品質"),
                                new BooleanPropertyEditControl("名:品:アンチエイリアス"),
                                new SelectablePropertyEditControl("名:品:複合品質"),
                            new PropertyNestEndControl(),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("非会話中表示"),
                            new SelectablePropertyEditControl("非:表示方法"),
                            new NumberPropertyEditControl(
                                "非:不透明度",
                                1.0,
                                NumberPropertyEditControlType.Double),
                            new NumberPropertyEditControl(
                                "非:明度",
                                1.0,
                                NumberPropertyEditControlType.Double),
                            new NumberPropertyEditControl(
                                "非:彩度",
                                1.0,
                                NumberPropertyEditControlType.Double),
                        new PropertyNestEndControl(),
                    new PropertyNestEndControl(),
                };

            // ラベル文字列設定
            foreach (PropertyEditControlBase c in controls)
            {
                Util.SetPropertyEditControlLabelByName(c, ":");
            }

            return controls;
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            // 特に変更しない
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // 共通プロパティ取得
            bool speeching = ((BooleanProperty)property["会話中"]).Boolean;
            bool hideText = ((BooleanProperty)property["テキスト非表示"]).Boolean;
            SilentDisplayType silentType =
                SilentDispTypes[((SelectableProperty)property["非:表示方法"]).Selected];
            double silentAlpha = ((NumberProperty)property["非:不透明度"]).DoubleValue;
            double silentBright = ((NumberProperty)property["非:明度"]).DoubleValue;
            double silentSaturate = ((NumberProperty)property["非:彩度"]).DoubleValue;

            // パラメータ決定
            double faceAlpha = 1.0, faceBright = 1.0, faceSaturate = 1.0;
            double allAlpha = 1.0, allBright = 1.0, allSaturate = 1.0;
            bool allConv = false;
            if (!speeching)
            {
                // 非会話中
                switch (silentType)
                {
                    case SilentDisplayType.SingleCharacter:
                        allAlpha = silentAlpha / 100.0;
                        allBright = silentBright / 100.0;
                        allSaturate = silentSaturate / 100.0;
                        allConv = true;
                        break;

                    case SilentDisplayType.MultiCharacter:
                        faceAlpha = silentAlpha / 100.0;
                        faceBright = silentBright / 100.0;
                        faceSaturate = silentSaturate / 100.0;
                        hideText = true;
                        break;
                }
            }

            // 描画処理
            ProcessingFaceImage(
                image, property, roi, time, faceAlpha, faceBright, faceSaturate);
            if (!hideText)
            {
                ProcessingNameText(image, property, roi, time);
                ProcessingSpeechText(image, property, roi, time);
            }

            // 全体の色変更
            if (allConv)
            {
                ImageUtil.ConvertImageColor(
                    image, allAlpha, allBright, allSaturate);
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 呼ばれないはず
            throw new NotImplementedException();
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "セリフ枠"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "セリフ枠レイヤーに顔絵、名前、セリフを描画します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
