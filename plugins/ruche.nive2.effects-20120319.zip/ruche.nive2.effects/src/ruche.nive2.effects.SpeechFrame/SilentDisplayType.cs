﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 非会話中の表示方法を表す列挙。
    /// </summary>
    internal enum SilentDisplayType
    {
        /// <summary>
        /// 1セリフ枠1キャラタイプ。
        /// セリフ枠を含む全体の色を変更する。
        /// </summary>
        [Description("全体の色変更")]
        [EnumDefaultValue]
        SingleCharacter,

        /// <summary>
        /// 1セリフ枠複数キャラタイプ。
        /// 顔の色を変更し、名前とセリフを消去する。
        /// </summary>
        [Description("顔の色変更＆テキスト非表示")]
        MultiCharacter,
    }
}
