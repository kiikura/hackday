﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 複数テキストの描画を行うNiVE2エフェクトクラス。
    /// </summary>
    [SimulationEffect]
    public partial class MultiText : EffectBase
    {
        /// <summary>
        /// 実処理インスタンス。
        /// </summary>
        private MultiTextEffectProcessor _processor = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public MultiText()
        {
            // ベーススレッド通知
            SafeInvoker.NotifyBaseThread();
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "テキスト"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            // 実処理インスタンス作成
            _processor = new MultiTextEffectProcessor(layer);
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            return _processor.CreateProperties();
        }

        public override PropertyEditControlBase[] GetControl()
        {
            return _processor.CreateControls();
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            if (_processor != null)
            {
                image = _processor.ProcessingImage(
                    image,
                    property,
                    roi,
                    time);
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            return audio;
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "マルチテキスト"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "複数テキストを描画します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
