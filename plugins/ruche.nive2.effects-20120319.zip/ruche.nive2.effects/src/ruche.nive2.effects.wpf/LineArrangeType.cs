﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 行要素の揃え方を表す列挙。
    /// </summary>
    public enum LineArrangeType
    {
        /// <summary>
        /// 行ごと。
        /// </summary>
        [Description("行ごと")]
        [EnumDefaultValue]
        ByLine,

        /// <summary>
        /// 全行均一。
        /// </summary>
        [Description("全行均一")]
        Even,
    }
}
