﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using ruche.text;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストスタイルタグ情報を保持するNiVE2プロパティセットクラス。
    /// </summary>
    [Serializable]
    public class TextStyleTagPropertySet : PropertySetBase
    {
        /// <summary>
        /// 既定のタグ名。
        /// </summary>
        public static readonly string DefaultTagName = "span";

        /// <summary>
        /// タグ名を検証するクラス。
        /// </summary>
        [Serializable]
        private class TagNameValidater : IValidater<string>
        {
            /// <summary>
            /// タグ名に使える文字列にマッチする正規表現。
            /// </summary>
            private static readonly Regex RegexInvalidChars =
                new Regex(
                    TaggedTextParser.RegexTagNameLetter.ToString() + "+",
                    RegexOptions.CultureInvariant);

            /// <summary>
            /// コンストラクタ。
            /// </summary>
            public TagNameValidater()
            {
            }

            #region IStringValidater メンバ

            public bool Validate(ref string value)
            {
                string dest = string.Empty;
                foreach (Match m in RegexInvalidChars.Matches(value))
                {
                    dest += m.Value;
                }
                value = (dest == string.Empty) ? DefaultTagName : dest;
                return true;
            }

            #endregion
        }

        /// <summary>
        /// タグプロパティを作成する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">タグ名の初期値。</param>
        /// <returns>タグプロパティ。</returns>
        private static SwitchableStringProperty CreateTagNameProperty(
            string name,
            string value)
        {
            return new SwitchableStringProperty(
                name,
                value,
                true,
                null,
                new TagNameValidater());
        }

        /// <summary>
        /// 有効状態の初期値。
        /// </summary>
        private bool _valid = true;

        /// <summary>
        /// 有効状態切り替え可能フラグ。
        /// </summary>
        private bool _switchable = true;

        /// <summary>
        /// プロパティ名とプロパティインスタンスのテーブル。
        /// </summary>
        private Dictionary<string, PropertyBase> _propTable = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="valid">有効状態の初期値。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        public TextStyleTagPropertySet(string name, bool valid, bool switchable)
            : base(name)
        {
            _valid = valid;
            _switchable = switchable;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public TextStyleTagPropertySet(TextStyleTagPropertySet src)
            : this(src.PropertyName, src._valid, src._switchable)
        {
            if (src._propTable != null)
            {
                _propTable =
                    new Dictionary<string, PropertyBase>(src._propTable.Count);
                foreach (var kv in src._propTable)
                {
                    _propTable.Add(kv.Key, kv.Value.Copy());
                }
            }
        }

        /// <summary>
        /// テキストスタイルプロパティを取得するインデクサ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <returns>
        /// テキストスタイルプロパティ。存在しないならば null 。
        /// </returns>
        public SwitchablePropertyBase this[string name]
        {
            get
            {
                return (name == TextEffectUtil.TagPropertyName) ?
                    null :
                    (FindProperty(name) as SwitchablePropertyBase);
            }
        }

        /// <summary>
        /// タグ名を取得する。
        /// </summary>
        public string TagName
        {
            get
            {
                var prop =
                    FindProperty(TextEffectUtil.TagPropertyName)
                        as SwitchableStringProperty;
                return (prop == null) ? null : prop.OriginalValue;
            }
        }

        /// <summary>
        /// プロパティを検索する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <returns>プロパティ。</returns>
        public PropertyBase FindProperty(string name)
        {
            PropertyBase result = null;

            if (_propTable != null)
            {
                if (!_propTable.TryGetValue(name, out result))
                {
                    result = null;
                }
            }

            return result;
        }

        #region PropertySetBase メンバ

        public override PropertyBase[] Properties
        {
            get { return _propTable.Values.ToArray(); }
            set
            {
                if (value != null)
                {
                    foreach (var prop in value)
                    {
                        if (_propTable.ContainsKey(prop.PropertyName))
                        {
                            _propTable[prop.PropertyName] = prop;
                        }
                    }
                }
            }
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // タグプロパティコントロール作成
            var tagCtrl = new TextPropertyEditControl<SwitchableStringProperty>(
                TextEffectUtil.TagPropertyName,
                false,
                128);
            tagCtrl.LabelName = "タグ名";
            tagCtrl.CreatePropertyDelegate = CreateTagNameProperty;

            // コントロール配列作成
            return Util.JoinArrays(
                new PropertyEditControlBase[] { tagCtrl },
                TextEffectUtil.CreateStylePropertyControls(_switchable));
        }

        public override void InitializeDefaultProperty()
        {
            // プロパティテーブル作成
            var props = TextEffectUtil.CreateStyleProperties(_valid);
            _propTable = new Dictionary<string, PropertyBase>(props.Length + 1);
            _propTable.Add(
                TextEffectUtil.TagPropertyName,
                CreateTagNameProperty(
                    TextEffectUtil.TagPropertyName,
                    DefaultTagName));
            foreach (var prop in props)
            {
                _propTable.Add(prop.PropertyName, prop);
            }
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase Copy()
        {
            return new TextStyleTagPropertySet(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            var prop = obj as TextStyleTagPropertySet;
            if (
                prop != null &&
                this.PropertyName == prop.PropertyName &&
                this._valid == prop._valid &&
                this._switchable == prop._switchable)
            {
                if (this._propTable == null || prop._propTable == null)
                {
                    return (this._propTable == prop._propTable);
                }

                return this._propTable.All(
                    kv => kv.Value.Equals(prop[kv.Key]));
            }
            return false;
        }

        #endregion
    }
}
