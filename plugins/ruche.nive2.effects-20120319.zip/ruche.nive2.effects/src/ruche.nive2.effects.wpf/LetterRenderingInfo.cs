﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 文字描画情報を保持するクラス。
    /// </summary>
    public class LetterRenderingInfo
    {
        /// <summary>
        /// 既定の文字。
        /// </summary>
        private const string DefaultLetter = " ";

        /// <summary>
        /// 文字。
        /// </summary>
        private string _letter = DefaultLetter;

        /// <summary>
        /// フォントタイプフェース。
        /// </summary>
        private Typeface _fontFace = TextEffectUtil.DefaultFontFace;

        /// <summary>
        /// フォントサイズ。
        /// </summary>
        private double _fontSize = TextEffectUtil.DefaultFontSize;

        /// <summary>
        /// フェードイン時間(ミリ秒単位)。
        /// </summary>
        private double _fadeinTime = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public LetterRenderingInfo()
        {
            this.Matrix = Matrix.Identity;
        }

        /// <summary>
        /// 文字を取得または設定する。
        /// </summary>
        /// <remarks>
        /// サロゲートペア対応のために string 型で持つ。
        /// </remarks>
        public string Letter
        {
            get { return _letter; }
            set
            {
                _letter = string.IsNullOrEmpty(value) ?
                    DefaultLetter :
                    StringInfo.GetNextTextElement(value);
            }
        }

        /// <summary>
        /// フォントタイプフェースを取得または設定する。
        /// </summary>
        public Typeface FontFace
        {
            get { return _fontFace; }
            set { _fontFace = value ?? TextEffectUtil.DefaultFontFace; }
        }

        /// <summary>
        /// フォントサイズを取得または設定する。
        /// </summary>
        /// <remarks>0 ならば描画しない。</remarks>
        public double FontSize
        {
            get { return _fontSize; }
            set { _fontSize = Math.Max(value, 0); }
        }

        /// <summary>
        /// 文字の基準位置を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 行全体の左上端を (0, 0) とする相対座標で表す。
        /// 
        /// この位置が文字の中心位置となる。
        /// また、 Matrix による座標変換の基準位置ともなる。
        /// </remarks>
        public Point2D Position { get; set; }

        /// <summary>
        /// 文字のスケーリング値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// Position を中心としてスケーリングする。
        /// </remarks>
        public Vector Scale { get; set; }

        /// <summary>
        /// 文字の配置変換を行うマトリクス値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// Position を変換の基準位置とする。
        /// このプロパティによる変換の前に Scale によるスケーリングが行われる。
        /// 
        /// 既定値は Matrix.Identity 。
        /// </remarks>
        public Matrix Matrix { get; set; }

        /// <summary>
        /// 塗り潰しに用いるブラシを取得または設定する。
        /// </summary>
        /// <remarks>null ならば描画しない。</remarks>
        public Brush FillBrush { get; set; }

        /// <summary>
        /// 縁の描画に用いるペンを取得または設定する。
        /// </summary>
        /// <remarks>null ならば描画しない。</remarks>
        public Pen EdgePen { get; set; }

        /// <summary>
        /// 文字左端から左方向への追加領域割合を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 文字の幅を 1.0 とする割合値で表す。
        /// 下線および取り消し線の範囲決定に用いられる。
        /// </remarks>
        public double PadLeftRate { get; set; }

        /// <summary>
        /// 文字右端から右方向への追加領域割合を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 文字の幅を 1.0 とする割合値で表す。
        /// 下線および取り消し線の範囲決定に用いられる。
        /// </remarks>
        public double PadRightRate { get; set; }

        /// <summary>
        /// 下線の描画情報を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 基準Y位置は行もしくは文字の下端となる。
        /// null ならば描画しない。
        /// </remarks>
        public LineRenderingInfo UnderlineInfo { get; set; }

        /// <summary>
        /// 取り消し線の描画情報を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 基準Y位置は行もしくは文字の中央となる。
        /// null ならば描画しない。
        /// </remarks>
        public LineRenderingInfo StrikeInfo { get; set; }

        /// <summary>
        /// 傍点の描画情報を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 基準Y位置は行もしくは文字の上端となる。
        /// null ならば描画しない。
        /// </remarks>
        public DotRenderingInfo DotInfo { get; set; }

        /// <summary>
        /// 文字に適用するエフェクトを取得または設定する。
        /// </summary>
        /// <remarks>null ならば適用しない。</remarks>
        public Effect Effect { get; set; }

        /// <summary>
        /// 描画開始秒数を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 値が負数である場合、現在の経過秒数に関わらず常に描画される。
        /// </remarks>
        public double BeginTime { get; set; }

        /// <summary>
        /// フェードイン秒数を取得または設定する。
        /// </summary>
        /// <remarks>
        /// BeginTime の値が負数である場合、この値は無視される。
        /// </remarks>
        public double FadeInSpan
        {
            get { return _fadeinTime; }
            set { _fadeinTime = Math.Max(value, 0); }
        }

        /// <summary>
        /// 経過秒数による文字の不透明度を算出する。
        /// </summary>
        /// <param name="time">経過秒数。</param>
        /// <returns>文字の不透明度。 0.0 ～ 1.0 。</returns>
        public double CalcOpacity(double time)
        {
            double opacity = 1;

            if (this.BeginTime >= 0)
            {
                double timeDiff = time - this.BeginTime;
                if (timeDiff < 0)
                {
                    opacity = 0;
                }
                else if (timeDiff < this.FadeInSpan)
                {
                    opacity = timeDiff / this.FadeInSpan;
                }
            }

            return opacity;
        }

        /// <summary>
        /// フォントタイプフェース、フォントサイズ、およびスケーリング値を基に
        /// 文字の高さを算出する。
        /// </summary>
        /// <returns>文字の高さ。マトリクス値は考慮されない。</returns>
        /// <remarks>エクスプレッション用メソッド。</remarks>
        public double CalcHeight()
        {
            FormattedText ft = new FormattedText(
                this.Letter,
                CultureInfo.CurrentCulture,
                FlowDirection.LeftToRight,
                this.FontFace,
                this.FontSize,
                Brushes.Black);

            return (ft.Height * this.Scale.Y);
        }
    }
}
