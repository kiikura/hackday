﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 傍点の描画情報を保持するクラス。
    /// </summary>
    public class DotRenderingInfo : DecorationRenderingInfoBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public DotRenderingInfo()
        {
        }
    }
}
