﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// フォントの太さ種別の列挙。
    /// </summary>
    public enum FontWeightType
    {
        /// <summary>
        /// 標準。
        /// </summary>
        [Description("標準")]
        [EnumDefaultValue]
        Normal,

        /// <summary>
        /// 太字。
        /// </summary>
        [Description("太字")]
        Bold,
    }
}
