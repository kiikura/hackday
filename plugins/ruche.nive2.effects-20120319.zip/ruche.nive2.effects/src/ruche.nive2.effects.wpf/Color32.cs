﻿using System;
using System.Windows.Media;
using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// System.Windows.Media.Color および System.Drawing.Color との
    /// 相互型変換をサポートする32ビットARGB色情報構造体。
    /// </summary>
    [Serializable]
    public struct Color32
    {
        #region 非公開フィールド

        /// <summary>
        /// アルファ成分値。
        /// </summary>
        private byte _a;
        
        /// <summary>
        /// 赤成分値。
        /// </summary>
        private byte _r;

        /// <summary>
        /// 緑成分値。
        /// </summary>
        private byte _g;

        /// <summary>
        /// 青成分値。
        /// </summary>
        private byte _b;

        #endregion

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="a">アルファ成分値。</param>
        /// <param name="r">赤成分値。</param>
        /// <param name="g">緑成分値。</param>
        /// <param name="b">青成分値。</param>
        public Color32(int a, int r, int g, int b)
        {
            _a = (byte)a;
            _r = (byte)r;
            _g = (byte)g;
            _b = (byte)b;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="r">赤成分値。</param>
        /// <param name="g">緑成分値。</param>
        /// <param name="b">青成分値。</param>
        public Color32(int r, int g, int b) : this(255, r, g, b)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="a">アルファ成分値。</param>
        /// <param name="color">赤、緑、青成分値取得元の色。</param>
        public Color32(int a, Color32 color)
            : this(a, color.R, color.G, color.B)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="color">コピー元。</param>
        public Color32(Color color)
            : this(color.A, color.R, color.G, color.B)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="color">コピー元。</param>
        public Color32(Drawing::Color color)
            : this(color.A, color.R, color.G, color.B)
        {
        }

        #endregion

        #region 公開プロパティ

        /// <summary>
        /// アルファ成分値を取得または設定する。
        /// </summary>
        public byte A
        {
            get { return _a; }
            set { _a = value; }
        }

        /// <summary>
        /// 赤成分値を取得または設定する。
        /// </summary>
        public byte R
        {
            get { return _r; }
            set { _r = value; }
        }

        /// <summary>
        /// 緑成分値を取得または設定する。
        /// </summary>
        public byte G
        {
            get { return _g; }
            set { _g = value; }
        }

        /// <summary>
        /// 青成分値を取得または設定する。
        /// </summary>
        public byte B
        {
            get { return _b; }
            set { _b = value; }
        }

        /// <summary>
        /// 32ビット表現値を取得または設定する。
        /// </summary>
        public uint Value
        {
            get
            {
                return (
                    ((uint)A << 24) |
                    ((uint)R << 16) |
                    ((uint)G << 8) |
                    ((uint)B << 0));
            }
            set
            {
                A = (byte)((value >> 24) & 0xFF);
                R = (byte)((value >> 16) & 0xFF);
                G = (byte)((value >> 8) & 0xFF);
                B = (byte)((value >> 0) & 0xFF);
            }
        }

        #endregion

        #region 公開メソッド

        public override bool Equals(object obj)
        {
            if (obj is Color32)
            {
                return (this == (Color32)obj);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return (int)Value;
        }

        public override string ToString()
        {
            return ((Color)this).ToString();
        }

        #endregion

        #region Color32 への型変換

        public static implicit operator Color32(Color src)
        {
            return new Color32(src);
        }

        public static implicit operator Color32(Drawing::Color src)
        {
            return new Color32(src);
        }

        #endregion

        #region Color32 からの型変換

        public static implicit operator Color(Color32 src)
        {
            return Color.FromArgb(src.A, src.R, src.G, src.B);
        }

        public static explicit operator Drawing::Color(Color32 src)
        {
            return Drawing::Color.FromArgb(src.A, src.R, src.G, src.B);
        }

        #endregion

        #region 演算子

        public static Color32 operator +(Color32 l, Color32 r)
        {
            return new Color32(
                Math.Min((int)l.A + r.A, 255),
                Math.Min((int)l.R + r.R, 255),
                Math.Min((int)l.G + r.G, 255),
                Math.Min((int)l.B + r.B, 255));
        }

        public static Color32 operator -(Color32 l, Color32 r)
        {
            return new Color32(
                Math.Max((int)l.A - r.A, 0),
                Math.Max((int)l.R - r.R, 0),
                Math.Max((int)l.G - r.G, 0),
                Math.Max((int)l.B - r.B, 0));
        }

        public static Color32 operator *(Color32 l, double r)
        {
            return new Color32(
                (byte)Math.Min(Math.Max(l.A * r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.R * r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.G * r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.B * r, 0.0), 255.0));
        }

        public static Color32 operator /(Color32 l, double r)
        {
            return new Color32(
                (byte)Math.Min(Math.Max(l.A / r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.R / r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.G / r, 0.0), 255.0),
                (byte)Math.Min(Math.Max(l.B / r, 0.0), 255.0));
        }

        public static bool operator ==(Color32 l, Color32 r)
        {
            return (l.Value == r.Value);
        }

        public static bool operator !=(Color32 l, Color32 r)
        {
            return !(l == r);
        }

        #endregion
    }
}
