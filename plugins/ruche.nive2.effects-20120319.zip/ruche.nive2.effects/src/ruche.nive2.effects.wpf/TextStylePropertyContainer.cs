﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストスタイルプロパティ値を保持するクラス。
    /// </summary>
    /// <remarks>
    /// 上書きをサポートするため、すべてのパラメータは null 許容値となる。
    /// </remarks>
    [Serializable]
    public sealed class TextStylePropertyContainer : Nive2PropertyContainerBase
    {
        /// <summary>
        /// タグ名。
        /// </summary>
        private string _tagName = null;

        /// <summary>
        /// タグ名固定フラグ。
        /// </summary>
        private bool _tagNameFrozen = false;

        /// <summary>
        /// 影のぼかし幅。
        /// </summary>
        private double? _shadowBlur = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextStylePropertyContainer()
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        public TextStylePropertyContainer(string tagName)
        {
            TagName = tagName;
        }

        /// <summary>
        /// タグ名が固定されているか否かを取得する。
        /// </summary>
        bool IsTagNameFrozen
        {
            get { return _tagNameFrozen; }
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property(TextEffectUtil.TagPropertyName)]
        public string TagName
        {
            get { return _tagName; }
            set
            {
                if (value != _tagName)
                {
                    if (IsTagNameFrozen)
                    {
                        throw new InvalidOperationException(
                            "タグ名は固定されています。");
                    }
                    _tagName = value;
                }
            }
        }

        [Nive2Property("valign")]
        public TextVerticalAlignment? VertAlign { get; set; }

        [Nive2Property("scale.x")]
        public double? ScaleXPercent { get; set; }

        [Nive2Property("scale.y")]
        public double? ScaleYPercent { get; set; }

        [Nive2Property("margin.top")]
        public double? MarginTop { get; set; }

        [Nive2Property("margin.bottom")]
        public double? MarginBottom { get; set; }

        [Nive2Property("margin.left")]
        public double? MarginLeft { get; set; }

        [Nive2Property("margin.right")]
        public double? MarginRight { get; set; }

        [Nive2Property("font.family")]
        public string FontFamilyName { get; set; }

        [Nive2Property("font.size")]
        public double? FontSize { get; set; }

        [Nive2Property("font.weight")]
        public FontWeightType? FontWeightType { get; set; }

        [Nive2Property("font.style")]
        public FontStyleType? FontStyleType { get; set; }

        [Nive2Property("fill.color")]
        private XamlSerializable<Brush> FillColorData { get; set; }

        [Nive2Property("edge.color")]
        private XamlSerializable<Brush> EdgeColorData { get; set; }
        
        [Nive2Property("edge.width")]
        public double? EdgeWidth { get; set; }

        [Nive2Property("edge.type")]
        public PenLineJoin? EdgeType { get; set; }

        [Nive2Property("underline.color")]
        private XamlSerializable<Brush> UnderlineColorData { get; set; }

        [Nive2Property("underline.width")]
        public double? UnderlineWidth { get; set; }

        [Nive2Property("underline.cap")]
        public PenLineCap? UnderlineCap { get; set; }

        [Nive2Property("underline.pattern")]
        public double[] UnderlinePattern { get; set; }

        [Nive2Property("underline.offset")]
        public double? UnderlineOffsetPercent { get; set; }

        [Nive2Property("underline.z")]
        public double? UnderlineZ { get; set; }

        [Nive2Property("strike.color")]
        private XamlSerializable<Brush> StrikeColorData { get; set; }

        [Nive2Property("strike.width")]
        public double? StrikeWidth { get; set; }

        [Nive2Property("strike.cap")]
        public PenLineCap? StrikeCap { get; set; }

        [Nive2Property("strike.pattern")]
        public double[] StrikePattern { get; set; }

        [Nive2Property("strike.offset")]
        public double? StrikeOffsetPercent { get; set; }

        [Nive2Property("strike.z")]
        public double? StrikeZ { get; set; }

        [Nive2Property("dot.color")]
        private XamlSerializable<Brush> DotColorData { get; set; }

        [Nive2Property("dot.width")]
        public double? DotWidth { get; set; }

        [Nive2Property("dot.offset")]
        public double? DotOffsetPercent { get; set; }

        [Nive2Property("dot.z")]
        public double? DotZ { get; set; }

        [Nive2Property("shadow.color")]
        private XamlSerializable<Brush> ShadowColorData { get; set; }

        [Nive2Property("shadow.dir")]
        private double? ShadowDirData { get; set; }

        [Nive2Property("shadow.depth")]
        public double? ShadowDepth { get; set; }

        [Nive2Property("shadow.blur")]
        public double? ShadowBlur
        {
            get { return _shadowBlur; }
            set
            {
                // 大きくし過ぎるとフリーズする可能性があるためキャップする
                if (value == null)
                {
                    _shadowBlur = null;
                }
                else
                {
                    _shadowBlur =
                        Math.Min((double)value, TextEffectUtil.ShadowBlurMax);
                }
            }
        }

        [Nive2Property("shadow.quality")]
        public RenderingBias? ShadowQuality { get; set; }

        #endregion

        #region NiVE2プロパティ対応メンバへのアクセッサ

        public double? ScaleX
        {
            get { return ScaleXPercent.HasValue ? (ScaleXPercent / 100) : null; }
            set { ScaleXPercent = value.HasValue ? (value * 100) : null; }
        }

        public double? ScaleY
        {
            get { return ScaleYPercent.HasValue ? (ScaleYPercent / 100) : null; }
            set { ScaleYPercent = value.HasValue ? (value * 100) : null; }
        }

        public FontFamily FontFamily
        {
            get
            {
                return (FontFamilyName == null) ?
                    null :
                    new FontFamily(FontFamilyName);
            }
            set
            {
                FontFamilyName = (value == null) ?
                    null :
                    TextEffectUtil.GetFontFamilyName(value);
            }
        }

        public FontWeight? FontWeight
        {
            get
            {
                var value = FontWeightType;
                if (value.HasValue)
                {
                    switch (value)
                    {
                    case wpf.FontWeightType.Normal:
                        return FontWeights.Normal;

                    case wpf.FontWeightType.Bold:
                        return FontWeights.Bold;
                    }
                }
                return null;
            }
            set
            {
                if (value.HasValue)
                {
                    var weight = value.Value.ToOpenTypeWeight();
                    if (weight > TextEffectUtil.NormalFontWeightMax)
                    {
                        FontWeightType = wpf.FontWeightType.Bold;
                    }
                    else
                    {
                        FontWeightType = wpf.FontWeightType.Normal;
                    }
                }
                else
                {
                    FontWeightType = null;
                }
            }
        }

        public FontStyle? FontStyle
        {
            get
            {
                var value = FontStyleType;
                if (value.HasValue)
                {
                    switch (value)
                    {
                    case wpf.FontStyleType.Normal:
                        return FontStyles.Normal;

                    case wpf.FontStyleType.Italic:
                        return FontStyles.Italic;

                    case wpf.FontStyleType.Oblique:
                        return FontStyles.Oblique;
                    }
                }
                return null;
            }
            set
            {
                if (value.HasValue)
                {
                    if (value == FontStyles.Italic)
                    {
                        FontStyleType = wpf.FontStyleType.Italic;
                    }
                    else if (value == FontStyles.Oblique)
                    {
                        FontStyleType = wpf.FontStyleType.Oblique;
                    }
                    else
                    {
                        FontStyleType = wpf.FontStyleType.Normal;
                    }
                }
                else
                {
                    FontStyleType = null;
                }
            }
        }

        public Brush FillColor
        {
            get
            {
                return (FillColorData == null) ? null : FillColorData.Value;
            }
            set
            {
                if (value == null)
                {
                    FillColorData = null;
                }
                else
                {
                    FillColorData =
                        new XamlSerializable<Brush>(value.SafeGetAsFrozen());
                }
            }
        }

        public Brush EdgeColor
        {
            get
            {
                return (EdgeColorData == null) ? null : EdgeColorData.Value;
            }
            set
            {
                if (value == null)
                {
                    EdgeColorData = null;
                }
                else
                {
                    EdgeColorData =
                        new XamlSerializable<Brush>(value.SafeGetAsFrozen());
                }
            }
        }

        public Brush UnderlineColor
        {
            get
            {
                return (UnderlineColorData == null) ?
                    null :
                    UnderlineColorData.Value;
            }
            set
            {
                if (value == null)
                {
                    UnderlineColorData = null;
                }
                else
                {
                    UnderlineColorData =
                        new XamlSerializable<Brush>(value.SafeGetAsFrozen());
                }
            }
        }

        public double? UnderlineOffset
        {
            get
            {
                return UnderlineOffsetPercent.HasValue ?
                    (UnderlineOffsetPercent / 100) :
                    null;
            }
            set
            {
                UnderlineOffsetPercent = value.HasValue ? (value * 100) : null;
            }
        }

        public Brush StrikeColor
        {
            get
            {
                return (StrikeColorData == null) ?
                    null :
                    StrikeColorData.Value;
            }
            set
            {
                if (value == null)
                {
                    StrikeColorData = null;
                }
                else
                {
                    StrikeColorData =
                        new XamlSerializable<Brush>(value.SafeGetAsFrozen());
                }
            }
        }

        public double? StrikeOffset
        {
            get
            {
                return StrikeOffsetPercent.HasValue ?
                    (StrikeOffsetPercent / 100) :
                    null;
            }
            set
            {
                StrikeOffsetPercent = value.HasValue ? (value * 100) : null;
            }
        }

        public Brush DotColor
        {
            get
            {
                return (DotColorData == null) ? null : DotColorData.Value;
            }
            set
            {
                if (value == null)
                {
                    DotColorData = null;
                }
                else
                {
                    DotColorData =
                        new XamlSerializable<Brush>(value.SafeGetAsFrozen());
                }
            }
        }

        public double? DotOffset
        {
            get
            {
                return DotOffsetPercent.HasValue ?
                    (DotOffsetPercent / 100) :
                    null;
            }
            set
            {
                DotOffsetPercent = value.HasValue ? (value * 100) : null;
            }
        }

        public Color32? ShadowColor
        {
            get
            {
                if (ShadowColorData != null)
                {
                    var brush = ShadowColorData.Value as SolidColorBrush;
                    if (brush != null)
                    {
                        var color = brush.Color;
                        color.ScA = (float)(color.ScA * brush.Opacity);
                        return color;
                    }
                }
                return null;
            }
            set
            {
                if (value == null)
                {
                    ShadowColorData = null;
                }
                else
                {
                    var brush = SafeInvoker.Call(
                        () =>
                        {
                            var b = new SolidColorBrush((Color)value);
                            b.Freeze();
                            return b;
                        });
                    ShadowColorData = new XamlSerializable<Brush>(brush);
                }
            }
        }

        public double? ShadowDir
        {
            get
            {
                if (ShadowDirData != null)
                {
                    double dir = (double)ShadowDirData;
                    while (dir < 0)
                    {
                        dir += 360;
                    }
                    while (dir >= 360)
                    {
                        dir -= 360;
                    }
                    return dir;
                }
                return null;
            }
            set { ShadowDirData = value; }
        }

        #endregion

        /// <summary>
        /// タグ名を固定する。
        /// </summary>
        public void FreezeTagName()
        {
            _tagNameFrozen = true;
        }

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        /// <remarks>タグ名は非固定状態となる。</remarks>
        public new TextStylePropertyContainer Clone()
        {
            return (TextStylePropertyContainer)base.Clone();
        }
    }
}
