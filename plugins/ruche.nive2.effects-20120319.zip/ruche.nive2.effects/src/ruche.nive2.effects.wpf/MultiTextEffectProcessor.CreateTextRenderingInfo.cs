﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using ruche.text;

namespace ruche.nive2.effects.wpf
{
    partial class MultiTextEffectProcessor
    {
        /// <summary>
        /// テキスト描画情報を作成する。
        /// </summary>
        /// <param name="textData">テキストプロパティコンテナ。</param>
        /// <param name="container">エフェクトプロパティコンテナ。</param>
        /// <param name="variables">変数リスト。</param>
        /// <param name="tags">タグコレクション。</param>
        /// <returns>テキスト描画情報。</returns>
#if DEBUG
        public
#else
        private
#endif
        static TextRenderingInfo CreateTextRenderingInfo(
            FormattedTextPropertyContainer textData,
            MultiTextEffectPropertyContainer container,
            Dictionary<string, object> variables,
            TextStyleTagCollection tags)
        {
            // 描画不要なら null を返す
            if (
                textData.Text.Length <= 0 ||
                textData.Post.Alpha <= 0)
            {
                return null;
            }

            // テキスト値取得
            string text = textData.Text;

            // スタイルと表示速度の既定値作成
            var style = container.Style.Clone();
            textData.Style.CopyTo(style, true);
            var speak = container.Speak.Clone();
            textData.Speak.CopyTo(speak, true);

            // 変数処理
            if (textData.Option.VariableEnabled)
            {
                text = ParseVariables(
                    text,
                    variables,
                    textData.Option.VariableNestEnabled);
            }

            // タグ＆エンティティ処理
            EffectedTextCollection texts;
            if (textData.Option.TagEnabled)
            {
                texts = ParseTags(
                    text,
                    style,
                    speak,
                    tags,
                    textData.Option.EntityEnabled);
            }
            else
            {
                if (textData.Option.EntityEnabled)
                {
                    text = EntityParser.Parse(text);
                }
                texts = new EffectedTextCollection();
                texts.Add(new EffectedText(text, style, speak));
            }

            // EffectedTextInfoLine のリストに変換
            var infoLines =
                ConvertToEffectedTextInfoRows(texts, textData.Arrange);

            // TextLineData のリストに変換
            var lines = ConvertToTextRowDatas(infoLines, textData.Arrange);

            return ConvertToTextRenderingInfo(
                lines,
                textData.Arrange,
                textData.Post,
                textData.Blend);
        }

        /// <summary>
        /// テキストの変数を変換する。
        /// </summary>
        /// <param name="text">テキスト。</param>
        /// <param name="variables">変数リスト。</param>
        /// <param name="nestEnabled">ネスト有効フラグ。</param>
        /// <returns>処理されたテキスト。</returns>
        private static string ParseVariables(
            string text,
            Dictionary<string, object> variables,
            bool nestEnabled)
        {
            // パーサ作成
            var varParser = new VariableParser();
            varParser.MaxNest = nestEnabled ?
                VariableParser.DefaultMaxNest :
                -1;
            foreach (var v in variables)
            {
                if (varParser.IsValidName(v.Key))
                {
                    varParser.SetValue(v.Key, v.Value);
                }
            }

            // パース
            try
            {
                text = varParser.Parse(text);
            }
            catch (VariableParser.NestException)
            {
                // ネスト例外が出たらネストなしでパース
                varParser.MaxNest = -1;
                text = varParser.Parse(text);
            }

            return text;
        }

        /// <summary>
        /// テキストのタグを変換する。
        /// </summary>
        /// <param name="text">テキスト。</param>
        /// <param name="style">既定のスタイル。</param>
        /// <param name="speak">既定の表示速度。</param>
        /// <param name="tags">スタイルタグコレクション。</param>
        /// <param name="entityEnabled">エンティティ有効フラグ</param>
        /// <returns>処理結果のパラメータテキストコレクション。</returns>
        private static EffectedTextCollection ParseTags(
            string text,
            TextStylePropertyContainer style,
            TextSpeakPropertyContainer speak,
            TextStyleTagCollection tags,
            bool entityEnabled)
        {
            // パーサ作成
            var entityParser = entityEnabled ? EntityParser : null;
            var tagParser =
                new TaggedTextParser(entityParser, entityParser);

            // パース
            var taggedTexts = tagParser.Parse(text);

            // パラメータテキスト配列作成
            return EffectedTextCollection.FromTaggedTexts(
                taggedTexts,
                style,
                speak,
                tags);
        }

        /// <summary>
        /// パラメータ付きテキストコレクションを
        /// EffectedTextInfoRow リストに変換する。
        /// </summary>
        /// <param name="texts">パラメータ付きテキストコレクション。</param>
        /// <param name="arrange">配置。</param>
        /// <returns>EffectedTextInfoRow リスト。</returns>
        private static List<EffectedTextInfoRow> ConvertToEffectedTextInfoRows(
            EffectedTextCollection texts,
            TextArrangePropertyContainer arrange)
        {
            // 行ごとに分割
            var textRows = SplitEffectedTextsByRow(texts);

            // 行を折り返し行単位に分割し、テキスト行データに変換する
            var infoRows = new List<EffectedTextInfoRow>();
            foreach (var l in textRows.Select((data, i) => new { data, i }))
            {
                // 情報配列を作成
                var lineInfos = l.data.Select(et => new EffectedTextInfo(et));

                // 最大行長で分割(折り返し行)
                var infoParts =
                    SplitEffectedTextInfos(lineInfos, arrange.MaxRowSize.Width);

                // 折り返し行ごとにテキスト行データに変換
                var infoLineParts = infoParts.ConvertAll(
                    infos => new EffectedTextInfoRow(l.i, infos));

                // リストに追加
                infoRows.AddRange(infoLineParts);
            }

            return infoRows;
        }

        /// <summary>
        /// EffectedTextInfoRow リストを TextRowData リストに変換する。
        /// </summary>
        /// <param name="infoRows">EffectedTextInfoRow リスト。</param>
        /// <param name="arrange">配置。</param>
        /// <returns>TextRowData リスト。上端は Y == 0 となる。</returns>
        private static List<TextRowData> ConvertToTextRowDatas(
            List<EffectedTextInfoRow> infoRows,
            TextArrangePropertyContainer arrange)
        {
            // 全体で最大の高さを取得
            double maxHeight = infoRows.Max(i => i.HighestInfo.Height);

            // 行データに各種座標情報付与
            double rowY = 0;
            double prevMarginB = 0;
            bool firstRow = true;
            var rows = infoRows.ConvertAll(
                row =>
                {
                    // 行の高さとベースライン決定
                    double height = maxHeight;
                    if (arrange.RowHeightType != LineArrangeType.Even)
                    {
                        height = Math.Max(
                            row.HighestInfo.Height,
                            arrange.MinRowSize.Height);
                    }
                    height = Math.Min(height, arrange.MaxRowSize.Height);
                    double baseline = height * row.HighestInfo.BaselineRate;

                    // 行内情報にX,Y位置を付与
                    // 上下最大マージンを保存
                    double x = 0;
                    double prevMarginR = 0;
                    double marginTop = double.MinValue;
                    double marginBottom = double.MinValue;
                    bool firstInfo = true;
                    var infos = row.Infos.ConvertAll(
                        info =>
                        {
                            // X,Y位置を付与
                            if (!firstInfo)
                            {
                                x += Math.Max(
                                    info.LetterMarginLeft,
                                    prevMarginR);
                            }
                            double y = CalcTextY(
                                height,
                                baseline,
                                info.Height,
                                info.Baseline,
                                info.VertAlign);
                            var r =
                                new EffectedTextInfoWithXY
                                {
                                    X = x,
                                    Y = y,
                                    Info = info,
                                };

                            // 最大マージン保存
                            double my = Math.Max(y, 0);
                            double mt = -(my - info.LetterMarginTop);
                            double mb =
                                my +
                                Math.Min(info.Height, height) +
                                info.LetterMarginBottom -
                                height;
                            marginTop = Math.Max(marginTop, mt);
                            marginBottom = Math.Max(marginBottom, mb);

                            // 次の情報用の更新
                            x += info.Width;
                            prevMarginR = info.LetterMarginRight;
                            firstInfo = false;

                            return r;
                        });

                    // マージンでY位置補正
                    if (!firstRow)
                    {
                        rowY += Math.Max(prevMarginB, marginTop);
                    }

                    // 行データ作成
                    var rr =
                        new TextRowData
                        {
                            Infos = infos,
                            Index = row.Index,
                            Y = rowY,
                            Width = Math.Max(x, arrange.MinRowSize.Width),
                            Height = height,
                        };

                    // 次の行用の更新
                    rowY += height;
                    prevMarginB = marginBottom;
                    firstRow = false;

                    return rr;
                });

            // 行間値によるY位置補正
            if (arrange.RowSpan != 1)
            {
                double baseCenterY = rows[0].CenterY;
                rows.ForEach(
                    line =>
                    {
                        var diff = line.CenterY - baseCenterY;
                        line.CenterY = baseCenterY + diff * arrange.RowSpan;
                    });
            }

            // 上端が Y == 0 となるように全体を移動
            double topY = rows.Min(l => l.Y);
            if (topY != 0)
            {
                rows.ForEach(l => { l.Y -= topY; });
            }

            return rows;
        }

        /// <summary>
        /// TextRowData リストをテキスト描画情報に変換する。
        /// </summary>
        /// <param name="rows">TextLineData リスト。</param>
        /// <param name="arrange">配置。</param>
        /// <param name="post">ポスト処理。</param>
        /// <param name="blendType">ブレンド種別。</param>
        /// <returns>テキスト描画情報。</returns>
        private static TextRenderingInfo ConvertToTextRenderingInfo(
            List<TextRowData> rows,
            TextArrangePropertyContainer arrange,
            TextPostPropertyContainer post,
            BlendType blendType)
        {
            // 各論理行の先頭と末尾の空白文字数を調べる
            var rowTexts = new List<string>(rows.Count);
            var rowLetterCounts = new List<int>(rows.Count);
            foreach (var rowSrc in rows)
            {
                int index = rowSrc.Index;
                while (rowTexts.Count <= index)
                {
                    rowTexts.Add(string.Empty);
                    rowLetterCounts.Add(0);
                }
                foreach (var ti in rowSrc.Infos)
                {
                    foreach (var le in ti.Info.Letters)
                    {
                        rowTexts[index] += le.Letter;
                    }
                    rowLetterCounts[index] += ti.Info.Letters.Count;
                }
            }
            var beginIndices = new List<int>(rowTexts.Count);
            var endIndices = new List<int>(rowTexts.Count);
            for (int i = 0; i < rowTexts.Count; ++i)
            {
                string rt = rowTexts[i];
                beginIndices.Add(rt.Length - rt.TrimStart(null).Length);
                endIndices.Add(
                    rowLetterCounts[i] - (rt.Length - rt.TrimEnd(null).Length));
            }

            // 全体の幅と高さを決定
            double textWidth = rows.Max(r => r.Width);
            double textHeight = rows.Max(r => r.Y + r.Height);
            textWidth = Math.Min(
                Math.Max(textWidth, arrange.MinSize.Width),
                arrange.MaxSize.Width);
            textHeight = Math.Min(
                Math.Max(textHeight, arrange.MinSize.Height),
                arrange.MaxSize.Height);

            // 全体の位置を決定
            double textX = Util.GetNearPosition(
                arrange.Position.X,
                textWidth,
                arrange.HorzAlign);
            double textY = Util.GetNearPosition(
                arrange.Position.Y,
                textHeight,
                arrange.VertAlign);

            // 回転マトリクス作成
            Matrix textMatrix = Matrix.Identity;
            textMatrix.RotateAt(
                arrange.RotateAngle,
                arrange.RotateCenter.X,
                arrange.RotateCenter.Y);

            // テキスト描画情報初期化
            var dest =
                new TextRenderingInfo
                {
                    Position = new Point2D(textX, textY),
                    Matrix = textMatrix,
                    Alpha = post.Alpha,
                    Brightness = post.Brightness,
                    Saturation = post.Saturation,
                    BlendType = blendType,
                };

            // テキスト行描画情報作成
            double beginTime = -1000, rowSpan = 0;
            int letterCount = 0, curIndex = -1;
            foreach (var rowSrc in rows)
            {
                // 論理行が変わった場合
                if (curIndex != rowSrc.Index)
                {
                    curIndex = rowSrc.Index;

                    // 文字数リセット
                    letterCount = 0;

                    // 改行分の時間を進める
                    if (beginTime >= 0)
                    {
                        beginTime += rowSpan;
                    }
                }

                // テキスト行描画情報初期化
                // とりあえず左揃えにしておく
                var rowDest =
                    new TextRowRenderingInfo
                    {
                        Position = new Point2D(0, rowSrc.Y),
                    };

                // テキスト情報ごとに処理
                foreach (var ti in rowSrc.Infos)
                {
                    double x = ti.X;
                    var info = ti.Info;

                    double margin = Math.Max(
                        info.LetterMarginLeft,
                        info.LetterMarginRight);

                    // 各種情報作成
                    var edgePen = MakeEdgePen(info.Style);
                    var underline = MakeUnderlineRenderingInfo(info.Style);
                    var strike = MakeStrikeRenderingInfo(info.Style);
                    var dot = MakeDotRenderingInfo(info.Style);
                    var shadow = MakeShadowEffect(info.Style);

                    // 有効範囲に入ったら表示開始時間設定開始
                    if (beginTime < 0 && curIndex > info.Speak.RowSkip)
                    {
                        beginTime = 0;
                    }

                    // 文字の有無で処理分け
                    if (info.Letters.Count == 0)
                    {
                        // 1文字も無いならウェイト時間分だけ進める
                        if (
                            beginTime < 0 &&
                            curIndex == info.Speak.RowSkip &&
                            letterCount >= info.Speak.LetterSkip)
                        {
                            beginTime = 0;
                        }
                        if (beginTime >= 0)
                        {
                            beginTime += info.Speak.Wait;
                        }
                    }
                    else
                    {
                        // 文字ごとに処理
                        var datas = info.Letters;
                        foreach (var c in datas.Select((d, i) => new { d, i }))
                        {
                            // 有効範囲に入ったら表示開始時間設定開始
                            if (
                                beginTime < 0 &&
                                curIndex == info.Speak.RowSkip &&
                                letterCount >= info.Speak.LetterSkip)
                            {
                                beginTime = 0;
                            }

                            // 文字の中心位置決定
                            Point2D pos = new Point2D(
                                x + c.d.Width / 2,
                                ti.Y + info.Height / 2);

                            // 左右追加文字領域算出(マージンの半分とする)
                            double leftRate =
                                (info.LetterMarginLeft / 2) / c.d.Width;
                            double rightRate =
                                (info.LetterMarginRight / 2) / c.d.Width;

                            // 文字描画情報作成＆追加
                            var letterDest =
                                new LetterRenderingInfo
                                {
                                    Letter = c.d.Letter,
                                    FontFace = info.FontFace,
                                    FontSize = info.FontSize,
                                    Position = pos,
                                    Scale = info.Scale,
                                    Matrix = Matrix.Identity,
                                    FillBrush =
                                        info.Style.FillColor ??
                                        Brushes.Transparent,
                                    EdgePen = edgePen,
                                    PadLeftRate = leftRate,
                                    PadRightRate = rightRate,
                                    UnderlineInfo = underline,
                                    StrikeInfo = strike,
                                    DotInfo = dot,
                                    Effect = shadow,
                                    BeginTime = beginTime / 1000,
                                    FadeInSpan = info.Speak.FadeInSpan / 1000,
                                };
                            rowDest.LetterInfos.Add(letterDest);

                            // 表示開始時間を進める
                            // ただし前後余白スキップ対象文字ならば進めない
                            if (beginTime >= 0)
                            {
                                bool skip = false;
                                if (info.Speak.BlankSkip)
                                {
                                    skip = (
                                        letterCount < beginIndices[curIndex] ||
                                        letterCount >= endIndices[curIndex]);
                                }
                                if (!skip)
                                {
                                    beginTime += info.Speak.LetterSpan;
                                }
                            }

                            // 論理行文字数とX位置を進める
                            ++letterCount;
                            x += c.d.Width + margin;
                        }
                    }

                    // 最後の改行時間保存
                    rowSpan = info.Speak.RowSpan;
                }

                // 行揃えタイプによるX位置の補正
                AdjustTextRowRenderingInfoAlignment(
                    rowDest,
                    arrange.RowAlign,
                    rowSrc.Width,
                    textWidth);

                // テキスト行描画情報追加
                dest.RowInfos.Add(rowDest);
            }

            return dest;
        }

        /// <summary>
        /// パラメータ付きテキストコレクションを行単位に分割する。
        /// </summary>
        /// <param name="src">パラメータ付きテキストコレクション。</param>
        /// <returns>行単位のパラメータ付きテキストコレクション。</returns>
        private static List<EffectedTextCollection> SplitEffectedTextsByRow(
            EffectedTextCollection src)
        {
            var dests = new List<EffectedTextCollection>();
            if (src.Count <= 0)
            {
                return dests;
            }

            var dest = new EffectedTextCollection();
            foreach (var et in src)
            {
                string[] rows = et.Text.Split(
                    new string[] { "\r\n", "\n", "\r" },
                    StringSplitOptions.None);
                for (int i = 0; i < rows.Length; ++i)
                {
                    dest.Add(new EffectedText(rows[i], et.Style, et.Speak));
                    if (i + 1 < rows.Length)
                    {
                        dests.Add(dest);
                        dest = new EffectedTextCollection();
                    }
                }
            }
            dests.Add(dest);

            return dests;
        }

        /// <summary>
        /// 改行なしのパラメータ付きテキスト情報リストを指定した幅に
        /// 収まるように分割する。
        /// </summary>
        /// <param name="src">パラメータ付きテキスト情報リスト。</param>
        /// <param name="width">幅。</param>
        /// <returns>分割されたパラメータ付きテキスト情報リスト。</returns>
        private static List<List<EffectedTextInfo>> SplitEffectedTextInfos(
            IEnumerable<EffectedTextInfo> src,
            double width)
        {
            var dests = new List<List<EffectedTextInfo>>();

            var dest = new List<EffectedTextInfo>();
            double x = 0;
            foreach (var info in src)
            {
                // 1文字も入らないなら1つ前までで分割
                if (
                    x > 0 &&
                    info.Letters.Count > 0 &&
                    x + info.CalcWidth(0, 1) > width)
                {
                    dests.Add(dest);
                    dest = new List<EffectedTextInfo>();
                    x = 0;
                }

                var temp = info;
                double tempWidth = temp.Width;
                for (; x + tempWidth > width; tempWidth = temp.Width)
                {
                    // 入る分だけ切り取って追加(最低1文字は入れる)
                    int n = Math.Max(temp.CalcLetterCount(width - x, 0), 1);
                    var prev = temp.GetRange(0, n);
                    dest.Add(prev);

                    // ここまでで分割
                    dests.Add(dest);
                    dest = new List<EffectedTextInfo>();
                    x = 0;

                    // 残りを取り出す
                    temp = temp.GetRange(n);
                }
                dest.Add(temp);
                x += tempWidth;
            }

            // 残りを追加
            if (dest.Count > 0)
            {
                dests.Add(dest);
            }

            return dests;
        }

        /// <summary>
        /// 行とテキストの高さおよび配置情報からテキストのY位置を算出する。
        /// </summary>
        /// <param name="rowHeight">行の高さ。</param>
        /// <param name="rowBaseline">行のベースラインまでの距離。</param>
        /// <param name="textHeight">テキストの高さ。</param>
        /// <param name="textBaseline">
        /// テキストのベースラインまでの距離。
        /// </param>
        /// <param name="vertAlign">テキストの配置。</param>
        /// <returns>テキストのY位置。</returns>
        private static double CalcTextY(
            double rowHeight,
            double rowBaseline,
            double textHeight,
            double textBaseline,
            TextVerticalAlignment vertAlign)
        {
            double y;
            switch (vertAlign)
            {
            case TextVerticalAlignment.Center:
                y = (rowHeight - textHeight) / 2;
                break;

            case TextVerticalAlignment.Baseline:
                y = rowBaseline - textBaseline;
                break;

            case TextVerticalAlignment.Bottom:
                y = rowHeight - textHeight;
                break;

            case TextVerticalAlignment.Top:
            default:
                y = 0;
                break;
            }

            return y;
        }

        /// <summary>
        /// 縁を描画するペンを作成する。
        /// </summary>
        /// <param name="style">スタイル。</param>
        /// <returns>縁を描画するペン。</returns>
        private static Pen MakeEdgePen(TextStylePropertyContainer style)
        {
            return SafeInvoker.Call(
                () =>
                {
                    var dest =
                        new Pen
                        {
                            Brush = style.EdgeColor ?? Brushes.Transparent,
                            LineJoin = style.EdgeType ?? PenLineJoin.Miter,
                            Thickness = style.EdgeWidth ?? 0,
                        };
                    dest.Freeze();
                    return dest;
                });
        }

        /// <summary>
        /// 下線の描画情報を作成する。
        /// </summary>
        /// <param name="style">スタイル。</param>
        /// <returns>下線の描画情報。</returns>
        private static LineRenderingInfo MakeUnderlineRenderingInfo(
            TextStylePropertyContainer style)
        {
            return
                new LineRenderingInfo
                {
                    OffsetRate = style.UnderlineOffset ?? 0,
                    Brush = style.UnderlineColor,
                    Width = style.UnderlineWidth ?? 0,
                    Cap = style.UnderlineCap ?? PenLineCap.Flat,
                    Pattern = style.UnderlinePattern,
                    ZOrder = style.UnderlineZ ?? 0,
                };
        }

        /// <summary>
        /// 取り消し線の描画情報を作成する。
        /// </summary>
        /// <param name="style">スタイル。</param>
        /// <returns>取り消し線の描画情報。</returns>
        private static LineRenderingInfo MakeStrikeRenderingInfo(
            TextStylePropertyContainer style)
        {
            return
                new LineRenderingInfo
                {
                    OffsetRate = style.StrikeOffset ?? 0,
                    Brush = style.StrikeColor,
                    Width = style.StrikeWidth ?? 0,
                    Cap = style.StrikeCap ?? PenLineCap.Flat,
                    Pattern = style.StrikePattern,
                    ZOrder = style.StrikeZ ?? 0,
                };
        }

        /// <summary>
        /// 傍点の描画情報を作成する。
        /// </summary>
        /// <param name="style">スタイル。</param>
        /// <returns>傍点の描画情報。</returns>
        private static DotRenderingInfo MakeDotRenderingInfo(
            TextStylePropertyContainer style)
        {
            return
                new DotRenderingInfo
                {
                    OffsetRate = style.DotOffset ?? 0,
                    Brush = style.DotColor,
                    Width = style.DotWidth ?? 0,
                    ZOrder = style.DotZ ?? 0,
                };
        }

        /// <summary>
        /// 影エフェクトを作成する。
        /// </summary>
        /// <param name="style">スタイル。</param>
        /// <returns>影エフェクト。</returns>
        private static DropShadowEffect MakeShadowEffect(
            TextStylePropertyContainer style)
        {
            return SafeInvoker.Call(
                () =>
                {
                    Color color = style.ShadowColor ?? Colors.Transparent;
                    double opacity = color.ScA;
                    color.ScA = 1;

                    var dest =
                        new DropShadowEffect
                        {
                            Color = color,
                            Direction = style.ShadowDir ?? 0,
                            ShadowDepth = style.ShadowDepth ?? 0,
                            BlurRadius = style.ShadowBlur ?? 0,
                            RenderingBias =
                                style.ShadowQuality ??
                                RenderingBias.Performance,
                            Opacity = opacity,
                        };
                    dest.Freeze();

                    return dest;
                });
        }

        /// <summary>
        /// テキスト行の行揃えを設定する。
        /// </summary>
        /// <param name="info">テキスト行描画情報。</param>
        /// <param name="alignment">行揃えタイプ。</param>
        /// <param name="rowWidth">行の幅。</param>
        /// <param name="textWidth">テキスト全体の幅。</param>
        private static void AdjustTextRowRenderingInfoAlignment(
            TextRowRenderingInfo info,
            TextAlignment alignment,
            double rowWidth,
            double textWidth)
        {
            var pos = info.Position;

            switch (alignment)
            {
            case TextAlignment.Left:
                pos.X = 0;
                break;

            case TextAlignment.Center:
                pos.X = (textWidth - rowWidth) / 2;
                break;

            case TextAlignment.Right:
                pos.X = textWidth - rowWidth;
                break;

            case TextAlignment.Justify:
                if (info.LetterInfos.Count == 1)
                {
                    // 1文字なら中央揃え
                    pos.X = (textWidth - rowWidth) / 2;
                }
                else
                {
                    // 行自体は左揃え
                    pos.X = 0;

                    // 文字位置の拡張割合算出
                    double firstX = info.LetterInfos[0].Position.X;
                    var lastX =
                        info.LetterInfos[info.LetterInfos.Count - 1].Position.X;
                    double newLastX = lastX + (textWidth - rowWidth);
                    double rate = (newLastX - firstX) / (lastX - firstX);

                    // 文字位置拡張
                    info.LetterInfos.ForEach(
                        i =>
                        {
                            var p = i.Position;
                            p.X = (p.X - firstX) * rate + firstX;
                            i.Position = p;
                        });
                }
                break;
            }

            info.Position = pos;
        }
    }
}
