﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Markup;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト描画エフェクト関連の処理を定義する静的クラス。
    /// </summary>
    public static class TextEffectUtil
    {
        /// <summary>
        /// タグ名プロパティのプロパティ名。
        /// </summary>
        public const string TagPropertyName = "tag.name";

        /// <summary>
        /// 既定のフォントファミリ。
        /// </summary>
        public static readonly FontFamily DefaultFontFamily;

        /// <summary>
        /// 既定のフォントタイプフェース。
        /// </summary>
        public static readonly Typeface DefaultFontFace;

        /// <summary>
        /// 既定のフォントサイズ。
        /// </summary>
        public static readonly double DefaultFontSize = 24;

        /// <summary>
        /// FontWeightType.Normal と判断される usWeightClass の最大値。
        /// </summary>
        public static readonly int NormalFontWeightMax;

        /// <summary>
        /// 影のぼかし幅の最大値。
        /// </summary>
        public static readonly double ShadowBlurMax = 50;

        /// <summary>
        /// フォントファミリ名取得に用いられる言語タグ。
        /// </summary>
        private static readonly XmlLanguage JapaneseLang;

        /// <summary>
        /// ラベル名テーブル。
        /// </summary>
        private static readonly Dictionary<string, string> LabelNameTable;

        #region 共通フィールド

        /// <summary>
        /// 位置の値範囲。
        /// </summary>
        private static readonly double[] PositionRange = { -1000000, 1000000 };

        /// <summary>
        /// サイズの値範囲。
        /// </summary>
        private static readonly double[] SizeRange = { 0, 1000000 };

        /// <summary>
        /// 角度の値範囲。
        /// </summary>
        private static readonly double[] AngleRange = { -3600000, 3600000 };

        /// <summary>
        /// Zオーダの値範囲。
        /// </summary>
        private static readonly double[] ZOrderRange = { -10000, 10000 };

        #endregion

        #region 配置用フィールド

        /// <summary>
        /// 横基準を表す列挙値の配列。
        /// </summary>
        private static readonly BaseAlignment[] HorzAlignValues;

        /// <summary>
        /// 横基準を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] HorzAlignTexts;

        /// <summary>
        /// 縦基準を表す列挙値の配列。
        /// </summary>
        private static readonly BaseAlignment[] VertAlignValues;

        /// <summary>
        /// 縦基準を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] VertAlignTexts;

        /// <summary>
        /// 行揃えを表す列挙値の配列。
        /// </summary>
        private static readonly TextAlignment[] RowAlignValues;

        /// <summary>
        /// 行揃えを表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] RowAlignTexts;

        /// <summary>
        /// 行高の揃え方を表す列挙値の配列。
        /// </summary>
        private static readonly LineArrangeType[] RowHeightArrangeValues;

        /// <summary>
        /// 行高の揃え方を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] RowHeightArrangeTexts;

        /// <summary>
        /// 行間の値範囲。
        /// </summary>
        private static readonly double[] RowSpanRange = { -1000000, 1000000 };

        #endregion

        #region スタイル用フィールド

        /// <summary>
        /// 行内位置を表す列挙値の配列。
        /// </summary>
        private static readonly TextVerticalAlignment[] TextVertAlignValues;

        /// <summary>
        /// 行内位置を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] TextVertAlignTexts;

        /// <summary>
        /// スケールの値範囲。
        /// </summary>
        private static readonly double[] ScaleRange = { 0, 100000 };

        /// <summary>
        /// マージンの値範囲。
        /// </summary>
        private static readonly double[] MarginRange = SizeRange;

        /// <summary>
        /// 共通のフォントファミリ名配列。
        /// </summary>
        private static readonly FontFamilyNameCollection FontFamilyNames;

        /// <summary>
        /// 既定のフォントファミリ名。
        /// </summary>
        private static readonly string DefaultFontFamilyName;

        /// <summary>
        /// フォントサイズの値範囲。
        /// </summary>
        private static readonly double[] FontSizeRange = { 0, 1000 };

        /// <summary>
        /// フォントの太さを表す列挙値の配列。
        /// </summary>
        private static readonly FontWeightType[] FontWeightValues;

        /// <summary>
        /// フォントの太さを表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] FontWeightTexts;

        /// <summary>
        /// フォントスタイルを表す列挙値の配列。
        /// </summary>
        private static readonly FontStyleType[] FontStyleValues;

        /// <summary>
        /// フォントスタイルを表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] FontStyleTexts;

        /// <summary>
        /// 縁幅の値範囲。
        /// </summary>
        private static readonly double[] EdgeWidthRange = { 0, 1000 };

        /// <summary>
        /// 縁形状を表す列挙値の配列。
        /// </summary>
        private static readonly PenLineJoin[] EdgeTypeValues;

        /// <summary>
        /// 縁形状を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] EdgeTypeTexts;

        /// <summary>
        /// テキスト装飾のオフセットの値範囲。
        /// </summary>
        private static readonly double[] DecorationOffsetRange =
            { -1000000, 1000000 };

        /// <summary>
        /// テキスト装飾の幅の値範囲。
        /// </summary>
        private static readonly double[] DecorationWidthRange = { 0, 10000 };

        /// <summary>
        /// 線の端形状を表す列挙値の配列。
        /// </summary>
        private static readonly PenLineCap[] LineCapValues;

        /// <summary>
        /// 線の端形状を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] LineCapTexts;

        /// <summary>
        /// 破線パターンの各値範囲。
        /// </summary>
        private static readonly double[] LinePatternRange = { 0, 10000 };

        /// <summary>
        /// 既定の破線パターン。
        /// </summary>
        private static readonly double[] DefaultLinePattern = { 1, 0 };

        /// <summary>
        /// 既定の影色ブラシ。
        /// </summary>
        private static readonly SolidColorBrush DefaultShadowBrush;

        /// <summary>
        /// 既定の影の方向。
        /// </summary>
        private static readonly double DefaultShadowDir = 315;

        /// <summary>
        /// 影の距離の値範囲。
        /// </summary>
        private static readonly double[] ShadowDepthRange = { 0, 1000000 };

        /// <summary>
        /// 既定の影の距離。
        /// </summary>
        private static readonly double DefaultShadowDepth = 5;

        /// <summary>
        /// 影のぼかし幅の値範囲。
        /// </summary>
        private static readonly double[] ShadowBlurRange = { 0, ShadowBlurMax };

        /// <summary>
        /// 既定の影のぼかし幅。
        /// </summary>
        private static readonly double DefaultShadowBlur = 0;

        /// <summary>
        /// 影の品質を表す列挙値の配列。
        /// </summary>
        private static readonly RenderingBias[] ShadowQualityValues;

        /// <summary>
        /// 影の品質を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] ShadowQualityTexts;

        #endregion

        #region その他フィールド

        /// <summary>
        /// 描画順序の値範囲。
        /// </summary>
        private static readonly double[] OrderRange = ZOrderRange;

        /// <summary>
        /// 字送り間隔とフェードイン時間の値範囲。
        /// </summary>
        private static readonly double[] SpeakSpanRange = { 0, 3600000 };

        /// <summary>
        /// 字送りスキップ数の値範囲。
        /// </summary>
        private static readonly double[] SpeakSkipRange = { 0, 10000 };

        /// <summary>
        /// ブレンド種別を表す列挙値の配列。
        /// </summary>
        private static readonly BlendType[] BlendTypeValues;

        /// <summary>
        /// ブレンド種別を表す列挙値の文字列表現配列。
        /// </summary>
        private static readonly string[] BlendTypeTexts;

        #endregion

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static TextEffectUtil()
        {
            NormalFontWeightMax = (
                FontWeights.Normal.ToOpenTypeWeight() +
                FontWeights.Bold.ToOpenTypeWeight()) / 2;

            JapaneseLang = XmlLanguage.GetLanguage("ja-JP");

            // ラベル名テーブル
            LabelNameTable =
                new Dictionary<string, string>()
                {
                    // Text
                    { "text",                       "表示文字列"        },

                    // Order
                    { "order",                      "描画順序"          },

                    // Arrange
                    { "arrange.position",           "基準位置"          },
                    { "arrange.halign",             "横基準"            },
                    { "arrange.valign",             "縦基準"            },
                    { "arrange.size.min",           "最小サイズ"        },
                    { "arrange.size.max",           "最大サイズ"        },
                    { "arrange.rotate.center",      "回転中心位置"      },
                    { "arrange.rotate.angle",       "回転角度"          },
                    { "arrange.row.align",          "行揃え"            },
                    { "arrange.row.size.min",       "最小サイズ"        },
                    { "arrange.row.size.max",       "最大サイズ"        },
                    { "arrange.row.htype",          "行高タイプ"        },
                    { "arrange.row.span",           "行間"              },

                    // Option
                    { "option.variable",            "変数"              },
                    { "option.variable.nest",       "変数ネスト"        },
                    { "option.tag",                 "タグ"              },
                    { "option.entity",              "エンティティ"      },

                    // Style
                    { "valign",                     "行内位置"          },
                    { "scale.x",                    "横"                },
                    { "scale.y",                    "縦"                },
                    { "margin.top",                 "上"                },
                    { "margin.bottom",              "下"                },
                    { "margin.left",                "左"                },
                    { "margin.right",               "右"                },
                    { "font.family",                "ファミリ"          },
                    { "font.size",                  "サイズ"            },
                    { "font.weight",                "太さ"              },
                    { "font.style",                 "スタイル"          },
                    { "fill.color",                 "塗り色"            },
                    { "edge.color",                 "色"                },
                    { "edge.width",                 "幅"                },
                    { "edge.type",                  "形状"              },
                    { "underline.color",            "色"                },
                    { "underline.width",            "幅"                },
                    { "underline.cap",              "端形状"            },
                    { "underline.pattern",          "破線パターン"      },
                    { "underline.offset",           "オフセット"        },
                    { "underline.z",                "Z位置"             },
                    { "strike.color",               "色"                },
                    { "strike.width",               "幅"                },
                    { "strike.cap",                 "端形状"            },
                    { "strike.pattern",             "破線パターン"      },
                    { "strike.offset",              "オフセット"        },
                    { "strike.z",                   "Z位置"             },
                    { "dot.color",                  "色"                },
                    { "dot.width",                  "幅"                },
                    { "dot.offset",                 "オフセット"        },
                    { "dot.z",                      "Z位置"             },
                    { "shadow.color",               "色"                },
                    { "shadow.dir",                 "方向"              },
                    { "shadow.depth",               "距離"              },
                    { "shadow.blur",                "ぼかし幅"          },
                    { "shadow.quality",             "品質"              },

                    // Speak
                    { "speak.letter",               "文字間隔"          },
                    { "speak.row",                 "改行間隔"          },
                    { "speak.fadein",               "フェードイン"      },
                    { "speak.skip.row",            "スキップ行数"      },
                    { "speak.skip.letter",          "スキップ文字数"    },
                    { "speak.skip.blank",           "余白スキップ"      },

                    // Post
                    { "post.alpha",                 "不透明度"          },
                    { "post.brightness",            "明度"              },
                    { "post.saturation",            "彩度"              },

                    // Blend
                    { "blend",                      "ブレンド"          },

                    // FormattedTexts
                    { "texts",                      "テキスト"          },

                    // Variable
                    { "variables",                  "変数"              },

                    // Tag
                    { "tags",                       "スタイルタグ"      },
                };

            // 横基準
            HorzAlignValues =
                new BaseAlignment[]
                {
                    BaseAlignment.Near,
                    BaseAlignment.Center,
                    BaseAlignment.Far,
                };
            HorzAlignTexts =
                new string[]
                {
                    "左",
                    "中央",
                    "右",
                };

            // 縦基準
            VertAlignValues = HorzAlignValues;
            VertAlignTexts =
                new string[]
                {
                    "上",
                    "中央",
                    "下",
                };

            // 行揃え
            RowAlignValues =
                new TextAlignment[]
                {
                    TextAlignment.Left,
                    TextAlignment.Center,
                    TextAlignment.Right,
                    TextAlignment.Justify,
                };
            RowAlignTexts =
                new string[]
                {
                    "左揃え",
                    "中央揃え",
                    "右揃え",
                    "両端揃え",
                };

            // 行高タイプ
            Util.GetEnumDescriptions(
                out RowHeightArrangeValues,
                out RowHeightArrangeTexts);

            // 行内位置
            Util.GetEnumDescriptions(
                out TextVertAlignValues,
                out TextVertAlignTexts);

            // フォントファミリ名
            FontFamilyNames = new FontFamilyNameCollection();
            string[] familyNames =
                new string[]
                {
                    "ＭＳ Ｐゴシック",
                    "MS PGothic",
                    "MS UI Gothic",
                    "ＭＳ ゴシック",
                    "MS Gothic",
                    "Tahoma",
                    "Microsoft Sans Serif",
                    FontFamilyNames[0],
                };
            DefaultFontFamilyName =
                Array.Find(familyNames, fn => FontFamilyNames.Contains(fn));

            // フォントファミリ名から各種既定値を作成
            DefaultFontFamily = new FontFamily(DefaultFontFamilyName);
            DefaultFontFace = new Typeface(
                DefaultFontFamily,
                FontStyles.Normal,
                FontWeights.Normal,
                FontStretches.Normal);

            // フォントの太さ
            Util.GetEnumDescriptions(
                out FontWeightValues,
                out FontWeightTexts);

            // フォントスタイル
            Util.GetEnumDescriptions(
                out FontStyleValues,
                out FontStyleTexts);

            // 縁形状
            EdgeTypeValues =
                new PenLineJoin[]
                {
                    PenLineJoin.Miter,
                    PenLineJoin.Bevel,
                    PenLineJoin.Round,
                };
            EdgeTypeTexts =
                new string[]
                {
                    "鋭角(miter)",
                    "面取り(bevel)",
                    "丸角(round)",
                };

            // 線の端形状
            LineCapValues =
                new PenLineCap[]
                {
                    PenLineCap.Flat,
                    PenLineCap.Square,
                    PenLineCap.Triangle,
                    PenLineCap.Round,
                };
            LineCapTexts =
                new string[]
                {
                    "なし(flat)",
                    "四角(square)",
                    "三角(triangle)",
                    "半円(circle)",
                };

            // 影色
            var shadowBrush = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
            shadowBrush.Freeze();
            DefaultShadowBrush = shadowBrush;

            // 影品質
            ShadowQualityValues =
                new RenderingBias[]
                {
                    RenderingBias.Performance,
                    RenderingBias.Quality,
                };
            ShadowQualityTexts =
                new string[]
                {
                    "標準",
                    "高品質",
                };

            // ブレンド種別
            Util.GetEnumDescriptions(
                out BlendTypeValues,
                out BlendTypeTexts);
        }

        #region プロパティ作成

        /// <summary>
        /// 指定したカテゴリのプロパティ配列を作成する。
        /// </summary>
        /// <param name="category">カテゴリ。</param>
        /// <returns>プロパティ配列。</returns>
        public static PropertyBase[] CreateProperties(
            TextEffectCategory category)
        {
            switch (category)
            {
            case TextEffectCategory.Text:
                return new PropertyBase[]
                    {
                        new KeyFrameStringProperty("text", string.Empty),
                    };

            case TextEffectCategory.Order:
                return new PropertyBase[]
                    {
                        new SwitchableNumberProperty(
                            "order",
                            0,
                            true,
                            OrderRange[0],
                            OrderRange[1]),
                    };

            case TextEffectCategory.Arrange:
                return CreateArrangeProperties(2000, 2000);

            case TextEffectCategory.Option:
                return new PropertyBase[]
                    {
                        new BooleanProperty("option.variable", true),
                        new BooleanProperty("option.variable.nest", true),
                        new BooleanProperty("option.tag", true),
                        new BooleanProperty("option.entity", true),
                    };

            case TextEffectCategory.Style:
                return CreateStyleProperties(true);

            case TextEffectCategory.Speak:
                return CreateSpeakProperties(true);

            case TextEffectCategory.Post:
                return new PropertyBase[]
                    {
                        new SwitchableNumberProperty(
                            "post.alpha",
                            100,
                            true,
                            0,
                            100),
                        new SwitchableNumberProperty(
                            "post.brightness",
                            100,
                            true,
                            0,
                            100),
                        new SwitchableNumberProperty(
                            "post.saturation",
                            100,
                            true,
                            0,
                            100),
                    };

            case TextEffectCategory.Blend:
                return new PropertyBase[]
                    {
                        new SwitchableValueProperty<BlendType>(
                            "blend",
                            BlendType.Normal,
                            true),
                    };

            case TextEffectCategory.Delegate:
                return new PropertyBase[]
                    {
                        new TextEffectDelegateProperty("delegate"),
                    };

            case TextEffectCategory.FormattedTexts:
                return CreateFormattedTextProperties(2000, 2000);

            case TextEffectCategory.Variables:
                return new PropertyBase[]
                    {
                        new AddableVariableProperty("variables"),
                    };

            case TextEffectCategory.Tags:
                return new PropertyBase[]
                    {
                        new AddableTextStyleTagProperty("tags"),
                    };
            }

            throw new InvalidEnumArgumentException(
                "category",
                (int)category,
                typeof(TextEffectCategory));
        }

        /// <summary>
        /// TextEffectCategory.Arrange のプロパティ配列を作成する。
        /// </summary>
        /// <param name="width">幅の基準値。</param>
        /// <param name="height">高さの基準値。</param>
        /// <returns>TextEffectCategory.Arrange のプロパティ配列。</returns>
        public static SwitchablePropertyBase[] CreateArrangeProperties(
            double width,
            double height)
        {
            return new SwitchablePropertyBase[]
                {
                    new SwitchableNumberArrayProperty(
                        "arrange.position",
                        new double[] { 0, 0 },
                        true,
                        PositionRange[0],
                        PositionRange[1]),
                    new SwitchableValueProperty<BaseAlignment>(
                        "arrange.halign",
                        BaseAlignment.Near,
                        true),
                    new SwitchableValueProperty<BaseAlignment>(
                        "arrange.valign",
                        BaseAlignment.Near,
                        true),
                    new SwitchableNumberArrayProperty(
                        "arrange.size.min",
                        new double[] { 0, 0 },
                        true,
                        SizeRange[0],
                        SizeRange[1]),
                    new SwitchableNumberArrayProperty(
                        "arrange.size.max",
                        new double[] { width, height },
                        true,
                        SizeRange[0],
                        SizeRange[1]),
                    new SwitchableNumberArrayProperty(
                        "arrange.rotate.center",
                        new double[] { 0, 0 },
                        true,
                        PositionRange[0],
                        PositionRange[1]),
                    new SwitchableNumberProperty(
                        "arrange.rotate.angle",
                        0,
                        true,
                        AngleRange[0],
                        AngleRange[1]),
                    new SwitchableValueProperty<TextAlignment>(
                        "arrange.row.align",
                        TextAlignment.Left,
                        true),
                    new SwitchableNumberArrayProperty(
                        "arrange.row.size.min",
                        new double[] { 0, 0 },
                        true,
                        SizeRange[0],
                        SizeRange[1]),
                    new SwitchableNumberArrayProperty(
                        "arrange.row.size.max",
                        new double[] { width, height },
                        true,
                        SizeRange[0],
                        SizeRange[1]),
                    new SwitchableValueProperty<LineArrangeType>(
                        "arrange.row.htype",
                        Util.GetEnumDefaultValue<LineArrangeType>(),
                        true),
                    new SwitchableNumberProperty(
                        "arrange.row.span",
                        100,
                        true,
                        RowSpanRange[0],
                        RowSpanRange[1]),
                };
        }

        /// <summary>
        /// TextEffectCategory.Style のプロパティ配列を作成する。
        /// </summary>
        /// <param name="valid">有効状態フラグの初期値。</param>
        /// <returns>TextEffectCategory.Style のプロパティ配列。</returns>
        public static SwitchablePropertyBase[] CreateStyleProperties(bool valid)
        {
            return new SwitchablePropertyBase[]
                {
                    new SwitchableValueProperty<TextVerticalAlignment>(
                        "valign",
                        Util.GetEnumDefaultValue<TextVerticalAlignment>(),
                        valid),
                    new SwitchableNumberProperty(
                        "scale.x",
                        100,
                        valid,
                        ScaleRange[0],
                        ScaleRange[1]),
                    new SwitchableNumberProperty(
                        "scale.y",
                        100,
                        valid,
                        ScaleRange[0],
                        ScaleRange[1]),
                    new SwitchableNumberProperty(
                        "margin.top",
                        0,
                        valid,
                        MarginRange[0],
                        MarginRange[1]),
                    new SwitchableNumberProperty(
                        "margin.bottom",
                        0,
                        valid,
                        MarginRange[0],
                        MarginRange[1]),
                    new SwitchableNumberProperty(
                        "margin.left",
                        0,
                        valid,
                        MarginRange[0],
                        MarginRange[1]),
                    new SwitchableNumberProperty(
                        "margin.right",
                        0,
                        valid,
                        MarginRange[0],
                        MarginRange[1]),
                    new SwitchableFontFamilyNameProperty(
                        "font.family",
                        DefaultFontFamilyName,
                        valid),
                    new SwitchableNumberProperty(
                        "font.size",
                        DefaultFontSize,
                        valid,
                        FontSizeRange[0],
                        FontSizeRange[1]),
                    new SwitchableValueProperty<FontWeightType>(
                        "font.weight",
                        Util.GetEnumDefaultValue<FontWeightType>(),
                        valid),
                    new SwitchableValueProperty<FontStyleType>(
                        "font.style",
                        Util.GetEnumDefaultValue<FontStyleType>(),
                        valid),
                    new SwitchableBrushProperty(
                        "fill.color",
                        Brushes.Black,
                        valid),
                    new SwitchableBrushProperty(
                        "edge.color",
                        Brushes.White,
                        valid),
                    new SwitchableNumberProperty(
                        "edge.width",
                        0,
                        valid,
                        EdgeWidthRange[0],
                        EdgeWidthRange[1]),
                    new SwitchableValueProperty<PenLineJoin>(
                        "edge.type",
                        PenLineJoin.Miter,
                        valid),
                    new SwitchableBrushProperty(
                        "underline.color",
                        Brushes.Black,
                        valid),
                    new SwitchableNumberProperty(
                        "underline.width",
                        0,
                        valid,
                        DecorationWidthRange[0],
                        DecorationWidthRange[1]),
                    new SwitchableValueProperty<PenLineCap>(
                        "underline.cap",
                        PenLineCap.Flat,
                        valid),
                    new SwitchableNumberArrayProperty(
                        "underline.pattern",
                        new double[] { 1, 0 },
                        valid,
                        LinePatternRange[0],
                        LinePatternRange[1]),
                    new SwitchableNumberProperty(
                        "underline.offset",
                        0,
                        valid,
                        DecorationOffsetRange[0],
                        DecorationOffsetRange[1]),
                    new SwitchableNumberProperty(
                        "underline.z",
                        0,
                        valid,
                        ZOrderRange[0],
                        ZOrderRange[1]),
                    new SwitchableBrushProperty(
                        "strike.color",
                        Brushes.Black,
                        valid),
                    new SwitchableNumberProperty(
                        "strike.width",
                        0,
                        valid,
                        DecorationWidthRange[0],
                        DecorationWidthRange[1]),
                    new SwitchableValueProperty<PenLineCap>(
                        "strike.cap",
                        PenLineCap.Flat,
                        valid),
                    new SwitchableNumberArrayProperty(
                        "strike.pattern",
                        new double[] { 1, 0 },
                        valid,
                        LinePatternRange[0],
                        LinePatternRange[1]),
                    new SwitchableNumberProperty(
                        "strike.offset",
                        0,
                        valid,
                        DecorationOffsetRange[0],
                        DecorationOffsetRange[1]),
                    new SwitchableNumberProperty(
                        "strike.z",
                        0,
                        valid,
                        ZOrderRange[0],
                        ZOrderRange[1]),
                    new SwitchableBrushProperty(
                        "dot.color",
                        Brushes.Black,
                        valid),
                    new SwitchableNumberProperty(
                        "dot.width",
                        0,
                        valid,
                        DecorationWidthRange[0],
                        DecorationWidthRange[1]),
                    new SwitchableNumberProperty(
                        "dot.offset",
                        0,
                        valid,
                        DecorationOffsetRange[0],
                        DecorationOffsetRange[1]),
                    new SwitchableNumberProperty(
                        "dot.z",
                        0,
                        valid,
                        ZOrderRange[0],
                        ZOrderRange[1]),
                    new SwitchableBrushProperty(
                        "shadow.color",
                        DefaultShadowBrush,
                        valid),
                    new SwitchableNumberProperty(
                        "shadow.dir",
                        DefaultShadowDir,
                        valid,
                        AngleRange[0],
                        AngleRange[1]),
                    new SwitchableNumberProperty(
                        "shadow.depth",
                        DefaultShadowDepth,
                        valid,
                        ShadowDepthRange[0],
                        ShadowDepthRange[1]),
                    new SwitchableNumberProperty(
                        "shadow.blur",
                        DefaultShadowBlur,
                        valid,
                        ShadowBlurRange[0],
                        ShadowBlurRange[1]),
                    new SwitchableValueProperty<RenderingBias>(
                        "shadow.quality",
                        RenderingBias.Performance,
                        valid),
                };
        }

        /// <summary>
        /// TextEffectCategory.Speak のプロパティ配列を作成する。
        /// </summary>
        /// <param name="valid">有効状態フラグの初期値。</param>
        /// <returns>TextEffectCategory.Speak のプロパティ配列。</returns>
        public static SwitchablePropertyBase[] CreateSpeakProperties(bool valid)
        {
            return new SwitchablePropertyBase[]
                {
                    new SwitchableNumberProperty(
                        "speak.letter",
                        0,
                        valid,
                        SpeakSpanRange[0],
                        SpeakSpanRange[1]),
                    new SwitchableNumberProperty(
                        "speak.row",
                        0,
                        valid,
                        SpeakSpanRange[0],
                        SpeakSpanRange[1]),
                    new SwitchableNumberProperty(
                        "speak.fadein",
                        0,
                        valid,
                        SpeakSpanRange[0],
                        SpeakSpanRange[1]),
                    new SwitchableNumberProperty(
                        "speak.skip.row",
                        0,
                        valid,
                        SpeakSkipRange[0],
                        SpeakSkipRange[1]),
                    new SwitchableNumberProperty(
                        "speak.skip.letter",
                        0,
                        valid,
                        SpeakSkipRange[0],
                        SpeakSkipRange[1]),
                    new SwitchableValueProperty<bool>(
                        "speak.skip.blank",
                        true,
                        valid),
                };
        }

        /// <summary>
        /// TextEffectCategory.Arrange のプロパティ配列を作成する。
        /// </summary>
        /// <param name="width">幅の基準値。</param>
        /// <param name="height">高さの基準値。</param>
        /// <returns>TextEffectCategory.Arrange のプロパティ配列。</returns>
        public static AddableFormattedTextProperty[]
            CreateFormattedTextProperties(
                double width,
                double height)
        {
            return new AddableFormattedTextProperty[]
                {
                    new AddableFormattedTextProperty("texts", width, height),
                };
        }

        #endregion

        #region プロパティコントロール配列作成

        /// <summary>
        /// 指定したカテゴリのプロパティコントロール配列を作成する。
        /// </summary>
        /// <param name="category">カテゴリ。</param>
        /// <returns>プロパティコントロール配列。</returns>
        public static PropertyEditControlBase[] CreatePropertyControls(
            TextEffectCategory category)
        {
            PropertyEditControlBase[] ctrls = null;

            // コントロール配列作成
            switch (category)
            {
            case TextEffectCategory.Text:
                ctrls = new PropertyEditControlBase[]
                    {
                        new TextPropertyEditControl<KeyFrameStringProperty>(
                            "text",
                            true),
                    };
                break;

            case TextEffectCategory.Order:
                ctrls = new PropertyEditControlBase[]
                    {
                        CreateNumberPropertyControl("order", 1),
                    };
                break;

            case TextEffectCategory.Arrange:
                ctrls = new PropertyEditControlBase[]
                    {
                        new PropertyNestBeginControl("全体配置"),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.position",
                                1,
                                "px",
                                ",",
                                false,
                                false),
                            CreateValuePropertyControl(
                                "arrange.halign",
                                HorzAlignValues,
                                HorzAlignTexts),
                            CreateValuePropertyControl(
                                "arrange.valign",
                                VertAlignValues,
                                VertAlignTexts),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.size.min",
                                1,
                                "px",
                                "×",
                                false,
                                false),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.size.max",
                                1,
                                "px",
                                "×",
                                false,
                                false),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.rotate.center",
                                1,
                                "px",
                                ",",
                                false,
                                false),
                            CreateNumberPropertyControl(
                                "arrange.rotate.angle",
                                1,
                                "°"),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("行配置"),
                            CreateValuePropertyControl(
                                "arrange.row.align",
                                RowAlignValues,
                                RowAlignTexts),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.row.size.min",
                                1,
                                "px",
                                "×",
                                false,
                                false),
                            new SwitchableNumberArrayPropertyEditControl(
                                "arrange.row.size.max",
                                1,
                                "px",
                                "×",
                                false,
                                false),
                            CreateValuePropertyControl(
                                "arrange.row.htype",
                                RowHeightArrangeValues,
                                RowHeightArrangeTexts),
                            CreatePercentageNumberPropertyControl(
                                "arrange.row.span"),
                        new PropertyNestEndControl(),
                    };
                break;

            case TextEffectCategory.Option:
                ctrls = new PropertyEditControlBase[]
                    {
                        new BooleanPropertyEditControl("option.variable"),
                        new BooleanPropertyEditControl("option.variable.nest"),
                        new BooleanPropertyEditControl("option.tag"),
                        new BooleanPropertyEditControl("option.entity"),
                    };
                break;

            case TextEffectCategory.Style:
                ctrls = new PropertyEditControlBase[]
                    {
                        new PropertyNestBeginControl("文字配置"),
                            CreateValuePropertyControl(
                                "valign",
                                TextVertAlignValues,
                                TextVertAlignTexts),
                            new PropertyNestBeginControl("スケール"),
                                CreatePercentageNumberPropertyControl(
                                    "scale.x"),
                                CreatePercentageNumberPropertyControl(
                                    "scale.y"),
                            new PropertyNestEndControl(),
                            new PropertyNestBeginControl("マージン"),
                                CreatePixelNumberPropertyControl(
                                    "margin.top"),
                                CreatePixelNumberPropertyControl(
                                    "margin.bottom"),
                                CreatePixelNumberPropertyControl(
                                    "margin.left"),
                                CreatePixelNumberPropertyControl(
                                    "margin.right"),
                            new PropertyNestEndControl(),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("フォント"),
                            new SwitchableFontFamilyNamePropertyEditControl(
                                "font.family",
                                false,
                                false,
                                FontFamilyNames),
                            CreatePixelNumberPropertyControl("font.size"),
                            CreateValuePropertyControl(
                                "font.weight",
                                FontWeightValues,
                                FontWeightTexts),
                            CreateValuePropertyControl(
                                "font.style",
                                FontStyleValues,
                                FontStyleTexts),
                        new PropertyNestEndControl(),
                        new SwitchableBrushPropertyEditControl(
                            "fill.color",
                            false,
                            false,
                            EditBrushTypes.All),
                        new PropertyNestBeginControl("縁"),
                            new SwitchableBrushPropertyEditControl(
                                "edge.color",
                                false,
                                false,
                                EditBrushTypes.All),
                            CreatePixelNumberPropertyControl("edge.width"),
                            CreateValuePropertyControl(
                                "edge.type",
                                EdgeTypeValues,
                                EdgeTypeTexts),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("下線"),
                            new SwitchableBrushPropertyEditControl(
                                "underline.color",
                                false,
                                false,
                                EditBrushTypes.All),
                            CreatePixelNumberPropertyControl(
                                "underline.width"),
                            CreateValuePropertyControl(
                                "underline.cap",
                                LineCapValues,
                                LineCapTexts),
                            new SwitchableNumberListPropertyEditControl(
                                "underline.pattern",
                                1,
                                false,
                                false),
                            CreatePercentageNumberPropertyControl(
                                "underline.offset"),
                            CreateNumberPropertyControl("underline.z", 1),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("取り消し線"),
                            new SwitchableBrushPropertyEditControl(
                                "strike.color",
                                false,
                                false,
                                EditBrushTypes.All),
                            CreatePixelNumberPropertyControl(
                                "strike.width"),
                            CreateValuePropertyControl(
                                "strike.cap",
                                LineCapValues,
                                LineCapTexts),
                            new SwitchableNumberListPropertyEditControl(
                                "strike.pattern",
                                1,
                                false,
                                false),
                            CreatePercentageNumberPropertyControl(
                                "strike.offset"),
                            CreateNumberPropertyControl("strike.z", 1),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("傍点"),
                            new SwitchableBrushPropertyEditControl(
                                "dot.color",
                                false,
                                false,
                                EditBrushTypes.All),
                            CreatePixelNumberPropertyControl("dot.width"),
                            CreatePercentageNumberPropertyControl(
                                "dot.offset"),
                            CreateNumberPropertyControl("dot.z", 1),
                        new PropertyNestEndControl(),
                        new PropertyNestBeginControl("影"),
                            new SwitchableBrushPropertyEditControl(
                                "shadow.color",
                                false,
                                false,
                                EditBrushTypes.SolidColor),
                            CreateNumberPropertyControl(
                                "shadow.dir",
                                1,
                                "°"),
                            CreatePixelNumberPropertyControl(
                                "shadow.depth"),
                            CreatePixelNumberPropertyControl(
                                "shadow.blur"),
                            CreateValuePropertyControl(
                                "shadow.quality",
                                ShadowQualityValues,
                                ShadowQualityTexts),
                        new PropertyNestEndControl(),
                    };
                break;

            case TextEffectCategory.Speak:
                ctrls = new PropertyEditControlBase[]
                    {
                        CreateNumberPropertyControl(
                            "speak.letter",
                            1,
                            "msec"),
                        CreateNumberPropertyControl(
                            "speak.row",
                            1,
                            "msec"),
                        CreateNumberPropertyControl(
                            "speak.fadein",
                            1,
                            "msec"),
                        CreateNumberPropertyControl(
                            "speak.skip.row",
                            1,
                            "行",
                            0),
                        CreateNumberPropertyControl(
                            "speak.skip.letter",
                            1,
                            "文字",
                            0),
                        CreateValuePropertyControl(
                            "speak.skip.blank",
                            new bool[] { false, true },
                            new string[] { "無効", "有効" }),
                    };
                break;

            case TextEffectCategory.Post:
                ctrls = new PropertyEditControlBase[]
                    {
                        CreatePercentageNumberPropertyControl(
                            "post.alpha"),
                        CreatePercentageNumberPropertyControl(
                            "post.brightness"),
                        CreatePercentageNumberPropertyControl(
                            "post.saturation"),
                    };
                break;

            case TextEffectCategory.Blend:
                ctrls = new PropertyEditControlBase[]
                    {
                        CreateValuePropertyControl(
                            "blend",
                            BlendTypeValues,
                            BlendTypeTexts),
                    };
                break;

            case TextEffectCategory.Delegate:
                // コントロールなし
                ctrls = new PropertyEditControlBase[0];
                break;

            case TextEffectCategory.FormattedTexts:
                ctrls = new PropertyEditControlBase[]
                    {
                        new AddablePropertyEditControl(
                            "texts",
                            typeof(AddableFormattedTextProperty)),
                    };
                break;

            case TextEffectCategory.Variables:
                ctrls = new PropertyEditControlBase[]
                    {
                        new AddablePropertyEditControl(
                            "variables",
                            typeof(AddableVariableProperty)),
                    };
                break;

            case TextEffectCategory.Tags:
                ctrls = new PropertyEditControlBase[]
                    {
                        new AddablePropertyEditControl(
                            "tags",
                            typeof(AddableTextStyleTagProperty)),
                    };
                break;
            }
            if (ctrls == null)
            {
                throw new InvalidEnumArgumentException(
                    "category",
                    (int)category,
                    typeof(TextEffectCategory));
            }

            // ラベル文字列設定
            string label;
            foreach (var c in ctrls)
            {
                if (LabelNameTable.TryGetValue(c.PropertyName, out label))
                {
                    c.LabelName = label;
                }
            }

            return ctrls;
        }

        /// <summary>
        /// TextEffectCategory.Style のプロパティコントロール配列を作成する。
        /// </summary>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <returns>
        /// TextEffectCategory.Style のプロパティコントロール配列。
        /// </returns>
        public static PropertyEditControlBase[] CreateStylePropertyControls(
            bool switchable)
        {
            return ChangeControlSwitchables(
                CreatePropertyControls(TextEffectCategory.Style),
                switchable);
        }

        /// <summary>
        /// TextEffectCategory.Speak のプロパティコントロール配列を作成する。
        /// </summary>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <returns>
        /// TextEffectCategory.Speak のプロパティコントロール配列。
        /// </returns>
        public static PropertyEditControlBase[] CreateSpeakPropertyControls(
            bool switchable)
        {
            return ChangeControlSwitchables(
                CreatePropertyControls(TextEffectCategory.Speak),
                switchable);
        }

        /// <summary>
        /// ネスト開始コントロール単体を含むコントロール配列を作成する。
        /// </summary>
        /// <param name="name">ラベル文字列。</param>
        /// <returns>
        /// ネスト開始コントロール単体を含むコントロール配列。
        /// </returns>
        public static PropertyEditControlBase[] CreateNestBeginControls(
            string name)
        {
            return new PropertyEditControlBase[]
                {
                    new PropertyNestBeginControl(name)
                };
        }

        /// <summary>
        /// ネスト終端コントロール単体を含むコントロール配列を作成する。
        /// </summary>
        /// <returns>
        /// ネスト終端コントロール単体を含むコントロール配列。
        /// </returns>
        public static PropertyEditControlBase[] CreateNestEndControls()
        {
            return new PropertyEditControlBase[]
                {
                    new PropertyNestEndControl()
                };
        }

        /// <summary>
        /// 有効状態切り替え不可の数値プロパティコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">インクリメント幅。</param>
        /// <returns>数値プロパティコントロール。</returns>
        public static SwitchableNumberPropertyEditControl
            CreateNumberPropertyControl(
                string name,
                double increment)
        {
            return CreateNumberPropertyControl(name, increment, null);
        }

        /// <summary>
        /// 有効状態切り替え不可の数値プロパティコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">インクリメント幅。</param>
        /// <param name="unit">単位文字列。</param>
        /// <returns>数値プロパティコントロール。</returns>
        public static SwitchableNumberPropertyEditControl
            CreateNumberPropertyControl(
                string name,
                double increment,
                string unit)
        {
            return CreateNumberPropertyControl(name, increment, unit, -1);
        }

        /// <summary>
        /// 有効状態切り替え不可の数値プロパティコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">インクリメント幅。</param>
        /// <param name="unit">単位文字列。</param>
        /// <param name="decimalPlaces">小数点以下桁数。</param>
        /// <returns>数値プロパティコントロール。</returns>
        public static SwitchableNumberPropertyEditControl
            CreateNumberPropertyControl(
                string name,
                double increment,
                string unit,
                int decimalPlaces)
        {
            return new SwitchableNumberPropertyEditControl(
                name,
                increment,
                unit,
                decimalPlaces,
                false,
                false);
        }

        /// <summary>
        /// 有効状態切り替え不可のpx指定数値プロパティコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <returns>数値プロパティコントロール。</returns>
        public static SwitchableNumberPropertyEditControl
            CreatePixelNumberPropertyControl(string name)
        {
            return CreateNumberPropertyControl(name, 1, "px");
        }

        /// <summary>
        /// 有効状態切り替え不可の％指定数値プロパティコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <returns>数値プロパティコントロール。</returns>
        public static SwitchableNumberPropertyEditControl
            CreatePercentageNumberPropertyControl(string name)
        {
            return CreateNumberPropertyControl(name, 1, "%");
        }

        /// <summary>
        /// 有効状態切り替え不可のデータ選択プロパティコントロールを作成する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="values">データ配列。</param>
        /// <param name="texts">文字列表現配列。</param>
        /// <returns>データ選択プロパティコントロール。</returns>
        public static SwitchableValuePropertyEditControl<T>
            CreateValuePropertyControl<T>(
                string name,
                T[] values,
                string[] texts)
        {
            return new SwitchableValuePropertyEditControl<T>(
                name,
                false,
                false,
                false,
                values,
                Util.CreateValueTextConverter(values, texts));
        }

        /// <summary>
        /// プロパティコントロール配列の有効状態切り替え可能フラグを変更する。
        /// </summary>
        /// <param name="controls">プロパティコントロール配列。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <returns>controls 自身。</returns>
        private static PropertyEditControlBase[] ChangeControlSwitchables(
            PropertyEditControlBase[] controls,
            bool switchable)
        {
            foreach (var c in controls)
            {
                var sc = c as SwitchablePropertyEditControlBase;
                if (sc != null)
                {
                    sc.Switchable = switchable;
                }
            }
            return controls;
        }

        #endregion

        /// <summary>
        /// フォントファミリ名を取得する。
        /// </summary>
        /// <param name="family">フォントファミリ。</param>
        /// <returns>フォントファミリ名。</returns>
        public static string GetFontFamilyName(FontFamily family)
        {
            string name;
            if (!family.FamilyNames.TryGetValue(JapaneseLang, out name))
            {
                name = family.Source;
            }
            return name;
        }
    }
}
