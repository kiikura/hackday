﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト表示速度プロパティ値を保持するクラス。
    /// </summary>
    /// <remarks>
    /// 上書きをサポートするため、すべてのパラメータは null 許容値となる。
    /// </remarks>
    [Serializable]
    public sealed class TextSpeakPropertyContainer : Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextSpeakPropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("speak.wait")]
        public double Wait { get; set; }

        [Nive2Property("speak.letter")]
        private double? LetterSpanData { get; set; }

        [Nive2Property("speak.row")]
        private double? RowSpanData { get; set; }

        [Nive2Property("speak.fadein")]
        private double? FadeInSpanData { get; set; }

        [Nive2Property("speak.skip.row")]
        private double? RowSkipData { get; set; }

        [Nive2Property("speak.skip.letter")]
        private double? LetterSkipData { get; set; }

        [Nive2Property("speak.skip.blank")]
        private bool? BlankSkipData { get; set; }

        #endregion

        #region NiVE2プロパティ対応メンバへのアクセッサ

        public double LetterSpan
        {
            get { return LetterSpanData ?? 0; }
            set { LetterSpanData = value; }
        }

        public double RowSpan
        {
            get { return RowSpanData ?? 0; }
            set { RowSpanData = value; }
        }

        public double FadeInSpan
        {
            get { return FadeInSpanData ?? 0; }
            set { FadeInSpanData = value; }
        }

        public int RowSkip
        {
            get { return (int)(RowSkipData ?? 0); }
            set { RowSkipData = value; }
        }

        public int LetterSkip
        {
            get { return (int)(LetterSkipData ?? 0); }
            set { LetterSkipData = value; }
        }

        public bool BlankSkip
        {
            get { return BlankSkipData ?? false; }
            set { BlankSkipData = value; }
        }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextSpeakPropertyContainer Clone()
        {
            return (TextSpeakPropertyContainer)base.Clone();
        }
    }
}
