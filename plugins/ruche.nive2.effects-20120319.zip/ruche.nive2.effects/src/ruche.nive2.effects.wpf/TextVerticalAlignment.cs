﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストの縦方向の配置を表す列挙。
    /// </summary>
    public enum TextVerticalAlignment
    {
        /// <summary>
        /// 上端。
        /// </summary>
        [Description("上端")]
        Top,

        /// <summary>
        /// 中央。
        /// </summary>
        [Description("中央")]
        Center,

        /// <summary>
        /// ベースライン。
        /// </summary>
        [Description("ベースライン")]
        [EnumDefaultValue]
        Baseline,

        /// <summary>
        /// 下端。
        /// </summary>
        [Description("下端")]
        Bottom,
    }
}
