﻿using System;
using System.Collections.Generic;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// ブラシを編集するNiVE2プロパティエディットコントロールの実処理を行うクラス。
    /// </summary>
    internal sealed class BrushPropertyEditControlEngine : IDisposable
    {
        /// <summary>
        /// ブラシ種別配列。
        /// </summary>
        private static readonly EditBrushTypes[] BrushTypes =
            {
                EditBrushTypes.SolidColor,
                EditBrushTypes.LinearGradient,
                EditBrushTypes.RadialGradient,
            };

        /// <summary>
        /// ブラシ種別配列に対応するブラシクラス型配列。
        /// </summary>
        private static readonly Type[] BrushClassTypes =
            {
                typeof(SolidColorBrush),
                typeof(LinearGradientBrush),
                typeof(RadialGradientBrush),
            };

        /// <summary>
        /// ブラシ種別配列に対応するメニュー表示名配列。
        /// </summary>
        private static readonly string[] BrushMenuTexts =
            {
                "単一色",
                "線形グラデーション",
                "放射状グラデーション",
            };

        /// <summary>
        /// 編集可能なブラシ種別の組み合わせ。
        /// </summary>
        private EditBrushTypes _types = EditBrushTypes.None;

        /// <summary>
        /// メニュー。
        /// </summary>
        private ContextMenuStrip _menu = null;

        /// <summary>
        /// 単一色ブラシダイアログのテンプレート色配列。
        /// </summary>
        private List<Color32> _templateColors = null;

        /// <summary>
        /// グラデーションブラシダイアログの編集マーカー有効フラグ。
        /// </summary>
        private bool _editMarkerEnabled = true;

        /// <summary>
        /// グラデーションブラシダイアログの編集マーカー色。
        /// </summary>
        private Color32 _editMarkerColor = Colors.Lime;

        /// <summary>
        /// 最後に選択したブラシ配列。
        /// </summary>
        private Brush[] _lastBrushes = new Brush[BrushClassTypes.Length];

        /// <summary>
        /// 最後に作成されたブラシ。
        /// </summary>
        private Brush _brush = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="owner">操作対象のプロパティコントロール。</param>
        /// <param name="editBox">編集処理に用いるピクチャボックス。</param>
        /// <param name="editBrushTypes">
        /// 編集可能なブラシ種別の組み合わせ。
        /// </param>
        public BrushPropertyEditControlEngine(
            PropertyEditControlBase owner,
            PictureBox editBox,
            EditBrushTypes editBrushTypes)
        {
            this.Owner = owner;
            this.EditBox = editBox;
            this.EditBrushTypes = editBrushTypes;
        }

        /// <summary>
        /// 操作対象のプロパティコントロールを取得する。
        /// </summary>
        public PropertyEditControlBase Owner { get; private set; }

        /// <summary>
        /// 編集処理に用いるピクチャボックスを取得する。
        /// </summary>
        public PictureBox EditBox { get; private set; }

        /// <summary>
        /// 編集可能なブラシ種別の組み合わせを取得する。
        /// </summary>
        public EditBrushTypes EditBrushTypes
        {
            get { return _types; }
            private set
            {
                _types = 0;
                foreach (EditBrushTypes t in BrushTypes)
                {
                    if ((value & t) != 0)
                    {
                        _types |= t;
                    }
                }
            }
        }

        /// <summary>
        /// 現在のブラシを取得または設定する。
        /// </summary>
        public Brush Brush
        {
            get { return _brush; }
            set
            {
                _brush = (value == null) ? null : value.SafeGetAsFrozen();
            }
        }

        /// <summary>
        /// コントロールの初期化を行う。
        /// </summary>
        public void Initialize()
        {
            InitializeEditBox();
            InitializeMenu();
        }

        /// <summary>
        /// 現在のブラシを基にコントロールを更新する。
        /// </summary>
        public void Update()
        {
            Update(true);
        }

        /// <summary>
        /// 現在のブラシを基にコントロールを更新する。
        /// </summary>
        /// <param name="enabled">
        /// 有効な状態ならば true 。無効な状態ならば false 。
        /// </param>
        public void Update(bool enabled)
        {
            if (this.Brush == null)
            {
                return;
            }

            // ブラシから画像作成
            var image = SafeInvoker.Call(this.Brush, () =>
                {
                    var bmp = BitmapUtil.CreateRenderTargetBitmap(
                        EditBox.ClientSize.Width,
                        EditBox.ClientSize.Height,
                        this.Brush);
                    bmp.Freeze();

                    return BitmapUtil.ConvertToBitmap(bmp);
                });

            if (!enabled)
            {
                // 無効状態画像作成
                var temp = image;
                image = BitmapUtil.CreateGrayedBitmap(image);
                temp.Dispose();
            }

            // ピクチャボックス画像に設定
            var old = EditBox.Image;
            EditBox.Image = image;
            if (old != null)
            {
                old.Dispose();
            }

            // 型検索＆選択ブラシ更新
            Type type = null;
            for (int i = 0; i < BrushClassTypes.Length; ++i)
            {
                if (BrushClassTypes[i].IsInstanceOfType(this.Brush))
                {
                    type = BrushClassTypes[i];
                    _lastBrushes[i] = this.Brush;
                    break;
                }
            }

            // デフォルトメニュー項目変更
            _menu.SuspendLayout();
            try
            {
                foreach (ToolStripMenuItem item in _menu.Items)
                {
                    item.Checked = (type == (item.Tag as Type));
                }
            }
            finally
            {
                _menu.ResumeLayout(false);
            }
        }

        /// <summary>
        /// ピクチャボックスを初期化する。
        /// </summary>
        private void InitializeEditBox()
        {
            // 背景画像作成
            var bmp = new Drawing::Bitmap(8, 8);
            using (var g = Drawing::Graphics.FromImage(bmp))
            {
                g.FillRectangles(
                    Drawing::Brushes.Silver,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 0, 4, 4),
                        new Drawing::Rectangle(4, 4, 4, 4),
                    });
                g.FillRectangles(
                    Drawing::Brushes.White,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 4, 4, 4),
                        new Drawing::Rectangle(4, 0, 4, 4),
                    });
            }

            EditBox.SuspendLayout();
            try
            {
                // 背景画像設定
                EditBox.BackgroundImageLayout = ImageLayout.Tile;
                var temp = EditBox.BackgroundImage;
                EditBox.BackgroundImage = bmp;
                if (temp != null)
                {
                    temp.Dispose();
                }

                // 配置モード設定
                EditBox.SizeMode = PictureBoxSizeMode.StretchImage;

                // イベント設定
                EditBox.Click += EditBox_Click;
            }
            finally
            {
                EditBox.ResumeLayout(false);
            }
        }

        /// <summary>
        /// メニューを初期化する。
        /// </summary>
        private void InitializeMenu()
        {
            _menu = new ContextMenuStrip();
            _menu.SuspendLayout();
            try
            {
                // アイテム追加(Tag にクラス型設定)
                for (int i = 0; i < BrushTypes.Length; ++i)
                {
                    if ((EditBrushTypes & BrushTypes[i]) != 0)
                    {
                        var item = new ToolStripMenuItem(BrushMenuTexts[i]);
                        item.Tag = BrushClassTypes[i];
                        _menu.Items.Add(item);
                    }
                }

                // イベントハンドラ設定
                _menu.ItemClicked += menu_ItemClicked;
            }
            finally
            {
                _menu.ResumeLayout(false);
            }
        }

        /// <summary>
        /// ブラシ編集ダイアログを表示する。
        /// </summary>
        /// <param name="type">ブラシクラス型。</param>
        /// <returns>作成されたブラシ。キャンセルされた場合は null 。</returns>
        private Brush ShowBrushDialog(Type type)
        {
            int index = Array.FindIndex(BrushClassTypes, (t) => (t == type));
            Brush lastBrush = (index < 0) ? null : _lastBrushes[index];

            Brush result = null;
            if (type == typeof(SolidColorBrush))
            {
                using (var dialog = new SolidColorBrushDialog())
                {
                    dialog.Brush = lastBrush as SolidColorBrush;
                    dialog.TemplateColors = _templateColors;
                    dialog.UserColor = dialog.BrushColor;
                    if (dialog.ShowDialog(Owner) == DialogResult.OK)
                    {
                        result = dialog.Brush;
                        _templateColors = dialog.TemplateColors;
                    }
                }
            }
            else if (type == typeof(LinearGradientBrush))
            {
                using (var dialog = new LinearGradientBrushDialog())
                {
                    dialog.Brush = lastBrush as LinearGradientBrush;
                    dialog.EditMarkerEnabled = _editMarkerEnabled;
                    dialog.EditMarkerColor = _editMarkerColor;
                    if (dialog.ShowDialog(Owner) == DialogResult.OK)
                    {
                        result = dialog.Brush;
                        _editMarkerEnabled = dialog.EditMarkerEnabled;
                        _editMarkerColor = dialog.EditMarkerColor;
                    }
                }
            }
            else if (type == typeof(RadialGradientBrush))
            {
                using (var dialog = new RadialGradientBrushDialog())
                {
                    dialog.Brush = lastBrush as RadialGradientBrush;
                    dialog.EditMarkerEnabled = _editMarkerEnabled;
                    dialog.EditMarkerColor = _editMarkerColor;
                    if (dialog.ShowDialog(Owner) == DialogResult.OK)
                    {
                        result = dialog.Brush;
                        _editMarkerEnabled = dialog.EditMarkerEnabled;
                        _editMarkerColor = dialog.EditMarkerColor;
                    }
                }
            }

            if (result != null)
            {
                result.SafeFreeze();
            }

            return result;
        }

        /// <summary>
        /// 操作によってブラシが更新された際に呼び出される。
        /// </summary>
        /// <param name="e">イベントパラメータ。</param>
        private void OnBrushChangeCommitted(EventArgs e)
        {
            if (BrushChangeCommitted != null)
            {
                BrushChangeCommitted(this, e);
            }
        }

        /// <summary>
        /// 操作によってブラシが更新された際に呼び出されるイベント。
        /// </summary>
        public event EventHandler BrushChangeCommitted;

        #region IDisposable メンバ

        public void Dispose()
        {
            if (EditBox != null)
            {
                EditBox.Click -= EditBox_Click;
                if (EditBox.Image != null)
                {
                    EditBox.Image.Dispose();
                    EditBox.Image = null;
                }
                if (EditBox.BackgroundImage != null)
                {
                    EditBox.BackgroundImage.Dispose();
                    EditBox.BackgroundImage = null;
                }
            }
            if (_menu != null)
            {
                _menu.ItemClicked -= menu_ItemClicked;
                _menu.Dispose();
                _menu = null;
            }
        }

        #endregion

        private void EditBox_Click(object sender, EventArgs e)
        {
            if (_menu.Items.Count == 1)
            {
                // 編集可能ブラシが1種類なら即編集
                Brush brush = ShowBrushDialog(_menu.Items[0].Tag as Type);
                if (brush != null)
                {
                    // ブラシ設定
                    this.Brush = brush;

                    // イベント呼び出し
                    OnBrushChangeCommitted(e);
                }
            }
            else if (_menu.Items.Count > 1)
            {
                // 編集可能ブラシが2種類以上あるならメニュー表示
                _menu.Show(EditBox, EditBox.PointToClient(Cursor.Position));
            }
        }

        private void menu_ItemClicked(
            object sender,
            ToolStripItemClickedEventArgs e)
        {
            // 選択されたブラシ種別を編集
            Brush brush = ShowBrushDialog(e.ClickedItem.Tag as Type);
            if (brush != null)
            {
                // ブラシ設定
                this.Brush = brush;

                // イベント呼び出し
                OnBrushChangeCommitted(EventArgs.Empty);
            }
        }
    }
}
