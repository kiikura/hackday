﻿using System;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト装飾の描画情報を保持する抽象基底クラス。
    /// </summary>
    public abstract class DecorationRenderingInfoBase
    {
        /// <summary>
        /// 幅。
        /// </summary>
        private double _width = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public DecorationRenderingInfoBase()
        {
        }

        /// <summary>
        /// 基準位置からのY方向のオフセット割合を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 文字の高さを 1.0 とする割合値で表す。
        /// </remarks>
        public double OffsetRate { get; set; }

        /// <summary>
        /// 塗り潰しに用いるブラシを取得または設定する。
        /// </summary>
        /// <remarks>null ならば描画しない。</remarks>
        public Brush Brush { get; set; }

        /// <summary>
        /// 幅を取得または設定する。
        /// </summary>
        /// <remarks>0 ならば描画しない。</remarks>
        public double Width
        {
            get { return _width; }
            set { _width = Math.Max(value, 0); }
        }

        /// <summary>
        /// Zオーダ値を取得または設定する。
        /// </summary>
        /// <seealso cref="TextRenderingInfo"/>
        public double ZOrder { get; set; }
    }
}
