﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Windows.Forms;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// SolidColorBrush を編集するコモンダイアログクラス。
    /// </summary>
    public class SolidColorBrushDialog : CommonDialog
    {
        /// <summary>
        /// テンプレート色の総数。
        /// </summary>
        public const int TemplateColorCount = 16;

        /// <summary>
        /// カスタム色の総数。
        /// </summary>
        public const int CustomColorCount = 16;

        #region static メンバ

        /// <summary>
        /// 既定のテンプレート色配列。
        /// </summary>
        private static readonly ReadOnlyCollection<Color32> _defaultTemplateColors =
            new ReadOnlyCollection<Color32>(
                new Color32[]
                    {
                        new Color32(0xFF, 0xFF, 0xFF),
                        new Color32(0xFF, 0xFF, 0x00),
                        new Color32(0xFF, 0x00, 0xFF),
                        new Color32(0x00, 0xFF, 0xFF),
                        new Color32(0xC0, 0xC0, 0xC0),
                        new Color32(0x80, 0x00, 0x80),
                        new Color32(0x80, 0x80, 0x00),
                        new Color32(0x00, 0x80, 0x80),
                        new Color32(0x80, 0x80, 0x80),
                        new Color32(0xFF, 0x00, 0x00),
                        new Color32(0x00, 0xFF, 0x00),
                        new Color32(0x00, 0x00, 0xFF),
                        new Color32(0x00, 0x00, 0x00),
                        new Color32(0x80, 0x00, 0x00),
                        new Color32(0x00, 0x80, 0x00),
                        new Color32(0x00, 0x00, 0x80),
                    });

        /// <summary>
        /// 既定のカスタム色配列。
        /// </summary>
        private static readonly ReadOnlyCollection<Color32> _defaultCustomColors =
            new ReadOnlyCollection<Color32>(
                new Color32[]
                    {
                        new Color32(0xFF, 0xFF, 0xFF),
                        new Color32(0x00, 0xFF, 0xFF),
                        new Color32(0xFF, 0x00, 0xFF),
                        new Color32(0xFF, 0xFF, 0xFF),
                        new Color32(0x80, 0x80, 0x00),
                        new Color32(0x80, 0x00, 0x80),
                        new Color32(0x00, 0x80, 0x80),
                        new Color32(0x80, 0x80, 0x80),
                        new Color32(0x00, 0x00, 0x00),
                        new Color32(0xFF, 0x00, 0x00),
                        new Color32(0x00, 0xFF, 0x00),
                        new Color32(0x00, 0x00, 0xFF),
                        new Color32(0x00, 0x00, 0x80),
                        new Color32(0x00, 0x80, 0x00),
                        new Color32(0x80, 0x00, 0x00),
                        new Color32(0xC0, 0xC0, 0xC0),
                    });

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// </remarks>
        public static SolidColorBrush DefaultBrush
        {
            get { return Brushes.Black; }
        }

        /// <summary>
        /// 既定のテンプレート色配列を取得する。
        /// </summary>
        public static ReadOnlyCollection<Color32> DefaultTemplateColors
        {
            get { return _defaultTemplateColors; }
        }

        /// <summary>
        /// 既定のカスタム色配列を取得する。
        /// </summary>
        public static ReadOnlyCollection<Color32> DefaultCustomColors
        {
            get { return _defaultCustomColors; }
        }

        #endregion

        /// <summary>
        /// ブラシ。
        /// </summary>
        private SolidColorBrush _brush = DefaultBrush;

        /// <summary>
        /// テンプレート色配列。
        /// </summary>
        private List<Color32> _templateColors =
            new List<Color32>(DefaultTemplateColors);

        /// <summary>
        /// ユーザ定義色。
        /// </summary>
        private Color _userColor = DefaultBrush.Color;

        /// <summary>
        /// カラーダイアログに設定されるカスタム色配列。
        /// </summary>
        private List<Color32> _customColors =
            new List<Color32>(DefaultCustomColors);

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public SolidColorBrushDialog()
        {
            Reset();
        }

        /// <summary>
        /// ブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// 変更可能なブラシを設定すると、変更不可なクローンを作成して保持する。
        /// </remarks>
        public SolidColorBrush Brush
        {
            get { return _brush; }
            set { _brush = (value ?? DefaultBrush).SafeGetAsFrozen(); }
        }

        /// <summary>
        /// ブラシ色を取得または設定する。
        /// </summary>
        public Color32 BrushColor
        {
            get { return Brush.Color; }
            set
            {
                SafeInvoker.Call(Brush, () =>
                {
                    SolidColorBrush brush = Brush.Clone();
                    brush.Color = value;
                    brush.Freeze();
                    Brush = brush;
                });
            }
        }

        /// <summary>
        /// テンプレート色配列を取得または設定する。
        /// null を渡すと DefaultTemplateColors が設定される。
        /// 実際に使われる色は GetTemplateColors メソッドで取得できる。
        /// </summary>
        public List<Color32> TemplateColors
        {
            get { return _templateColors; }
            set
            {
                _templateColors =
                    value ?? (new List<Color32>(DefaultTemplateColors));
            }
        }

        /// <summary>
        /// ユーザ定義色を取得または設定する。
        /// 設定時にアルファ成分値は取り除かれる。
        /// </summary>
        public Color32 UserColor
        {
            get { return _userColor; }
            set { _userColor = new Color32(255, value); }
        }

        /// <summary>
        /// 実際に使われるテンプレート色配列を取得する。
        /// </summary>
        /// <returns>テンプレート色配列。</returns>
        public Color32[] GetTemplateColors()
        {
            Color32[] colors = new Color32[TemplateColorCount];

            for (int i = 0; i < colors.Length; ++i)
            {
                Color32 c = (i < TemplateColors.Count) ?
                    TemplateColors[i] :
                    DefaultTemplateColors[i];
                c.A = 255;
                colors[i] = c;
            }

            return colors;
        }

        #region CommonDialog メンバ

        public override void Reset()
        {
            this.Brush = DefaultBrush;
            this.TemplateColors = new List<Color32>(DefaultTemplateColors);
            this.UserColor = DefaultBrush.Color;
        }

        protected override bool RunDialog(IntPtr hwndOwner)
        {
            bool result = false;

            using (var window = new SolidColorBrushWindow())
            {
                window.Brush = this.Brush;
                window.TemplateColors = GetTemplateColors();
                window.UserColor = this.UserColor;

                Control owner = Control.FromHandle(hwndOwner);
                if (window.ShowDialog(owner) == DialogResult.OK)
                {
                    this.Brush = window.Brush;
                    this.TemplateColors =
                        new List<Color32>(window.TemplateColors);
                    this.UserColor = window.UserColor;

                    result = true;
                }
            }

            return result;
        }

        #endregion
    }
}
