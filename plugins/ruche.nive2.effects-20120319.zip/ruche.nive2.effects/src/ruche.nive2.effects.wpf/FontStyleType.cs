﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// フォントスタイル種別の列挙。
    /// </summary>
    public enum FontStyleType
    {
        /// <summary>
        /// 標準。
        /// </summary>
        [Description("標準")]
        [EnumDefaultValue]
        Normal,

        /// <summary>
        /// イタリック体。
        /// </summary>
        [Description("イタリック体")]
        Italic,

        /// <summary>
        /// 斜体。
        /// </summary>
        [Description("斜体")]
        Oblique,
    }
}
