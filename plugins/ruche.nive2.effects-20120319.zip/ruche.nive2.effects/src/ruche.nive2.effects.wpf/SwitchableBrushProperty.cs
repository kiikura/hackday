﻿using System;
using System.Windows.Media;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// WPFブラシとその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    /// <remarks>
    /// OriginalBrush プロパティや OriginalValue プロパティで取得できる
    /// Brush オブジェクトは必ずフリーズ済みであるため、
    /// 内部値を変更したい場合はオブジェクトのクローンを作成する必要がある。
    /// 
    /// OriginalBrush プロパティや OriginalValue プロパティに未フリーズの
    /// Brush オブジェクトを設定しようとすると、内部でクローンを作成して
    /// フリーズさせた上で設定される。
    /// </remarks>
    [Serializable]
    public class SwitchableBrushProperty
        :
        SwitchablePropertyBase<XamlSerializable<Brush>>
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableBrushProperty(string name, bool valid)
            : this(name, null, valid)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期ブラシ。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableBrushProperty(string name, Brush value, bool valid)
            : base(name, new XamlSerializable<Brush>(), valid)
        {
            // 値補正のため再度設定
            OriginalBrush = value;
        }

        /// <summary>
        /// 内部ブラシ値を取得または設定する。
        /// </summary>
        public Brush OriginalBrush
        {
            get { return OriginalValue.Value; }
            set { OriginalValue = new XamlSerializable<Brush>(value); }
        }

        /// <summary>
        /// 有効状態ならば内部ブラシ値を、無効状態ならば null 値を取得する。
        /// </summary>
        public Brush Brush
        {
            get { return Valid ? OriginalBrush : null; }
        }

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        public Brush DefaultBrush
        {
            get { return Brushes.Black; }
        }

        /// <summary>
        /// 有効状態ならば内部値を、無効状態ならば null 値を取得する。
        /// </summary>
        public new XamlSerializable<Brush> Value
        {
            get { return Valid ? OriginalValue : null; }
        }

        #region SwitchablePropertyBase<XamlSerializable<Brush>> メンバ

        public override XamlSerializable<Brush> DefaultValue
        {
            get { return new XamlSerializable<Brush>(DefaultBrush); }
        }

        protected override bool ValidateValue(ref XamlSerializable<Brush> value)
        {
            Brush brush = value.Value;
            if (brush == null)
            {
                brush = DefaultBrush;
            }
            else
            {
                brush = SafeInvoker.Call(brush,
                    () =>
                    {
                        return brush.IsFrozen ?
                            null :
                            (Brush)brush.GetAsFrozen();
                    });
            }

            if (brush != null)
            {
                value = new XamlSerializable<Brush>(brush);
            }

            return true;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return new SwitchableBrushProperty(name, false);
        }

        #endregion

        #region PropertyBase メンバ

        public override PropertyInterpolationType SupportInterpolationType
        {
            get
            {
                return (
                    PropertyInterpolationType.Fixed |
                    PropertyInterpolationType.Liner);
            }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            // 前方キーフレーム取得
            KeyFrame prevKey = Util.GetPrevKeyFrame(keyFrame, time);
            if (prevKey == null)
            {
                return Util.GetAboveKeyFrame(keyFrame, time).Property;
            }
            if (
                prevKey.Type == PropertyInterpolationType.Fixed ||
                prevKey.Time >= time)
            {
                return prevKey.Property;
            }

            // 後方キーフレーム取得
            KeyFrame nextKey = Util.GetAboveKeyFrame(keyFrame, time);
            if (nextKey == null)
            {
                return prevKey.Property;
            }

            // リニア補間
            var prevProp = (SwitchableBrushProperty)prevKey.Property;
            Brush brush = Interpolater.Linear(
                prevProp.OriginalBrush,
                ((SwitchableBrushProperty)nextKey.Property).OriginalBrush,
                (time - prevKey.Time) / (nextKey.Time - prevKey.Time));
            brush.SafeFreeze();

            return new SwitchableBrushProperty(
                prevProp.PropertyName,
                brush,
                prevProp.Valid);
        }

        #endregion
    }
}
