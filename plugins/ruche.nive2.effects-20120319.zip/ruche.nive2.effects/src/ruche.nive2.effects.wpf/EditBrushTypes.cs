﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 編集するブラシの組み合わせを表す列挙。
    /// </summary>
    [Flags]
    public enum EditBrushTypes
    {
        /// <summary>
        /// なし。
        /// </summary>
        None = 0,

        /// <summary>
        /// 単一色ブラシ。
        /// </summary>
        SolidColor = 1 << 0,

        /// <summary>
        /// 線形グラデーションブラシ。
        /// </summary>
        LinearGradient = 1 << 1,

        /// <summary>
        /// 放射状グラデーションブラシ。
        /// </summary>
        RadialGradient = 1 << 2,

        /// <summary>
        /// すべて。
        /// </summary>
        All = SolidColor | LinearGradient | RadialGradient,
    }
}
