﻿using System;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 値の補間演算を定義する静的クラス。
    /// </summary>
    public static class Interpolater
    {
        /// <summary>
        /// 数値のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static double Linear(
            double begin,
            double end,
            double rate)
        {
            return (begin + (end - begin) * rate);
        }

        /// <summary>
        /// 数値のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static int Linear(
            int begin,
            int end,
            double rate)
        {
            return (int)Math.Round(Linear((double)begin, (double)end, rate));
        }

        /// <summary>
        /// 数値のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static byte Linear(
            byte begin,
            byte end,
            double rate)
        {
            int result = Linear((int)begin, (int)end, rate);
            return (byte)Math.Min(Math.Max(result, 0), 255);
        }

        /// <summary>
        /// 2D座標のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Point2D Linear(
            Point2D begin,
            Point2D end,
            double rate)
        {
            return Point2D.Linear(begin, end, rate);
        }

        /// <summary>
        /// 色のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Color Linear(
            Color begin,
            Color end,
            double rate)
        {
            return Color.FromArgb(
                Linear(begin.A, end.A, rate),
                Linear(begin.R, end.R, rate),
                Linear(begin.G, end.G, rate),
                Linear(begin.B, end.B, rate));
        }

        /// <summary>
        /// GradientStop のリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static GradientStop Linear(
            GradientStop begin,
            GradientStop end,
            double rate)
        {
            GradientStop result = begin;

            SafeInvoker.Call(begin, () =>
            {
                result = begin.Clone();
                result.Color = Linear(begin.Color, end.Color, rate);
                result.Offset = Linear(begin.Offset, end.Offset, rate);
            });

            return result;
        }

        /// <summary>
        /// GradientStopCollection のリニア補間を行う。
        /// </summary>
        /// <param name="begins">開始値。</param>
        /// <param name="ends">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static GradientStopCollection Linear(
            GradientStopCollection begins,
            GradientStopCollection ends,
            double rate)
        {
            GradientStopCollection results = null;

            SafeInvoker.Call(begins, () =>
            {
                int max = Math.Max(begins.Count, ends.Count);
                results = new GradientStopCollection(max);

                if (begins.Count == ends.Count)
                {
                    // 個数が同じ場合
                    for (int i = 0; i < max; ++i)
                    {
                        results.Add(Linear(begins[i], ends[i], rate));
                    }
                }
                else
                {
                    // 個数が異なるなら 少→多 と変化させる
                    GradientStopCollection b = begins, e = ends;
                    if (begins.Count > ends.Count)
                    {
                        b = ends;
                        e = begins;
                        rate = 1 - rate;
                    }

                    // 1個の開始点から複数個の終端点に分離する
                    int splitMin = e.Count / b.Count; // 最小分離数
                    int incCount = e.Count % b.Count; // 1個多く分離する開始点の数
                    for (int bi = 0, ei = 0; bi < b.Count; ++bi)
                    {
                        int splitCount = splitMin;
                        if (bi < incCount) { ++splitCount; }
                        for (int s = 0; s < splitCount; ++s)
                        {
                            results.Add(Linear(b[bi], e[ei], rate));
                            ++ei;
                        }
                    }
                }
            });

            return results;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            SolidColorBrush begin,
            SolidColorBrush end,
            double rate)
        {
            SolidColorBrush result = null;

            SafeInvoker.Call(begin, () =>
            {
                result =
                    new SolidColorBrush(Linear(begin.Color, end.Color, rate));
                result.Opacity = Linear(begin.Opacity, end.Opacity, rate);
            });

            return result;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            SolidColorBrush begin,
            GradientBrush end,
            double rate)
        {
            GradientBrush result = null;

            SafeInvoker.Call(begin, () =>
            {
                result = end.Clone();
                foreach (GradientStop gs in result.GradientStops)
                {
                    gs.Color = Linear(begin.Color, gs.Color, rate);
                }
                result.Opacity = Linear(begin.Opacity, end.Opacity, rate);
            });

            return result;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            GradientBrush begin,
            SolidColorBrush end,
            double rate)
        {
            GradientBrush result = null;

            SafeInvoker.Call(begin, () =>
            {
                result = begin.Clone();
                foreach (GradientStop gs in result.GradientStops)
                {
                    gs.Color = Linear(gs.Color, end.Color, rate);
                }
                result.Opacity = Linear(begin.Opacity, end.Opacity, rate);
            });

            return result;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            LinearGradientBrush begin,
            LinearGradientBrush end,
            double rate)
        {
            LinearGradientBrush result = null;

            SafeInvoker.Call(begin, () =>
            {
                result = begin.Clone();
                result.StartPoint =
                    Linear(begin.StartPoint, end.StartPoint, rate);
                result.EndPoint = Linear(begin.EndPoint, end.EndPoint, rate);
                result.GradientStops =
                    Linear(begin.GradientStops, end.GradientStops, rate);
                result.Opacity = Linear(begin.Opacity, end.Opacity, rate);
            });

            return result;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            RadialGradientBrush begin,
            RadialGradientBrush end,
            double rate)
        {
            RadialGradientBrush result = null;

            SafeInvoker.Call(begin, () =>
            {
                result = begin.Clone();
                result.GradientOrigin =
                    Linear(begin.GradientOrigin, end.GradientOrigin, rate);
                result.Center = Linear(begin.Center, end.Center, rate);
                result.RadiusX = Linear(begin.RadiusX, end.RadiusX, rate);
                result.RadiusY = Linear(begin.RadiusY, end.RadiusY, rate);
                result.GradientStops =
                    Linear(begin.GradientStops, end.GradientStops, rate);
                result.Opacity = Linear(begin.Opacity, end.Opacity, rate);
            });

            return result;
        }

        /// <summary>
        /// ブラシのリニア補間を行う。
        /// </summary>
        /// <param name="begin">開始値。</param>
        /// <param name="end">終端値。</param>
        /// <param name="rate">割合。 0.0 で開始値、 1.0 で終端値。</param>
        /// <returns>補間された値。</returns>
        public static Brush Linear(
            Brush begin,
            Brush end,
            double rate)
        {
            Brush result = null;

            if (rate == 0)
            {
                result = begin.SafeGetAsFrozen();
            }
            else if (rate == 1)
            {
                result = end.SafeGetAsFrozen();
            }
            else if (begin is SolidColorBrush)
            {
                if (end is SolidColorBrush)
                {
                    result = Linear(
                        (SolidColorBrush)begin,
                        (SolidColorBrush)end,
                        rate);
                }
                else if (end is GradientBrush)
                {
                    result = Linear(
                        (SolidColorBrush)begin,
                        (GradientBrush)end,
                        rate);
                }
            }
            else if (begin is LinearGradientBrush)
            {
                if (end is SolidColorBrush)
                {
                    result = Linear(
                        (LinearGradientBrush)begin,
                        (SolidColorBrush)end,
                        rate);
                }
                else if (end is LinearGradientBrush)
                {
                    result = Linear(
                        (LinearGradientBrush)begin,
                        (LinearGradientBrush)end,
                        rate);
                }
            }
            else if (begin is RadialGradientBrush)
            {
                if (end is SolidColorBrush)
                {
                    result = Linear(
                        (RadialGradientBrush)begin,
                        (SolidColorBrush)end,
                        rate);
                }
                else if (end is RadialGradientBrush)
                {
                    result = Linear(
                        (RadialGradientBrush)begin,
                        (RadialGradientBrush)end,
                        rate);
                }
            }

            if (result == null)
            {
                result = ((rate < 1) ? begin : end).SafeClone();
            }

            return result;
        }
    }
}
