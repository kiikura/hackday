﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト行描画情報を保持するクラス。
    /// </summary>
    public class TextRowRenderingInfo
    {
        /// <summary>
        /// 文字描画情報リスト。
        /// </summary>
        private List<LetterRenderingInfo> _letterInfos =
            new List<LetterRenderingInfo>();

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextRowRenderingInfo()
        {
        }

        /// <summary>
        /// 文字描画情報リストを取得または設定する。
        /// </summary>
        public List<LetterRenderingInfo> LetterInfos
        {
            get { return _letterInfos; }
            set { _letterInfos = value ?? new List<LetterRenderingInfo>(); }
        }

        /// <summary>
        /// 行全体の左上端位置を取得または設定する。
        /// </summary>
        /// <remarks>
        /// テキスト全体の左上端を (0, 0) とする相対座標で表す。
        /// </remarks>
        public Point2D Position { get; set; }
    }
}
