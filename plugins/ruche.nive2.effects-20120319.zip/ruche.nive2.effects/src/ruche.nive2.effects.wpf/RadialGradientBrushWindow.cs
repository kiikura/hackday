﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NiVE2.Plugin.Controls;

using Drawing = System.Drawing;
using Drawing2D = System.Drawing.Drawing2D;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// RadialGradientBrush を編集するダイアログクラス。
    /// </summary>
    internal partial class RadialGradientBrushWindow : Form
    {
        /// <summary>
        /// マーカーの円の半径。
        /// </summary>
        private const int MarkerCircleRadius = 4;

        /// <summary>
        /// マーカーの十字線の半径。
        /// </summary>
        private const int MarkerCrossRadius = 6;

        /// <summary>
        /// マーカー範囲と判定される距離。
        /// </summary>
        private const double MarkerAreaDistance = 6;

        /// <summary>
        /// 色空間配列。
        /// </summary>
        private static readonly ColorInterpolationMode[] ColorSpaces =
            new ColorInterpolationMode[]
                {
                    ColorInterpolationMode.SRgbLinearInterpolation,
                    ColorInterpolationMode.ScRgbLinearInterpolation,
                };

        /// <summary>
        /// 拡散円の中心位置。
        /// </summary>
        private static readonly Point CircleCenter = new Point(0.5, 0.5);

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// </remarks>
        public static RadialGradientBrush DefaultBrush
        {
            get { return RadialGradientBrushDialog.DefaultBrush; }
        }

        /// <summary>
        /// 編集対象のブラシ。
        /// </summary>
        private RadialGradientBrush _brush = DefaultBrush;

        /// <summary>
        /// カラーポイントコレクション。
        /// </summary>
        private ColorPointCollection _points = new ColorPointCollection();

        /// <summary>
        /// 選択中のカラーポイント。
        /// </summary>
        private ColorPoint _selPoint = null;

        /// <summary>
        /// 色空間。
        /// </summary>
        private ColorInterpolationMode _colorSpace =
            ColorInterpolationMode.SRgbLinearInterpolation;

        /// <summary>
        /// コントロール状態の更新カウンタ。
        /// </summary>
        private int _ctrlUpdateCounter = 0;

        /// <summary>
        /// カラーダイアログのカスタムカラー配列。
        /// </summary>
        private int[] _customColors = new int[]
            {
                0xFFFFFF, 0xFFFF00, 0xFF00FF, 0x00FFFF,
                0x008080, 0x800080, 0x808000, 0x808080,
                0x000000, 0x0000FF, 0x00FF00, 0xFF0000,
                0x800000, 0x008000, 0x000080, 0xC0C0C0,
            };

        /// <summary>
        /// マウスのビューボックス上での位置。
        /// </summary>
        private Drawing::PointF _mouseViewPoint = Drawing::PointF.Empty;

        /// <summary>
        /// マウスボタン投下時の対象カラーポイント位置。
        /// </summary>
        private Point _mouseDownPostion = new Point();

        /// <summary>
        /// マウスボタン投下時の対象カラーポイントオフセット値。
        /// </summary>
        private double _mouseDownOffset = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public RadialGradientBrushWindow()
        {
            InitializeComponent();

            // 開始点と終端点の名前設定
            _points.Begin.Name = "開始点";
            _points.End.Name = "終端点";

            // コンボボックス表示項目設定
            comboPoint.DisplayMember = "Name";

            // マーカー色設定
            this.EditMarkerColor = Colors.Lime;
        }

        /// <summary>
        /// 編集対象のブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 現状では以下の制約がある。
        /// <list type="bullet">
        /// <item>
        /// <description>Center は常に (0.5, 0.5) となる。</description>
        /// </item>
        /// <item>
        /// <description>RadiusX と RadiusY は同値となる。</description>
        /// </item>
        /// </list>
        /// このプロパティに設定されたブラシはダイアログを表示するタイミングで
        /// 次のように補正される。
        /// <list type="bullet">
        /// <item>
        /// <description>Center を (0.5, 0.5) に変更する。</description>
        /// </item>
        /// <item>
        /// <description>
        /// RadiusX と RadiusY のうち大きい方を半径として採用する。
        /// ただし Math.Sqrt(0.5) より大きい場合は Math.Sqrt(0.5) とする。
        /// </description>
        /// </item>
        /// </list>
        /// ただし編集をキャンセルしてダイアログを閉じた場合、
        /// このプロパティ値自体は変更されない。
        /// 
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// 変更可能なブラシを設定すると、変更不可なクローンを作成して保持する。
        /// </remarks>
        public RadialGradientBrush Brush
        {
            get
            {
                return _brush;
            }
            set
            {
                if (
                    value != null &&
                    value.MappingMode != BrushMappingMode.RelativeToBoundingBox)
                {
                    throw new NotSupportedException(
                        "相対座標系以外のブラシはサポートされていません。");
                }

                _brush = (value ?? DefaultBrush).SafeGetAsFrozen();
            }
        }

        /// <summary>
        /// 編集マーカーを有効にするか否かを取得または設定する。
        /// </summary>
        public bool EditMarkerEnabled
        {
            get { return checkMark.Checked; }
            set { checkMark.Checked = value; }
        }

        /// <summary>
        /// 編集マーカーの色を取得または設定する。
        /// </summary>
        public Color32 EditMarkerColor
        {
            get
            {
                return buttonMarkColor.BackColor;
            }
            set
            {
                buttonMarkColor.BackColor = (Drawing::Color)value;
                if (EditMarkerEnabled)
                {
                    pictureView.Invalidate();
                }
            }
        }

        /// <summary>
        /// 編集マーカーをマウスでドラッグ中であるか否かを取得または設定する。
        /// コンボボックスの有効状態と逆連動する。
        /// </summary>
        private bool EditMarkerDragging
        {
            get { return !comboPoint.Enabled; }
            set { comboPoint.Enabled = !value; }
        }

        /// <summary>
        /// コントロールが更新中であるか否かを取得する。
        /// </summary>
        private bool ControlUpdating
        {
            get { return (_ctrlUpdateCounter > 0); }
        }

        /// <summary>
        /// コントロールの更新を開始する。
        /// </summary>
        private void BeginControlUpdate()
        {
            if (++_ctrlUpdateCounter == 1)
            {
                this.SuspendLayout();
            }
        }

        /// <summary>
        /// コントロールの更新を完了する。
        /// </summary>
        private void EndControlUpdate()
        {
            if (_ctrlUpdateCounter > 0)
            {
                if (--_ctrlUpdateCounter == 0)
                {
                    this.ResumeLayout();
                }
            }
        }

        /// <summary>
        /// ビューボックスの背景画像を初期化する。
        /// </summary>
        private void InitializeViewBackground()
        {
            // 画像作成
            var bmp = new Drawing::Bitmap(16, 16);
            using (var g = Drawing::Graphics.FromImage(bmp))
            {
                g.FillRectangles(
                    Drawing::Brushes.Silver,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 0, 8, 8),
                        new Drawing::Rectangle(8, 8, 8, 8),
                    });
                g.FillRectangles(
                    Drawing::Brushes.White,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 8, 8, 8),
                        new Drawing::Rectangle(8, 0, 8, 8),
                    });
            }

            // 設定
            pictureView.BackgroundImageLayout = ImageLayout.Tile;
            var temp = pictureView.BackgroundImage;
            pictureView.BackgroundImage = bmp;
            if (temp != null)
            {
                temp.Dispose();
            }
        }

        /// <summary>
        /// 新しいカラーポイントを追加する。
        /// </summary>
        /// <returns>追加されたカラーポイント。</returns>
        private ColorPoint AddNewColorPoint()
        {
            // 既存の点のうち2点間の距離が最も長いペアを検索
            ColorPoint p1, p2 = _points.Begin;
            ColorPoint sp1 = p2, sp2 = p2;
            double diff = -1;
            foreach (ColorPoint cp in _points)
            {
                p1 = p2;
                p2 = cp;
                if (p2.Offset - p1.Offset > diff)
                {
                    diff = p2.Offset - p1.Offset;
                    sp1 = p1;
                    sp2 = p2;
                }
            }

            // 追加
            ColorPoint point = _points.AddNew();

            // 名前設定
            point.Name = string.Format("中間点{0:D2}", point.Id + 1);

            // オフセットと色を2点の中間にする
            point.Offset = (sp1.Offset + sp2.Offset) / 2;
            point.Color = Color.FromArgb(
                (byte)(((int)sp1.Color.A + sp2.Color.A) / 2),
                (byte)(((int)sp1.Color.R + sp2.Color.R) / 2),
                (byte)(((int)sp1.Color.G + sp2.Color.G) / 2),
                (byte)(((int)sp1.Color.B + sp2.Color.B) / 2));

            // 位置情報更新
            UpdateColorPointPosition(point);

            return point;
        }

        /// <summary>
        /// ブラシを用いてカラーポイントコレクションと色空間を初期化する。
        /// </summary>
        /// <param name="brush">ブラシ。</param>
        private void InitializeColorPoints(RadialGradientBrush brush)
        {
            double radius = Math.Max(brush.RadiusX, brush.RadiusY);
            double xy = Math.Min(Math.Sqrt(radius * radius / 2), 0.5);

            // オフセット値が最大および最小の点を検索
            GradientStop stopMin = null, stopMax = null;
            foreach (GradientStop gs in Brush.GradientStops)
            {
                if (stopMin == null || gs.Offset < stopMin.Offset)
                {
                    stopMin = gs;
                }
                if (stopMax == null || gs.Offset > stopMax.Offset)
                {
                    stopMax = gs;
                }
            }

            // 初期化
            _points.Clear();

            // 開始点と終端点設定
            if (stopMin != null && stopMax != null)
            {
                _points.Begin.Value = stopMin;
                _points.End.Value = stopMax;
            }
            _points.Begin.Position = brush.GradientOrigin;
            _points.End.Position = new Point(
                0.5 + ((_points.Begin.Position.X > 0.5) ? -xy : +xy),
                0.5 + ((_points.Begin.Position.Y > 0.5) ? -xy : +xy));

            // それ以外の点を追加
            foreach (GradientStop gs in Brush.GradientStops)
            {
                if (
                    (gs.Offset != 0 && gs.Offset != 1) ||
                    (gs != stopMin && gs != stopMax))
                {
                    ColorPoint cp = AddNewColorPoint();
                    cp.Value = gs;
                    UpdateColorPointPosition(cp);
                }
            }

            // 色空間設定
            _colorSpace = brush.ColorInterpolationMode;
        }

        /// <summary>
        /// カラーポイントコレクションと色空間からブラシを作成する。
        /// </summary>
        /// <returns>ブラシ。</returns>
        private RadialGradientBrush MakeBrushFromColorPoints()
        {
            RadialGradientBrush brush = null;

            SafeInvoker.Call(Brush, () =>
            {
                brush = new RadialGradientBrush();

                // パラメータ設定
                brush.GradientOrigin = _points.Begin.Position;
                brush.Center = CircleCenter;
                double radius =
                    Point2D.Distance(CircleCenter, _points.End.Position);
                brush.RadiusX = radius;
                brush.RadiusY = radius;

                // 点を追加
                foreach (ColorPoint cp in _points)
                {
                    brush.GradientStops.Add(cp.Value.Clone());
                }

                // 色空間設定
                brush.ColorInterpolationMode = _colorSpace;

                // 変更不可にする
                brush.Freeze();
            });

            return brush;
        }

        /// <summary>
        /// 色選択ダイアログを表示する。
        /// </summary>
        /// <param name="color">初期選択色。</param>
        /// <returns>選択された色。キャンセルされた場合は null 。</returns>
        private Color32? ShowColorDialog(Color32 color)
        {
            Color32? result = null;

            // ドラッグ強制中断
            EditMarkerDragging = false;

            using (var dialog = new ColorSelectWindow())
            {
                dialog.Color = (Drawing::Color)color;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    result = dialog.Color;
                }
            }

            return result;
        }

        /// <summary>
        /// オフセット値を基にカラーポイントの位置を更新する。
        /// </summary>
        /// <param name="point">カラーポイント。</param>
        private void UpdateColorPointPosition(ColorPoint point)
        {
            if (!point.FreezeOffset)
            {
                point.Position = Point2D.Linear(
                    _points.Begin.Position,
                    _points.End.Position,
                    point.Offset);
            }
        }

        /// <summary>
        /// オフセット値を基にすべてのカラーポイントの位置を更新する。
        /// </summary>
        private void UpdateAllColorPointPositions()
        {
            foreach (ColorPoint cp in _points)
            {
                UpdateColorPointPosition(cp);
            }
        }

        /// <summary>
        /// カラーポイントのポジション値からビューボックス上の位置を算出する。
        /// </summary>
        /// <param name="point">カラーポイント。</param>
        /// <returns>ビューボックス上の位置。</returns>
        private Drawing::PointF CalcLocationOfView(ColorPoint point)
        {
            return CalcLocationOfView(point.Position);
        }

        /// <summary>
        /// ポジション値からビューボックス上の位置を算出する。
        /// </summary>
        /// <param name="position">ポジション値。</param>
        /// <returns>ビューボックス上の位置。</returns>
        private Drawing::PointF CalcLocationOfView(Point position)
        {
            return new Drawing::PointF(
                (float)(position.X * (pictureView.ClientSize.Width - 1)),
                (float)(position.Y * (pictureView.ClientSize.Height - 1)));
        }

        /// <summary>
        /// ビューボックス上の位置からポジション値を算出する。
        /// </summary>
        /// <param name="location">ビューボックス上の位置。</param>
        /// <returns>ポジション値。</returns>
        private Point CalcPositionOfView(Drawing::PointF location)
        {
            return new Point(
                (double)location.X / (pictureView.ClientSize.Width - 1),
                (double)location.Y / (pictureView.ClientSize.Height - 1));
        }

        /// <summary>
        /// カラーポイント位置をビューボックス上に描画する。
        /// </summary>
        /// <param name="g">グラフィクスインタフェース。</param>
        /// <param name="pen">ペン。</param>
        /// <param name="point">カラーポイント。</param>
        private void DrawColorPointToView(
            Drawing::Graphics g,
            Drawing::Pen pen,
            ColorPoint point)
        {
            Drawing::PointF pos = CalcLocationOfView(point);

            g.DrawEllipse(
                pen,
                pos.X - MarkerCircleRadius,
                pos.Y - MarkerCircleRadius,
                MarkerCircleRadius * 2,
                MarkerCircleRadius * 2);

            if (point == _selPoint)
            {
                var oldSmooth = g.SmoothingMode;
                try
                {
                    g.SmoothingMode = Drawing2D::SmoothingMode.None;

                    g.DrawLine(
                        pen,
                        pos.X - MarkerCrossRadius,
                        pos.Y,
                        pos.X + MarkerCrossRadius,
                        pos.Y);
                    g.DrawLine(
                        pen,
                        pos.X,
                        pos.Y - MarkerCrossRadius,
                        pos.X,
                        pos.Y + MarkerCrossRadius);
                }
                finally
                {
                    g.SmoothingMode = oldSmooth;
                }
            }
        }

        /// <summary>
        /// ビューボックス上の位置を基にカラーポイントを検索する。
        /// </summary>
        /// <param name="location">位置。</param>
        /// <returns>カラーポイント。見つからなかった場合は null 。</returns>
        private ColorPoint FindColorPoint(Drawing::PointF location)
        {
            ColorPoint point = null;
            double nearest = MarkerAreaDistance + 1;

            foreach (ColorPoint cp in _points)
            {
                double dist = Point2D.Distance(location, CalcLocationOfView(cp));
                if (dist <= MarkerAreaDistance)
                {
                    // 選択中の点を最優先
                    if (cp == _selPoint)
                    {
                        return cp;
                    }

                    // そうでなければ最も近い点を優先
                    if (dist < nearest)
                    {
                        point = cp;
                        nearest = dist;
                    }
                }
            }

            return point;
        }

        /// <summary>
        /// 選択中のカラーポイントに関する情報を更新する。
        /// </summary>
        private void UpdateSelectedColorPointInfo()
        {
            // コントロールの更新
            try
            {
                BeginControlUpdate();

                // コンボボックス設定
                comboPoint.SelectedIndex = comboPoint.Items.IndexOf(_selPoint);

                // 開始点または終端点ならば point.FreezeOffset == true
                // 開始点と終端点 : オフセット変更不可、削除不可
                // それ以外の点   : 座標変更不可
                numDragX.Enabled = _selPoint.FreezeOffset;
                numDragY.Enabled = _selPoint.FreezeOffset;
                numDragOffset.Enabled = !_selPoint.FreezeOffset;
                buttonRemove.Enabled = !_selPoint.FreezeOffset;

                // 値設定
                numDragX.Value = (decimal)(_selPoint.Position.X * 100);
                numDragY.Value = (decimal)(_selPoint.Position.Y * 100);
                numDragOffset.Value = (decimal)(_selPoint.Offset * 100);
                buttonColor.BackColor = _selPoint.DrawingColorXrgb;
                numDragAlpha.Value = _selPoint.Alpha;
            }
            finally
            {
                EndControlUpdate();
            }
        }

        /// <summary>
        /// カラーポイントを選択する。
        /// </summary>
        /// <param name="point">選択するカラーポイント。</param>
        private void SelectColorPoint(ColorPoint point)
        {
            // 選択点変更
            if (!_points.Contains(point))
            {
                throw new ArgumentException(
                    "存在しない ColorPoint です。", "point");
            }
            _selPoint = point;

            // ドラッグ強制中断
            EditMarkerDragging = false;

            // 選択点情報の更新
            UpdateSelectedColorPointInfo();

            // ビューの再描画
            pictureView.Invalidate();
        }

        /// <summary>
        /// 現在のカラーポイント設定でコンボボックスアイテムを更新し、
        /// カラーポイントを選択する。
        /// </summary>
        /// <param name="point">選択するカラーポイント。</param>
        /// <remarks>内部で SelectColorPoint を呼び出す。</remarks>
        private void UpdateComboItems(ColorPoint point)
        {
            try
            {
                BeginControlUpdate();

                // アイテム更新
                comboPoint.Items.Clear();
                foreach (ColorPoint cp in _points)
                {
                    comboPoint.Items.Add(cp);
                }
            }
            finally
            {
                EndControlUpdate();
            }

            // 選択
            SelectColorPoint(point);
        }

        /// <summary>
        /// 現在のカラーポイント設定でビュー画像を更新する。
        /// </summary>
        private void UpdateViewImage()
        {
            // ブラシで塗り潰した Bitmap 作成
            var brush = MakeBrushFromColorPoints();
            var bmp = SafeInvoker.Call(() =>
                {
                    var dest = BitmapUtil.CreateRenderTargetBitmap(
                        pictureView.ClientSize.Width,
                        pictureView.ClientSize.Height,
                        brush);
                    dest.Freeze();

                    return BitmapUtil.ConvertToBitmap(dest);
                });

            // ビュー画像変更
            var temp = pictureView.Image;
            pictureView.Image = bmp;
            if (temp != null)
            {
                temp.Dispose();
            }
        }

        private void RadialGradientBrushDialog_Load(object sender, EventArgs e)
        {
            InitializeViewBackground();
            InitializeColorPoints(this.Brush);

            // 色空間コンボボックス選択初期化
            try
            {
                BeginControlUpdate();
                comboCSpace.SelectedIndex =
                    Array.FindIndex(ColorSpaces, (cs) => (cs == _colorSpace));
            }
            finally
            {
                EndControlUpdate();
            }

            UpdateComboItems(_points.Begin);
            UpdateViewImage();
        }

        private void RadialGradientBrushDialog_FormClosing(
            object sender, FormClosingEventArgs e)
        {
            // ドラッグ強制中断
            EditMarkerDragging = false;
        }

        private void RadialGradientBrushDialog_FormClosed(
            object sender, FormClosedEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                // ブラシを反映
                Brush = MakeBrushFromColorPoints();
            }

            // イメージを破棄
            if (pictureView.Image != null)
            {
                pictureView.Image.Dispose();
                pictureView.Image = null;
            }
            if (pictureView.BackgroundImage != null)
            {
                pictureView.BackgroundImage.Dispose();
                pictureView.BackgroundImage = null;
            }
        }

        private void ColorButton_BackColorChanged(object sender, EventArgs e)
        {
            var ctrl = sender as Control;
            if (ctrl != null)
            {
                // ボタン文字列設定
                var c = ctrl.BackColor;
                ctrl.Text =
                    "#" + string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);

                // 前景色変更
                ctrl.ForeColor = (ImageUtil.CalcBrightness(c) < 0.5) ?
                    Drawing::Color.White : Drawing::Color.Black;
            }
        }

        private void buttonMarkColor_Click(object sender, EventArgs e)
        {
            var color = ShowColorDialog(buttonMarkColor.BackColor);
            if (color != null)
            {
                // マーカー色変更
                this.EditMarkerColor = color.Value;
            }
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            if (_selPoint != null)
            {
                var color = ShowColorDialog(buttonColor.BackColor);
                if (color != null)
                {
                    // ボタン背景色設定
                    buttonColor.BackColor = (Drawing::Color)color.Value;

                    // 選択点の色変更
                    _selPoint.DrawingColorXrgb = (Drawing::Color)color.Value;
                    UpdateViewImage();
                }
            }
        }

        private void comboPoint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!ControlUpdating)
            {
                // 選択点変更
                var cp = comboPoint.SelectedItem as ColorPoint;
                if (cp != null)
                {
                    SelectColorPoint(cp);
                }
            }
        }

        private void numDragXY_ValueChanged(object sender, EventArgs e)
        {
            if (!ControlUpdating && _selPoint != null)
            {
                // 選択点の座標変更
                _selPoint.Position = new Point(
                    (double)(numDragX.Value / 100),
                    (double)(numDragY.Value / 100));
                UpdateAllColorPointPositions();
                UpdateViewImage();
            }
        }

        private void numDragOffset_ValueChanged(object sender, EventArgs e)
        {
            if (!ControlUpdating && _selPoint != null)
            {
                // 選択点のオフセット変更
                _selPoint.Offset = (double)(numDragOffset.Value / 100);
                UpdateColorPointPosition(_selPoint);

                // 並び順が変わった可能性があるためコンボボックスも更新
                UpdateComboItems(_selPoint);
                UpdateViewImage();
            }
        }

        private void numDragAlpha_ValueChanged(object sender, EventArgs e)
        {
            if (!ControlUpdating && _selPoint != null)
            {
                // 選択点の不透明度変更
                _selPoint.Alpha = (byte)numDragAlpha.Value;
                UpdateViewImage();
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // 追加
            ColorPoint cp = AddNewColorPoint();
            UpdateComboItems(cp);
            UpdateViewImage();
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (_selPoint != null)
            {
                // 前後の点を取得
                ColorPoint pp = _points.PrevOfId(_selPoint.Id);
                ColorPoint np = _points.NextOfId(_selPoint.Id);
                if (pp == null || np == null)
                {
                    return;
                }

                // 片方が開始点or終端点でもう片方が中間点ならば中間点を、
                // そうでなければ現在の点に近い方を削除後の選択点とする
                ColorPoint cp = null;
                if (pp.FreezeOffset != np.FreezeOffset)
                {
                    cp = pp.FreezeOffset ? np : pp;
                }
                else
                {
                    double diff1 = _selPoint.Offset - pp.Offset;
                    double diff2 = np.Offset - _selPoint.Offset;
                    cp = (diff1 <= diff2) ? pp : np;
                }

                // 削除
                if (_points.Remove(_selPoint))
                {
                    UpdateComboItems(cp);
                    UpdateViewImage();
                }
            }
        }

        private void checkMark_CheckedChanged(object sender, EventArgs e)
        {
            buttonMarkColor.Enabled = checkMark.Checked;
            pictureView.Invalidate();
        }

        private void pictureView_Paint(object sender, PaintEventArgs e)
        {
            if (EditMarkerEnabled)
            {
                var oldSmooth = e.Graphics.SmoothingMode;
                try
                {
                    e.Graphics.SmoothingMode =
                        Drawing2D::SmoothingMode.HighQuality;

                    Drawing::Color color = (Drawing::Color)EditMarkerColor;
                    using (var pen = new Drawing::Pen(color))
                    {
                        Drawing::PointF end = CalcLocationOfView(_points.End);
                        Drawing::PointF center = CalcLocationOfView(CircleCenter);

                        // 開始点と終端点を結ぶ直線描画
                        pen.DashStyle = Drawing2D::DashStyle.Dash;
                        e.Graphics.DrawLine(
                            pen,
                            CalcLocationOfView(_points.Begin),
                            end);

                        // 放射円描画
                        pen.DashStyle = Drawing2D::DashStyle.Solid;
                        double radius = Point2D.Distance(center, end);
                        pen.Color = Drawing::Color.FromArgb(192, color);
                        e.Graphics.DrawEllipse(
                            pen,
                            new Drawing::RectangleF(
                                (float)(center.X - radius),
                                (float)(center.Y - radius),
                                (float)(radius * 2),
                                (float)(radius * 2)));
                        pen.Color = color;

                        if (
                            EditMarkerDragging &&
                            _selPoint != null &&
                            !_selPoint.FreezeOffset)
                        {
                            // ドラッグ中描画
                            pen.DashStyle = Drawing2D::DashStyle.Dash;
                            pen.Color = Drawing::Color.FromArgb(96, color);
                            e.Graphics.DrawLine(
                                pen,
                                _mouseViewPoint,
                                CalcLocationOfView(_selPoint));
                            pen.Color = color;
                        }

                        // カラーポイント位置描画
                        pen.DashStyle = Drawing2D::DashStyle.Solid;
                        foreach (ColorPoint cp in _points)
                        {
                            DrawColorPointToView(e.Graphics, pen, cp);
                        }
                    }
                }
                finally
                {
                    e.Graphics.SmoothingMode = oldSmooth;
                }
            }
        }

        private void pictureView_MouseDown(object sender, MouseEventArgs e)
        {
            if (EditMarkerEnabled && e.Button == MouseButtons.Left)
            {
                _mouseViewPoint = e.Location;

                ColorPoint cp = FindColorPoint(_mouseViewPoint);
                if (cp != null)
                {
                    // 対象カラーポイント選択
                    SelectColorPoint(cp);

                    // 状態保存して位置変更開始
                    _mouseDownPostion = cp.Position;
                    _mouseDownOffset = cp.Offset;
                    EditMarkerDragging = true;
                }
            }
            else if (
                EditMarkerDragging &&
                _selPoint != null &&
                (e.Button == MouseButtons.Right ||
                 e.Button == MouseButtons.Middle))
            {
                // 位置変更キャンセル
                if (_selPoint.FreezeOffset)
                {
                    _selPoint.Position = _mouseDownPostion;
                    UpdateAllColorPointPositions();
                }
                else
                {
                    _selPoint.Offset = _mouseDownOffset;
                    UpdateColorPointPosition(_selPoint);
                }
                EditMarkerDragging = false;

                // 並び順が変わった可能性があるためコンボボックスも更新
                UpdateComboItems(_selPoint);
                UpdateViewImage();
            }
        }

        private void pictureView_MouseMove(object sender, MouseEventArgs e)
        {
            if (EditMarkerDragging && _selPoint != null)
            {
                _mouseViewPoint = e.Location;

                Point pos = CalcPositionOfView(_mouseViewPoint);
                if (_selPoint.FreezeOffset)
                {
                    // 開始点or終端点なら位置設定
                    pos.X = Math.Min(Math.Max(pos.X, 0.0), 1.0);
                    pos.Y = Math.Min(Math.Max(pos.Y, 0.0), 1.0);
                    _selPoint.Position = pos;
                    UpdateAllColorPointPositions();
                }
                else
                {
                    // 中間点なら最も近い位置にオフセット設定
                    // 参考: http://d.hatena.ne.jp/Sampo/20070626/p1
                    Point pb = _points.Begin.Position;
                    Point pe = _points.End.Position;
                    double dot = Point2D.Dot(pb, pe, pos);
                    double distSq = Point2D.DistanceSquare(pb, pe);
                    _selPoint.Offset =
                        Math.Min(Math.Max(dot / distSq, 0.0), 1.0);
                    UpdateColorPointPosition(_selPoint);

                    // カラーポイントの並び順が変わった可能性があるが、
                    // ここにコンボボックス更新を入れてしまうと
                    // ビューボックスの再描画がうまくいかないため、
                    // ドラッグ完了時に更新するようにする。
                    //UpdateComboItems(_selPoint);
                }

                // 選択点情報の更新
                UpdateSelectedColorPointInfo();

                // ビューボックス更新
                UpdateViewImage();
            }
        }

        private void pictureView_MouseUp(object sender, MouseEventArgs e)
        {
            if (EditMarkerDragging && e.Button == MouseButtons.Left)
            {
                // 位置変更終了
                EditMarkerDragging = false;

                // 並び順が変わった可能性があるためコンボボックス更新
                UpdateComboItems(_selPoint);
            }
        }

        private void comboCSpace_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!ControlUpdating)
            {
                int index = comboCSpace.SelectedIndex;
                if (index >= 0 && index < ColorSpaces.Length)
                {
                    // 色空間変更
                    _colorSpace = ColorSpaces[index];
                    UpdateViewImage();
                }
            }
        }
    }
}
