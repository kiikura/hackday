﻿using System;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using NiVE2.Utils;

namespace ruche.nive2.effects.wpf
{
    partial class Nive2PropertyContainerBase
    {
        /// <summary>
        /// PropertyInfo テーブルデータクラス。
        /// </summary>
        public sealed class PropertyInfoTableData
        {
            /// <summary>
            /// コンストラクタ。
            /// </summary>
            /// <param name="subContainers">
            /// サブコンテナプロパティ情報配列。
            /// </param>
            /// <param name="memberTable">
            /// NiVE2プロパティ対応メンバ情報配列。
            /// </param>
            public PropertyInfoTableData(
                ReadOnlyCollection<PropertyInfo> subContainers,
                ReadOnlyDictionary<string, PropertyInfo> memberTable)
            {
                this.SubContainers = subContainers;
                this.MemberTable = memberTable;
            }

            /// <summary>
            /// サブコンテナプロパティ情報配列を取得する。
            /// </summary>
            public ReadOnlyCollection<PropertyInfo> SubContainers
            {
                get; private set;
            }

            /// <summary>
            /// NiVE2プロパティ対応メンバ情報配列を取得する。
            /// </summary>
            public ReadOnlyDictionary<string, PropertyInfo> MemberTable
            {
                get; private set;
            }
        }

        /// <summary>
        /// Type に結び付く PropertyInfo テーブルデータをキャッシュするクラス。
        /// </summary>
        private static class PropertyInfoTableDataCache
        {
            /// <summary>
            /// PropertyInfo テーブルデータのテーブル。
            /// </summary>
            private static Dictionary<Type, PropertyInfoTableData> _dataTable =
                new Dictionary<Type, PropertyInfoTableData>();

            /// <summary>
            /// PropertyInfo テーブルデータを取得する。
            /// </summary>
            /// <param name="ownerType">キャッシュ元のクラス型。</param>
            /// <returns>PropertyInfo テーブルデータ。</returns>
            public static PropertyInfoTableData GetData(Type ownerType)
            {
                if (ownerType == null)
                {
                    throw new ArgumentNullException("ownerType");
                }

                PropertyInfoTableData result;
                if (!_dataTable.TryGetValue(ownerType, out result))
                {
                    result = MakeData(ownerType);
                    _dataTable.Add(ownerType, result);
                }
                return result;
            }

            /// <summary>
            /// PropertyInfo テーブルデータを生成する。
            /// </summary>
            /// <param name="ownerType">キャッシュ元のクラス型。</param>
            /// <returns>PropertyInfo テーブルデータ。</returns>
            private static PropertyInfoTableData MakeData(Type ownerType)
            {
                // 全プロパティ情報を取得
                var infos = ownerType.GetProperties(
                    BindingFlags.Instance |
                    BindingFlags.Public |
                    BindingFlags.NonPublic);

                // 追加先作成
                var subs = new List<PropertyInfo>();
                var members = new Dictionary<string, PropertyInfo>();

                // 追加
                Type contType = typeof(Nive2PropertyContainerBase);
                foreach (var info in infos)
                {
                    var attrs = info.GetCustomAttributes(
                        typeof(Nive2PropertyAttribute),
                        false);
                    if (attrs.Length == 1)
                    {
                        // サブコンテナorメンバテーブルに追加
                        if (contType.IsAssignableFrom(info.PropertyType))
                        {
                            subs.Add(info);
                        }
                        else
                        {
                            var attr = (Nive2PropertyAttribute)attrs[0];
                            members.Add(attr.PropertyName, info);
                        }
                    }
                }

                // データ作成
                return new PropertyInfoTableData(
                    new ReadOnlyCollection<PropertyInfo>(subs),
                    new ReadOnlyDictionary<string, PropertyInfo>(members));
            }
        }

        /// <summary>
        /// PropertyInfo に結び付くデリゲートをキャッシュするクラス。
        /// </summary>
        private static class DelegateCache
        {
            /// <summary>
            /// プロパティの getter デリゲートテーブル。
            /// </summary>
            private static Dictionary<PropertyInfo, Delegate> _getterTable =
                new Dictionary<PropertyInfo, Delegate>();

            /// <summary>
            /// プロパティの setter デリゲートテーブル。
            /// </summary>
            private static Dictionary<PropertyInfo, Delegate> _setterTable =
                new Dictionary<PropertyInfo, Delegate>();

            /// <summary>
            /// プロパティの getter デリゲートを取得する。
            /// </summary>
            /// <param name="info">PropertyInfo 。</param>
            /// <returns>getter デリゲート。</returns>
            public static Delegate GetGetter(PropertyInfo info)
            {
                if (info == null)
                {
                    throw new ArgumentNullException("info");
                }

                Delegate result;
                if (!_getterTable.TryGetValue(info, out result))
                {
                    result = MakeGetter(info);
                    _getterTable.Add(info, result);
                }

                return result;
            }

            /// <summary>
            /// プロパティの setter デリゲートを取得する。
            /// </summary>
            /// <param name="info">PropertyInfo 。</param>
            /// <returns>setter デリゲート。</returns>
            public static Delegate GetSetter(PropertyInfo info)
            {
                if (info == null)
                {
                    throw new ArgumentNullException("info");
                }

                Delegate result;
                if (!_setterTable.TryGetValue(info, out result))
                {
                    result = MakeSetter(info);
                    _setterTable.Add(info, result);
                }

                return result;
            }

            /// <summary>
            /// プロパティの getter デリゲートを生成する。
            /// </summary>
            /// <param name="info">PropertyInfo 。</param>
            /// <returns>getter デリゲート。</returns>
            private static Delegate MakeGetter(PropertyInfo info)
            {
                if (info == null)
                {
                    throw new ArgumentNullException("info");
                }

                // getter の MethodInfo 取得
                var getterInfo = info.GetGetMethod(true);

                // getter デリゲート作成
                var selfExp = Expression.Parameter(info.ReflectedType, "self");
                var getterCallExp = Expression.Call(selfExp, getterInfo);
                var getterExp = Expression.Lambda(getterCallExp, selfExp);

                return getterExp.Compile();
            }

            /// <summary>
            /// プロパティの setter デリゲートを生成する。
            /// </summary>
            /// <param name="info">PropertyInfo 。</param>
            /// <returns>setter デリゲート。</returns>
            private static Delegate MakeSetter(PropertyInfo info)
            {
                if (info == null)
                {
                    throw new ArgumentNullException("info");
                }

                // setter の MethodInfo 取得
                var setterInfo = info.GetSetMethod(true);

                // setter デリゲート作成
                var selfExp = Expression.Parameter(info.ReflectedType, "self");
                var valueExp = Expression.Parameter(info.PropertyType, "value");
                var setterCallExp =
                    Expression.Call(selfExp, setterInfo, valueExp);
                var setterExp =
                    Expression.Lambda(setterCallExp, selfExp, valueExp);

                return setterExp.Compile();
            }
        }
    }
}
