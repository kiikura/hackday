﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// マルチテキストエフェクトプロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class MultiTextEffectPropertyContainer
        :
        Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public MultiTextEffectPropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("texts")]
        public FormattedTextPropertyContainer[] Texts { get; set; }

        [Nive2Property]
        public TextStylePropertyContainer Style { get; set; }

        [Nive2Property]
        public TextSpeakPropertyContainer Speak { get; set; }

        [Nive2Property("variables")]
        public TextVariablePropertyContainer[] Variables { get; set; }

        [Nive2Property("tags")]
        public TextStylePropertyContainer[] Tags { get; set; }

        [Nive2Property]
        public TextPostPropertyContainer BackgroundPost { get; set; }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextOptionPropertyContainer Clone()
        {
            return (TextOptionPropertyContainer)base.Clone();
        }
    }
}
