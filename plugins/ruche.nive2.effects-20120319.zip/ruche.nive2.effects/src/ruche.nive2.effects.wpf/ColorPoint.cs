﻿using System;
using System.Windows;
using System.Windows.Media;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// カラーポイントを表すクラス。
    /// </summary>
    internal class ColorPoint : IComparable<ColorPoint>
    {
        /// <summary>
        /// グラデーションストップ値。
        /// </summary>
        private GradientStop _value = new GradientStop(Colors.Black, 0);

        /// <summary>
        /// 位置。
        /// </summary>
        private Point _position;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="id">ID値。</param>
        public ColorPoint(int id)
        {
            Id = id;
            Name = id.ToString();
            Position = new Point();
            FreezeOffset = false;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <param name="offset">オフセット値。</param>
        /// <param name="color">色。</param>
        public ColorPoint(int id, double offset, Color color)
            : this(id, offset, color, false)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <param name="offset">オフセット値。</param>
        /// <param name="color">色。</param>
        /// <param name="freezeOffset">
        /// オフセット値を変更不可にするならば true 。
        /// </param>
        public ColorPoint(
            int id, double offset, Color color, bool freezeOffset)
            : this(id)
        {
            Offset = offset;
            Color = color;
            Position = new Point(Offset, Offset);
            FreezeOffset = freezeOffset;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public ColorPoint(ColorPoint src)
            : this(src.Id, src.Offset, src.Color, src.FreezeOffset)
        {
            Name = src.Name;
            Value = src.Value;
        }

        /// <summary>
        /// ID値を取得する。
        /// </summary>
        public int Id { get; protected set; }

        /// <summary>
        /// 名前を取得または設定する。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// グラデーションストップ値を取得または設定する。
        /// </summary>
        /// <remarks>値の設定時にはクローンを作成する。</remarks>
        public GradientStop Value
        {
            get
            {
                return _value;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value");
                }

                SafeInvoker.Call(value, () =>
                {
                    double offset = _value.Offset;
                    _value = value.Clone();

                    if (FreezeOffset)
                    {
                        _value.Offset = offset;
                    }
                    else if (_value.Offset != offset && OffsetChanged != null)
                    {
                        OffsetChanged(this, EventArgs.Empty);
                    }
                });
            }
        }

        /// <summary>
        /// オフセット値を取得または設定する。
        /// </summary>
        public double Offset
        {
            get
            {
                return Value.Offset;
            }
            set
            {
                if (!FreezeOffset)
                {
                    double offset = Math.Min(Math.Max(value, 0.0), 1.0);
                    if (offset != Value.Offset)
                    {
                        Value.Offset = offset;

                        if (OffsetChanged != null)
                        {
                            OffsetChanged(this, EventArgs.Empty);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 色を取得または設定する。
        /// </summary>
        public Color Color
        {
            get { return Value.Color; }
            set { Value.Color = value; }
        }

        /// <summary>
        /// 不透明度を取得または設定する。
        /// </summary>
        public byte Alpha
        {
            get
            {
                return Color.A;
            }
            set
            {
                Color c = Color;
                c.A = value;
                Color = c;
            }
        }

        /// <summary>
        /// 不透明度を 0.0 ～ 1.0 の実数値で取得または設定する。
        /// </summary>
        public double AlphaRate
        {
            get { return Alpha / 255.0; }
            set { Alpha = (byte)Math.Min(value * 255 + 0.5, 255.0); }
        }

        /// <summary>
        /// 不透明度を含まない色を
        /// System.Drawing.Color で取得または設定する。
        /// </summary>
        public Drawing::Color DrawingColorXrgb
        {
            get
            {
                return Drawing::Color.FromArgb(Color.R, Color.G, Color.B);
            }
            set
            {
                Color = Color.FromArgb(Alpha, value.R, value.G, value.B);
            }
        }

        /// <summary>
        /// 不透明度を含まない色のRGB値を取得または設定する。
        /// </summary>
        public int ColorXrgbValue
        {
            get
            {
                return (
                    ((int)Color.B << 0) |
                    ((int)Color.G << 8) |
                    ((int)Color.R << 16));
            }
            set
            {
                Color = Color.FromArgb(
                    Alpha,
                    (byte)((value & 0xFF0000) >> 16),
                    (byte)((value & 0x00FF00) >> 8),
                    (byte)((value & 0x0000FF) >> 0));
            }
        }

        /// <summary>
        /// 位置を取得または設定する。
        /// 開始点または終端点の場合のみ意味を持つ。
        /// </summary>
        public Point Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = new Point(
                    Math.Min(Math.Max(value.X, 0.0), 1.0),
                    Math.Min(Math.Max(value.Y, 0.0), 1.0));
            }
        }

        /// <summary>
        /// オフセット値を固定するか否かを取得する。
        /// </summary>
        public bool FreezeOffset { get; protected set; }

        /// <summary>
        /// オフセット値が変更されたときに発生するイベント。
        /// </summary>
        public event EventHandler OffsetChanged;

        /// <summary>
        /// このカラーポイントのクローンを作成する。
        /// </summary>
        /// <returns>新しいカラーポイント。</returns>
        public ColorPoint Clone()
        {
            return new ColorPoint(this);
        }

        public override string ToString()
        {
            return string.Format("Id = {0}, Offset = {1}", Id, Offset);
        }

        #region IComparable<ColorPoint> メンバ

        public int CompareTo(ColorPoint other)
        {
            if (other == null)
            {
                return 1;
            }
            if (this.Offset != other.Offset)
            {
                return (this.Offset > other.Offset) ? 1 : -1;
            }
            if (this.ColorXrgbValue != other.ColorXrgbValue)
            {
                return (this.ColorXrgbValue - other.ColorXrgbValue);
            }
            return 0;
        }

        #endregion
    }
}
