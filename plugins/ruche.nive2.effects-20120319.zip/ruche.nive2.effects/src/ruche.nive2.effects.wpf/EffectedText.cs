﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Media;
using System.Windows.Media.Effects;
using ruche.text;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストとそれに付随するパラメータを保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class EffectedText : ICloneable
    {
        /// <summary>
        /// タグ情報を変換するデリゲート。
        /// </summary>
        /// <param name="tagInfo">タグ情報。</param>
        /// <returns>変換されたタグ情報。</returns>
        private delegate TagInfo TagInfoConverter(TagInfo tagInfo);

        /// <summary>
        /// タグ属性値を変換して適用するデリゲート。
        /// </summary>
        /// <param name="attrName">タグ属性名。</param>
        /// <param name="attrValue">タグ属性値。</param>
        /// <param name="container">適用先コンテナ。</param>
        private delegate void TagAttrConverter(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container);

        #region static フィールド

        /// <summary>
        /// 標準の数値文字列スタイル。
        /// </summary>
        private const NumberStyles NumberStyle =
            NumberStyles.Float & ~NumberStyles.AllowExponent;

        /// <summary>
        /// 標準の数値文字列フォーマット情報。
        /// </summary>
        private static readonly IFormatProvider NumberFormat =
            NumberFormatInfo.InvariantInfo;

        /// <summary>
        /// 特殊タグ名とそのタグ情報コンバータのテーブル。
        /// </summary>
        private static readonly Dictionary<string, TagInfoConverter>
            TagInfoConverterTable;

        /// <summary>
        /// テキストスタイルのタグ属性名とその属性コンバータのテーブル。
        /// </summary>
        private static readonly Dictionary<string, TagAttrConverter>
            StyleAttrConverterTable;

        /// <summary>
        /// テキスト表示速度のタグ属性名とその属性コンバータのテーブル。
        /// </summary>
        private static readonly Dictionary<string, TagAttrConverter>
            SpeakAttrConverterTable;

        /// <summary>
        /// 16進数表記の色表記を表す正規表現。
        /// </summary>
        private static readonly Regex RegexHexColor;

        /// <summary>
        /// RGB色表記を表す正規表現。
        /// </summary>
        private static readonly Regex RegexRgbColor;

        /// <summary>
        /// RGBA色表記を表す正規表現。
        /// </summary>
        private static readonly Regex RegexRgbaColor;

        /// <summary>
        /// ARGB色表記を表す正規表現。
        /// </summary>
        private static readonly Regex RegexArgbColor;

        /// <summary>
        /// 連続した空白文字を表す正規表現。
        /// </summary>
        private static readonly Regex RegexSpace;

        /// <summary>
        /// 割合値への変換倍率とそれに対応する単位文字列のテーブル。
        /// </summary>
        private static readonly Dictionary<double, string[]> RateUnitTable;

        /// <summary>
        /// ピクセルサイズ値への変換倍率とそれに対応する単位文字列のテーブル。
        /// </summary>
        private static readonly Dictionary<double, string[]> PixelSizeUnitTable;

        /// <summary>
        /// ミリ秒値への変換倍率とそれに対応する単位文字列のテーブル。
        /// </summary>
        private static readonly Dictionary<double, string[]> MsecUnitTable;

        #endregion

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static EffectedText()
        {
            #region コンバータテーブル

            TagInfoConverterTable = new Dictionary<string, TagInfoConverter>()
                {
                    { "scale",                  ConvertCommonTagInfo        },
                    { "margin",                 ConvertCommonTagInfo        },
                    { "font",                   ConvertFontTagInfo          },
                    { "fill",                   ConvertCommonTagInfo        },
                    { "edge",                   ConvertCommonTagInfo        },
                    { "u",                      ConvertUnderlineTagInfo     },
                    { "underline",              ConvertDecorationTagInfo    },
                    { "s",                      ConvertStrikeTagInfo        },
                    { "strike",                 ConvertDecorationTagInfo    },
                    { "dot",                    ConvertDecorationTagInfo    },
                    { "shadow",                 ConvertCommonTagInfo        },

                    { "speak",                  ConvertCommonTagInfo        },
                    { "w",                      ConvertSpeakTagInfo         },
                    { "ww",                     ConvertSpeakTagInfo         },
                    { "www",                    ConvertSpeakTagInfo         },
                    { "wwww",                   ConvertSpeakTagInfo         },
                    { "wwwww",                  ConvertSpeakTagInfo         },
                    { "wwwwww",                 ConvertSpeakTagInfo         },
                    { "wwwwwww",                ConvertSpeakTagInfo         },
                    { "wwwwwwww",               ConvertSpeakTagInfo         },
                };

            StyleAttrConverterTable = new Dictionary<string, TagAttrConverter>()
                {
                    { "valign",                 ConvertValignAttr           },
                    { "scale.x",                ConvertPercentAttr          },
                    { "scale.y",                ConvertPercentAttr          },
                    { "scale",                  ConvertScaleAttr            },
                    { "margin.top",             ConvertPixelSizeAttr        },
                    { "margin.bottom",          ConvertPixelSizeAttr        },
                    { "margin.left",            ConvertPixelSizeAttr        },
                    { "margin.right",           ConvertPixelSizeAttr        },
                    { "margin",                 ConvertMarginAttr           },
                    { "font.family",            ConvertFontFamilyAttr       },
                    { "font.size",              ConvertPixelSizeAttr        },
                    { "font.weight",            ConvertFontWeightAttr       },
                    { "font.style",             ConvertFontStyleAttr        },
                    { "font",                   ConvertFontAttr             },
                    { "fill.color",             ConvertColorAttr            },
                    { "fill",                   ConvertFillAttr             },
                    { "edge.color",             ConvertColorAttr            },
                    { "edge.width",             ConvertPixelSizeAttr        },
                    { "edge.type",              ConvertLineJoinAttr         },
                    { "edge",                   ConvertEdgeAttr             },
                    { "underline.color",        ConvertColorAttr            },
                    { "underline.width",        ConvertPixelSizeAttr        },
                    { "underline.width.min",    ConvertWidthMinAttr         },
                    { "underline.cap",          ConvertLineCapAttr          },
                    { "underline.pattern",      ConvertNumberArrayAttr      },
                    { "underline.offset",       ConvertPercentAttr          },
                    { "underline.z",            ConvertNumberAttr           },
                    { "underline",              ConvertLineDecorationAttr   },
                    { "strike.color",           ConvertColorAttr            },
                    { "strike.width",           ConvertPixelSizeAttr        },
                    { "strike.width.min",       ConvertWidthMinAttr         },
                    { "strike.cap",             ConvertLineCapAttr          },
                    { "strike.pattern",         ConvertNumberArrayAttr      },
                    { "strike.offset",          ConvertPercentAttr          },
                    { "strike.z",               ConvertNumberAttr           },
                    { "strike",                 ConvertLineDecorationAttr   },
                    { "dot.color",              ConvertColorAttr            },
                    { "dot.width",              ConvertPixelSizeAttr        },
                    { "dot.width.min",          ConvertWidthMinAttr         },
                    { "dot.offset",             ConvertPercentAttr          },
                    { "dot.z",                  ConvertNumberAttr           },
                    { "dot",                    ConvertDotAttr              },
                    { "shadow.color",           ConvertSingleColorAttr      },
                    { "shadow.dir",             ConvertNumberAttr           },
                    { "shadow.depth",           ConvertPixelSizeAttr        },
                    { "shadow.blur",            ConvertPixelSizeAttr        },
                    { "shadow.quality",         ConvertRenderingBiasAttr    },
                    { "shadow",                 ConvertShadowAttr           },
                };

            SpeakAttrConverterTable = new Dictionary<string, TagAttrConverter>()
                {
                    { "speak.wait",             ConvertTimeSpanAttr         },
                    { "speak.letter",           ConvertTimeSpanAttr         },
                    { "speak.row",              ConvertTimeSpanAttr         },
                    { "speak.fadein",           ConvertTimeSpanAttr         },
                };

            #endregion

            #region 正規表現

            RegexHexColor = new Regex(
                @"^(#|0x)(?<Hex>[0-9a-f]{3,8})$",
                RegexOptions.CultureInvariant |
                RegexOptions.IgnoreCase |
                RegexOptions.ExplicitCapture);

            RegexRgbColor = new Regex(
                @"^RGB\s*\(\s*(?<R>\d+)\s*,\s*(?<G>\d+)\s*,\s*(?<B>\d+)\s*\)$",
                RegexOptions.CultureInvariant |
                RegexOptions.IgnoreCase |
                RegexOptions.ExplicitCapture);

            RegexRgbaColor = new Regex(
                @"^RGBA\s*\(\s*(?<R>\d+)\s*,\s*(?<G>\d+)\s*," +
                @"\s*(?<B>\d+)\s*,\s*(?<A>\d+)\s*\)$",
                RegexOptions.CultureInvariant |
                RegexOptions.IgnoreCase |
                RegexOptions.ExplicitCapture);

            RegexArgbColor = new Regex(
                @"^ARGB\s*\(\s*(?<A>\d+)\s*,\s*(?<R>\d+)\s*," +
                @"\s*(?<G>\d+)\s*,\s*(?<B>\d+)\s*\)$",
                RegexOptions.CultureInvariant |
                RegexOptions.IgnoreCase |
                RegexOptions.ExplicitCapture);

            RegexSpace = new Regex(@"\s+");

            #endregion

            #region 数値単位テーブル

            RateUnitTable = new Dictionary<double, string[]>()
                {
                    { 1 /   1.0, new string[] { "em" }      },
                    { 1 / 100.0, new string[] { "%", "％" } },
                };

            PixelSizeUnitTable = new Dictionary<double, string[]>()
                {
                    { 96 / 96.00, new string[] { "px", "pixel" } },
                    { 96 / 72.00, new string[] { "pt", "point" } },
                    { 96 / 25.40, new string[] { "mm" }          },
                    { 96 /  6.00, new string[] { "pc", "pica" }  },
                    { 96 /  2.54, new string[] { "cm" }          },
                    { 96 /  1.00, new string[] { "in", "inch" }  },
                };

            MsecUnitTable = new Dictionary<double, string[]>()
                {
                    {  1000, new string[] { "s", "sec" }   },
                    {     1, new string[] { "ms", "msec" } },
                    { 60000, new string[] { "m", "min" }   },
                };

            #endregion
        }

        /// <summary>
        /// タグテキストからインスタンスを生成する。
        /// </summary>
        /// <param name="src">タグテキスト。</param>
        /// <param name="style">既定のスタイル。</param>
        /// <param name="speak">既定の表示速度。</param>
        /// <param name="styleTags">
        /// スタイルタグコレクション。不要ならば null 。
        /// </param>
        /// <returns>新しいインスタンス。</returns>
        /// <remarks>
        /// タグテキストがテキストを持たない場合、空のテキストで初期化される。
        /// </remarks>
        public static EffectedText FromTaggedText(
            TaggedText src,
            TextStylePropertyContainer style,
            TextSpeakPropertyContainer speak,
            TextStyleTagCollection styleTags)
        {
            if (src == null)
            {
                throw new ArgumentNullException("src");
            }

            var dest = new EffectedText(src.Text, style, speak);
            dest.Apply(src.TagInfos, styleTags);

            return dest;
        }

        #region コンバートメソッド

        private static TagInfo ConvertCommonTagInfo(TagInfo tagInfo)
        {
            TagInfo dest = tagInfo;

            if (tagInfo.AttrCount > 0)
            {
                // 未定義の属性名を [タグ名].[属性名] に変換
                Dictionary<string, string> attrTable =
                    new Dictionary<string, string>(tagInfo.AttrCount);
                foreach (var kv in tagInfo)
                {
                    string attrName = kv.Key;
                    if (
                        !StyleAttrConverterTable.ContainsKey(attrName) &&
                        !SpeakAttrConverterTable.ContainsKey(attrName))
                    {
                        attrName = tagInfo.TagName + "." + attrName;
                    }
                    attrTable[attrName] = kv.Value;
                }
                dest = new TagInfo(tagInfo.TagName, attrTable);
            }

            return dest;
        }

        private static TagInfo ConvertFontTagInfo(TagInfo tagInfo)
        {
            TagInfo dest = ConvertCommonTagInfo(tagInfo);

            if (tagInfo.AttrNames.Contains("color"))
            {
                var attrTable = dest.GetAttrTable();
                attrTable["fill.color"] = tagInfo["color"];
                dest = new TagInfo(dest.TagName, attrTable);
            }

            return dest;
        }

        private static TagInfo ConvertDecorationTagInfo(TagInfo tagInfo)
        {
            // width と width.min が指定されていなければ width.min を 1 にする
            if (
                !tagInfo.AttrNames.Contains("width") &&
                !tagInfo.AttrNames.Contains("width.min"))
            {
                var attrTable = tagInfo.GetAttrTable();
                attrTable["width.min"] = "1";
                tagInfo = new TagInfo(tagInfo.TagName, attrTable);                    
            }

            return ConvertCommonTagInfo(tagInfo);
        }

        private static TagInfo ConvertUnderlineTagInfo(TagInfo tagInfo)
        {
            // underline タグとして処理した後、元のタグ名に戻す
            return new TagInfo(
                tagInfo.TagName,
                ConvertDecorationTagInfo(new TagInfo("underline", tagInfo)));
        }

        private static TagInfo ConvertStrikeTagInfo(TagInfo tagInfo)
        {
            // strike タグとして処理した後、元のタグ名に戻す
            return new TagInfo(
                tagInfo.TagName,
                ConvertDecorationTagInfo(new TagInfo("strike", tagInfo)));
        }

        private static TagInfo ConvertSpeakTagInfo(TagInfo tagInfo)
        {
            // タグ名の長さ×250msを wait 属性に設定
            int letterMsec = tagInfo.TagName.Length * 250;
            var attrTable =
                new Dictionary<string, string>()
                {
                    { "wait", letterMsec.ToString() },
                };

            // その他の属性を設定
            foreach (var kv in tagInfo)
            {
                attrTable[kv.Key] = kv.Value;
            }

            // speak タグとして処理した後、元のタグ名に戻す
            return new TagInfo(
                tagInfo.TagName,
                ConvertCommonTagInfo(new TagInfo("speak", attrTable)));
        }

        private static void ConvertValignAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            TextVerticalAlignment valign;
            switch (value)
            {
            case "top":
                valign = TextVerticalAlignment.Top;
                break;

            case "center":
                valign = TextVerticalAlignment.Center;
                break;

            case "baseline":
                valign = TextVerticalAlignment.Baseline;
                break;

            case "bottom":
                valign = TextVerticalAlignment.Bottom;
                break;

            default:
                return;
            }

            container.TrySetValue(attrName, valign, false);
        }

        private static void ConvertPercentAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            double? per;
            if (TryParsePercent(attrValue, out per) && per != null)
            {
                container.TrySetValue(attrName, per, false);
            }
        }

        private static void ConvertScaleAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value);
            switch (vals.Length)
            {
            case 1:
                vals = new string[] { vals[0], vals[0] };
                break;

            case 2:
                break;

            default:
                return;
            }

            bool parseOk = true;
            double?[] pers = Array.ConvertAll(
                vals,
                v =>
                {
                    double? per;
                    parseOk &= TryParsePercent(v, out per);
                    return per;
                });

            if (parseOk)
            {
                var names = new string[] { ".x", ".y" };
                for (int i = 0; i < names.Length; ++i)
                {
                    if (pers[i] != null)
                    {
                        container.TrySetValue(
                            attrName + names[i],
                            pers[i],
                            false);
                    }
                }
            }
        }

        private static void ConvertPixelSizeAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            double? size;
            if (TryParsePixelSize(attrValue, out size) && size != null)
            {
                container.TrySetValue(attrName, size, false);
            }
        }

        private static void ConvertMarginAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value);
            switch (vals.Length)
            {
            case 1:
                vals = new string[] { vals[0], vals[0], vals[0], vals[0] };
                break;

            case 2:
                vals = new string[] { vals[0], vals[1], vals[0], vals[1] };
                break;

            case 3:
                vals = new string[] { vals[0], vals[1], vals[2], vals[1] };
                break;

            case 4:
                break;
            }

            bool parseOk = true;
            double?[] sizes = Array.ConvertAll(
                vals,
                v =>
                {
                    double? size;
                    parseOk &= TryParsePixelSize(v, out size);
                    return size;
                });

            if (parseOk)
            {
                var names =
                    new string[] { ".top", ".right", ".bottom", ".left" };
                for (int i = 0; i < names.Length; ++i)
                {
                    if (sizes[i] != null)
                    {
                        container.TrySetValue(
                            attrName + names[i],
                            sizes[i],
                            false);
                    }
                }
            }
        }

        private static void ConvertFontFamilyAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            try
            {
                var ff = new FontFamily(value.Trim());
                container.TrySetValue(
                    attrName,
                    TextEffectUtil.GetFontFamilyName(ff),
                    false);
            }
            catch { }
        }

        private static void ConvertFontWeightAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            FontWeightType? type;
            if (
                TryParseFontWeightType(attrValue, true, out type) &&
                type != null)
            {
                container.TrySetValue(attrName, type, false);
            }
        }

        private static void ConvertFontStyleAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            FontStyleType? type;
            if (TryParseFontStyleType(attrValue, out type) && type != null)
            {
                container.TrySetValue(attrName, type, false);
            }
        }

        private static void ConvertFontAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value, 4);

            bool[] oks = { false, false, false };
            FontStyleType? style = null;
            FontWeightType? weight = null;
            double? size = null;
            string family = null;
            for (int i = 0; i < vals.Length; ++i)
            {
                if (!oks[0])
                {
                    oks[0] = TryParseFontStyleType(vals[i], out style);
                    if (oks[0]) { continue; }
                }
                if (!oks[1])
                {
                    oks[1] = TryParseFontWeightType(vals[i], false, out weight);
                    if (oks[1]) { continue; }
                }
                if (!oks[2])
                {
                    oks[2] = TryParsePixelSize(vals[i], out size);
                    if (oks[2]) { continue; }
                }

                var ffs = string.Join(" ", vals, i, vals.Length - i);
                try
                {
                    var ff = new FontFamily(ffs);
                    family = TextEffectUtil.GetFontFamilyName(ff);
                }
                catch
                {
                    return;
                }
                break;
            }
            if (!oks[1] && style == FontStyleType.Normal)
            {
                weight = FontWeightType.Normal;
            }

            if (style != null)
            {
                container.TrySetValue(attrName + ".style", style, false);
            }
            if (weight != null)
            {
                container.TrySetValue(attrName + ".weight", weight, false);
            }
            if (size != null)
            {
                container.TrySetValue(attrName + ".size", size, false);
            }
            if (family != null)
            {
                container.TrySetValue(attrName + ".family", family, false);
            }
        }

        private static void ConvertColorAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            Brush brush;
            if (TryParseBrush(attrValue, false, out brush) && brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName,
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertFillAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            ConvertColorAttr(attrName + ".color", attrValue, container);
        }

        private static void ConvertLineJoinAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            PenLineJoin? join;
            if (TryParseLineJoin(attrValue, out join) && join != null)
            {
                container.TrySetValue(attrName, join, false);
            }
        }

        private static void ConvertEdgeAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value, 3);

            bool[] oks = { false, false };
            PenLineJoin? join = null;
            double? width = null;
            Brush brush = null;
            for (int i = 0; i < vals.Length; ++i)
            {
                if (!oks[0])
                {
                    oks[0] = TryParseLineJoin(vals[i], out join);
                    if (oks[0]) { continue; }
                }
                if (!oks[1])
                {
                    oks[1] = TryParsePixelSize(vals[i], out width);
                    if (oks[1]) { continue; }
                }

                var cval = string.Join(" ", vals, i, vals.Length - i);
                if (!TryParseBrush(cval, false, out brush))
                {
                    return;
                }
                break;
            }

            if (join != null)
            {
                container.TrySetValue(attrName + ".type", join, false);
            }
            if (width != null)
            {
                container.TrySetValue(attrName + ".width", width, false);
            }
            if (brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName + ".color",
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertWidthMinAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            // 対象属性名を取得
            // 属性名から最後の '.' 以降を除いたものが対象属性名
            int dotMinPos = attrName.LastIndexOf('.');
            if (dotMinPos <= 0)
            {
                return;
            }
            string targetAttrName = attrName.Substring(0, dotMinPos);

            // 対象属性の現在値を取得
            double? width;
            if (!container.TryGetValue(targetAttrName, out width, false))
            {
                return;
            }

            // 指定値を取得
            double? widthMin;
            if (!TryParsePixelSize(attrValue, out widthMin) || widthMin == null)
            {
                return;
            }

            // 現在値が指定値未満ならば更新
            if (width == null || width < widthMin)
            {
                container.TrySetValue(targetAttrName, widthMin, false);
            }
        }

        private static void ConvertLineCapAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            PenLineCap? cap;
            if (TryParseLineCap(attrValue, out cap) && cap != null)
            {
                container.TrySetValue(attrName, cap, false);
            }
        }

        private static void ConvertNumberArrayAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value);
            bool parseOk = true;
            double[] nums = Array.ConvertAll(
                vals,
                v =>
                {
                    double num;
                    parseOk &=
                        double.TryParse(v, NumberStyle, NumberFormat, out num);
                    return num;
                });

            if (parseOk)
            {
                container.TrySetValue(attrName, nums, false);
            }
        }

        private static void ConvertNumberAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            double? num;
            if (TryParseNumber(attrValue, out num) && num != null)
            {
                container.TrySetValue(attrName, num, false);
            }
        }

        private static void ConvertLineDecorationAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value, 4);

            bool[] oks = { false, false };
            PenLineCap? cap = null;
            double? width = null;
            Brush brush = null;
            for (int i = 0; i < vals.Length; ++i)
            {
                if (!oks[0])
                {
                    oks[0] = TryParseLineCap(vals[i], out cap);
                    if (oks[0]) { continue; }
                }
                if (!oks[1])
                {
                    oks[1] = TryParsePixelSize(vals[i], out width);
                    if (oks[1]) { continue; }
                }

                var cval = string.Join(" ", vals, i, vals.Length - i);
                if (!TryParseBrush(cval, false, out brush))
                {
                    return;
                }
                break;
            }

            if (cap != null)
            {
                container.TrySetValue(attrName + ".cap", cap, false);
            }
            if (width != null)
            {
                container.TrySetValue(attrName + ".width", width, false);
            }
            if (brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName + ".color",
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertDotAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value, 3);

            bool[] oks = { false };
            double? width = null;
            Brush brush = null;
            for (int i = 0; i < vals.Length; ++i)
            {
                if (!oks[0])
                {
                    oks[0] = TryParsePixelSize(vals[i], out width);
                    if (oks[0]) { continue; }
                }

                var cval = string.Join(" ", vals, i, vals.Length - i);
                if (!TryParseBrush(cval, false, out brush))
                {
                    return;
                }
                break;
            }

            if (width != null)
            {
                container.TrySetValue(attrName + ".width", width, false);
            }
            if (brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName + ".color",
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertSingleColorAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            Brush brush;
            if (TryParseBrush(attrValue, true, out brush) && brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName,
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertRenderingBiasAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            RenderingBias? bias;
            if (TryParseRenderingBias(attrValue, out bias) && bias != null)
            {
                container.TrySetValue(attrName, bias, false);
            }
        }

        private static void ConvertShadowAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            var value = attrValue.Trim().ToLower();
            if (value.Length == 0 || IsInheritValue(value))
            {
                return;
            }

            var vals = RegexSpace.Split(value, 4);

            bool[] oks = { false, false, false };
            RenderingBias? bias = null;
            double? dir = null;
            double? depth = null;
            Brush brush = null;
            for (int i = 0; i < vals.Length; ++i)
            {
                if (!oks[0])
                {
                    oks[0] = TryParseRenderingBias(vals[i], out bias);
                    if (oks[0]) { continue; }
                }
                if (!oks[1])
                {
                    oks[1] = TryParseNumber(vals[i], out dir);
                    if (oks[1]) { continue; }
                }
                if (!oks[2])
                {
                    oks[2] = TryParsePixelSize(vals[i], out depth);
                    if (oks[2]) { continue; }
                }

                var cval = string.Join(" ", vals, i, vals.Length - i);
                if (!TryParseBrush(cval, true, out brush))
                {
                    return;
                }
                break;
            }

            if (bias != null)
            {
                container.TrySetValue(attrName + ".quality", bias, false);
            }
            if (dir != null)
            {
                container.TrySetValue(attrName + ".dir", dir, false);
            }
            if (depth != null)
            {
                container.TrySetValue(attrName + ".depth", depth, false);
            }
            if (brush != null)
            {
                brush.SafeFreeze();
                container.TrySetValue(
                    attrName + ".color",
                    new XamlSerializable<Brush>(brush),
                    false);
            }
        }

        private static void ConvertTimeSpanAttr(
            string attrName,
            string attrValue,
            Nive2PropertyContainerBase container)
        {
            double? msec;
            if (TryParseMsec(attrValue, out msec) && msec != null)
            {
                container.TrySetValue(attrName, msec, false);
            }
        }

        #endregion

        #region 属性値のパース

        /// <summary>
        /// 親の値を継承することを表す文字列であるか否かを調べる。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <returns>
        /// 文字列が "inherit" または "auto" ならば true 。
        /// そうでなければ false 。
        /// </returns>
        private static bool IsInheritValue(string value)
        {
            return (
                value.Equals("inherit", StringComparison.OrdinalIgnoreCase) ||
                value.Equals("auto", StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// 文字列をパーセント値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="percent">
        /// パーセント値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParsePercent(string value, out double? percent)
        {
            percent = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            double rate = 1;
            foreach (var kv in RateUnitTable)
            {
                var unit = Array.Find(
                    kv.Value,
                    u => value.EndsWith(u, StringComparison.Ordinal));
                if (unit != null)
                {
                    rate = kv.Key;
                    value = value.Remove(value.Length - unit.Length);
                    break;
                }
            }

            double s;
            if (double.TryParse(value, NumberStyle, NumberFormat, out s))
            {
                percent = s * rate * 100;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列をピクセルサイズ値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="size">
        /// ピクセルサイズ値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParsePixelSize(string value, out double? size)
        {
            size = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            double rate = 1;
            foreach (var kv in PixelSizeUnitTable)
            {
                var unit = Array.Find(
                    kv.Value,
                    u => value.EndsWith(u, StringComparison.Ordinal));
                if (unit != null)
                {
                    rate = kv.Key;
                    value = value.Remove(value.Length - unit.Length);
                    break;
                }
            }

            double s;
            if (double.TryParse(value, NumberStyle, NumberFormat, out s))
            {
                size = s * rate;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列をミリ秒値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="msec">
        /// ミリ秒値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseMsec(string value, out double? msec)
        {
            msec = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            double rate = 1;
            foreach (var kv in MsecUnitTable)
            {
                var unit = Array.Find(
                    kv.Value,
                    u => value.EndsWith(u, StringComparison.Ordinal));
                if (unit != null)
                {
                    rate = kv.Key;
                    value = value.Remove(value.Length - unit.Length);
                    break;
                }
            }

            double s;
            if (double.TryParse(value, NumberStyle, NumberFormat, out s))
            {
                msec = s * rate;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列を数値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="number">
        /// 数値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseNumber(string value, out double? number)
        {
            number = null;

            value = value.Trim();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            double s;
            if (double.TryParse(value, NumberStyle, NumberFormat, out s))
            {
                number = s;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列をフォントの太さタイプ値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="allowNumber">
        /// 数値による指定を有効にするならば true 。
        /// </param>
        /// <param name="type">
        /// フォントの太さタイプ値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseFontWeightType(
            string value,
            bool allowNumber,
            out FontWeightType? type)
        {
            type = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            switch (value)
            {
            case "normal":
            case "regular":
            case "medium":
                type = FontWeightType.Normal;
                return true;

            case "bold":
            case "heavy":
                type = FontWeightType.Bold;
                return true;
            }

            if (allowNumber)
            {
                double w;
                if (double.TryParse(value, NumberStyle, NumberFormat, out w))
                {
                    type = (w > TextEffectUtil.NormalFontWeightMax) ?
                        FontWeightType.Bold :
                        FontWeightType.Normal;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 文字列をフォントスタイルタイプ値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="type">
        /// フォントスタイルタイプ値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseFontStyleType(
            string value,
            out FontStyleType? type)
        {
            type = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            switch (value)
            {
            case "normal":
                type = FontStyleType.Normal;
                return true;

            case "italic":
                type = FontStyleType.Italic;
                return true;

            case "oblique":
                type = FontStyleType.Oblique;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列をブラシに変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="solidOnly">単色のみをサポートするならば true 。</param>
        /// <param name="brush">
        /// ブラシの設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseBrush(
            string value,
            bool solidOnly,
            out Brush brush)
        {
            brush = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            Match m;

            // 16進数表記
            if ((m = RegexHexColor.Match(value)).Success)
            {
                value = m.Groups["Hex"].Value;
                var style = NumberStyles.AllowHexSpecifier;
                int hex = int.Parse(value, style, NumberFormat);

                int a = 255, r, g, b;
                switch (value.Length)
                {
                case 3:
                case 4:
                    b = (hex % 0x10) * 0x11;
                    hex /= 0x10;
                    g = (hex % 0x10) * 0x11;
                    hex /= 0x10;
                    r = (hex % 0x10) * 0x11;
                    if (value.Length == 4)
                    {
                        hex /= 0x10;
                        a = (hex % 0x10) * 0x11;
                    }
                    break;

                case 6:
                case 8:
                    b = hex % 0x100;
                    hex /= 0x100;
                    g = hex % 0x100;
                    hex /= 0x100;
                    r = hex % 0x100;
                    if (value.Length == 8)
                    {
                        hex /= 0x100;
                        a = hex % 0x100;
                    }
                    break;

                default:
                    return false;
                }

                brush = SafeInvoker.Call(
                    () => new SolidColorBrush(new Color32(a, r, g, b)));
                return true;
            }

            // RGB, RGBA, ARGB
            if (
                (m = RegexRgbColor.Match(value)).Success ||
                (m = RegexRgbaColor.Match(value)).Success ||
                (m = RegexArgbColor.Match(value)).Success)
            {
                int r = int.Parse(m.Groups["R"].Value, NumberFormat);
                int g = int.Parse(m.Groups["G"].Value, NumberFormat);
                int b = int.Parse(m.Groups["B"].Value, NumberFormat);
                int a = 255;
                if (m.Groups["A"].Success)
                {
                    a = int.Parse(m.Groups["A"].Value, NumberFormat);
                }

                brush = SafeInvoker.Call(
                    () => new SolidColorBrush(new Color32(a, r, g, b)));
                return true;
            }

            if (!solidOnly)
            {
                // TODO: グラデーションカラー対応するならばここに記述
            }

            // HTMLカラー
            try
            {
                var c = Drawing::ColorTranslator.FromHtml(value);
                brush = SafeInvoker.Call(
                    () => new SolidColorBrush(new Color32(c)));
                return true;
            }
            catch { }

            return false;
        }

        /// <summary>
        /// 文字列を線形状値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="join">
        /// 線形状値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseLineJoin(string value, out PenLineJoin? join)
        {
            join = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            switch (value)
            {
            case "normal":
            case "miter":
                join = PenLineJoin.Miter;
                return true;

            case "bevel":
                join = PenLineJoin.Bevel;
                return true;

            case "round":
                join = PenLineJoin.Round;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列を終端形状値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="cap">
        /// 終端形状値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseLineCap(string value, out PenLineCap? cap)
        {
            cap = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            switch (value)
            {
            case "normal":
            case "none":
            case "flat":
                cap = PenLineCap.Flat;
                return true;

            case "square":
                cap = PenLineCap.Square;
                return true;

            case "tri":
            case "triangle":
                cap = PenLineCap.Triangle;
                return true;

            case "circle":
            case "round":
                cap = PenLineCap.Round;
                return true;
            }

            return false;
        }

        /// <summary>
        /// 文字列を描画バイアス値に変換する。
        /// </summary>
        /// <param name="value">文字列。</param>
        /// <param name="bias">
        /// 描画バイアス値の設定先。設定しないことを表す場合は null 。
        /// </param>
        /// <returns>変換できたならば true 。そうでなければ false 。</returns>
        private static bool TryParseRenderingBias(
            string value,
            out RenderingBias? bias)
        {
            bias = null;

            value = value.Trim().ToLower();
            if (value.Length == 0)
            {
                return false;
            }
            if (IsInheritValue(value))
            {
                return true;
            }

            switch (value)
            {
            case "normal":
            case "performance":
                bias = RenderingBias.Performance;
                return true;

            case "high":
            case "quality":
                bias = RenderingBias.Quality;
                return true;
            }

            return false;
        }

        #endregion

        /// <summary>
        /// テキスト。
        /// </summary>
        private string _text;

        /// <summary>
        /// スタイル。
        /// </summary>
        private TextStylePropertyContainer _style;

        /// <summary>
        /// 表示速度。
        /// </summary>
        private TextSpeakPropertyContainer _speak;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public EffectedText()
            : this(string.Empty)
        {
            SafeInvoker.NotifyBaseThread();
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="text">テキスト。</param>
        public EffectedText(string text)
            : this(text, null, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="text">テキスト。</param>
        /// <param name="style">スタイル。</param>
        /// <param name="speak">表示速度。</param>
        public EffectedText(
            string text,
            TextStylePropertyContainer style,
            TextSpeakPropertyContainer speak)
        {
            Text = text;
            Style = style;
            Speak = speak;
        }

        /// <summary>
        /// テキストを取得または設定する。
        /// </summary>
        public string Text
        {
            get { return _text; }
            set { _text = value ?? string.Empty; }
        }

        /// <summary>
        /// スタイルを取得または設定する。
        /// </summary>
        public TextStylePropertyContainer Style
        {
            get { return _style; }
            set { _style = value ?? new TextStylePropertyContainer(); }
        }

        /// <summary>
        /// 表示速度を取得または設定する。
        /// </summary>
        public TextSpeakPropertyContainer Speak
        {
            get { return _speak; }
            set { _speak = value ?? new TextSpeakPropertyContainer(); }
        }

        /// <summary>
        /// タグ情報を適用する。
        /// </summary>
        /// <param name="tagInfo">タグ情報。</param>
        /// <param name="styleTags">
        /// スタイルタグコレクション。不要ならば null 。
        /// </param>
        public void Apply(TagInfo tagInfo, TextStyleTagCollection styleTags)
        {
            if (tagInfo == null)
            {
                throw new ArgumentNullException("tagInfo");
            }

            // 特殊タグならばタグ情報を更新
            TagInfoConverter infoConv;
            if (TagInfoConverterTable.TryGetValue(tagInfo.TagName, out infoConv))
            {
                tagInfo = infoConv(tagInfo);
            }

            // タグ名に対応するスタイルがあれば適用
            if (styleTags != null && styleTags.Contains(tagInfo.TagName))
            {
                styleTags[tagInfo.TagName].CopyTo(Style, true);
            }

            // タグ属性を適用
            TagAttrConverter attrConv;
            foreach (var kv in tagInfo)
            {
                // スタイル
                if (StyleAttrConverterTable.TryGetValue(kv.Key, out attrConv))
                {
                    attrConv(kv.Key, kv.Value, Style);
                }

                // 表示速度
                if (SpeakAttrConverterTable.TryGetValue(kv.Key, out attrConv))
                {
                    attrConv(kv.Key, kv.Value, Speak);
                }
            }
        }

        /// <summary>
        /// タグ情報コレクションを適用する。
        /// </summary>
        /// <param name="tagInfos">タグ情報コレクション。</param>
        /// <param name="styleTags">
        /// スタイルタグコレクション。不要ならば null 。
        /// </param>
        public void Apply(
            TagInfoCollection tagInfos,
            TextStyleTagCollection styleTags)
        {
            if (tagInfos == null)
            {
                throw new ArgumentNullException("tagInfos");
            }

            try
            {
                foreach (var info in tagInfos)
                {
                    Apply(info, styleTags);
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(
                    "要素に null が含まれています。",
                    "tagInfos",
                    ex);
            }
        }

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public EffectedText Clone()
        {
            return new EffectedText(
                this.Text,
                this.Style.Clone(),
                this.Speak.Clone());
        }

        public override string ToString()
        {
            return this.Text;
        }

        #region ICloneable メンバ

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }
}
