﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト拡張オプションプロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class TextOptionPropertyContainer
        :
        Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextOptionPropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("option.variable")]
        public bool VariableEnabled { get; set; }

        [Nive2Property("option.variable.nest")]
        public bool VariableNestEnabled { get; set; }

        [Nive2Property("option.tag")]
        public bool TagEnabled { get; set; }

        [Nive2Property("option.entity")]
        public bool EntityEnabled { get; set; }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextOptionPropertyContainer Clone()
        {
            return (TextOptionPropertyContainer)base.Clone();
        }
    }
}
