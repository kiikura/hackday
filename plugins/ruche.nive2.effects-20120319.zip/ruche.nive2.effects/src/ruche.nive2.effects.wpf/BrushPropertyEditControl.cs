﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// ブラシプロパティを編集するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class BrushPropertyEditControl : PropertyEditControlBase
    {
        private PictureBox pictureEdit;

        /// <summary>
        /// 実処理インスタンス。
        /// </summary>
        BrushPropertyEditControlEngine _engine = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        public BrushPropertyEditControl(string name)
            : this(name, EditBrushTypes.All)
        {   
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="types">編集可能なブラシ種別の組み合わせ。</param>
        public BrushPropertyEditControl(string name, EditBrushTypes types)
        {
            PropertyName = name;
            LabelName = name;

            // コントロール設定
            InitializeComponent();

            // 実処理インスタンス初期化
            _engine = new BrushPropertyEditControlEngine(
                this,
                pictureEdit,
                types);
            _engine.Initialize();

            // イベント登録
            _engine.BrushChangeCommitted += engine_BrushChangeCommitted;
        }

        #region PropertyEditControlBase メンバ

        public override int SpliterDistance
        {
            get
            {
                return base.SpliterDistance;
            }
            set
            {
                base.SpliterDistance = value;

                // コントロールの位置合わせを行う
                pictureEdit.Left = value + Util.PropertyEditControlLeftDistance;
            }
        }

        public override Type UseProperetyType()
        {
            return typeof(BrushProperty);
        }

        public override void ChangeProperty(PropertyBase property)
        {
            var prop = property as BrushProperty;
            if (prop != null)
            {
                _engine.Brush = prop.Brush;
                _engine.Update();
            }

            base.ChangeProperty(property);
        }

        protected override void Dispose(bool disposing)
        {
            if (_engine != null)
            {
                _engine.BrushChangeCommitted -= engine_BrushChangeCommitted;
                _engine.Dispose();
                _engine = null;
            }

            base.Dispose(disposing);
        }

        #endregion

        private void InitializeComponent()
        {
            this.pictureEdit = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureEdit
            // 
            this.pictureEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureEdit.Location = new System.Drawing.Point(114, 0);
            this.pictureEdit.Name = "pictureEdit";
            this.pictureEdit.Size = new System.Drawing.Size(38, 19);
            this.pictureEdit.TabIndex = 3;
            this.pictureEdit.TabStop = false;
            // 
            // BrushPropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.pictureEdit);
            this.Name = "BrushPropertyEditControl";
            this.Controls.SetChildIndex(this.pictureEdit, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit)).EndInit();
            this.ResumeLayout(false);

        }

        private void engine_BrushChangeCommitted(object sender, EventArgs e)
        {
            if (_engine.Brush != null)
            {
                // プロパティ作成
                var prop = new BrushProperty(this.PropertyName, _engine.Brush);
                SetProperty(prop);
            }
        }
    }
}
