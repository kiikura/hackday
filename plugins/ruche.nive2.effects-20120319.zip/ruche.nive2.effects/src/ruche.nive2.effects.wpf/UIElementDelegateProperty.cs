﻿using System;
using System.Windows;
using System.Windows.Media;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// UIElement に対する処理を行うデリゲート。
    /// </summary>
    /// <param name="element">UIElement オブジェクト。</param>
    public delegate void UIElementDelegate(UIElement element);

    /// <summary>
    /// UIElement に対する処理を行うデリゲートを保持する
    /// NiVE2エフェクトプラグインクラス。
    /// エクスプレッションからの利用を想定している。
    /// </summary>
    [Serializable]
    public class UIElementDelegateProperty : PropertyBase
    {
        /// <summary>
        /// デリゲート。
        /// </summary>
        [NonSerialized]
        UIElementDelegate _delegate = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public UIElementDelegateProperty(string name)
            : base(name)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public UIElementDelegateProperty(UIElementDelegateProperty src)
            : this(src.PropertyName)
        {
            Delegate = src.Delegate;
        }

        /// <summary>
        /// デリゲートを取得または設定する。
        /// </summary>
        public UIElementDelegate Delegate
        {
            get { return _delegate; }
            set { _delegate = value; }
        }

        public override string ToString()
        {
            return (Delegate == null) ? "(null)" : Delegate.ToString();
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return false; }
        }

        public override object Value
        {
            get { return Delegate; }
            set { Delegate = (UIElementDelegate)value; }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.Fixed; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            KeyFrame key = Util.GetFixedKeyFrame(keyFrame, time);
            return (key == null) ? null : key.Property.Copy();
        }

        public override PropertyBase Copy()
        {
            return new UIElementDelegateProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            var p = obj as UIElementDelegateProperty;
            if (p != null)
            {
                return (Delegate == null) ?
                    (p.Delegate == null) :
                    Delegate.Equals(p.Delegate);
            }
            return false;
        }

        #endregion
    }
}
