﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace ruche.nive2.effects.wpf
{
    partial class MultiTextEffectProcessor
    {
        /// <summary>
        /// テキスト描画情報を基に描画要素をキャンバスへ追加する。
        /// </summary>
        /// <param name="info">テキスト描画情報。</param>
        /// <param name="time">テキスト表示開始からの経過秒数。</param>
        /// <param name="canvas">キャンバス。</param>
        /// <param name="canvasMatrix">要素全体にかかるマトリクス。</param>
        /// <returns>追加されたならば true 。そうでなければ false 。</returns>
        /// <remarks>
        /// canvas と同一のスレッドから呼び出すこと。
        /// ポスト処理とブレンド種別のパラメータは無視される。
        /// </remarks>
#if DEBUG
        public
#else
        private
#endif
        static void RenderToCanvas(
            TextRenderingInfo info,
            double time,
            Canvas canvas,
            Matrix canvasMatrix)
        {
            // テキスト全体にかかるマトリクス作成
            Matrix textMatrix = Matrix.Identity;
            textMatrix.Translate(info.Position.X, info.Position.Y);
            textMatrix.Append(info.Matrix);
            textMatrix.Append(canvasMatrix);

            // エフェクト非適用/適用図形データの追加先
            var overShapes = new List<TextShapeData>();
            var shapes = new List<TextShapeData>();

            var pos = new Point[2];
            Effect prevEffect = null;

            foreach (var r in info.RowInfos.Select((d, i) => new { d, i }))
            {
                var row = r.d;
                bool lastRow = (r.i == info.RowInfos.Count - 1);
                double ulOffset = 0, strikeOffset = 0;

                // 行全体にかかるマトリクス作成
                Matrix rowMatrix = Matrix.Identity;
                rowMatrix.Translate(row.Position.X, row.Position.Y);
                rowMatrix.Append(textMatrix);

                foreach (var c in row.LetterInfos.Select((d, i) => new { d, i }))
                {
                    var li = c.d;
                    bool lastLetter = (c.i == row.LetterInfos.Count - 1);

                    // エフェクトが変わったらここまでのデータを書き出し
                    if (li.Effect != prevEffect)
                    {
                        AddTextShapeDatas(canvas, shapes, prevEffect);
                        shapes.Clear();
                    }
                    prevEffect = li.Effect;

                    // 表示開始時間による文字の不透明度決定
                    double opacity = li.CalcOpacity(time);
                    if (opacity <= 0)
                    {
                        continue;
                    }

                    // 文字のマトリクス作成
                    Matrix letterMatrix = Matrix.Identity;
                    letterMatrix.Scale(li.Scale.X, li.Scale.Y);
                    letterMatrix.Append(li.Matrix);
                    letterMatrix.Translate(li.Position.X, li.Position.Y);
                    letterMatrix.Append(rowMatrix);

                    // 文字の Transform 作成
                    var letterTrans = new MatrixTransform(letterMatrix);
                    letterTrans.Freeze();

                    // FormattedText 作成＆サイズ取得
                    var ft = new FormattedText(
                        li.Letter,
                        CultureInfo.CurrentCulture,
                        FlowDirection.LeftToRight,
                        li.FontFace,
                        li.FontSize,
                        li.FillBrush);
                    var width = ft.WidthIncludingTrailingWhitespace;
                    var height = ft.Height;

                    // 下線＆取り消し線の基準X位置算出
                    double lineL = -(width / 2 + width * li.PadLeftRate);
                    double lineR = +(width / 2 + width * li.PadRightRate);

                    // 文字
                    if (!char.IsWhiteSpace(li.Letter[0]))
                    {
                        // 文字ジオメトリ作成
                        var letterGeoPos = new Point(-width / 2, -height / 2);
                        var letterGeo = ft.BuildGeometry(letterGeoPos);
                        if (!letterGeo.IsFrozen)
                        {
                            // Transform 設定して固定
                            letterGeo.Transform = letterTrans;
                            letterGeo.Freeze();

                            // 文字の図形データ作成＆追加
                            var letterShape = MakeLetterData(
                                letterGeo,
                                li.FillBrush,
                                li.EdgePen,
                                opacity);
                            shapes.Add(letterShape);
                        }
                    }

                    // 下線
                    if (li.UnderlineInfo != null && li.UnderlineInfo.Width > 0)
                    {
                        var deco = li.UnderlineInfo;

                        // 基本位置算出
                        double decoY =
                            (height / 2) + (height * deco.OffsetRate);
                        pos[0].X = lineL;
                        pos[0].Y = decoY;
                        pos[1].X = lineR;
                        pos[1].Y = decoY;
                        letterMatrix.Transform(pos);

                        // 図形データ作成
                        var decoShape = MakeLineData(
                            TextContent.Underline,
                            deco,
                            pos,
                            ulOffset,
                            opacity);

                        // 追加
                        if (deco.ZOrder > TextRenderingInfo.MaxEffectiveZ)
                        {
                            overShapes.Add(decoShape);
                        }
                        else
                        {
                            shapes.Add(decoShape);
                        }

                        // オフセットを進める
                        if (deco.Width > 0)
                        {
                            ulOffset +=
                                Point2D.Distance(pos[0], pos[1]) / deco.Width;
                        }
                    }

                    // 取り消し線
                    if (li.StrikeInfo != null && li.StrikeInfo.Width > 0)
                    {
                        var deco = li.StrikeInfo;

                        // 基本位置算出
                        double decoY = height * deco.OffsetRate;
                        pos[0].X = lineL;
                        pos[0].Y = decoY;
                        pos[1].X = lineR;
                        pos[1].Y = decoY;
                        letterMatrix.Transform(pos);

                        // 図形データ作成
                        var decoShape = MakeLineData(
                            TextContent.Strike,
                            deco,
                            pos,
                            strikeOffset,
                            opacity);

                        // 追加
                        if (deco.ZOrder > TextRenderingInfo.MaxEffectiveZ)
                        {
                            overShapes.Add(decoShape);
                        }
                        else
                        {
                            shapes.Add(decoShape);
                        }

                        // オフセットを進める
                        if (deco.Width > 0)
                        {
                            strikeOffset +=
                                Point2D.Distance(pos[0], pos[1]) / deco.Width;
                        }
                    }

                    // 傍点
                    if (li.DotInfo != null && li.DotInfo.Width > 0)
                    {
                        var deco = li.DotInfo;

                        // 基本位置算出
                        double decoY =
                            -(height / 2) + (height * deco.OffsetRate);
                        pos[0].X = 0;
                        pos[0].Y = decoY;
                        pos[0] = letterMatrix.Transform(pos[0]);

                        // 図形データ作成
                        var decoShape = MakeDotData(deco, pos[0], opacity);

                        // 追加
                        if (deco.ZOrder > TextRenderingInfo.MaxEffectiveZ)
                        {
                            overShapes.Add(decoShape);
                        }
                        else
                        {
                            shapes.Add(decoShape);
                        }
                    }
                }
            }

            // 残りのデータとエフェクトなしのデータを書き出し
            AddTextShapeDatas(canvas, shapes, prevEffect);
            AddTextShapeDatas(canvas, overShapes, null);
        }

        /// <summary>
        /// キャンバスに図形データリストを追加する。
        /// </summary>
        /// <param name="dest">追加先のキャンバス。</param>
        /// <param name="shapes">図形データリスト。</param>
        /// <param name="effect">適用するエフェクト。</param>
        private static void AddTextShapeDatas(
            Canvas dest,
            List<TextShapeData> shapes,
            Effect effect)
        {
            if (shapes.Count > 0)
            {
                // Zオーダおよび種別でソート
                shapes.Sort();

                // Canvas にまとめて Effect 適用
                var canvas = new Canvas();
                shapes.ForEach(s => canvas.Children.Add(s.Shape));
                canvas.Effect = effect;

                // 追加
                dest.Children.Add(canvas);
            }
        }

        /// <summary>
        /// 文字のジオメトリと各種情報から図形データを生成する。
        /// </summary>
        /// <summary>
        /// ジオメトリと各種パラメータを基に Path を生成する。
        /// </summary>
        /// <param name="geometry">ジオメトリ。</param>
        /// <param name="fillBrush">
        /// 塗り潰しに用いるブラシ。不要ならば null 。
        /// </param>
        /// <param name="strokePen">
        /// 縁の描画に用いるペン。不要ならば null 。
        /// </param>
        /// <param name="opacity">不透明度。</param>
        /// <returns>生成された図形データ。</returns>
        private static TextShapeData MakeLetterData(
            Geometry geometry,
            Brush fillBrush,
            Pen strokePen,
            double opacity)
        {
            Path path =
                new Path
                {
                    Data = geometry,
                    Fill = fillBrush,
                    Opacity = opacity,
                };
            if (strokePen != null && strokePen.Thickness > 0)
            {
                path.Stroke = strokePen.Brush;
                path.StrokeDashArray = strokePen.DashStyle.Dashes;
                path.StrokeDashCap = strokePen.DashCap;
                path.StrokeDashOffset = strokePen.DashStyle.Offset;
                path.StrokeEndLineCap = strokePen.EndLineCap;
                path.StrokeLineJoin = strokePen.LineJoin;
                path.StrokeMiterLimit = strokePen.MiterLimit;
                path.StrokeStartLineCap = strokePen.StartLineCap;
                path.StrokeThickness = strokePen.Thickness;
            }

            return
                new TextShapeData
                {
                    Shape = path,
                    Content = TextContent.Letter,
                    ZOrder = 0,
                };
        }

        /// <summary>
        /// 線の描画情報から図形データを生成する。
        /// </summary>
        /// <param name="content">種別。</param>
        /// <param name="info">線の描画情報。</param>
        /// <param name="pos">始点位置と終点位置の配列。</param>
        /// <param name="strokeOffset">ストロークの開始オフセット。</param>
        /// <param name="opacity">不透明度。</param>
        /// <returns>生成された図形データ。</returns>
        private static TextShapeData MakeLineData(
            TextContent content,
            LineRenderingInfo info,
            Point[] pos,
            double strokeOffset,
            double opacity)
        {
            // 平行または垂直であれば位置を調整(アンチエイリアシング緩和)
            Point pb = pos[0], pe = pos[1];
            double halfW = info.Width / 2;
            if (pb.X == pe.X)
            {
                pb.X = Math.Round(pb.X - halfW) + halfW;
                pe.X = Math.Round(pe.X - halfW) + halfW;
            }
            if (pb.Y == pe.Y)
            {
                pb.Y = Math.Round(pb.Y - halfW) + halfW;
                pe.Y = Math.Round(pe.Y - halfW) + halfW;
            }

            // ジオメトリ作成
            var decoGeo = new LineGeometry(pb, pe);
            decoGeo.Freeze();

            // 図形データ作成
            return
                new TextShapeData
                {
                    Shape =
                        new Path
                        {
                            Data = decoGeo,
                            Stroke = info.Brush,
                            StrokeThickness = info.Width,
                            StrokeStartLineCap = info.Cap,
                            StrokeEndLineCap = info.Cap,
                            StrokeDashCap = info.Cap,
                            StrokeDashArray =
                                new DoubleCollection(info.Pattern),
                            StrokeDashOffset = strokeOffset,
                            Opacity = opacity,
                        },
                    Content = content,
                    ZOrder = info.ZOrder,
                };
        }

        /// <summary>
        /// 点の描画情報から図形データを生成する。
        /// </summary>
        /// <param name="info">点の描画情報。</param>
        /// <param name="pos">位置。</param>
        /// <param name="opacity">不透明度。</param>
        /// <returns>生成された図形データ。</returns>
        private static TextShapeData MakeDotData(
            DotRenderingInfo info,
            Point pos,
            double opacity)
        {
            // ジオメトリ作成
            var decoGeo =
                new EllipseGeometry(pos, info.Width / 2, info.Width / 2);
            decoGeo.Freeze();

            // 図形データ作成
            return
                new TextShapeData
                {
                    Shape =
                        new Path
                        {
                            Data = decoGeo,
                            Fill = info.Brush,
                            Opacity = opacity,
                        },
                    Content = TextContent.Dot,
                    ZOrder = info.ZOrder,
                };
        }
    }
}
