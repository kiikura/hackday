﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.Threading;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う
    /// 静的メソッドを提供するクラス。
    /// </summary>
    public static class SafeInvoker
    {
        /// <summary>
        /// ベーススレッドの Dispatcher 。
        /// </summary>
        private static Dispatcher _baseDispatcher = null;

        /// <summary>
        /// ベーススレッドの Dispatcher を取得する。
        /// </summary>
        public static Dispatcher BaseDispatcher
        {
            get { return _baseDispatcher; }
        }

        /// <summary>
        /// ベーススレッドからの通知メソッド。
        /// 初回呼び出し時に BaseDispatcher を設定する。
        /// </summary>
        public static void NotifyBaseThread()
        {
            if (_baseDispatcher == null)
            {
                _baseDispatcher = Dispatcher.CurrentDispatcher;
            }
        }

        #region Call メソッド

        /// <summary>
        /// BaseDispatcher とスレッドが異なる場合のみ Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="method">デリゲート。</param>
        /// <param name="args">引数リストもしくは null 。</param>
        /// <returns>デリゲートの戻り値もしくは null 。</returns>
        /// <remarks>
        /// BaseDispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// BaseDispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static object Call(Delegate method, params object[] args)
        {
            return Call(BaseDispatcher, method, args);
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="dispatcher">Dispatcher もしくは null 。</param>
        /// <param name="method">デリゲート。</param>
        /// <param name="args">引数リストもしくは null 。</param>
        /// <returns>デリゲートの戻り値もしくは null 。</returns>
        /// <remarks>
        /// dispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// dispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// dispatcher が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static object Call(
            Dispatcher dispatcher,
            Delegate method,
            params object[] args)
        {
            object result = null;

            if (dispatcher == null)
            {
                dispatcher = BaseDispatcher;
            }

            if (dispatcher.Thread == Thread.CurrentThread)
            {
                result = method.DynamicInvoke(args);
            }
            else
            {
                result = dispatcher.Invoke(method, args);
            }

            return result;
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="obj">DispatcherObject もしくは null 。</param>
        /// <param name="method">デリゲート。</param>
        /// <param name="args">引数リストもしくは null 。</param>
        /// <returns>デリゲートの戻り値もしくは null 。</returns>
        /// <remarks>
        /// obj と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// obj と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// obj が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static object Call(
            DispatcherObject obj,
            Delegate method,
            params object[] args)
        {
            return Call(
                (obj == null) ? BaseDispatcher : obj.Dispatcher,
                method,
                args);
        }

        /// <summary>
        /// BaseDispatcher とスレッドが異なる場合のみ Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="action">アクションデリゲート。</param>
        /// <remarks>
        /// BaseDispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// BaseDispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static void Call(Action action)
        {
            Call((Delegate)action);
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="dispatcher">Dispatcher もしくは null 。</param>
        /// <param name="action">アクションデリゲート。</param>
        /// <remarks>
        /// dispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// dispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// dispatcher が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static void Call(Dispatcher dispatcher, Action action)
        {
            Call(dispatcher, (Delegate)action);
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <param name="obj">DispatcherObject もしくは null 。</param>
        /// <param name="action">アクションデリゲート。</param>
        /// <remarks>
        /// obj と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// obj と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// obj が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static void Call(DispatcherObject obj, Action action)
        {
            Call(obj, (Delegate)action);
        }

        /// <summary>
        /// BaseDispatcher とスレッドが異なる場合のみ Invoke 呼び出しを行う。
        /// </summary>
        /// <typeparam name="TResult">戻り値の型。</typeparam>
        /// <param name="func">ファンクションデリゲート。</param>
        /// <returns>ファンクションデリゲートの戻り値。</returns>
        /// <remarks>
        /// BaseDispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// BaseDispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static TResult Call<TResult>(Func<TResult> func)
        {
            return (TResult)Call((Delegate)func);
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <typeparam name="TResult">戻り値の型。</typeparam>
        /// <param name="dispatcher">Dispatcher もしくは null 。</param>
        /// <param name="func">ファンクションデリゲート。</param>
        /// <returns>ファンクションデリゲートの戻り値。</returns>
        /// <remarks>
        /// dispatcher と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// dispatcher と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// dispatcher が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static TResult Call<TResult>(
            Dispatcher dispatcher,
            Func<TResult> func)
        {
            return (TResult)Call(dispatcher, (Delegate)func);
        }

        /// <summary>
        /// スレッドが異なる場合のみ Dispatcher の Invoke 呼び出しを行う。
        /// </summary>
        /// <typeparam name="TResult">戻り値の型。</typeparam>
        /// <param name="obj">DispatcherObject もしくは null 。</param>
        /// <param name="func">ファンクションデリゲート。</param>
        /// <returns>ファンクションデリゲートの戻り値。</returns>
        /// <remarks>
        /// obj と同一のスレッドから呼び出した場合は
        /// 通常のデリゲート呼び出しを行う。
        /// obj と異なるスレッドから呼び出した場合は
        /// Dispatcher の Invoke 呼び出しを行う。
        /// obj が null である場合は BaseDispatcher を用いて判断する。
        /// BaseDispatcher が未設定である場合は例外となる。
        /// </remarks>
        public static TResult Call<TResult>(
            DispatcherObject obj,
            Func<TResult> func)
        {
            return (TResult)Call(obj, (Delegate)func);
        }

        #endregion

        #region 拡張メソッド

        /// <summary>
        /// スレッドセーフなアクションデリゲート呼び出しを行う拡張メソッド。
        /// </summary>
        /// <typeparam name="T">DispatcherObject 型。</typeparam>
        /// <param name="owner">呼び出し元。</param>
        /// <param name="action">
        /// アクションデリゲート。第一引数に owner が渡される。
        /// </param>
        public static void SafeCall<T>(this T owner, Action<T> action)
            where T : DispatcherObject
        {
            Call(owner, action, owner);
        }

        /// <summary>
        /// スレッドセーフなファンクションデリゲート呼び出しを行う拡張メソッド。
        /// </summary>
        /// <typeparam name="T">DispatcherObject 型。</typeparam>
        /// <typeparam name="TResult">戻り値の型。</typeparam>
        /// <param name="owner">呼び出し元。</param>
        /// <param name="func">
        /// ファンクションデリゲート。第一引数に owner が渡される。
        /// </param>
        /// <returns>ファンクションデリゲートの戻り値。</returns>
        public static TResult SafeCall<T, TResult>(
            this T owner,
            Func<T, TResult> func)
            where T : DispatcherObject
        {
            return (TResult)Call(owner, func, owner);
        }

        /// <summary>
        /// スレッドセーフな Freeze メソッド呼び出しを行う拡張メソッド。
        /// </summary>
        /// <param name="owner">呼び出し元。</param>
        /// <returns>
        /// フリーズに成功したか既にフリーズ済みならば true 。
        /// フリーズできない状態ならば false 。
        /// </returns>
        public static bool SafeFreeze(this Freezable owner)
        {
            return Call(owner, () =>
                {
                    bool result = owner.IsFrozen;
                    if (!result && owner.CanFreeze)
                    {
                        owner.Freeze();
                        result = true;
                    }
                    return result;
                });
        }

        /// <summary>
        /// スレッドセーフな Clone メソッド呼び出しを行う拡張メソッド。
        /// </summary>
        /// <typeparam name="T">Freezable 型。</typeparam>
        /// <param name="owner">呼び出し元。</param>
        /// <returns>呼び出し元の未フリーズなクローン。</returns>
        public static T SafeClone<T>(this T owner)
            where T : Freezable
        {
            return Call(owner, () => (T)owner.Clone());
        }

        /// <summary>
        /// スレッドセーフな GetAsFrozen メソッド呼び出しを行う拡張メソッド。
        /// </summary>
        /// <typeparam name="T">Freezable 型。</typeparam>
        /// <param name="owner">呼び出し元。</param>
        /// <returns>呼び出し元のフリーズ済みクローン。</returns>
        public static T SafeGetAsFrozen<T>(this T owner)
            where T : Freezable
        {
            return Call(owner, () => (T)owner.GetAsFrozen());
        }

        #endregion
    }
}
