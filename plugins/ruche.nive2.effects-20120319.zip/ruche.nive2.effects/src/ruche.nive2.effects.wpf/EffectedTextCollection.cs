﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using ruche.text;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// パラメータ付きテキストのコレクションクラス。
    /// </summary>
    public sealed class EffectedTextCollection
        :
        Collection<EffectedText>,
        ICloneable
    {
        /// <summary>
        /// タグテキストコレクションからインスタンスを生成する。
        /// </summary>
        /// <param name="src">タグテキストコレクション。</param>
        /// <param name="style">既定のスタイル。</param>
        /// <param name="speak">既定の表示速度。</param>
        /// <param name="styleTags">
        /// スタイルタグコレクション。不要ならば null 。
        /// </param>
        /// <returns>新しいインスタンス。</returns>
        public static EffectedTextCollection FromTaggedTexts(
            TaggedTextCollection src,
            TextStylePropertyContainer style,
            TextSpeakPropertyContainer speak,
            TextStyleTagCollection styleTags)
        {
            if (src == null)
            {
                throw new ArgumentNullException("src");
            }

            var dest = new EffectedTextCollection();
            foreach (var tt in src)
            {
                var et = EffectedText.FromTaggedText(
                    tt,
                    (style == null) ? null : style.Clone(),
                    (speak == null) ? null : speak.Clone(),
                    styleTags);
                dest.Add(et);
            }

            return dest;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public EffectedTextCollection()
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">パラメータ付きテキスト列挙。</param>
        public EffectedTextCollection(IEnumerable<EffectedText> src)
        {
            if (src == null)
            {
                throw new ArgumentNullException("src");
            }

            try
            {
                foreach (var t in src)
                {
                    Add(t);
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(
                    "列挙要素に null が含まれています。",
                    "src",
                    ex);
            }
        }

        /// <summary>
        /// コレクションに追加可能なアイテムであるか否かをチェックし、
        /// 追加できないならば例外を送出する。
        /// </summary>
        /// <param name="item">アイテム。</param>
        /// <remarks>
        /// item が null である場合に例外を送出する。
        /// </remarks>
        private void CheckItem(EffectedText item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
        }

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public EffectedTextCollection Clone()
        {
            var dest = new EffectedTextCollection();
            foreach (var t in this)
            {
                dest.Add(t.Clone());
            }
            return dest;
        }

        #region Collection<EffectedText> メンバ

        protected override void InsertItem(int index, EffectedText item)
        {
            CheckItem(item);

            base.InsertItem(index, item);
        }

        protected override void SetItem(int index, EffectedText item)
        {
            CheckItem(item);

            base.SetItem(index, item);
        }

        #endregion

        #region ICloneable メンバ

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }
}
