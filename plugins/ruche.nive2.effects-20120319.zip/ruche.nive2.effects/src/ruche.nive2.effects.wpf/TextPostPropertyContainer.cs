﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストポスト処理プロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class TextPostPropertyContainer : Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextPostPropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("post.alpha")]
        public double AlphaPercent { get; set; }

        [Nive2Property("post.brightness")]
        public double BrightnessPercent { get; set; }

        [Nive2Property("post.saturation")]
        public double SaturationPercent { get; set; }

        #endregion

        #region NiVE2プロパティ対応メンバへのアクセッサ

        public double Alpha
        {
            get { return AlphaPercent / 100; }
            set { AlphaPercent = Math.Min(Math.Max(value, 0), 1) * 100; }
        }

        public double Brightness
        {
            get { return BrightnessPercent / 100; }
            set { BrightnessPercent = Math.Min(Math.Max(value, 0), 1) * 100; }
        }

        public double Saturation
        {
            get { return SaturationPercent / 100; }
            set { SaturationPercent = Math.Min(Math.Max(value, 0), 1) * 100; }
        }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextPostPropertyContainer Clone()
        {
            return (TextPostPropertyContainer)base.Clone();
        }
    }
}
