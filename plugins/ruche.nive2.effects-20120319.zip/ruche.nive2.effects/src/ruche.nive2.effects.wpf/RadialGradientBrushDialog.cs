﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Forms;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// RadialGradientBrush を編集するコモンダイアログクラス。
    /// </summary>
    /// <remarks>
    /// 現状では以下の制約がある。
    /// 
    /// <list type="bullet">
    /// <item>
    /// <description>Center は常に (0.5, 0.5) となる。</description>
    /// </item>
    /// <item>
    /// <description>RadiusX と RadiusY は同値となる。</description>
    /// </item>
    /// </list>
    /// </remarks>
    public class RadialGradientBrushDialog : CommonDialog
    {
        #region static メンバ

        /// <summary>
        /// 既定のブラシ。
        /// </summary>
        private static readonly RadialGradientBrush _defaultBrush;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static RadialGradientBrushDialog()
        {
            SafeInvoker.NotifyBaseThread();

            RadialGradientBrush brush = null;
            SafeInvoker.Call(() =>
            {
                brush = new RadialGradientBrush(Colors.Red, Colors.Blue);
                brush.Freeze();
            });
            _defaultBrush = brush;
        }

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// </remarks>
        public static RadialGradientBrush DefaultBrush
        {
            get { return _defaultBrush; }
        }

        #endregion

        /// <summary>
        /// ブラシ。
        /// </summary>
        private RadialGradientBrush _brush = DefaultBrush;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public RadialGradientBrushDialog()
        {
            Reset();
        }

        /// <summary>
        /// ブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 現状では以下の制約がある。
        /// 
        /// <list type="bullet">
        /// <item>
        /// <description>Center は常に (0.5, 0.5) となる。</description>
        /// </item>
        /// <item>
        /// <description>RadiusX と RadiusY は同値となる。</description>
        /// </item>
        /// </list>
        /// 
        /// このプロパティに設定されたブラシはダイアログを表示するタイミングで
        /// 次のように補正される。
        /// 
        /// <list type="bullet">
        /// <item>
        /// <description>Center を (0.5, 0.5) に変更する。</description>
        /// </item>
        /// <item>
        /// <description>
        /// RadiusX と RadiusY のうち大きい方を半径として採用する。
        /// ただし Math.Sqrt(0.5) より大きい場合は Math.Sqrt(0.5) とする。
        /// </description>
        /// </item>
        /// </list>
        /// 
        /// ただし編集をキャンセルしてダイアログを閉じた場合、
        /// このプロパティ値自体は変更されない。
        /// 
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// 変更可能なブラシもしくは相対座標系以外のブラシを設定すると、
        /// 相対座標系で変更不可なクローンを作成して保持する。
        /// </remarks>
        public RadialGradientBrush Brush
        {
            get { return _brush; }
            set
            {
                _brush = value ?? DefaultBrush;
                SafeInvoker.Call(_brush, () =>
                {
                    if (
                        !_brush.IsFrozen ||
                        _brush.MappingMode != BrushMappingMode.RelativeToBoundingBox)
                    {
                        _brush = _brush.Clone();
                        _brush.MappingMode = BrushMappingMode.RelativeToBoundingBox;
                        _brush.Freeze();
                    }
                });
            }
        }

        /// <summary>
        /// 編集マーカーを有効にするか否かを取得または設定する。
        /// </summary>
        public bool EditMarkerEnabled { get; set; }

        /// <summary>
        /// 編集マーカーの色を取得または設定する。
        /// </summary>
        public Color32 EditMarkerColor { get; set; }

        #region CommonDialog メンバ

        public override void Reset()
        {
            this.Brush = DefaultBrush;
            this.EditMarkerEnabled = true;
            this.EditMarkerColor = Colors.Lime;
        }

        protected override bool RunDialog(IntPtr hwndOwner)
        {
            bool result = false;

            using (var window = new RadialGradientBrushWindow())
            {
                window.Brush = this.Brush;
                window.EditMarkerEnabled = this.EditMarkerEnabled;
                window.EditMarkerColor = this.EditMarkerColor;

                Control owner = Control.FromHandle(hwndOwner);
                if (window.ShowDialog(owner) == DialogResult.OK)
                {
                    this.Brush = window.Brush;
                    this.EditMarkerEnabled = window.EditMarkerEnabled;
                    this.EditMarkerColor = window.EditMarkerColor;

                    result = true;
                }
            }

            return result;
        }

        #endregion
    }
}
