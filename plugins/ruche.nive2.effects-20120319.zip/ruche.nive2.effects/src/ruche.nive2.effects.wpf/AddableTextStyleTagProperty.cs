﻿using System;
using System.Collections.Generic;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 追加可能なテキストスタイルタグプロパティセットを保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class AddableTextStyleTagProperty : AddablePropertyBase
    {
        /// <summary>
        /// プロパティセット配列。
        /// </summary>
        private PropertySetBase[] _properties = new PropertySetBase[0];

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public AddableTextStyleTagProperty(string name) : base(name)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public AddableTextStyleTagProperty(
            AddableTextStyleTagProperty src)
            : this(src.PropertyName)
        {
            this.Properties = Array.ConvertAll(
                src.Properties,
                p => (PropertySetBase)p.Copy());
        }

        /// <summary>
        /// 指定したタグ名を持つテキストスタイルタグプロパティセットを検索する。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <returns>
        /// テキストスタイルタグプロパティセット。存在しない場合は null 。
        /// </returns>
        public TextStyleTagPropertySet FindTagProperty(string tagName)
        {
            foreach (var prop in Properties)
            {
                var tp = prop as TextStyleTagPropertySet;
                if (tp != null && tp.TagName == tagName)
                {
                    return tp;
                }
            }
            return null;
        }

        /// <summary>
        /// テキストスタイルタグプロパティセットを取得する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>テキストスタイルタグプロパティセット。</returns>
        public TextStyleTagPropertySet GetProperty(int index)
        {
            if (index < 0 || index >= Properties.Length)
            {
                throw new ArgumentOutOfRangeException(
                    "index", index, "インデックスが配列の範囲外です。");
            }

            return Properties[index] as TextStyleTagPropertySet;
        }

        /// <summary>
        /// テキストスタイルタグプロパティセット配列を取得する。
        /// </summary>
        /// <returns>テキストスタイルタグプロパティセット配列。</returns>
        public TextStyleTagPropertySet[] GetProperties()
        {
            return Array.ConvertAll(
                Properties,
                p => (TextStyleTagPropertySet)p);
        }

        #region AddablePropertyBase メンバ

        public override Type[] PropertyTypes
        {
            get
            {
                return new Type[] { typeof(TextStyleTagPropertySet) };
            }
        }

        public override PropertySetBase[] Properties
        {
            get { return _properties; }
            set { _properties = value ?? new PropertySetBase[0]; }
        }

        public override PropertySetBase CreateProperty(Type propertyType)
        {
            PropertySetBase prop = null;

            if (propertyType == typeof(TextStyleTagPropertySet))
            {
                prop = new TextStyleTagPropertySet("タグ", false, true);
            }

            return prop;
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase Copy()
        {
            return new AddableTextStyleTagProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            // 手抜き
            return ((object)this).Equals(obj);
        }

        #endregion
    }
}
