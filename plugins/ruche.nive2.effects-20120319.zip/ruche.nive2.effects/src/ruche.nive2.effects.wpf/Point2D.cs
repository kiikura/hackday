﻿using System;
using System.Windows;
using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 様々な2D座標型との相互型変換をサポートする2D座標情報構造体。
    /// </summary>
    [Serializable]
    public struct Point2D
    {
        #region 非公開フィールド

        /// <summary>
        /// X位置。
        /// </summary>
        private double _x;

        /// <summary>
        /// Y位置。
        /// </summary>
        private double _y;

        #endregion

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="x">X位置。</param>
        /// <param name="y">Y位置。</param>
        public Point2D(double x, double y)
        {
            _x = x;
            _y = y;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Point2D(Point src) : this(src.X, src.Y)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Point2D(Drawing::PointF src) : this(src.X, src.Y)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Point2D(Vector src) : this(src.X, src.Y)
        {
        }

        #endregion

        #region 公開プロパティ

        /// <summary>
        /// X位置を取得または設定する。
        /// </summary>
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }

        /// <summary>
        /// Y位置を取得または設定する。
        /// </summary>
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }

        #endregion

        #region 公開メソッド

        public override bool Equals(object obj)
        {
            if (obj is Point2D)
            {
                return (this == (Point2D)obj);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ((Point)this).GetHashCode();
        }

        public override string ToString()
        {
            return ((Point)this).ToString();
        }

        #endregion

        #region Point2D への型変換

        public static implicit operator Point2D(Point src)
        {
            return new Point2D(src);
        }

        public static implicit operator Point2D(Drawing::PointF src)
        {
            return new Point2D(src);
        }

        public static explicit operator Point2D(Vector src)
        {
            return new Point2D(src);
        }

        #endregion

        #region Point2D からの型変換

        public static implicit operator Point(Point2D src)
        {
            return new Point(src.X, src.Y);
        }

        public static explicit operator Drawing::PointF(Point2D src)
        {
            return new Drawing::PointF((float)src.X, (float)src.Y);
        }

        public static explicit operator Vector(Point2D src)
        {
            return new Vector(src.X, src.Y);
        }

        #endregion

        #region 演算子

        public static Point2D operator +(Point2D l, Vector r)
        {
            return new Point2D(l.X + r.X, l.Y + r.Y);
        }

        public static Vector operator -(Point2D l, Point2D r)
        {
            return new Vector(l.X - r.X, l.Y - r.Y);
        }

        public static Point2D operator -(Point2D l, Vector r)
        {
            return new Point2D(l.X - r.X, l.Y - r.Y);
        }

        public static bool operator ==(Point2D l, Point2D r)
        {
            return (l.X == r.X && l.Y == r.Y);
        }

        public static bool operator !=(Point2D l, Point2D r)
        {
            return !(l == r);
        }

        #endregion

        #region 静的メソッド

        /// <summary>
        /// 2点間の距離の2乗を求める。
        /// </summary>
        /// <param name="c1">点1。</param>
        /// <param name="c2">点2。</param>
        /// <returns>2点間の距離の2乗。</returns>
        public static double DistanceSquare(Point2D c1, Point2D c2)
        {
            var dx = c2.X - c1.X;
            var dy = c2.Y - c1.Y;
            return (dx * dx) + (dy * dy);
        }

        /// <summary>
        /// 2点間の距離を求める。
        /// </summary>
        /// <param name="c1">点1。</param>
        /// <param name="c2">点2。</param>
        /// <returns>2点間の距離。</returns>
        public static double Distance(Point2D c1, Point2D c2)
        {
            return Math.Sqrt(DistanceSquare(c1, c2));
        }

        /// <summary>
        /// ベクトル p→a とベクトル p→b との内積を求める。
        /// </summary>
        /// <param name="p">点 p 。</param>
        /// <param name="a">点 a 。</param>
        /// <param name="b">点 b 。</param>
        /// <returns>ベクトル pa とベクトル pb との内積。</returns>
        public static double Dot(Point2D p, Point2D a, Point2D b)
        {
            return Vector.Multiply(a - p, b - p);
        }

        /// <summary>
        /// 始点から終点方向へ指定した割合だけ移動した位置を求める。
        /// </summary>
        /// <param name="begin">始点。</param>
        /// <param name="end">終点。</param>
        /// <param name="rate">移動割合。 0.0 で始点、 1.0 で終点。</param>
        /// <returns>移動した位置。</returns>
        public static Point2D Linear(Point2D begin, Point2D end, double rate)
        {
            return (begin + (end - begin) * rate);
        }

        #endregion
    }
}
