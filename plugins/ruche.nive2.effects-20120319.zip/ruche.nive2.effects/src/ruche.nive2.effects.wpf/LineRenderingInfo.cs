﻿using System;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 線の描画情報を保持するクラス。
    /// </summary>
    public class LineRenderingInfo : DecorationRenderingInfoBase
    {
        /// <summary>
        /// 既定の破線パターン。
        /// </summary>
        private static readonly double[] DefaultPattern = { 1, 0 };

        /// <summary>
        /// 破線パターン。
        /// </summary>
        private double[] _pattern = (double[])DefaultPattern.Clone();

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public LineRenderingInfo()
        {
        }

        /// <summary>
        /// 線の端形状を取得または設定する。
        /// </summary>
        public PenLineCap Cap { get; set; }

        /// <summary>
        /// 破線パターン値を取得または設定する。
        /// </summary>
        public double[] Pattern
        {
            get { return _pattern; }
            set { _pattern = value ?? ((double[])DefaultPattern.Clone()); }
        }
    }
}
