﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト描画情報を保持するクラス。
    /// </summary>
    /// <remarks>
    /// 文字およびそれに付随する文字装飾はZオーダの小さい順に描画される。
    /// 文字のZオーダは LetterZ で固定となる。
    /// 
    /// Zオーダが同値である場合は次の順序で描画される。
    /// 
    /// <list type="number">
    /// <item><description>文字</description></item>
    /// <item><description>下線</description></item>
    /// <item><description>取り消し線</description></item>
    /// <item><description>傍点</description></item>
    /// </list>
    /// 
    /// また、Zオーダが MaxEffectiveZ 以下である場合は文字に設定された
    /// エフェクトが適用される。
    /// </remarks>
    public class TextRenderingInfo
    {
        /// <summary>
        /// 文字のZオーダ値。
        /// </summary>
        public static readonly double LetterZ = 0;

        /// <summary>
        /// エフェクト適用対象となるZオーダの最大値。
        /// </summary>
        public static readonly double MaxEffectiveZ = 100;

        /// <summary>
        /// テキスト行描画情報リスト。
        /// </summary>
        private List<TextRowRenderingInfo> _rowInfos =
            new List<TextRowRenderingInfo>();

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextRenderingInfo()
        {
        }

        /// <summary>
        /// テキスト行描画情報リストを取得または設定する。
        /// </summary>
        public List<TextRowRenderingInfo> RowInfos
        {
            get { return _rowInfos; }
            set { _rowInfos = value ?? new List<TextRowRenderingInfo>(); }
        }

        /// <summary>
        /// テキスト全体の左上端位置を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 描画先レイヤの左上端を (0, 0) とする相対座標で表す。
        /// </remarks>
        public Point2D Position { get; set; }

        /// <summary>
        /// テキスト全体の配置変換を行うマトリクス値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 描画先レイヤの左上端を変換の基準位置とする。
        /// 既定では回転設定が適用されている。
        /// </remarks>
        public Matrix Matrix { get; set; }

        /// <summary>
        /// テキスト全体の不透明度を取得または設定する。
        /// </summary>
        public double Alpha { get; set; }

        /// <summary>
        /// テキスト全体の明度を取得または設定する。
        /// </summary>
        public double Brightness { get; set; }

        /// <summary>
        /// テキスト全体の彩度を取得または設定する。
        /// </summary>
        public double Saturation { get; set; }

        /// <summary>
        /// 描画先レイヤに対するブレンド種別を取得または設定する。
        /// </summary>
        public BlendType BlendType { get; set; }
    }
}
