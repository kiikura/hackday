﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストエフェクトの設定項目のカテゴリを表す列挙。
    /// </summary>
    public enum TextEffectCategory
    {
        /// <summary>
        /// テキスト。
        /// </summary>
        Text,

        /// <summary>
        /// 描画順序。
        /// </summary>
        Order,

        /// <summary>
        /// 配置。
        /// </summary>
        Arrange,

        /// <summary>
        /// 拡張オプション。
        /// </summary>
        Option,

        /// <summary>
        /// スタイル。
        /// </summary>
        Style,

        /// <summary>
        /// 表示速度。
        /// </summary>
        Speak,

        /// <summary>
        /// ポスト処理。
        /// </summary>
        Post,

        /// <summary>
        /// ブレンド。
        /// </summary>
        Blend,

        /// <summary>
        /// デリゲート。エクスプレッション用。
        /// </summary>
        Delegate,

        /// <summary>
        /// フォーマットテキスト。可変長。
        /// </summary>
        FormattedTexts,

        /// <summary>
        /// 変数。可変長。
        /// </summary>
        Variables,

        /// <summary>
        /// ユーザ定義タグ。可変長。
        /// </summary>
        Tags,
    }
}
