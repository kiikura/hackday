﻿using System;
using System.Windows.Media;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

using Drawing2D = System.Drawing.Drawing2D;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// WPFのブラシを保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class BrushProperty : PropertyBase
    {
        /// <summary>
        /// ブラシ。
        /// </summary>
        private XamlSerializable<Brush> _brush = new XamlSerializable<Brush>();

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public BrushProperty(string name) : this(name, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="brush">ブラシ。</param>
        public BrushProperty(string name, Brush brush) : base(name)
        {
            Brush = brush;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public BrushProperty(BrushProperty src)
            : base(src.PropertyName)
        {
            Brush = src.Brush;
        }

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        public static Brush DefaultBrush
        {
            get { return Brushes.Black; }
        }

        /// <summary>
        /// ブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 値の設定時にはクローンが作成され、即座にフリーズされる。
        /// </remarks>
        public Brush Brush
        {
            get { return _brush.Value; }
            set
            {
                _brush = new XamlSerializable<Brush>(
                    (value ?? DefaultBrush).SafeGetAsFrozen());
            }
        }

        public override string ToString()
        {
            return Brush.ToString();
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return false; }
        }

        public override object Value
        {
            get { return Brush; }
            set { Brush = (Brush)value; }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get
            {
                return (
                    PropertyInterpolationType.Fixed |
                    PropertyInterpolationType.Liner);
            }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            // 前方キーフレーム取得
            KeyFrame prevKey = Util.GetPrevKeyFrame(keyFrame, time);
            if (prevKey == null)
            {
                return Util.GetAboveKeyFrame(keyFrame, time).Property;
            }
            if (
                prevKey.Type == PropertyInterpolationType.Fixed ||
                prevKey.Time >= time)
            {
                return prevKey.Property;
            }

            // 後方キーフレーム取得
            KeyFrame nextKey = Util.GetAboveKeyFrame(keyFrame, time);
            if (nextKey == null)
            {
                return prevKey.Property;
            }

            // リニア補間
            var prevProp = (BrushProperty)prevKey.Property;
            Brush brush = Interpolater.Linear(
                prevProp.Brush,
                ((BrushProperty)nextKey.Property).Brush,
                (time - prevKey.Time) / (nextKey.Time - prevKey.Time));
            brush.SafeFreeze();

            return new BrushProperty(prevProp.PropertyName, brush);
        }

        public override PropertyBase Copy()
        {
            return new BrushProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            if (obj is BrushProperty)
            {
                return (Brush == null) ?
                    (((BrushProperty)obj).Brush == null) :
                    Brush.Equals(((BrushProperty)obj).Brush);
            }
            return false;
        }

        #endregion
    }
}
