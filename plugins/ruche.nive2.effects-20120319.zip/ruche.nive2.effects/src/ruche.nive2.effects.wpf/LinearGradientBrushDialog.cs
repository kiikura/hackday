﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Forms;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// LinearGradientBrush を編集するコモンダイアログクラス。
    /// </summary>
    public class LinearGradientBrushDialog : CommonDialog
    {
        #region static メンバ

        /// <summary>
        /// 既定のブラシ。
        /// </summary>
        private static readonly LinearGradientBrush _defaultBrush;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static LinearGradientBrushDialog()
        {
            SafeInvoker.NotifyBaseThread();

            LinearGradientBrush brush = null;
            SafeInvoker.Call(() =>
            {
                brush =
                    new LinearGradientBrush(
                        Colors.Red,
                        Colors.Blue,
                        new Point(0, 0),
                        new Point(1, 1));
                brush.Freeze();
            });
            _defaultBrush = brush;
        }

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// </remarks>
        public static LinearGradientBrush DefaultBrush
        {
            get { return _defaultBrush; }
        }

        #endregion

        /// <summary>
        /// ブラシ。
        /// </summary>
        private LinearGradientBrush _brush = DefaultBrush;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public LinearGradientBrushDialog()
        {
            Reset();
        }

        /// <summary>
        /// ブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// 変更可能なブラシもしくは相対座標系以外のブラシを設定すると、
        /// 相対座標系で変更不可なクローンを作成して保持する。
        /// </remarks>
        public LinearGradientBrush Brush
        {
            get { return _brush; }
            set
            {
                _brush = value ?? DefaultBrush;
                SafeInvoker.Call(_brush, () =>
                {
                    if (
                        !_brush.IsFrozen ||
                        _brush.MappingMode != BrushMappingMode.RelativeToBoundingBox)
                    {
                        _brush = _brush.Clone();
                        _brush.MappingMode = BrushMappingMode.RelativeToBoundingBox;
                        _brush.Freeze();
                    }
                });
            }
        }

        /// <summary>
        /// 編集マーカーを有効にするか否かを取得または設定する。
        /// </summary>
        public bool EditMarkerEnabled { get; set; }

        /// <summary>
        /// 編集マーカーの色を取得または設定する。
        /// </summary>
        public Color32 EditMarkerColor { get; set; }

        #region CommonDialog メンバ

        public override void Reset()
        {
            this.Brush = DefaultBrush;
            this.EditMarkerEnabled = true;
            this.EditMarkerColor = Colors.Lime;
        }

        protected override bool RunDialog(IntPtr hwndOwner)
        {
            bool result = false;

            using (var window = new LinearGradientBrushWindow())
            {
                window.Brush = this.Brush;
                window.EditMarkerEnabled = this.EditMarkerEnabled;
                window.EditMarkerColor = this.EditMarkerColor;

                Control owner = Control.FromHandle(hwndOwner);
                if (window.ShowDialog(owner) == DialogResult.OK)
                {
                    this.Brush = window.Brush;
                    this.EditMarkerEnabled = window.EditMarkerEnabled;
                    this.EditMarkerColor = window.EditMarkerColor;

                    result = true;
                }
            }

            return result;
        }

        #endregion
    }
}
