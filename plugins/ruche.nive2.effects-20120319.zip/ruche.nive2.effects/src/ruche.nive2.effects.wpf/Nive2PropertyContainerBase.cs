﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using NiVE2.Plugin.Interface;
using NiVE2.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 派生先の Nive2PropertyAttribute 属性を適用したプロパティに対する操作を
    /// 提供する抽象基底クラス。
    /// </summary>
    /// <remarks>
    /// 派生先クラスで Nive2PropertyAttribute 属性を適用したプロパティメンバを
    /// 定義することで、対応メンバへNiVE2プロパティ値を適用する処理を提供する。
    /// 
    /// プロパティメンバはそれぞれ次の型にする必要がある。
    /// 
    /// <list type="table">
    /// <listheader>
    /// <term>NiVE2プロパティクラス型</term>
    /// <description>対応メンバの型</description>
    /// </listheader>
    /// <item>
    /// <term>AddablePropertyBase 派生クラス型</term>
    /// <description>
    /// Nive2PropertyContainerBase 派生クラスの配列型。
    /// </description>
    /// </item>
    /// <item>
    /// <term>上記以外の型</term>
    /// <description>
    /// 値型もしくは不変タイプの参照型、およびそれらの配列型。
    /// </description>
    /// </item>
    /// </list>
    /// 
    /// また、上記とは別に Nive2PropertyContainerBase 派生クラス型に対して
    /// Nive2PropertyAttribute 属性を適用すると、サブコンテナとして扱われる。
    /// Apply メソッドによるNiVE2プロパティ値の適用は、インスタンス自身と
    /// インスタンスが保持するサブコンテナに対して行われる。
    /// 
    /// このクラスを継承する場合、引数なしのコンストラクタを定義する必要がある。
    /// Clone メソッド等では引数なしのコンストラクタを用いて派生クラス型の
    /// 新しいインスタンスを生成する。
    /// また、 sealed クラスとすることが推奨される。
    /// </remarks>
    [Serializable]
    public abstract partial class Nive2PropertyContainerBase : ICloneable
    {
        /// <summary>
        /// Nive2PropertyContainerBase 派生クラス型のインスタンスを生成する。
        /// </summary>
        /// <param name="type">
        /// Nive2PropertyContainerBase 派生クラス型。
        /// </param>
        /// <returns>インスタンス。</returns>
        private static Nive2PropertyContainerBase CreateInstance(Type type)
        {
            return (Nive2PropertyContainerBase)Activator.CreateInstance(
                type,
                true);
        }

        /// <summary>
        /// NiVE2プロパティ値のクローンを作成する。
        /// </summary>
        /// <param name="value">NiVE2プロパティ値。</param>
        /// <returns>NiVE2プロパティ値のクローン。</returns>
        /// <remarks>
        /// value が配列であれば各要素のクローンを保持する配列を作成して返す。
        /// value が ICloneable であればクローンを作成して返す。
        /// それ以外であれば value そのものを返す。
        /// </remarks>
        private static object ClonePropertyValue(object value)
        {
            object result = value;

            if (value != null)
            {
                if (value is Array)
                {
                    var src = (Array)value;
                    var dest = (Array)src.Clone();
                    for (int i = 0; i < dest.Length; ++i)
                    {
                        dest.SetValue(ClonePropertyValue(src.GetValue(i)), i);
                    }
                    result = dest;
                }
                else if (value is ICloneable)
                {
                    result = ((ICloneable)value).Clone();
                }
            }

            return result;
        }

        /// <summary>
        /// プロパティ情報テーブルデータ。
        /// </summary>
        private PropertyInfoTableData _propertyData;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public Nive2PropertyContainerBase()
        {
            SafeInvoker.NotifyBaseThread();

            _propertyData = PropertyInfoTableDataCache.GetData(GetType());
        }

        /// <summary>
        /// サブコンテナプロパティ情報配列を取得する。
        /// </summary>
        private ReadOnlyCollection<PropertyInfo> SubContainerInfos
        {
            get { return _propertyData.SubContainers; }
        }

        /// <summary>
        /// NiVE2プロパティ対応メンバ情報配列を取得する。
        /// </summary>
        private ReadOnlyDictionary<string, PropertyInfo> MemberInfoTable
        {
            get { return _propertyData.MemberTable; }
        }

        /// <summary>
        /// NiVE2プロパティに対応する値を取得または設定するインデクサ。
        /// </summary>
        /// <param name="propertyName">NiVE2プロパティ名。</param>
        /// <returns>値。</returns>
        /// <remarks>サブコンテナは走査しない。</remarks>
        public object this[string propertyName]
        {
            get
            {
                if (propertyName == null)
                {
                    throw new ArgumentNullException("propertyName");
                }

                object value;
                if (!TryGetValue(propertyName, out value, false))
                {
                    throw new ArgumentException(
                        "NiVE2プロパティ \"" + propertyName +
                        "\" に対応するメンバは存在しません。",
                        "propertyName");
                }
                return value;
            }
            set
            {
                if (propertyName == null)
                {
                    throw new ArgumentNullException("propertyName");
                }

                if (!TrySetValue(propertyName, value, false))
                {
                    throw new ArgumentException(
                        "NiVE2プロパティ \"" + propertyName +
                        "\" に対応するメンバは存在しません。",
                        "propertyName");
                }
            }
        }

        /// <summary>
        /// NiVE2プロパティに対応する値の取得を試行する。
        /// </summary>
        /// <typeparam name="T">値の型。</typeparam>
        /// <param name="propertyName">NiVE2プロパティ名。</param>
        /// <param name="value">値の設定先。</param>
        /// <param name="recursive">
        /// サブコンテナに対しても試行するならば true 。
        /// </param>
        /// <returns>取得できたならば true 。そうでなければ false 。</returns>
        public bool TryGetValue<T>(
            string propertyName,
            out T value,
            bool recursive)
        {
            if (propertyName == null)
            {
                throw new ArgumentNullException("propertyName");
            }

            var info = GetPropertyInfo(propertyName);
            if (info != null)
            {
                value = GetValue<T>(info);
                return true;
            }

            if (recursive)
            {
                foreach (var i in SubContainerInfos)
                {
                    var c = GetSubContainer(i);
                    if (c.TryGetValue(propertyName, out value, true))
                    {
                        return true;
                    }
                }
            }

            value = default(T);
            return false;
        }

        /// <summary>
        /// NiVE2プロパティに対応する値の設定を試行する。
        /// </summary>
        /// <typeparam name="T">値の型。</typeparam>
        /// <param name="propertyName">NiVE2プロパティ名。</param>
        /// <param name="value">値。</param>
        /// <param name="recursive">
        /// サブコンテナに対しても試行するならば true 。
        /// </param>
        /// <returns>設定できたならば true 。そうでなければ false 。</returns>
        public bool TrySetValue<T>(
            string propertyName,
            T value,
            bool recursive)
        {
            if (propertyName == null)
            {
                throw new ArgumentNullException("propertyName");
            }

            bool result = false;

            var info = GetPropertyInfo(propertyName);
            if (info != null)
            {
                result = true;
                SetValue(info, value);
            }

            if (recursive)
            {
                foreach (var i in SubContainerInfos)
                {
                    var c = GetSubContainer(i);
                    result |= c.TrySetValue(propertyName, value, true);
                }
            }

            return result;
        }

        /// <summary>
        /// NiVE2プロパティに対応する値をすべて初期値にする。
        /// </summary>
        public void ResetValues()
        {
            // メンバを初期化
            foreach (var info in MemberInfoTable.Values)
            {
                object value = null;
                if (info.PropertyType.IsArray)
                {
                    value = Array.CreateInstance(
                        info.PropertyType.GetElementType(),
                        0);
                }
                else if (info.PropertyType.IsValueType)
                {
                    value = Activator.CreateInstance(info.PropertyType, true);
                }
                SetValueCore(info, value);
            }

            // サブコンテナを初期化
            foreach (var info in SubContainerInfos)
            {
                var c = GetSubContainer(info);
                c.ResetValues();
            }
        }

        /// <summary>
        /// このインスタンスの値を別のインスタンスへコピーする。
        /// </summary>
        /// <param name="dest">
        /// コピー先のインスタンス。
        /// コピー元のインスタンスと型が完全に等価でなければならない。
        /// </param>
        /// <param name="ignoreNull">
        /// 値が null のNiVE2プロパティ値をコピーしないならば true 。
        /// </param>
        public void CopyTo(Nive2PropertyContainerBase dest, bool ignoreNull)
        {
            if (dest == null)
            {
                throw new ArgumentNullException("dest");
            }
            if (this._propertyData != dest._propertyData)
            {
                throw new ArgumentException(
                    "コピー先の型は " + GetType() +
                    " と完全に等価でなければなりません。",
                    "dest");
            }

            // メンバをコピー
            foreach (var info in MemberInfoTable.Values)
            {
                object value = this.GetValue<object>(info);
                if (!ignoreNull || value != null)
                {
                    dest.SetValue(info, value);
                }
            }

            // サブコンテナをコピー
            foreach (var info in SubContainerInfos)
            {
                var s = this.GetSubContainer(info);
                var d = dest.GetSubContainer(info);
                s.CopyTo(d, ignoreNull);
            }

            // 追加のコピー
            CopyExtraTo(dest);
        }

        /// <summary>
        /// このインスタンスのクローンを生成する。
        /// </summary>
        /// <returns>このインスタンスのクローン。</returns>
        public Nive2PropertyContainerBase Clone()
        {
            var dest = CreateInstance(GetType());
            CopyTo(dest, false);
            return dest;
        }

        /// <summary>
        /// NiVE2プロパティの値を対応メンバに設定する。
        /// </summary>
        /// <param name="property">NiVE2プロパティ。</param>
        /// <returns>設定できたならば true 。そうでなければ false 。</returns>
        public bool Apply(PropertyBase property)
        {
            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            return (property is AddablePropertyBase) ?
                Apply((AddablePropertyBase)property) :
                TrySetValue(property.PropertyName, property.Value, true);
        }

        /// <summary>
        /// NiVE2可変長プロパティの値を対応メンバに設定する。
        /// </summary>
        /// <param name="property">NiVE2可変長プロパティ。</param>
        /// <returns>設定できたならば true 。そうでなければ false 。</returns>
        public bool Apply(AddablePropertyBase property)
        {
            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            // 対象リスト作成(自身＋サブコンテナ)
            var owners = new List<Nive2PropertyContainerBase>(
                SubContainerInfos.Count + 1);
            owners.Add(this);
            foreach (var i in SubContainerInfos)
            {
                owners.Add(GetSubContainer(i));
            }

            // 対象ごとに処理
            bool result = false;
            foreach (var owner in owners)
            {
                // プロパティ情報取得
                var info = owner.GetPropertyInfo(property.PropertyName);
                if (info == null)
                {
                    continue;
                }

                // 配列要素型取得
                Type contType = info.PropertyType.GetElementType();

                // 型チェック
                if (
                    !info.PropertyType.IsArray ||
                    contType == null ||
                    contType.IsAbstract ||
                    !contType.IsSubclassOf(typeof(Nive2PropertyContainerBase)))
                {
                    continue;
                }

                // 配列作成
                Array values =
                    Array.CreateInstance(contType, property.Properties.Length);
                for (int i = 0; i < values.Length; ++i)
                {
                    var s = CreateInstance(contType);
                    s.Apply(property.Properties[i].Properties);
                    values.SetValue(s, i);
                }

                // 値設定
                owner.SetValueCore(info, values);
                result = true;
            }

            return result;
        }

        /// <summary>
        /// NiVE2プロパティ列挙の各値を各対応メンバに設定する。
        /// </summary>
        /// <param name="properties">NiVE2プロパティ列挙。</param>
        public void Apply<PropertyType>(IEnumerable<PropertyType> properties)
            where PropertyType : PropertyBase
        {
            if (properties == null)
            {
                throw new ArgumentNullException("properties");
            }

            foreach (var p in properties)
            {
                if (p == null)
                {
                    throw new ArgumentException(
                        "要素に null が含まれています。",
                        "properties");
                }
                Apply(p);
            }
        }

        /// <summary>
        /// NiVE2プロパティ値以外の値を別のインスタンスへコピーする。
        /// </summary>
        /// <param name="dest">
        /// コピー先のインスタンス。
        /// コピー元のインスタンスと完全に等価な型となる。
        /// </param>
        /// <remarks>
        /// CopyTo メソッドから呼び出される。既定では何も行わない。
        /// </remarks>
        protected virtual void CopyExtraTo(Nive2PropertyContainerBase dest)
        {
        }

        /// <summary>
        /// プロパティ情報からプロパティ値を取得する。
        /// </summary>
        /// <typeparam name="T">プロパティの型。</typeparam>
        /// <param name="info">プロパティ情報。</param>
        /// <returns>プロパティ値。</returns>
        private T GetValue<T>(PropertyInfo info)
        {
            Delegate getter = DelegateCache.GetGetter(info);
            return (T)getter.DynamicInvoke(this);
        }

        /// <summary>
        /// プロパティ情報からプロパティ値を設定する。
        /// </summary>
        /// <typeparam name="T">プロパティの型。</typeparam>
        /// <param name="info">プロパティ情報。</param>
        /// <param name="value">値。</param>
        private void SetValue<T>(PropertyInfo info, T value)
        {
            if (typeof(T).IsValueType)
            {
                SetValueCore(info, value);
            }
            else
            {
                SetValueCore(info, ClonePropertyValue(value));
            }
        }

        /// <summary>
        /// プロパティ情報からプロパティ値を設定する。
        /// </summary>
        /// <typeparam name="T">プロパティの型。</typeparam>
        /// <param name="info">プロパティ情報。</param>
        /// <param name="value">値。</param>
        private void SetValueCore<T>(PropertyInfo info, T value)
        {
            Delegate setter = DelegateCache.GetSetter(info);
            setter.DynamicInvoke(this, value);
        }

        /// <summary>
        /// もしプロパティの値が null ならば新しいインスタンスを設定し、
        /// その値を返す。
        /// </summary>
        /// <typeparam name="T">プロパティの型。</typeparam>
        /// <param name="info">プロパティ情報。</param>
        /// <returns>プロパティ値。</returns>
        private T CreateValueIfNull<T>(PropertyInfo info)
        {
            T value = GetValue<T>(info);
            if (object.Equals(value, null))
            {
                SetValueCore(
                    info,
                    (T)Activator.CreateInstance(info.PropertyType, true));
                value = GetValue<T>(info);
                if (object.Equals(value, null))
                {
                    throw new InvalidOperationException(
                        "プロパティ " + info.Name +
                        " に非 null 値を設定しましたが null 値を返しました。");
                }
            }

            return value;
        }

        /// <summary>
        /// サブコンテナの値を取得する。
        /// </summary>
        /// <param name="info">サブコンテナのプロパティ情報。</param>
        /// <returns>サブコンテナの値。</returns>
        private Nive2PropertyContainerBase GetSubContainer(PropertyInfo info)
        {
            return CreateValueIfNull<Nive2PropertyContainerBase>(info);
        }

        /// <summary>
        /// NiVE2プロパティに対応するプロパティ情報を取得する。
        /// </summary>
        /// <param name="propertyName">NiVE2プロパティ名。</param>
        /// <returns>プロパティ情報。存在しない場合は null 。</returns>
        private PropertyInfo GetPropertyInfo(string propertyName)
        {
            PropertyInfo result;
            if (!MemberInfoTable.TryGetValue(propertyName, out result))
            {
                result = null;
            }
            return result;
        }

        #region ICloneable メンバ

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }
}
