﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストスタイルタグのコレクションクラス。
    /// </summary>
    /// <remarks>
    /// 値を追加もしくは上書きする際にはタグ名を固定したクローンが作成される。
    /// そのため、追加ソースへの変更はコレクション内の値に反映されない。
    /// </remarks>
    [Serializable]
    public sealed class TextStyleTagCollection
        :
        KeyedCollection<string, TextStylePropertyContainer>,
        ICloneable
    {
        /// <summary>
        /// 標準スタイルタグ配列。
        /// </summary>
        private static readonly TextStylePropertyContainer[] StandardTags;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static TextStyleTagCollection()
        {
            var tags = new List<TextStylePropertyContainer>();

            #region 標準スタイルタグ作成

            TextStylePropertyContainer tag;

            // b
            tag = new TextStylePropertyContainer("b");
            tag.FontWeight = FontWeights.Bold;
            tags.Add(tag);

            // big
            tag = new TextStylePropertyContainer("big");
            tag.ScaleX = 1.25;
            tag.ScaleY = 1.25;
            tags.Add(tag);

            // del
            tag = new TextStylePropertyContainer("del");
            tag.StrikeColor = Brushes.Black;
            tag.StrikeWidth = 1;
            tag.StrikePattern = new double[] { 2, 1 };
            tags.Add(tag);

            // em
            tag = new TextStylePropertyContainer("em");
            tag.FontStyle = FontStyles.Oblique;
            tags.Add(tag);

            // i
            tag = new TextStylePropertyContainer("i");
            tag.FontStyle = FontStyles.Italic;
            tags.Add(tag);

            // ins
            tag = new TextStylePropertyContainer("ins");
            tag.UnderlineColor = Brushes.Black;
            tag.UnderlineWidth = 1;
            tag.UnderlinePattern = new double[] { 2, 1 };
            tags.Add(tag);

            // q
            tag = new TextStylePropertyContainer("q");
            tag.UnderlineColor = Brushes.Black;
            tag.UnderlineWidth = 1;
            tag.UnderlinePattern = new double[] { 1, 1 };
            tags.Add(tag);

            // small
            tag = new TextStylePropertyContainer("small");
            tag.ScaleX = 0.75;
            tag.ScaleY = 0.75;
            tags.Add(tag);

            // strong
            tag = new TextStylePropertyContainer("strong");
            tag.FontWeight = FontWeights.Bold;
            tag.FontStyle = FontStyles.Oblique;
            tags.Add(tag);

            // sub
            tag = new TextStylePropertyContainer("sub");
            tag.VertAlign = TextVerticalAlignment.Bottom;
            tag.ScaleX = 0.5;
            tag.ScaleY = 0.5;
            tags.Add(tag);

            // sup
            tag = new TextStylePropertyContainer("sup");
            tag.VertAlign = TextVerticalAlignment.Top;
            tag.ScaleX = 0.5;
            tag.ScaleY = 0.5;
            tags.Add(tag);

            // tt
            tag = new TextStylePropertyContainer("tt");
            tag.FontFamilyName = "ＭＳ ゴシック";
            tags.Add(tag);

            #endregion

            tags.ForEach(t => t.FreezeTagName());
            StandardTags = tags.ToArray();
        }

        /// <summary>
        /// 標準スタイルタグコレクションを作成する。
        /// </summary>
        /// <returns>標準スタイルタグコレクション。</returns>
        public static TextStyleTagCollection CreateStandard()
        {
            return new TextStyleTagCollection(StandardTags);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextStyleTagCollection()
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">スタイルタグ列挙。</param>
        public TextStyleTagCollection(
            IEnumerable<TextStylePropertyContainer> src)
        {
            if (src == null)
            {
                throw new ArgumentNullException("src");
            }

            try
            {
                MergeRange(src);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(
                    "不正な要素が含まれています。",
                    "src",
                    ex);
            }
        }

        /// <summary>
        /// 同一タグ名のアイテムが存在しない場合は新しく追加し、
        /// 存在する場合は非 null 値のパラメータを上書きする。
        /// </summary>
        /// <param name="item">アイテム。</param>
        public void Merge(TextStylePropertyContainer item)
        {
            CheckItem(item);

            if (Contains(item.TagName))
            {
                item.CopyTo(this[item.TagName], true);
            }
            else
            {
                Add(item);
            }
        }

        /// <summary>
        /// 同一タグ名のアイテムが存在しない場合は新しく追加し、
        /// 存在する場合は非 null 値のパラメータを上書きする。
        /// </summary>
        /// <param name="items">アイテム列挙。</param>
        public void MergeRange(IEnumerable<TextStylePropertyContainer> items)
        {
            if (items == null)
            {
                throw new ArgumentNullException("items");
            }

            try
            {
                foreach (var item in items)
                {
                    Merge(item);
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(
                    "不正な要素が含まれています。",
                    "items",
                    ex);
            }
        }

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public TextStyleTagCollection Clone()
        {
            return new TextStyleTagCollection(this);
        }

        /// <summary>
        /// コレクションに追加可能なアイテムであるか否かをチェックし、
        /// 追加できないならば例外を送出する。
        /// </summary>
        /// <param name="item">アイテム。</param>
        /// <remarks>
        /// item が null であるか、
        /// item.TagName が null もしくは空の文字列である場合に例外を送出する。
        /// </remarks>
        private void CheckItem(TextStylePropertyContainer item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            if (item.TagName == null)
            {
                throw new ArgumentException("タグ名が null です。", "item");
            }
        }

        #region KeyedCollection<string, TextStyleParamSet> メンバ

        protected override void InsertItem(
            int index,
            TextStylePropertyContainer item)
        {
            CheckItem(item);

            var p = item.Clone();
            p.FreezeTagName();

            base.InsertItem(index, p);
        }

        protected override void SetItem(
            int index,
            TextStylePropertyContainer item)
        {
            CheckItem(item);

            var p = item.Clone();
            p.FreezeTagName();

            base.SetItem(index, p);
        }

        protected override string GetKeyForItem(
            TextStylePropertyContainer item)
        {
            return item.TagName;
        }

        #endregion

        #region ICloneable メンバ

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }
}
