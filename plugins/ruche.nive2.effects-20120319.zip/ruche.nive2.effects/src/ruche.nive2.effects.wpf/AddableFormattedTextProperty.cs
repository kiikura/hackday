﻿using System;
using System.Collections.Generic;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 追加可能なフォーマットテキストプロパティセットを保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class AddableFormattedTextProperty : AddablePropertyBase
    {
        /// <summary>
        /// プロパティセット配列。
        /// </summary>
        private PropertySetBase[] _properties = new PropertySetBase[0];

        /// <summary>
        /// 幅の基準値。
        /// </summary>
        private double _width = 2000;

        /// <summary>
        /// 高さの基準値。
        /// </summary>
        private double _height = 2000;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="width">幅の基準値。</param>
        /// <param name="height">高さの基準値。</param>
        public AddableFormattedTextProperty(
            string name,
            double width,
            double height)
            : base(name)
        {
            _width = width;
            _height = height;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public AddableFormattedTextProperty(
            AddableFormattedTextProperty src)
            :
            this(
                src.PropertyName,
                src._width,
                src._height)
        {
            this.Properties = Array.ConvertAll(
                src.Properties,
                p => (PropertySetBase)p.Copy());
        }

        /// <summary>
        /// フォーマットテキストプロパティセットを取得する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>フォーマットテキストプロパティセット。</returns>
        public FormattedTextPropertySet GetProperty(int index)
        {
            if (index < 0 || index >= Properties.Length)
            {
                throw new ArgumentOutOfRangeException(
                    "index", index, "インデックスが配列の範囲外です。");
            }

            return Properties[index] as FormattedTextPropertySet;
        }

        /// <summary>
        /// フォーマットテキストプロパティセット配列を取得する。
        /// </summary>
        /// <returns>フォーマットテキストプロパティセット配列。</returns>
        public FormattedTextPropertySet[] GetProperties()
        {
            return Array.ConvertAll(
                Properties,
                p => (FormattedTextPropertySet)p);
        }

        #region AddablePropertyBase メンバ

        public override Type[] PropertyTypes
        {
            get
            {
                return new Type[] { typeof(FormattedTextPropertySet) };
            }
        }

        public override PropertySetBase[] Properties
        {
            get { return _properties; }
            set { _properties = value ?? new PropertySetBase[0]; }
        }

        public override PropertySetBase CreateProperty(Type propertyType)
        {
            PropertySetBase prop = null;

            if (propertyType == typeof(FormattedTextPropertySet))
            {
                prop = new FormattedTextPropertySet(
                    "テキスト",
                    false,
                    true,
                    _width,
                    _height);
            }

            return prop;
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase Copy()
        {
            return new AddableFormattedTextProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            // 手抜き
            return ((object)this).Equals(obj);
        }

        #endregion
    }
}
