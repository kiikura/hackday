﻿using System;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;
using System.Windows.Markup;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// XAML化することでシリアライズ可能なオブジェクトのラッパクラス。
    /// </summary>
    /// <typeparam name="T">保持データ型。</typeparam>
    [Serializable]
    public sealed class XamlSerializable<T> : ISerializable
    {
        /// <summary>
        /// XAML文字列からインスタンスを生成する。
        /// </summary>
        /// <param name="xaml">XAML文字列。</param>
        /// <returns>インスタンス。</returns>
        public static XamlSerializable<T> FromXaml(string xaml)
        {
            T value;

            using (var sr = new StringReader(xaml))
            using (var xr = XmlReader.Create(sr))
            {
                value = (T)XamlReader.Load(xr);
            }

            return new XamlSerializable<T>(value);
        }

        /// <summary>
        /// インスタンスをXAML文字列に変換する。
        /// </summary>
        /// <param name="value">インスタンス。</param>
        /// <returns>XAML文字列。</returns>
        public static string ToXaml(T value)
        {
            return XamlWriter.Save(value);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public XamlSerializable()
            : this(default(T))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="value">初期値。</param>
        public XamlSerializable(T value)
        {
            Value = value;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public XamlSerializable(XamlSerializable<T> src)
            : this(src.Value)
        {
        }

        /// <summary>
        /// デシリアライズコンストラクタ。
        /// </summary>
        /// <param name="info">シリアライズ情報。</param>
        /// <param name="context">ストリームコンテキスト。</param>
        private XamlSerializable(
            SerializationInfo info,
            StreamingContext context)
            : this(FromXaml(info.GetString("xaml")))
        {
        }

        /// <summary>
        /// 保持データを取得する。
        /// </summary>
        public T Value { get; private set; }

        /// <summary>
        /// XAML文字列に変換する。
        /// </summary>
        /// <returns></returns>
        public string ToXaml()
        {
            return ToXaml(Value);
        }

        public override bool Equals(object obj)
        {
            var o = obj as XamlSerializable<T>;
            if (o != null)
            {
                return object.Equals(Value, o.Value);
            }
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override string ToString()
        {
            return Value.ToString();
        }

        /// <summary>
        /// T 型への暗黙の型変換のオーバロード。
        /// </summary>
        /// <param name="src">変換元の値。</param>
        /// <returns>変換された値。</returns>
        public static implicit operator T(XamlSerializable<T> src)
        {
            return src.Value;
        }

        #region ISerializable メンバ

        void ISerializable.GetObjectData(
            SerializationInfo info,
            StreamingContext context)
        {
            info.AddValue("xaml", ToXaml());
        }

        #endregion
    }
}
