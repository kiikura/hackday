﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Windows.Forms;
using NiVE2.Plugin.Controls;

using Drawing = System.Drawing;
using Imaging = System.Drawing.Imaging;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// SolidColorBrush を編集するダイアログクラス。
    /// </summary>
    internal partial class SolidColorBrushWindow : Form
    {
        /// <summary>
        /// テンプレート色配列要素数。
        /// </summary>
        public const int TemplateColorCount =
            SolidColorBrushDialog.TemplateColorCount;

        /// <summary>
        /// 既定のブラシを取得する。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// </remarks>
        public static SolidColorBrush DefaultBrush
        {
            get { return SolidColorBrushDialog.DefaultBrush; }
        }

        /// <summary>
        /// 既定のテンプレート色配列を取得する。
        /// </summary>
        public static Color32[] DefaultTemplateColors
        {
            get
            {
                return SolidColorBrushDialog.DefaultTemplateColors.ToArray();
            }
        }

        /// <summary>
        /// ブラシ。
        /// </summary>
        private SolidColorBrush _brush = DefaultBrush;

        /// <summary>
        /// テンプレート色配列。
        /// </summary>
        private Color32[] _templateColors = DefaultTemplateColors.ToArray();

        /// <summary>
        /// テンプレート色ボタン配列。
        /// </summary>
        private Button[] _buttonDefs = null;

        /// <summary>
        /// 現在の色。
        /// </summary>
        private Color32 _color = DefaultBrush.Color;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public SolidColorBrushWindow()
        {
            // コントロール初期化
            InitializeComponent();

            // ボタン配列作成
            _buttonDefs = new Button[]
                {
                    buttonDef0,
                    buttonDef1,
                    buttonDef2,
                    buttonDef3,
                    buttonDef4,
                    buttonDef5,
                    buttonDef6,
                    buttonDef7,
                    buttonDef8,
                    buttonDef9,
                    buttonDef10,
                    buttonDef11,
                    buttonDef12,
                    buttonDef13,
                    buttonDef14,
                    buttonDef15,
                };

            // ユーザ定義色初期化
            UserColor = DefaultBrush.Color;
        }

        /// <summary>
        /// ブラシを取得または設定する。
        /// null を渡すと DefaultBrush が設定される。
        /// </summary>
        /// <remarks>
        /// 変更不可状態であるため、変更するためには Brush.Clone メソッドにより
        /// クローンを作成すること。
        /// 変更可能なブラシを設定すると、変更不可なクローンを作成して保持する。
        /// </remarks>
        public SolidColorBrush Brush
        {
            get { return _brush; }
            set { _brush = (value ?? DefaultBrush).SafeGetAsFrozen(); }
        }

        /// <summary>
        /// テンプレート色配列を取得または設定する。
        /// 足りない分は DefaultTemplateColors が設定される。
        /// </summary>
        public Color32[] TemplateColors
        {
            get { return _templateColors; }
            set
            {
                _templateColors = DefaultTemplateColors;
                if (value != null)
                {
                    int count = Math.Min(_templateColors.Length, value.Length);
                    for (int i = 0; i < count; ++i)
                    {
                        _templateColors[i] = value[i];
                    }
                }
            }
        }

        /// <summary>
        /// ユーザ定義色を取得または設定する。
        /// 設定時にアルファ成分値は取り除かれる。
        /// </summary>
        public Color32 UserColor
        {
            get { return new Color32(255, buttonDefUser.BackColor); }
            set
            {
                buttonDefUser.BackColor =
                    (Drawing::Color)new Color32(255, value);
            }
        }

        /// <summary>
        /// 色選択ダイアログを表示する。
        /// </summary>
        /// <param name="color">初期選択色。</param>
        /// <returns>選択された色。キャンセルされた場合は null 。</returns>
        private Color32? ShowColorDialog(Color32 color)
        {
            Color32? result = null;

            using (var dialog = new ColorSelectWindow())
            {
                dialog.Color = (Drawing::Color)color;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    result = dialog.Color;
                }
            }

            return result;
        }

        /// <summary>
        /// ビューボックスの背景画像を初期化する。
        /// </summary>
        private void InitializeViewBackground()
        {
            // 画像作成
            var bmp = new Drawing::Bitmap(16, 16);
            using (var g = Drawing::Graphics.FromImage(bmp))
            {
                g.FillRectangles(
                    Drawing::Brushes.Silver,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 0, 8, 8),
                        new Drawing::Rectangle(8, 8, 8, 8),
                    });
                g.FillRectangles(
                    Drawing::Brushes.White,
                    new Drawing::Rectangle[]
                    {
                        new Drawing::Rectangle(0, 8, 8, 8),
                        new Drawing::Rectangle(8, 0, 8, 8),
                    });
            }

            // 設定
            pictureView.BackgroundImageLayout = ImageLayout.Tile;
            var temp = pictureView.BackgroundImage;
            pictureView.BackgroundImage = bmp;
            if (temp != null)
            {
                temp.Dispose();
            }
        }

        /// <summary>
        /// 現在の選択色を更新し、ビューボックス画像を変更する。
        /// </summary>
        /// <param name="color">更新色。アルファ成分値は無視される。</param>
        private void UpdateCurrentColor(Color32 color)
        {
            // 色設定
            _color = color;
            _color.A = (byte)numDragAlpha.Value;

            // Bitmap 作成
            var bmp = new Drawing::Bitmap(
                pictureView.ClientSize.Width,
                pictureView.ClientSize.Height,
                Imaging::PixelFormat.Format32bppArgb);
            using (var g = Drawing::Graphics.FromImage(bmp))
            using (
                var db = new Drawing::SolidBrush((Drawing::Color)_color))
            {
                g.FillRectangle(db, pictureView.ClientRectangle);
            }

            // ビュー画像変更
            var temp = pictureView.Image;
            pictureView.Image = bmp;
            if (temp != null)
            {
                temp.Dispose();
            }
        }

        private void SolidColorBrushDialog_Load(object sender, EventArgs e)
        {
            InitializeViewBackground();

            // テンプレート色設定
            for (int i = 0; i < TemplateColorCount; ++i)
            {
                _buttonDefs[i].BackColor = (Drawing::Color)TemplateColors[i];
            }

            // 不透明度設定
            numDragAlpha.Value = Brush.Color.A;

            // 色更新
            UpdateCurrentColor(Brush.Color);
        }

        private void SolidColorBrushDialog_FormClosed(
            object sender, FormClosedEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                // ブラシを反映
                SafeInvoker.Call(Brush, () =>
                {
                    var brush = new SolidColorBrush(_color);
                    brush.Freeze();
                    Brush = brush;
                });
            }

            // イメージを破棄
            if (pictureView.Image != null)
            {
                pictureView.Image.Dispose();
                pictureView.Image = null;
            }
            if (pictureView.BackgroundImage != null)
            {
                pictureView.BackgroundImage.Dispose();
                pictureView.BackgroundImage = null;
            }
        }

        private void buttonDef_Click(object sender, EventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                UpdateCurrentColor((Color32)button.BackColor);
            }
        }

        private void buttonDef_BackColorChanged(object sender, EventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                // ボタン文字列変更
                var c = button.BackColor;
                button.Text =
                    "#" + string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);

                // 前景色変更
                button.ForeColor = (ImageUtil.CalcBrightness(c) < 0.5) ?
                    Drawing::Color.White : Drawing::Color.Black;
            }
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            var color = ShowColorDialog(new Color32(255, _color));
            if (color != null)
            {
                Color32 c = (Color32)color;
                UserColor = c;
                UpdateCurrentColor(c);
            }
        }

        private void numDragAlpha_ValueChanged(object sender, EventArgs e)
        {
            UpdateCurrentColor(_color);
        }
    }
}
