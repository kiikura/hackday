﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// NiVE2プロパティに対応する値であることを表す属性。
    /// </summary>
    /// <remarks>
    /// 詳細は Nive2PropertyContainerBase クラスを参照すること。
    /// </remarks>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class Nive2PropertyAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public Nive2PropertyAttribute()
            : this(null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">NiVE2プロパティ名。</param>
        public Nive2PropertyAttribute(string name)
        {
            PropertyName = name;
        }

        /// <summary>
        /// NiVE2プロパティ名を取得または設定する。
        /// </summary>
        public string PropertyName { get; set; }
    }
}
