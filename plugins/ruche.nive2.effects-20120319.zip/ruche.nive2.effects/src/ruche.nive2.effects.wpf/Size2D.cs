﻿using System;
using System.Windows;
using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// 様々な2D領域型との相互型変換をサポートする2D領域情報構造体。
    /// </summary>
    [Serializable]
    public struct Size2D
    {
        #region 非公開フィールド

        /// <summary>
        /// 幅。
        /// </summary>
        private double _width;

        /// <summary>
        /// 高さ。
        /// </summary>
        private double _height;

        #endregion

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        public Size2D(double width, double height)
        {
            _width = width;
            _height = height;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Size2D(Size src)
            : this(src.Width, src.Height)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Size2D(Drawing::SizeF src)
            : this(src.Width, src.Height)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public Size2D(Vector src)
            : this(src.X, src.Y)
        {
        }

        #endregion

        #region 公開プロパティ

        /// <summary>
        /// 幅を取得または設定する。
        /// </summary>
        public double Width
        {
            get { return _width; }
            set { _width = Math.Max(value, 0); }
        }

        /// <summary>
        /// 高さを取得または設定する。
        /// </summary>
        public double Height
        {
            get { return _height; }
            set { _height = Math.Max(value, 0); }
        }

        #endregion

        #region 公開メソッド

        public override bool Equals(object obj)
        {
            if (obj is Size2D)
            {
                return (this == (Size2D)obj);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ((Size)this).GetHashCode();
        }

        public override string ToString()
        {
            return ((Size)this).ToString();
        }

        #endregion

        #region Size2D への型変換

        public static implicit operator Size2D(Size src)
        {
            return new Size2D(src);
        }

        public static implicit operator Size2D(Drawing::SizeF src)
        {
            return new Size2D(src);
        }

        public static explicit operator Size2D(Vector src)
        {
            return new Size2D(src);
        }

        #endregion

        #region Size2D からの型変換

        public static implicit operator Size(Size2D src)
        {
            return new Size(src.Width, src.Height);
        }

        public static explicit operator Drawing::SizeF(Size2D src)
        {
            return new Drawing::SizeF((float)src.Width, (float)src.Height);
        }

        public static explicit operator Vector(Size2D src)
        {
            return new Vector(src.Width, src.Height);
        }

        #endregion

        #region 演算子

        public static Size2D operator +(Size2D l, Vector r)
        {
            return new Size2D(l.Width + r.X, l.Height + r.Y);
        }

        public static Size2D operator -(Size2D l, Vector r)
        {
            return new Size2D(l.Width - r.X, l.Height - r.Y);
        }

        public static bool operator ==(Size2D l, Size2D r)
        {
            return (l.Width == r.Width && l.Height == r.Height);
        }

        public static bool operator !=(Size2D l, Size2D r)
        {
            return !(l == r);
        }

        #endregion

        #region 静的メソッド

        /// <summary>
        /// 面積を求める。
        /// </summary>
        /// <param name="s">サイズ。</param>
        /// <returns>面積。</returns>
        public static double Area(Size2D s)
        {
            return Math.Abs(s.Width * s.Height);
        }

        #endregion
    }
}
