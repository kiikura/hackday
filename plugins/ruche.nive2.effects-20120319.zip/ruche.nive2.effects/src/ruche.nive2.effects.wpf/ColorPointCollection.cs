﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// カラーポイントコレクションクラス。
    /// </summary>
    /// <remarks>
    /// このコレクションには常に開始点および終端点が含まれる。
    /// Clear メソッドを呼び出した場合も開始点および終端点は削除されない。
    /// </remarks>
    internal class ColorPointCollection : ICollection<ColorPoint>
    {
        /// <summary>
        /// 追加と削除が可能なカラーポイントの最小ID値。
        /// </summary>
        public const int AddableIdMin = 0;

        /// <summary>
        /// 開始点を表すカラーポイントID値。
        /// </summary>
        public const int BeginPointId = AddableIdMin - 1;

        /// <summary>
        /// 終端点を表すカラーポイントID値。
        /// </summary>
        public const int EndPointId = AddableIdMin - 2;

        /// <summary>
        /// 中心点を表すカラーポイントID値。
        /// </summary>
        public const int CenterPointId = AddableIdMin - 3;

        /// <summary>
        /// 開始点のカラーポイントの既定値。
        /// イベントハンドラは設定されていない。
        /// </summary>
        private static readonly ColorPoint DefaultBegin =
            new ColorPoint(BeginPointId, 0, Colors.Black, true);

        /// <summary>
        /// 終端点のカラーポイントの既定値。
        /// イベントハンドラは設定されていない。
        /// </summary>
        private static readonly ColorPoint DefaultEnd =
            new ColorPoint(EndPointId, 1, Colors.White, true);

        /// <summary>
        /// リスト実体。
        /// </summary>
        private List<ColorPoint> _items = new List<ColorPoint>();

        /// <summary>
        /// AddNew メソッドでのID割り振り用。
        /// </summary>
        private int _idBase = AddableIdMin;

        /// <summary>
        /// 開始点のカラーポイント。
        /// </summary>
        private ColorPoint _begin = new ColorPoint(DefaultBegin);

        /// <summary>
        /// 終端点のカラーポイント。
        /// </summary>
        private ColorPoint _end = new ColorPoint(DefaultEnd);

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public ColorPointCollection()
        {
            _begin.OffsetChanged += OnItemOffsetChanged;
            _end.OffsetChanged += OnItemOffsetChanged;

            Clear();
        }

        /// <summary>
        /// 開始点のカラーポイントを取得する。
        /// </summary>
        public ColorPoint Begin
        {
            get { return _begin; }
        }

        /// <summary>
        /// 終端点のカラーポイントを取得する。
        /// </summary>
        public ColorPoint End
        {
            get { return _end; }
        }

        /// <summary>
        /// 指定したID値のカラーポイントを取得するインデクサ。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <returns>
        /// カラーポイント。見つからなかった場合は null 。
        /// </returns>
        public ColorPoint this[int id]
        {
            get
            {
                int index = IndexOfId(id);
                return (index < 0) ? null : _items[index];
            }
        }

        /// <summary>
        /// 実体リストを取得する。
        /// </summary>
        protected List<ColorPoint> ItemList
        {
            get { return _items; }
        }

        /// <summary>
        /// 新しいカラーポイントを作成して追加する。
        /// </summary>
        /// <returns>追加されたカラーポイント。</returns>
        public ColorPoint AddNew()
        {
            while (ContainsId(_idBase))
            {
                ++_idBase;
            }

            var cp = new ColorPoint(_idBase);
            Add(cp);

            return cp;
        }

        /// <summary>
        /// 指定したID値のカラーポイントが含まれているか否かを取得する。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <returns>
        /// 含まれているならば true 。そうでなければ false 。
        /// </returns>
        public bool ContainsId(int id)
        {
            return (this[id] != null);
        }

        /// <summary>
        /// 指定したID値のカラーポイントをコレクションから削除する。
        /// </summary>
        /// <param name="id">
        /// ID値。 AddableIdMin 以上でなければならない。
        /// </param>
        /// <returns>
        /// 削除できたならば true 。そうでなければ false 。
        /// </returns>
        public bool RemoveById(int id)
        {
            if (id < AddableIdMin)
            {
                return false;
            }

            ColorPoint cp = this[id];
            return (cp == null) ? false : Remove(cp);
        }

        /// <summary>
        /// 開始点と終端点以外をクリアし、開始点と終端点を既定値にする。
        /// </summary>
        /// <param name="keepParams">
        /// 開始点と終端点の値を保持するならば true 。
        /// </param>
        public void Clear(bool keepParams)
        {
            // 一旦開始点と終端点を外す
            _items.Remove(_begin);
            _items.Remove(_end);

            // イベントハンドラを解除してからクリア
            foreach (ColorPoint cp in _items)
            {
                cp.OffsetChanged -= OnItemOffsetChanged;
            }
            _items.Clear();

            // 値を既定値にする
            if (!keepParams)
            {
                _begin.Value = DefaultBegin.Value;
                _begin.Position = DefaultBegin.Position;
                _end.Value = DefaultEnd.Value;
                _end.Position = DefaultEnd.Position;
            }

            // 再度追加
            _items.Add(_begin);
            _items.Add(_end);

            // AddNew 用
            _idBase = AddableIdMin;
        }

        /// <summary>
        /// 指定したID値のカラーポイントの1つ前にあるカラーポイントを取得する。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <returns>
        /// カラーポイント。引数が不正もしくは開始点である場合は null 。
        /// </returns>
        public ColorPoint PrevOfId(int id)
        {
            int index = IndexOfId(id) - 1;
            return (index < 0) ? null : _items[index];
        }

        /// <summary>
        /// 指定したID値のカラーポイントの1つ後ろにあるカラーポイントを取得する。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <returns>
        /// カラーポイント。引数が不正もしくは終端点である場合は null 。
        /// </returns>
        public ColorPoint NextOfId(int id)
        {
            int index = IndexOfId(id) + 1;
            return (index <= 0 || index >= Count) ? null : _items[index];
        }

        /// <summary>
        /// 指定したID値のカラーポイントの実体リスト内でのインデックスを取得する。
        /// </summary>
        /// <param name="id">ID値。</param>
        /// <returns>インデックス。見つからなかった場合は -1 。</returns>
        protected int IndexOfId(int id)
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                if (_items[i].Id == id)
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// ソートを行う。
        /// </summary>
        protected void Sort()
        {
            // 開始点は必ず先頭、終端点は必ず末尾にする
            _items.Sort((src1, src2) =>
            {
                int comp = src1.CompareTo(src2);
                if (comp != 0)
                {
                    if (src1.Id == BeginPointId || src2.Id == EndPointId)
                    {
                        return -1;
                    }
                    if (src1.Id == EndPointId || src2.Id == BeginPointId)
                    {
                        return 1;
                    }
                }
                return comp;
            });
        }

        /// <summary>
        /// アイテムのオフセット値が変更されたときに呼び出される。
        /// </summary>
        /// <param name="sender">イベントの発生元。</param>
        /// <param name="e">空のイベントパラメータ。</param>
        protected virtual void OnItemOffsetChanged(
            object sender, EventArgs e)
        {
            ColorPoint cp = sender as ColorPoint;
            if (cp != null)
            {
                switch (cp.Id)
                {
                    case BeginPointId:
                        cp.Offset = 0;
                        break;

                    case EndPointId:
                        cp.Offset = 1;
                        break;

                    default:
                        Sort();
                        break;
                }
            }
        }

        #region ICollection<ColorPoint> メンバ

        public void Add(ColorPoint item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            if (item.Id < AddableIdMin)
            {
                throw new ArgumentOutOfRangeException(
                    "item",
                    item,
                    AddableIdMin +
                    " 未満のIDを持つカラーポイントは追加できません。");
            }
            if (ContainsId(item.Id))
            {
                throw new ArgumentException(
                    "ID " + item.Id +
                    " のカラーポイントは既に追加されています。",
                    "item");
            }

            item.OffsetChanged += OnItemOffsetChanged;

            _items.Add(item);
            Sort();
        }

        /// <summary>
        /// 開始点と終端点以外を削除し、開始点と終端点を既定値にする。
        /// </summary>
        public void Clear()
        {
            Clear(false);
        }

        public bool Contains(ColorPoint item)
        {
            return _items.Contains(item);
        }

        public void CopyTo(ColorPoint[] array, int arrayIndex)
        {
            _items.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return _items.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(ColorPoint item)
        {
            if (item == null || item.Id < AddableIdMin)
            {
                return false;
            }

            bool result = _items.Remove(item);
            if (result)
            {
                item.OffsetChanged -= OnItemOffsetChanged;
            }

            return result;
        }

        #endregion

        #region IEnumerable<ColorPoint> メンバ

        public IEnumerator<ColorPoint> GetEnumerator()
        {
            return _items.GetEnumerator();
        }

        #endregion

        #region IEnumerable メンバ

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion
    }
}
