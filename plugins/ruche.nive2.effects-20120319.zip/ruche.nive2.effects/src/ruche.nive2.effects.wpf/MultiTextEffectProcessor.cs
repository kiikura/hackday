﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using NiVE2.Plugin.Interface;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using ruche.text;

using Drawing = System.Drawing;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// マルチテキストエフェクトの実処理を行うクラス。
    /// </summary>
    public partial class MultiTextEffectProcessor
    {
        /// <summary>
        /// 標準スタイルタグコレクション。
        /// </summary>
        private static readonly TextStyleTagCollection StandardTags =
            TextStyleTagCollection.CreateStandard();

        /// <summary>
        /// HTMLエンティティパーサ。
        /// </summary>
        private static readonly HtmlEntityParser EntityParser =
            new HtmlEntityParser();

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer;

        /// <summary>
        /// プロパティ値コンテナ。
        /// </summary>
        private MultiTextEffectPropertyContainer _container;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="layer">対象レイヤ。</param>
        public MultiTextEffectProcessor(ILayer layer)
        {
            SafeInvoker.NotifyBaseThread();

            if (layer == null)
            {
                throw new ArgumentNullException("layer");
            }

            _layer = layer;
            _container = new MultiTextEffectPropertyContainer();
            _container.ResetValues();
        }

        /// <summary>
        /// 対象レイヤを取得する。
        /// </summary>
        public ILayer Layer
        {
            get { return _layer; }
        }

        /// <summary>
        /// テキストエフェクトプロパティ配列を作成する。
        /// </summary>
        /// <returns>テキストエフェクトプロパティ配列。</returns>
        public PropertyBase[] CreateProperties()
        {
            var rect = Layer.GetImageBounds(0);

            return Util.JoinArrays(
                TextEffectUtil.CreateFormattedTextProperties(
                    rect.Width,
                    rect.Height),
                TextEffectUtil.CreateStyleProperties(true),
                TextEffectUtil.CreateSpeakProperties(true),
                TextEffectUtil.CreateProperties(
                    TextEffectCategory.Variables),
                TextEffectUtil.CreateProperties(
                    TextEffectCategory.Tags),
                TextEffectUtil.CreateProperties(
                    TextEffectCategory.Post),
                TextEffectUtil.CreateProperties(
                    TextEffectCategory.Delegate));
        }

        /// <summary>
        /// テキストエフェクトプロパティコントロール配列を作成する。
        /// </summary>
        /// <returns>テキストエフェクトプロパティコントロール配列。</returns>
        public PropertyEditControlBase[] CreateControls()
        {
            return Util.JoinArrays(
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.FormattedTexts),
                TextEffectUtil.CreateNestBeginControls("ベーススタイル"),
                    TextEffectUtil.CreateStylePropertyControls(false),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreateNestBeginControls("ベース表示速度"),
                    TextEffectUtil.CreateSpeakPropertyControls(false),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Variables),
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Tags),
                TextEffectUtil.CreateNestBeginControls("背景ポスト処理"),
                    TextEffectUtil.CreatePropertyControls(
                        TextEffectCategory.Post),
                TextEffectUtil.CreateNestEndControls());
        }

        /// <summary>
        /// イメージを処理する。
        /// </summary>
        /// <param name="image">イメージ。</param>
        /// <param name="propertyTable">プロパティテーブル。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="time">時刻。</param>
        /// <returns>処理されたイメージ。</returns>
        public NBitmap ProcessingImage(
            NBitmap image,
            IDictionary<string, PropertyBase> propertyTable,
            Roi roi,
            double time)
        {
            // プロパティ値更新
            _container.Apply(propertyTable.Values);

            // 共通のデリゲートプロパティ取得
            var commDeleProp =
                (TextEffectDelegateProperty)propertyTable["delegate"];

            // 変数リスト作成
            var baseVariables = new Dictionary<string, object>(
                _container.Variables.Length * 2 + 10);
            foreach (var vc in _container.Variables)
            {
                baseVariables[vc.Name] = vc.Value;
            }

            // 変数リスト共通デリゲート処理
            if (commDeleProp.Variable != null)
            {
                commDeleProp.Variable(baseVariables);
            }

            // タグコレクション作成
            var tags = StandardTags.Clone();
            tags.MergeRange(_container.Tags);

            // 解像度取得
            double resoRate = this.Layer.ResolutionRate;
            Size orgSize = new Size(
                roi.InterestWidth / resoRate,
                roi.InterestHeight / resoRate);

            // キャッシュサイズ算出
            long backCacheSize = BitmapUtil.Calc32bppSize(
                roi.InterestWidth,
                roi.InterestHeight);
            long orgCacheSize =
                BitmapUtil.Calc32bppSize(orgSize.Width, orgSize.Height);
            long allCacheSize = backCacheSize + orgCacheSize * 2;

            // 背景を切り取って処理
            using (var backLock = new CacheLocker(allCacheSize))
            using (
                var backImg = ImageUtil.CutImage(
                    image,
                    roi.InterestX,
                    roi.InterestY,
                    roi.InterestWidth,
                    roi.InterestHeight))
            {
                // 背景へのポスト処理
                ImageUtil.ConvertImageColor(
                    backImg,
                    _container.BackgroundPost.Alpha,
                    _container.BackgroundPost.Brightness,
                    _container.BackgroundPost.Saturation);

                // 描画用パラメータ用意
                var clipRect =
                    new Drawing::Rectangle(Drawing::Point.Empty, backImg.Size);
                var resoMatrix = new Matrix3D();
                resoMatrix.Scale((float)resoRate, (float)resoRate);

                // キャンバス作成
                var canvas = SafeInvoker.Call(
                    () =>
                    {
                        var c = new Canvas();
                        c.Width = orgSize.Width;
                        c.Height = orgSize.Height;
                        return c;
                    });

                // キャンバス要素全体にかかるマトリクス作成
                Matrix canvasMatrix = Matrix.Identity;
                canvasMatrix.Translate(
                    (roi.ImageX - roi.InterestX) / resoRate,
                    (roi.ImageY - roi.InterestY) / resoRate);

                // 各テキストセットの経過時間とデリゲート取得
                var textProp =
                    propertyTable["texts"] as AddableFormattedTextProperty;
                if (textProp == null)
                {
                    return image;
                }
                var ftProps = textProp.Properties.Select(
                    ps =>
                    {
                        var ftPropSet = (FormattedTextPropertySet)ps;
                        var keyProp =
                            ftPropSet.FindProperty("text")
                                as KeyFrameStringProperty;
                        var delegateProp =
                            ftPropSet.FindProperty("delegate")
                                as TextEffectDelegateProperty;
                        double elapsedTime =
                            (keyProp != null && keyProp.ElapsedTime >= 0) ?
                                keyProp.ElapsedTime :
                                time;
                        return new { delegateProp, elapsedTime };
                    })
                    .ToArray();

                // テキストを描画順序の小さい順にソート
                // Zオーダが同値の場合は元のインデックスでソート
                // orderby より List<T>.Sort の方が速いのでそちらを使う
                var textDatas = _container.Texts
                    .Select((t, i) => new { t, i, ftProp = ftProps[i] })
                    .ToList();
                textDatas.Sort(
                    (v1, v2) =>
                    {
                        int order = v1.t.Order.CompareTo(v2.t.Order);
                        return (order == 0) ? v1.i.CompareTo(v2.i) : order;
                    });

                // テキストごとに処理
                SafeInvoker.Call(canvas, () =>
                {
                    foreach (var d in textDatas)
                    {
                        var textData = d.t;
                        double elapsedTime = d.ftProp.elapsedTime;
                        var eachDeleProp = d.ftProp.delegateProp;

                        // 変数リスト個別デリゲート処理
                        var variables = baseVariables;
                        if (
                            textData.Option.VariableEnabled &&
                            eachDeleProp.Variable != null)
                        {
                            variables =
                                new Dictionary<string, object>(baseVariables);
                            eachDeleProp.Variable(variables);
                        }

                        // テキストデリゲート処理
                        if (commDeleProp.Text != null)
                        {
                            textData.Text = commDeleProp.Text(
                                textData.Text,
                                elapsedTime);
                        }
                        if (eachDeleProp.Text != null)
                        {
                            textData.Text = eachDeleProp.Text(
                                textData.Text,
                                elapsedTime);
                        }

                        // 描画情報作成
                        var info = CreateTextRenderingInfo(
                            textData,
                            _container,
                            variables,
                            tags);
                        if (info == null)
                        {
                            continue;
                        }

                        // 描画情報デリゲート処理
                        if (commDeleProp.RenderingInfo != null)
                        {
                            commDeleProp.RenderingInfo(info, elapsedTime);
                        }
                        if (eachDeleProp.RenderingInfo != null)
                        {
                            eachDeleProp.RenderingInfo(info, elapsedTime);
                        }

                        // キャンバスへ設定
                        canvas.Children.Clear();
                        RenderToCanvas(info, elapsedTime, canvas, canvasMatrix);
                        if (canvas.Children.Count <= 0)
                        {
                            continue;
                        }

                        // キャンバスレイアウト設定
                        canvas.Measure(orgSize);
                        canvas.Arrange(new Rect(orgSize));
                        canvas.UpdateLayout();

                        // NBitmap に変換
                        var rtBmp = BitmapUtil.CreateRenderTargetBitmap(
                            orgSize.Width,
                            orgSize.Height,
                            canvas);
                        using (var srcBmp = BitmapUtil.ConvertToNBitmap(rtBmp))
                        {
                            // ポスト処理
                            ImageUtil.ConvertImageColor(
                                srcBmp,
                                info.Alpha,
                                info.Brightness,
                                info.Saturation);

                            // ブレンド描画
                            ImageUtil.BlendImage(
                                backImg,
                                srcBmp,
                                Drawing::PointF.Empty,
                                info.BlendType,
                                clipRect,
                                resoMatrix,
                                true,
                                false);
                        }
                    }
                });

                // 元画像へ書き戻す
                ImageUtil.BlendImage(
                    image,
                    backImg,
                    roi.Interest.Location,
                    BlendType.Normal,
                    false,
                    false);
            }

            return image;
        }
    }
}
