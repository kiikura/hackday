﻿using System;
using System.Windows;
using System.Windows.Media;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト配置プロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class TextArrangePropertyContainer
        :
        Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextArrangePropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("arrange.position")]
        private double[] PositionData { get; set; }

        [Nive2Property("arrange.halign")]
        public BaseAlignment HorzAlign { get; set; }

        [Nive2Property("arrange.valign")]
        public BaseAlignment VertAlign { get; set; }

        [Nive2Property("arrange.size.min")]
        private double[] MinSizeData { get; set; }

        [Nive2Property("arrange.size.max")]
        private double[] MaxSizeData { get; set; }

        [Nive2Property("arrange.rotate.center")]
        private double[] RotateCenterData { get; set; }

        [Nive2Property("arrange.rotate.angle")]
        private double RotateAngleData { get; set; }

        [Nive2Property("arrange.row.align")]
        public TextAlignment RowAlign { get; set; }

        [Nive2Property("arrange.row.size.min")]
        private double[] MinRowSizeData { get; set; }

        [Nive2Property("arrange.row.size.max")]
        private double[] MaxRowSizeData { get; set; }

        [Nive2Property("arrange.row.htype")]
        public LineArrangeType RowHeightType { get; set; }

        [Nive2Property("arrange.row.span")]
        public double RowSpanPercent { get; set; }

        #endregion

        #region NiVE2プロパティ対応メンバへのアクセッサ

        public Point2D Position
        {
            get
            {
                return (PositionData == null || PositionData.Length < 2) ?
                    new Point2D() :
                    new Point2D(PositionData[0], PositionData[1]);
            }
            set
            {
                PositionData = new double[] { value.X, value.Y };
            }
        }

        public Size2D MinSize
        {
            get
            {
                return (MinSizeData == null || MinSizeData.Length < 2) ?
                    new Size2D() :
                    new Size2D(MinSizeData[0], MinSizeData[1]);
            }
            set
            {
                MinSizeData = new double[] { value.Width, value.Height };
            }
        }

        public Size2D MaxSize
        {
            get
            {
                return (MaxSizeData == null || MaxSizeData.Length < 2) ?
                    new Size2D() :
                    new Size2D(MaxSizeData[0], MaxSizeData[1]);
            }
            set
            {
                MaxSizeData = new double[] { value.Width, value.Height };
            }
        }

        public Point2D RotateCenter
        {
            get
            {
                if (RotateCenterData == null || RotateCenterData.Length < 2)
                {
                    return new Point2D();
                }
                return new Point2D(RotateCenterData[0], RotateCenterData[1]);
            }
            set
            {
                RotateCenterData = new double[] { value.X, value.Y };
            }
        }

        public double RotateAngle
        {
            get
            {
                var dest = RotateAngleData;
                while (dest < 0)
                {
                    dest += 360;
                }
                while (dest >= 360)
                {
                    dest -= 360;
                }
                return dest;
            }
            set { RotateAngleData = value; }
        }

        public Size2D MinRowSize
        {
            get
            {
                return (MinRowSizeData == null || MinRowSizeData.Length < 2) ?
                    new Size2D() :
                    new Size2D(MinRowSizeData[0], MinRowSizeData[1]);
            }
            set
            {
                MinRowSizeData = new double[] { value.Width, value.Height };
            }
        }

        public Size2D MaxRowSize
        {
            get
            {
                return (MaxRowSizeData == null || MaxRowSizeData.Length < 2) ?
                    new Size2D() :
                    new Size2D(MaxRowSizeData[0], MaxRowSizeData[1]);
            }
            set
            {
                MaxRowSizeData = new double[] { value.Width, value.Height };
            }
        }

        public double RowSpan
        {
            get { return (RowSpanPercent / 100); }
            set { RowSpanPercent = value * 100; }
        }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextArrangePropertyContainer Clone()
        {
            return (TextArrangePropertyContainer)base.Clone();
        }
    }
}
