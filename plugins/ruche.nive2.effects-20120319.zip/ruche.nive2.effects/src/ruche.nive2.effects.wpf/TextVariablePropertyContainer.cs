﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキスト変数プロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class TextVariablePropertyContainer
        :
        Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextVariablePropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("variable.name")]
        public string Name { get; set; }

        [Nive2Property("variable.value")]
        public object Value { get; set; }

        #endregion

        #region NiVE2プロパティ対応メンバへのアクセッサ

        public string StringValue
        {
            get { return (Value ?? string.Empty).ToString(); }
            set { Value = value; }
        }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new TextVariablePropertyContainer Clone()
        {
            return (TextVariablePropertyContainer)base.Clone();
        }
    }
}
