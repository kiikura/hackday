﻿using System;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// フォーマットテキストプロパティ値を保持するクラス。
    /// </summary>
    [Serializable]
    public sealed class FormattedTextPropertyContainer
        :
        Nive2PropertyContainerBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public FormattedTextPropertyContainer()
        {
        }

        #region NiVE2プロパティ対応メンバ

        [Nive2Property("text")]
        public string Text { get; set; }

        [Nive2Property("order")]
        public double Order { get; set; }

        [Nive2Property]
        public TextArrangePropertyContainer Arrange { get; set; }

        [Nive2Property]
        public TextOptionPropertyContainer Option { get; set; }

        [Nive2Property]
        public TextStylePropertyContainer Style { get; set; }

        [Nive2Property]
        public TextSpeakPropertyContainer Speak { get; set; }

        [Nive2Property]
        public TextPostPropertyContainer Post { get; set; }

        [Nive2Property("blend")]
        public BlendType Blend { get; set; }

        #endregion

        /// <summary>
        /// 自身のクローンを生成する。
        /// </summary>
        /// <returns>自身のクローン。</returns>
        public new FormattedTextPropertyContainer Clone()
        {
            return (FormattedTextPropertyContainer)base.Clone();
        }
    }
}
