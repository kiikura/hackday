﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// テキストエフェクトのデリゲートを保持するNiVE2プロパティクラス。
    /// エクスプレッションからの利用を想定している。
    /// </summary>
    /// <remarks>
    /// 不要なデリゲートには null を設定することで処理効率が向上する。
    /// 既定ではすべてのデリゲートに null が設定されている。
    /// </remarks>
    [Serializable]
    public class TextEffectDelegateProperty : PropertyBase
    {
        /// <summary>
        /// 変数リストに対する処理を行うデリゲート。
        /// </summary>
        /// <param name="variables">変数リスト。</param>
        public delegate void VariableDelegate(
            Dictionary<string, object> variables);

        /// <summary>
        /// テキストに対する処理を行い、最終的なテキストを返すデリゲート。
        /// </summary>
        /// <param name="text">テキスト。</param>
        /// <param name="elapsedTime">
        /// テキストが表示されてからの経過秒数。
        /// </param>
        /// <returns>最終的に使われるテキスト。</returns>
        public delegate string TextDelegate(
            string text,
            double elapsedTime);

        /// <summary>
        /// テキスト描画情報に対する処理を行うデリゲート。
        /// </summary>
        /// <param name="info">テキスト描画情報。</param>
        /// <param name="elapsedTime">
        /// テキストが表示されてからの経過秒数。
        /// </param>
        public delegate void RenderingInfoDelegate(
            TextRenderingInfo info,
            double elapsedTime);

        /// <summary>
        /// 変数リストデリゲート。
        /// </summary>
        [NonSerialized]
        private VariableDelegate _variable = null;

        /// <summary>
        /// テキストデリゲート。
        /// </summary>
        [NonSerialized]
        private TextDelegate _text = null;

        /// <summary>
        /// 描画情報デリゲート。
        /// </summary>
        [NonSerialized]
        private RenderingInfoDelegate _renderingInfo = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public TextEffectDelegateProperty(string name)
            : base(name)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public TextEffectDelegateProperty(TextEffectDelegateProperty src)
            : this(src.PropertyName)
        {
            this.Variable = src.Variable;
            this.Text = src.Text;
            this.RenderingInfo = src.RenderingInfo;
        }

        /// <summary>
        /// 変数リストデリゲートを取得または設定する。
        /// </summary>
        /// <remarks>
        /// 変数名をキーとする変数値のディクショナリを引数に受け取り、
        /// それに対して操作を行うデリゲート。
        /// </remarks>
        public VariableDelegate Variable
        {
            get { return _variable; }
            set { _variable = value; }
        }

        /// <summary>
        /// テキストデリゲートを取得または設定する。
        /// </summary>
        /// <remarks>
        /// テキストとそれが表示されてからの経過秒数を引数に受け取り、
        /// 最終的なテキストを作成して返すデリゲート。
        /// </remarks>
        public TextDelegate Text
        {
            get { return _text; }
            set { _text = value; }
        }

        /// <summary>
        /// テキスト描画情報デリゲートを取得または設定する。
        /// </summary>
        /// <remarks>
        /// テキストの描画情報とテキストが表示されてからの経過秒数を引数に
        /// 受け取り、テキスト描画情報に対して操作を行うデリゲート。
        /// </remarks>
        public RenderingInfoDelegate RenderingInfo
        {
            get { return _renderingInfo; }
            set { _renderingInfo = value; }
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return false; }
        }

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.Fixed; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            KeyFrame key = Util.GetFixedKeyFrame(keyFrame, time);
            return (key == null) ? null : key.Property.Copy();
        }

        public override PropertyBase Copy()
        {
            return new TextEffectDelegateProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            var p = obj as TextEffectDelegateProperty;
            if (p != null)
            {
                return (
                    Delegate.Equals(this.Variable, p.Variable) &&
                    Delegate.Equals(this.Text, p.Text) &&
                    Delegate.Equals(this.RenderingInfo, p.RenderingInfo));
            }
            return false;
        }

        #endregion
    }
}
