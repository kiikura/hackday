﻿using System;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using ruche.nive2.effects;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// ブラシプロパティを編集するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class SwitchableBrushPropertyEditControl
        :
        SwitchablePropertyEditControlBase
    {
        private PictureBox pictureEdit;

        /// <summary>
        /// 実処理インスタンス。
        /// </summary>
        BrushPropertyEditControlEngine _engine = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableBrushPropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable)
            : this(name, switchable, alwaysEditable, EditBrushTypes.All)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="types">編集可能なブラシ種別の組み合わせ。</param>
        public SwitchableBrushPropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            EditBrushTypes types)
            : base(name, switchable, alwaysEditable)
        {
            PropertyName = name;
            LabelName = name;

            // コントロール設定
            InitializeComponent();

            // 実処理インスタンス初期化
            _engine = new BrushPropertyEditControlEngine(
                this,
                pictureEdit,
                types);
            _engine.Initialize();

            // イベント登録
            _engine.BrushChangeCommitted += engine_BrushChangeCommitted;
        }

        #region SwitchablePropertyEditControlBase メンバ

        protected override SwitchablePropertyBase CreateProperty()
        {
            SwitchableBrushProperty prop = null;

            if (_engine.Brush != null)
            {
                prop = new SwitchableBrushProperty(
                    this.PropertyName,
                    _engine.Brush,
                    this.PropertyValid);
            }

            return prop;
        }

        protected override void UpdateControls(SwitchablePropertyBase property)
        {
            var prop = property as SwitchableBrushProperty;
            if (prop != null)
            {
                bool editable = (AlwaysEditable || PropertyValid);

                // 編集可否で枠線変更
                pictureEdit.BorderStyle = editable ?
                    BorderStyle.FixedSingle :
                    BorderStyle.None;

                // ブラシでコントロール更新
                _engine.Brush = prop.OriginalBrush;
                _engine.Update(editable);
            }
        }

        public override Type UseProperetyType()
        {
            return typeof(SwitchableBrushProperty);
        }

        #endregion

        #region PropertyEditControlBase メンバ

        protected override void Dispose(bool disposing)
        {
            if (_engine != null)
            {
                _engine.BrushChangeCommitted -= engine_BrushChangeCommitted;
                _engine.Dispose();
                _engine = null;
            }

            base.Dispose(disposing);
        }

        #endregion

        private void InitializeComponent()
        {
            this.pictureEdit = new System.Windows.Forms.PictureBox();
            this.panelClient.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // panelClient
            // 
            this.panelClient.Controls.Add(this.pictureEdit);
            this.panelClient.Location = new System.Drawing.Point(129, 0);
            this.panelClient.Size = new System.Drawing.Size(49, 18);
            // 
            // pictureEdit
            // 
            this.pictureEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureEdit.Location = new System.Drawing.Point(1, 0);
            this.pictureEdit.Name = "pictureEdit";
            this.pictureEdit.Size = new System.Drawing.Size(36, 18);
            this.pictureEdit.TabIndex = 0;
            this.pictureEdit.TabStop = false;
            // 
            // SwitchableBrushPropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Name = "SwitchableBrushPropertyEditControl";
            this.panelClient.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void engine_BrushChangeCommitted(object sender, EventArgs e)
        {
            // 新規プロパティ作成
            if (_engine.Brush != null)
            {
                NotifyPropertyChanged();
            }
        }
    }
}
