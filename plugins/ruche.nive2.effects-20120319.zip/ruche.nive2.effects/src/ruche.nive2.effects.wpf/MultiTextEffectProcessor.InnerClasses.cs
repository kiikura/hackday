﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ruche.nive2.effects.wpf
{
    partial class MultiTextEffectProcessor
    {
        /// <summary>
        /// 文字とその大きさを保持する構造体。
        /// </summary>
        private sealed class LetterData
        {
            /// <summary>
            /// 文字を取得または設定する。
            /// </summary>
            public string Letter { get; set; }

            /// <summary>
            /// 文字の幅を取得または設定する。
            /// </summary>
            /// <remarks>スケーリング済みの値を表す。</remarks>
            public double Width { get; set; }
        }

        /// <summary>
        /// パラメータ付きテキストの情報を保持するクラス。
        /// </summary>
        private sealed class EffectedTextInfo
        {
            /// <summary>
            /// コンストラクタ。
            /// </summary>
            /// <param name="src">基となる EffectedText 。</param>
            public EffectedTextInfo(EffectedText src)
            {
                var fontFace = new Typeface(
                    src.Style.FontFamily ?? TextEffectUtil.DefaultFontFamily,
                    src.Style.FontStyle ?? FontStyles.Normal,
                    src.Style.FontWeight ?? FontWeights.Normal,
                    FontStretches.Normal,
                    TextEffectUtil.DefaultFontFamily);
                var scale = new Vector(
                    src.Style.ScaleX ?? 1,
                    src.Style.ScaleY ?? 1);

                // 文字データリストの高さ、ベースライン比以外を設定
                this.Style = src.Style;
                this.Speak = src.Speak;
                this.FontFace = fontFace;
                this.FontSize =
                    src.Style.FontSize ?? TextEffectUtil.DefaultFontSize;
                this.Scale = scale;
                this.Height = double.MinValue;
                this.BaselineRate = 0;

                // 文字データリスト作成と高さ、ベースライン比設定
                this.Letters = new List<LetterData>();
                var e = StringInfo.GetTextElementEnumerator(src.Text);
                while (e.MoveNext())
                {
                    // サイズ計測用の FormattedText 作成
                    string letter = e.GetTextElement();
                    var ft = new FormattedText(
                        letter,
                        CultureInfo.CurrentCulture,
                        FlowDirection.LeftToRight,
                        fontFace,
                        this.FontSize,
                        Brushes.Black);
                    double width =
                        ft.WidthIncludingTrailingWhitespace * scale.X;
                    double height = ft.Height * scale.Y;

                    // 文字データ追加
                    var data =
                        new LetterData
                        {
                            Letter = letter,
                            Width = width,
                        };
                    this.Letters.Add(data);

                    // 高さ、ベースライン比更新
                    // 本当は文字ごとに持った方がいいのかも
                    if (height > this.Height)
                    {
                        this.Height = height;
                        this.BaselineRate = ft.Baseline / ft.Height;
                    }
                }

                // 文字が無いなら高さ、ベースライン比だけ設定
                if (this.Letters.Count == 0)
                {
                    var ft = new FormattedText(
                        " ",
                        CultureInfo.CurrentCulture,
                        FlowDirection.LeftToRight,
                        fontFace,
                        this.FontSize,
                        Brushes.Black);
                    this.Height = ft.Height * scale.Y;
                    this.BaselineRate = ft.Baseline / ft.Height;
                }
            }

            /// <summary>
            /// コンストラクタ。
            /// </summary>
            private EffectedTextInfo()
            {
            }

            /// <summary>
            /// 文字データコレクションを取得する。
            /// </summary>
            public List<LetterData> Letters { get; private set; }

            /// <summary>
            /// スタイルを取得する。
            /// </summary>
            public TextStylePropertyContainer Style { get; private set; }

            /// <summary>
            /// 表示速度を取得する。
            /// </summary>
            public TextSpeakPropertyContainer Speak { get; private set; }

            /// <summary>
            /// フォントタイプフェースを取得する。
            /// </summary>
            public Typeface FontFace { get; private set; }

            /// <summary>
            /// フォントサイズを取得する。
            /// </summary>
            public double FontSize { get; private set; }

            /// <summary>
            /// スケーリング値を取得する。
            /// </summary>
            public Vector Scale { get; private set; }

            /// <summary>
            /// 文字列の高さを取得する。
            /// </summary>
            /// <remarks>スケーリング済みの値を返す。</remarks>
            public double Height { get; private set; }

            /// <summary>
            /// 文字列の上端からベースラインまでの高さに対する割合を取得する。
            /// </summary>
            public double BaselineRate { get; private set; }

            /// <summary>
            /// 文字列の上端からベースラインまでの距離を取得する。
            /// </summary>
            public double Baseline
            {
                get { return Height * BaselineRate; }
            }

            /// <summary>
            /// 文字列の幅を取得する。
            /// </summary>
            public double Width
            {
                get { return CalcWidth(0, Letters.Count); }
            }

            /// <summary>
            /// 縦方向の配置を取得する。
            /// </summary>
            public TextVerticalAlignment VertAlign
            {
                get
                {
                    return Style.VertAlign ?? TextVerticalAlignment.Baseline;
                }
            }

            /// <summary>
            /// 各文字の上方向のマージンを取得する。
            /// </summary>
            public double LetterMarginTop
            {
                get { return (Style.MarginTop ?? 0); }
            }

            /// <summary>
            /// 各文字の右方向のマージンを取得する。
            /// </summary>
            public double LetterMarginRight
            {
                get { return (Style.MarginRight ?? 0); }
            }

            /// <summary>
            /// 各文字の下方向のマージンを取得する。
            /// </summary>
            public double LetterMarginBottom
            {
                get { return (Style.MarginBottom ?? 0); }
            }

            /// <summary>
            /// 各文字の左方向のマージンを取得する。
            /// </summary>
            public double LetterMarginLeft
            {
                get { return (Style.MarginLeft ?? 0); }
            }

            /// <summary>
            /// 先頭の空白文字数を取得する。
            /// </summary>
            /// <returns>先頭の空白文字数。</returns>
            public int GetLeftWhiteSpaceCount()
            {
                int count = 0;
                foreach (var l in Letters)
                {
                    if (!char.IsWhiteSpace(l.Letter[0]))
                    {
                        break;
                    }
                    ++count;
                }
                return count;
            }

            /// <summary>
            /// 末尾の空白文字数を取得する。
            /// </summary>
            /// <returns>先頭の空白文字数。</returns>
            public int GetRightWhiteSpaceCount()
            {
                int count = 0;
                foreach (var l in Letters.Reverse<LetterData>())
                {
                    if (!char.IsWhiteSpace(l.Letter[0]))
                    {
                        break;
                    }
                    ++count;
                }
                return count;
            }

            /// <summary>
            /// 指定した文字範囲の幅を算出する。
            /// </summary>
            /// <param name="startIndex">開始位置。</param>
            /// <param name="count">文字数。</param>
            /// <returns>幅。</returns>
            public double CalcWidth(int startIndex, int count)
            {
                var letters = Letters;
                if (startIndex > 0 || startIndex + count < letters.Count)
                {
                    letters = letters.GetRange(startIndex, count);
                }

                double margin = Math.Max(LetterMarginLeft, LetterMarginRight);
                return (letters.Sum((l) => l.Width + margin) - margin);
            }

            /// <summary>
            /// 指定した幅に収まる文字数を算出する。
            /// </summary>
            /// <param name="width">幅。</param>
            /// <param name="startIndex">開始位置。</param>
            /// <returns>文字数。</returns>
            public int CalcLetterCount(double width, int startIndex)
            {
                for (int count = Letters.Count - startIndex; count > 0; --count)
                {
                    if (CalcWidth(startIndex, count) <= width)
                    {
                        return count;
                    }
                }
                return 0;
            }

            /// <summary>
            /// 指定位置から末尾までを抜き出した新しいインスタンスを取得する。
            /// </summary>
            /// <param name="startIndex">開始位置。</param>
            /// <returns>新しいインスタンス。</returns>
            public EffectedTextInfo GetRange(int startIndex)
            {
                return GetRange(startIndex, Letters.Count - startIndex);
            }

            /// <summary>
            /// 指定した文字範囲を抜き出した新しいインスタンスを取得する。
            /// </summary>
            /// <param name="startIndex">開始位置。</param>
            /// <param name="count">文字数。</param>
            /// <returns>新しいインスタンス。</returns>
            public EffectedTextInfo GetRange(int startIndex, int count)
            {
                return new EffectedTextInfo
                    {
                        Letters = this.Letters.GetRange(startIndex, count),
                        Style = this.Style,
                        Speak = this.Speak,
                        FontFace = this.FontFace,
                        FontSize = this.FontSize,
                        Scale = this.Scale,
                        Height = this.Height,
                        BaselineRate = this.BaselineRate,
                    };
            }
        }

        /// <summary>
        /// テキスト情報のリストで表されるテキスト行のデータを保持するクラス。
        /// </summary>
        private sealed class EffectedTextInfoRow
        {
            /// <summary>
            /// コンストラクタ。
            /// </summary>
            /// <param name="index">論理行番号。</param>
            /// <param name="src">基となるテキスト情報リスト。</param>
            public EffectedTextInfoRow(int index, List<EffectedTextInfo> src)
            {
                // 最も高いテキスト情報を検索
                EffectedTextInfo hinfo = null;
                double h = double.MinValue;
                foreach (var info in src)
                {
                    if (info.Height > h || hinfo == null)
                    {
                        hinfo = info;
                        h = info.Height;
                    }
                }

                this.Index = index;
                this.Infos = src;
                this.HighestInfo = hinfo;
            }

            /// <summary>
            /// 論理行番号を取得する。
            /// </summary>
            public int Index { get; private set; }

            /// <summary>
            /// テキスト情報リストを取得する。
            /// </summary>
            public List<EffectedTextInfo> Infos { get; private set; }

            /// <summary>
            /// 最も Height の値が大きいテキスト情報を取得する。
            /// </summary>
            public EffectedTextInfo HighestInfo { get; private set; }
        }

        /// <summary>
        /// 位置情報付きの EffectedTextInfo を保持するクラス。
        /// </summary>
        private sealed class EffectedTextInfoWithXY
        {
            /// <summary>
            /// EffectedTextInfo を取得または設定する。
            /// </summary>
            public EffectedTextInfo Info { get; set; }

            /// <summary>
            /// X位置を取得または設定する。
            /// </summary>
            public double X { get; set; }

            /// <summary>
            /// Y位置を取得または設定する。
            /// </summary>
            public double Y { get; set; }
        }

        /// <summary>
        /// テキスト行データを保持するクラス。
        /// </summary>
        private sealed class TextRowData
        {
            /// <summary>
            /// 内包するテキスト情報リストを取得または設定する。
            /// </summary>
            public List<EffectedTextInfoWithXY> Infos { get; set; }

            /// <summary>
            /// 論理行番号を取得または設定する。
            /// </summary>
            public int Index { get; set; }

            /// <summary>
            /// Y位置を取得または設定する。
            /// </summary>
            public double Y { get; set; }

            /// <summary>
            /// 幅を取得または設定する。
            /// </summary>
            public double Width { get; set; }

            /// <summary>
            /// 高さを取得または設定する。
            /// </summary>
            public double Height { get; set; }

            /// <summary>
            /// Y位置に高さの半分を加えた値を取得または設定する。
            /// </summary>
            /// <remarks>
            /// 値を設定すると、 Height はそのままで Y が更新される。
            /// </remarks>
            public double CenterY
            {
                get { return Y + Height / 2; }
                set { Y = value - Height / 2; }
            }

            /// <summary>
            /// Y位置に高さを加えた値を取得または設定する。
            /// </summary>
            /// <remarks>
            /// 値を設定すると、 Height はそのままで Y が更新される。
            /// </remarks>
            public double BottomY
            {
                get { return Y + Height; }
                set { Y = value - Height; }
            }
        }

        /// <summary>
        /// テキストの構成要素を表す列挙。
        /// </summary>
        private enum TextContent
        {
            /// <summary>
            /// 文字。
            /// </summary>
            Letter,

            /// <summary>
            /// 下線。
            /// </summary>
            Underline,

            /// <summary>
            /// 取り消し線。
            /// </summary>
            Strike,

            /// <summary>
            /// 傍点。
            /// </summary>
            Dot,
        }

        /// <summary>
        /// テキストの図形データを保持するクラス。
        /// </summary>
        private sealed class TextShapeData : IComparable<TextShapeData>
        {
            /// <summary>
            /// 図形を取得または設定する。
            /// </summary>
            public Shape Shape { get; set; }

            /// <summary>
            /// 構成要素種別を取得または設定する。
            /// </summary>
            public TextContent Content { get; set; }

            /// <summary>
            /// Zオーダを取得または設定する。
            /// </summary>
            public double ZOrder { get; set; }

            #region IComparable<TextVisualData> メンバ

            public int CompareTo(TextShapeData other)
            {
                int result = 1;
                if (other != null)
                {
                    result = this.ZOrder.CompareTo(other.ZOrder);
                    if (result == 0)
                    {
                        result = this.Content.CompareTo(other.Content);
                    }
                }
                return result;
            }

            #endregion
        }
    }
}
