﻿using System;
using System.Collections.Generic;
using System.Linq;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// フォーマットテキスト情報を保持するNiVE2プロパティセットクラス。
    /// </summary>
    [Serializable]
    public class FormattedTextPropertySet : PropertySetBase
    {
        /// <summary>
        /// 有効状態の初期値。
        /// </summary>
        private bool _valid = true;

        /// <summary>
        /// 有効状態切り替え可能フラグ。
        /// </summary>
        private bool _switchable = true;

        /// <summary>
        /// 幅の基準値。
        /// </summary>
        private double _width = 2000;

        /// <summary>
        /// 高さの基準値。
        /// </summary>
        private double _height = 2000;

        /// <summary>
        /// プロパティ名とプロパティインスタンスのテーブル。
        /// </summary>
        private Dictionary<string, PropertyBase> _propTable = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="valid">有効状態の初期値。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="width">幅の基準値。</param>
        /// <param name="height">高さの基準値。</param>
        public FormattedTextPropertySet(
            string name,
            bool valid,
            bool switchable,
            double width,
            double height)
            : base(name)
        {
            _valid = valid;
            _switchable = switchable;
            _width = width;
            _height = height;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public FormattedTextPropertySet(FormattedTextPropertySet src)
            :
            this(
                src.PropertyName,
                src._valid,
                src._switchable,
                src._width,
                src._height)
        {
            if (src._propTable != null)
            {
                _propTable =
                    new Dictionary<string, PropertyBase>(src._propTable.Count);
                foreach (var kv in src._propTable)
                {
                    _propTable.Add(kv.Key, kv.Value.Copy());
                }
            }
        }

        /// <summary>
        /// プロパティを取得するインデクサ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <returns>プロパティ。存在しないならば null 。</returns>
        public PropertyBase this[string name]
        {
            get { return FindProperty(name); }
        }

        /// <summary>
        /// プロパティを検索する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <returns>プロパティ。存在しないならば null 。</returns>
        public PropertyBase FindProperty(string name)
        {
            PropertyBase result = null;

            if (_propTable != null)
            {
                if (!_propTable.TryGetValue(name, out result))
                {
                    result = null;
                }
            }

            return result;
        }

        #region PropertySetBase メンバ

        public override PropertyBase[] Properties
        {
            get { return _propTable.Values.ToArray(); }
            set
            {
                if (value != null)
                {
                    foreach (var prop in value)
                    {
                        if (_propTable.ContainsKey(prop.PropertyName))
                        {
                            _propTable[prop.PropertyName] = prop;
                        }
                    }
                }
            }
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // コントロール配列作成
            return Util.JoinArrays(
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Text),
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Order),
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Arrange),
                TextEffectUtil.CreateNestBeginControls("拡張書式"),
                    TextEffectUtil.CreatePropertyControls(
                        TextEffectCategory.Option),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreateNestBeginControls("スタイル"),
                    TextEffectUtil.CreateStylePropertyControls(_switchable),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreateNestBeginControls("表示速度"),
                    TextEffectUtil.CreateSpeakPropertyControls(_switchable),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreateNestBeginControls("ポスト処理"),
                    TextEffectUtil.CreatePropertyControls(
                        TextEffectCategory.Post),
                TextEffectUtil.CreateNestEndControls(),
                TextEffectUtil.CreatePropertyControls(
                    TextEffectCategory.Blend));
        }

        public override void InitializeDefaultProperty()
        {
            // 内部プロパティ配列作成
            var props = Util.JoinArrays(
                TextEffectUtil.CreateProperties(TextEffectCategory.Text),
                TextEffectUtil.CreateProperties(TextEffectCategory.Order),
                TextEffectUtil.CreateArrangeProperties(_width, _height),
                TextEffectUtil.CreateProperties(TextEffectCategory.Option),
                TextEffectUtil.CreateStyleProperties(_valid),
                TextEffectUtil.CreateSpeakProperties(_valid),
                TextEffectUtil.CreateProperties(TextEffectCategory.Post),
                TextEffectUtil.CreateProperties(TextEffectCategory.Blend),
                TextEffectUtil.CreateProperties(TextEffectCategory.Delegate));

            // プロパティテーブル作成
            _propTable = new Dictionary<string, PropertyBase>(props.Length);
            foreach (var prop in props)
            {
                _propTable.Add(prop.PropertyName, prop);
            }
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase Copy()
        {
            return new FormattedTextPropertySet(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            var prop = obj as FormattedTextPropertySet;
            if (
                prop != null &&
                this.PropertyName == prop.PropertyName &&
                this._valid == prop._valid &&
                this._switchable == prop._switchable &&
                this._width == prop._width &&
                this._height == prop._height)
            {
                if (this._propTable == null || prop._propTable == null)
                {
                    return (this._propTable == prop._propTable);
                }

                return this._propTable.All(
                    kv => kv.Value.Equals(prop[kv.Key]));
            }
            return false;
        }

        #endregion
    }
}
