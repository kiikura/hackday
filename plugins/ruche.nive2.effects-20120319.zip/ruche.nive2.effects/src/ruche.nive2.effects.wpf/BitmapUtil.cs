﻿#define USE_COPYPIXELS

using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using NiVE2.Drawing;
using ruche.nive2.effects;

using Drawing = System.Drawing;
using Drawing2D = System.Drawing.Drawing2D;
using Imaging = System.Drawing.Imaging;
using Media = System.Windows.Media;
using Shapes = System.Windows.Shapes;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// ビットマップ関連の処理を定義する静的クラス。
    /// </summary>
    public static class BitmapUtil
    {
        #region 32bppサイズ計算

        /// <summary>
        /// 指定した幅と高さを持つ32bppイメージのデータサイズを算出する。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <returns>データサイズ。</returns>
        public static long Calc32bppSize(double width, double height)
        {
            return (4L * (long)Math.Ceiling(width) * (long)Math.Ceiling(height));
        }

        /// <summary>
        /// ソースイメージを32bppイメージに変換した時のデータサイズを算出する。
        /// </summary>
        /// <param name="src">ソースイメージ。</param>
        /// <returns>データサイズ。</returns>
        public static long Calc32bppSize(BitmapSource src)
        {
            return Calc32bppSize(src.PixelWidth, src.PixelHeight);
        }

        /// <summary>
        /// ソースイメージ32bppイメージに変換した時のデータサイズを算出する。
        /// </summary>
        /// <param name="src">ソースイメージ。</param>
        /// <returns>データサイズ。</returns>
        public static long Calc32bppSize(NBitmap src)
        {
            return Calc32bppSize(src.Width, src.Height);
        }

        /// <summary>
        /// ソースイメージを32bppイメージに変換した時のデータサイズを算出する。
        /// </summary>
        /// <param name="src">ソースイメージ。</param>
        /// <returns>データサイズ。</returns>
        public static long Calc32bppSize(Drawing::Image src)
        {
            return Calc32bppSize(src.Width, src.Height);
        }

        #endregion

        #region BGRA32形式 BitmapSource インスタンス生成

        /// <summary>
        /// RenderTargetBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <returns>RenderTargetBitmap インスタンス。</returns>
        public static RenderTargetBitmap CreateRenderTargetBitmap(
            double width, double height)
        {
            return new RenderTargetBitmap(
                (int)Math.Ceiling(width),
                (int)Math.Ceiling(height),
                96,
                96,
                PixelFormats.Pbgra32);
        }

        /// <summary>
        /// RenderTargetBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <param name="src">初期表示ビジュアル。</param>
        /// <returns>RenderTargetBitmap インスタンス。</returns>
        public static RenderTargetBitmap CreateRenderTargetBitmap(
            double width, double height, Visual src)
        {
            var dest = CreateRenderTargetBitmap(width, height);

            dest.Render(src);

            return dest;
        }

        /// <summary>
        /// RenderTargetBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <param name="fillBrush">塗り潰すブラシ。</param>
        /// <returns>RenderTargetBitmap インスタンス。</returns>
        public static RenderTargetBitmap CreateRenderTargetBitmap(
            double width, double height, Media::Brush fillBrush)
        {
            var rect = new Shapes::Rectangle();
            rect.Width = width;
            rect.Height = height;
            rect.Fill = fillBrush;
            rect.Measure(new Size(width, height));
            rect.Arrange(new Rect(new Size(width, height)));

            return CreateRenderTargetBitmap(width, height, rect);
        }

        /// <summary>
        /// WriteableBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <returns>WriteableBitmap インスタンス。</returns>
        public static WriteableBitmap CreateWriteableBitmap(
            double width, double height)
        {
            return new WriteableBitmap(
                (int)Math.Ceiling(width),
                (int)Math.Ceiling(height),
                96,
                96,
                PixelFormats.Bgra32,
                null);
        }

        /// <summary>
        /// WriteableBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="src">ソースイメージ。</param>
        /// <returns>WriteableBitmap インスタンス。</returns>
        public static WriteableBitmap CreateWriteableBitmap(NBitmap src)
        {
            var dest = CreateWriteableBitmap(src.Width, src.Height);

            var rect = new Int32Rect(0, 0, src.Width, src.Height);
            dest.Lock();
            dest.WritePixels(rect, src.GetData(), src.Width * 4, 0);
            dest.AddDirtyRect(rect);
            dest.Unlock();

            return dest;
        }

        /// <summary>
        /// WriteableBitmap インスタンスを生成する。
        /// </summary>
        /// <param name="src">ソースイメージ。</param>
        /// <returns>WriteableBitmap インスタンス。</returns>
        public static WriteableBitmap CreateWriteableBitmap(Drawing::Bitmap src)
        {
            WriteableBitmap dest = null;

            using (var bmp = new NBitmap(src))
            {
                dest = CreateWriteableBitmap(bmp);
            }

            return dest;
        }

        #endregion

        #region BitmapSource からの変換

        /// <summary>
        /// BitmapSource インスタンスをBGRA32形式に変換する。
        /// </summary>
        /// <param name="src">BitmapSource インスタンス。</param>
        /// <returns>
        /// BGRA32形式の BitmapSource インスタンス。
        /// src が既にBGRA32形式である場合は src そのもの。
        /// </returns>
        public static BitmapSource ConvertToBgra32(BitmapSource src)
        {
            return SafeInvoker.Call(src, () =>
                {
                    var dest = (BitmapSource)src.GetAsFrozen();
                    if (dest.Format != PixelFormats.Bgra32)
                    {
                        dest = new FormatConvertedBitmap(
                            dest,
                            PixelFormats.Bgra32,
                            null,
                            0.0);
                        dest.Freeze();
                    }
                    return dest;
                });
        }

        /// <summary>
        /// BitmapSource インスタンスを NBitmap インスタンスに変換する。
        /// </summary>
        /// <param name="src">BitmapSource インスタンス。</param>
        /// <returns>NBitmap インスタンス。</returns>
        public static NBitmap ConvertToNBitmap(BitmapSource src)
        {
#if USE_COPYPIXELS
            // version 1.3 以降

            NBitmap dest = new NBitmap(
                (int)Math.Ceiling(src.Width),
                (int)Math.Ceiling(src.Height));

            SafeInvoker.Call(src, () =>
            {
                BitmapSource src32 = ConvertToBgra32(src);
                src32.CopyPixels(dest.GetData(), dest.Width * 4, 0);
            });

            return dest;

#else // USE_COPYPIXELS
            // version 1.2 以前

            NBitmap dest = null;

            using (var bmp = ConvertToBitmap(src))
            {
                dest = new NBitmap(bmp);
            }

            return dest;

#endif // USE_COPYPIXELS
        }

        /// <summary>
        /// BitmapSource インスタンスを Bitmap インスタンスに変換する。
        /// </summary>
        /// <param name="src">BitmapSource インスタンス。</param>
        /// <returns>Bitmap インスタンス。</returns>
        public static Drawing::Bitmap ConvertToBitmap(BitmapSource src)
        {
#if USE_COPYPIXELS
            // version 1.3 以降

            Drawing::Bitmap dest = null;

            using (var bmp = ConvertToNBitmap(src))
            {
                dest = bmp.ToBitmap();
            }

            return dest;

#else // USE_COPYPIXELS
            // version 1.2 以前

            return SafeInvoker.Call(src, () =>
                {
                    var encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(
                        BitmapFrame.Create((BitmapSource)src.GetAsFrozen()));

                    Drawing::Bitmap dest = null;
                    using (var s = new MemoryStream())
                    {
                        encoder.Save(s);
                        s.Seek(0, SeekOrigin.Begin);
                        dest = new Drawing::Bitmap(s);
                    }

                    return dest;
                });

#endif // USE_COPYPIXELS
        }

        #endregion

        #region その他

        /// <summary>
        /// 無効状態を表す Bitmap を作成する。
        /// </summary>
        /// <param name="src">Bitmap インスタンス。</param>
        /// <returns>無効状態を表す Bitmap インスタンス。</returns>
        public static Drawing::Bitmap CreateGrayedBitmap(Drawing::Image src)
        {
            var dest = new Drawing::Bitmap(src);

            // 無効状態テキスト色取得(黒がこの色になる)
            Color32 gray = Drawing::SystemColors.GrayText;
            float dr = gray.R / 255.0F;
            float dg = gray.G / 255.0F;
            float db = gray.B / 255.0F;

            // 無効状態テキスト色を反転した値取得
            float ir = 1 - dr;
            float ig = 1 - dg;
            float ib = 1 - db;

            // 明るさ割合取得(グレースケール用)
            float br = (float)ImageUtil.BrightnessRateRed;
            float bg = (float)ImageUtil.BrightnessRateGreen;
            float bb = (float)ImageUtil.BrightnessRateBlue;

            // 色変換行列作成
            float[][] matrix = new float[][]
                {
                    new float[] { br * ir, br * ig, br * ib, 0, 0 },
                    new float[] { bg * ir, bg * ig, bg * ib, 0, 0 },
                    new float[] { bb * ir, bb * ig, bb * ib, 0, 0 },
                    new float[] { 0      , 0      , 0      , 1, 0 },
                    new float[] { dr     , dg     , db     , 0, 1 },
                };

            using (var attr = new Imaging::ImageAttributes())
            using (var g = Drawing::Graphics.FromImage(dest))
            {
                // 色変換行列設定
                attr.SetColorMatrix(new Imaging::ColorMatrix(matrix));

                // 上書き描画
                g.CompositingMode = Drawing2D::CompositingMode.SourceCopy;
                g.DrawImage(
                    src,
                    new Drawing::Rectangle(0, 0, dest.Width, dest.Height),
                    0, 0, src.Width, src.Height,
                    Drawing::GraphicsUnit.Pixel,
                    attr);
            }

            return dest;
        }

        #endregion
    }
}
