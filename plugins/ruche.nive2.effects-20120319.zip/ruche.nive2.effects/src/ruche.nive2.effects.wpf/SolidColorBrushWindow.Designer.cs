﻿namespace ruche.nive2.effects.wpf
{
    partial class SolidColorBrushWindow
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureView = new System.Windows.Forms.PictureBox();
            this.buttonDef0 = new System.Windows.Forms.Button();
            this.buttonDef1 = new System.Windows.Forms.Button();
            this.buttonDef2 = new System.Windows.Forms.Button();
            this.buttonDef3 = new System.Windows.Forms.Button();
            this.buttonDef7 = new System.Windows.Forms.Button();
            this.buttonDef6 = new System.Windows.Forms.Button();
            this.buttonDef5 = new System.Windows.Forms.Button();
            this.buttonDef4 = new System.Windows.Forms.Button();
            this.buttonDef11 = new System.Windows.Forms.Button();
            this.buttonDef10 = new System.Windows.Forms.Button();
            this.buttonDef9 = new System.Windows.Forms.Button();
            this.buttonDef8 = new System.Windows.Forms.Button();
            this.buttonDef15 = new System.Windows.Forms.Button();
            this.buttonDef14 = new System.Windows.Forms.Button();
            this.buttonDef13 = new System.Windows.Forms.Button();
            this.buttonDef12 = new System.Windows.Forms.Button();
            this.buttonColor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDefUser = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.numDragAlpha = new ruche.nive2.effects.NumericDragBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureView)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureView
            // 
            this.pictureView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureView.Location = new System.Drawing.Point(8, 8);
            this.pictureView.Name = "pictureView";
            this.pictureView.Size = new System.Drawing.Size(110, 140);
            this.pictureView.TabIndex = 0;
            this.pictureView.TabStop = false;
            // 
            // buttonDef0
            // 
            this.buttonDef0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef0.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef0.Location = new System.Drawing.Point(126, 8);
            this.buttonDef0.Name = "buttonDef0";
            this.buttonDef0.Size = new System.Drawing.Size(64, 21);
            this.buttonDef0.TabIndex = 4;
            this.buttonDef0.Text = "#000000";
            this.buttonDef0.UseVisualStyleBackColor = true;
            this.buttonDef0.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef0.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef1
            // 
            this.buttonDef1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef1.Location = new System.Drawing.Point(191, 8);
            this.buttonDef1.Name = "buttonDef1";
            this.buttonDef1.Size = new System.Drawing.Size(64, 21);
            this.buttonDef1.TabIndex = 5;
            this.buttonDef1.Text = "#000000";
            this.buttonDef1.UseVisualStyleBackColor = true;
            this.buttonDef1.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef1.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef2
            // 
            this.buttonDef2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef2.Location = new System.Drawing.Point(256, 8);
            this.buttonDef2.Name = "buttonDef2";
            this.buttonDef2.Size = new System.Drawing.Size(64, 21);
            this.buttonDef2.TabIndex = 6;
            this.buttonDef2.Text = "#000000";
            this.buttonDef2.UseVisualStyleBackColor = true;
            this.buttonDef2.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef2.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef3
            // 
            this.buttonDef3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef3.Location = new System.Drawing.Point(321, 8);
            this.buttonDef3.Name = "buttonDef3";
            this.buttonDef3.Size = new System.Drawing.Size(64, 21);
            this.buttonDef3.TabIndex = 7;
            this.buttonDef3.Text = "#000000";
            this.buttonDef3.UseVisualStyleBackColor = true;
            this.buttonDef3.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef3.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef7
            // 
            this.buttonDef7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef7.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef7.Location = new System.Drawing.Point(321, 30);
            this.buttonDef7.Name = "buttonDef7";
            this.buttonDef7.Size = new System.Drawing.Size(64, 21);
            this.buttonDef7.TabIndex = 11;
            this.buttonDef7.Text = "#000000";
            this.buttonDef7.UseVisualStyleBackColor = true;
            this.buttonDef7.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef7.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef6
            // 
            this.buttonDef6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef6.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef6.Location = new System.Drawing.Point(256, 30);
            this.buttonDef6.Name = "buttonDef6";
            this.buttonDef6.Size = new System.Drawing.Size(64, 21);
            this.buttonDef6.TabIndex = 10;
            this.buttonDef6.Text = "#000000";
            this.buttonDef6.UseVisualStyleBackColor = true;
            this.buttonDef6.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef6.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef5
            // 
            this.buttonDef5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef5.Location = new System.Drawing.Point(191, 30);
            this.buttonDef5.Name = "buttonDef5";
            this.buttonDef5.Size = new System.Drawing.Size(64, 21);
            this.buttonDef5.TabIndex = 9;
            this.buttonDef5.Text = "#000000";
            this.buttonDef5.UseVisualStyleBackColor = true;
            this.buttonDef5.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef5.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef4
            // 
            this.buttonDef4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef4.Location = new System.Drawing.Point(126, 30);
            this.buttonDef4.Name = "buttonDef4";
            this.buttonDef4.Size = new System.Drawing.Size(64, 21);
            this.buttonDef4.TabIndex = 8;
            this.buttonDef4.Text = "#000000";
            this.buttonDef4.UseVisualStyleBackColor = true;
            this.buttonDef4.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef4.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef11
            // 
            this.buttonDef11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef11.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef11.Location = new System.Drawing.Point(321, 52);
            this.buttonDef11.Name = "buttonDef11";
            this.buttonDef11.Size = new System.Drawing.Size(64, 21);
            this.buttonDef11.TabIndex = 15;
            this.buttonDef11.Text = "#000000";
            this.buttonDef11.UseVisualStyleBackColor = true;
            this.buttonDef11.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef11.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef10
            // 
            this.buttonDef10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef10.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef10.Location = new System.Drawing.Point(256, 52);
            this.buttonDef10.Name = "buttonDef10";
            this.buttonDef10.Size = new System.Drawing.Size(64, 21);
            this.buttonDef10.TabIndex = 14;
            this.buttonDef10.Text = "#000000";
            this.buttonDef10.UseVisualStyleBackColor = true;
            this.buttonDef10.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef10.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef9
            // 
            this.buttonDef9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef9.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef9.Location = new System.Drawing.Point(191, 52);
            this.buttonDef9.Name = "buttonDef9";
            this.buttonDef9.Size = new System.Drawing.Size(64, 21);
            this.buttonDef9.TabIndex = 13;
            this.buttonDef9.Text = "#000000";
            this.buttonDef9.UseVisualStyleBackColor = true;
            this.buttonDef9.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef9.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef8
            // 
            this.buttonDef8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef8.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef8.Location = new System.Drawing.Point(126, 52);
            this.buttonDef8.Name = "buttonDef8";
            this.buttonDef8.Size = new System.Drawing.Size(64, 21);
            this.buttonDef8.TabIndex = 12;
            this.buttonDef8.Text = "#000000";
            this.buttonDef8.UseVisualStyleBackColor = true;
            this.buttonDef8.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef8.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef15
            // 
            this.buttonDef15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef15.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef15.Location = new System.Drawing.Point(321, 74);
            this.buttonDef15.Name = "buttonDef15";
            this.buttonDef15.Size = new System.Drawing.Size(64, 21);
            this.buttonDef15.TabIndex = 19;
            this.buttonDef15.Text = "#000000";
            this.buttonDef15.UseVisualStyleBackColor = true;
            this.buttonDef15.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef15.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef14
            // 
            this.buttonDef14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef14.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef14.Location = new System.Drawing.Point(256, 74);
            this.buttonDef14.Name = "buttonDef14";
            this.buttonDef14.Size = new System.Drawing.Size(64, 21);
            this.buttonDef14.TabIndex = 18;
            this.buttonDef14.Text = "#000000";
            this.buttonDef14.UseVisualStyleBackColor = true;
            this.buttonDef14.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef14.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef13
            // 
            this.buttonDef13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef13.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef13.Location = new System.Drawing.Point(191, 74);
            this.buttonDef13.Name = "buttonDef13";
            this.buttonDef13.Size = new System.Drawing.Size(64, 21);
            this.buttonDef13.TabIndex = 17;
            this.buttonDef13.Text = "#000000";
            this.buttonDef13.UseVisualStyleBackColor = true;
            this.buttonDef13.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef13.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonDef12
            // 
            this.buttonDef12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDef12.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDef12.Location = new System.Drawing.Point(126, 74);
            this.buttonDef12.Name = "buttonDef12";
            this.buttonDef12.Size = new System.Drawing.Size(64, 21);
            this.buttonDef12.TabIndex = 16;
            this.buttonDef12.Text = "#000000";
            this.buttonDef12.UseVisualStyleBackColor = true;
            this.buttonDef12.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDef12.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonColor
            // 
            this.buttonColor.Location = new System.Drawing.Point(196, 100);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(102, 23);
            this.buttonColor.TabIndex = 21;
            this.buttonColor.Text = "その他の色(&C)...";
            this.buttonColor.UseVisualStyleBackColor = true;
            this.buttonColor.Click += new System.EventHandler(this.buttonColor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "不透明度(&A):";
            // 
            // buttonDefUser
            // 
            this.buttonDefUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDefUser.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonDefUser.Location = new System.Drawing.Point(126, 101);
            this.buttonDefUser.Name = "buttonDefUser";
            this.buttonDefUser.Size = new System.Drawing.Size(64, 21);
            this.buttonDefUser.TabIndex = 20;
            this.buttonDefUser.Text = "#000000";
            this.buttonDefUser.UseVisualStyleBackColor = true;
            this.buttonDefUser.BackColorChanged += new System.EventHandler(this.buttonDef_BackColorChanged);
            this.buttonDefUser.Click += new System.EventHandler(this.buttonDef_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(310, 158);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 3;
            this.buttonCancel.Text = "キャンセル";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonOk
            // 
            this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOk.Location = new System.Drawing.Point(229, 158);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 2;
            this.buttonOk.Text = "OK(&O)";
            this.buttonOk.UseVisualStyleBackColor = true;
            // 
            // numDragAlpha
            // 
            this.numDragAlpha.AutoSize = false;
            this.numDragAlpha.BackColor = System.Drawing.SystemColors.Control;
            this.numDragAlpha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numDragAlpha.DecimalPlaces = 0;
            this.numDragAlpha.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numDragAlpha.Location = new System.Drawing.Point(196, 130);
            this.numDragAlpha.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numDragAlpha.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numDragAlpha.Name = "numDragAlpha";
            this.numDragAlpha.Size = new System.Drawing.Size(59, 18);
            this.numDragAlpha.TabIndex = 1;
            this.numDragAlpha.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDragAlpha.ValueChanged += new System.EventHandler(this.numDragAlpha_ValueChanged);
            // 
            // SolidColorBrushWindow
            // 
            this.AcceptButton = this.buttonOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(394, 188);
            this.Controls.Add(this.numDragAlpha);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonDefUser);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonColor);
            this.Controls.Add(this.buttonDef15);
            this.Controls.Add(this.buttonDef14);
            this.Controls.Add(this.buttonDef13);
            this.Controls.Add(this.buttonDef12);
            this.Controls.Add(this.buttonDef11);
            this.Controls.Add(this.buttonDef10);
            this.Controls.Add(this.buttonDef9);
            this.Controls.Add(this.buttonDef8);
            this.Controls.Add(this.buttonDef7);
            this.Controls.Add(this.buttonDef6);
            this.Controls.Add(this.buttonDef5);
            this.Controls.Add(this.buttonDef4);
            this.Controls.Add(this.buttonDef3);
            this.Controls.Add(this.buttonDef2);
            this.Controls.Add(this.buttonDef1);
            this.Controls.Add(this.buttonDef0);
            this.Controls.Add(this.pictureView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SolidColorBrushWindow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "色の編集";
            this.Load += new System.EventHandler(this.SolidColorBrushDialog_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SolidColorBrushDialog_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureView;
        private System.Windows.Forms.Button buttonDef0;
        private System.Windows.Forms.Button buttonDef1;
        private System.Windows.Forms.Button buttonDef2;
        private System.Windows.Forms.Button buttonDef3;
        private System.Windows.Forms.Button buttonDef7;
        private System.Windows.Forms.Button buttonDef6;
        private System.Windows.Forms.Button buttonDef5;
        private System.Windows.Forms.Button buttonDef4;
        private System.Windows.Forms.Button buttonDef11;
        private System.Windows.Forms.Button buttonDef10;
        private System.Windows.Forms.Button buttonDef9;
        private System.Windows.Forms.Button buttonDef8;
        private System.Windows.Forms.Button buttonDef15;
        private System.Windows.Forms.Button buttonDef14;
        private System.Windows.Forms.Button buttonDef13;
        private System.Windows.Forms.Button buttonDef12;
        private System.Windows.Forms.Button buttonColor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonDefUser;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonOk;
        private NumericDragBox numDragAlpha;
    }
}