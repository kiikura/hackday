﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// ブレンド処理を行うNiVE2エフェクトクラス。
    /// </summary>
    [UseLayer]
    public class Blend : EffectBase
    {
        /// <summary>
        /// ブレンド種別配列。
        /// </summary>
        private static readonly BlendType[] BlendTypes;

        /// <summary>
        /// ブレンド種別名配列。
        /// </summary>
        private static readonly string[] BlendTypeNames;

        /// <summary>
        /// 反転種別配列。
        /// </summary>
        private static readonly FlipType[] FlipTypes;

        /// <summary>
        /// 反転種別名配列。
        /// </summary>
        private static readonly string[] FlipTypeNames;

        /// <summary>
        /// 基準点に対する配置の配列。
        /// </summary>
        private static readonly BaseAlignment[] BaseAlignments =
            new BaseAlignment[]
                {
                    BaseAlignment.Near,
                    BaseAlignment.Center,
                    BaseAlignment.Far,
                };

        /// <summary>
        /// 回転の基準点種別配列。直接指定の場合は null 。
        /// </summary>
        private static RectangleAlignment?[] RotateBaseTypes;

        /// <summary>
        /// 回転の基準点種別名配列。
        /// </summary>
        private static readonly string[] RotateBaseTypeNames;

        /// <summary>
        /// グラデーション方向配列。
        /// </summary>
        private static readonly GradientDirection[] GradientDirs;

        /// <summary>
        /// グラデーション方向名配列。
        /// </summary>
        private static readonly string[] GradientDirNames;

        /// <summary>
        /// 時間決定方法配列。
        /// </summary>
        private static readonly TimeDecideType[] TimeDecideTypes;

        /// <summary>
        /// 時間決定方法名配列。
        /// </summary>
        private static readonly string[] TimeDecideTypeNames;

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer = null;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static Blend()
        {
            // ブレンドの種別配列とその名前配列初期化
            Util.GetEnumDescriptions(out BlendTypes, out BlendTypeNames);

            // 反転の種別配列とその名前配列初期化
            Util.GetEnumDescriptions(out FlipTypes, out FlipTypeNames);

            // 回転の基準点種別配列とその名前配列初期化
            {
                IDictionary<RectangleAlignment, string> dict =
                    Util.GetEnumDescriptions<RectangleAlignment>();

                List<RectangleAlignment?> types =
                    new List<RectangleAlignment?>(dict.Count + 1);
                List<string> names = new List<string>(types.Capacity);

                types.Add(null);
                names.Add("直接指定");
                foreach (KeyValuePair<RectangleAlignment, string> v in dict)
                {
                    types.Add(v.Key);
                    names.Add("元レイヤーの" + v.Value);
                }

                RotateBaseTypes = types.ToArray();
                RotateBaseTypeNames = names.ToArray();
            }

            // グラデーションの配列とその名前配列初期化
            Util.GetEnumDescriptions(out GradientDirs, out GradientDirNames);

            // 時間決定方法配列とその名前配列初期化
            Util.GetEnumDescriptions(
                out TimeDecideTypes, out TimeDecideTypeNames);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public Blend()
        {
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "チャンネル"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            SizeF size = _layer.GetImageBounds(0.0).Size;
            PointF basePos = new PointF(size.Width * 0.5F, size.Height * 0.5F);

            return new PropertyBase[]
                {
                    new LayerSelectableProperty("重ねるレイヤー"),
                    new SelectableProperty(
                        "ブレンド",
                        Util.FindEnumDefaultValue(BlendTypes),
                        BlendTypeNames),
                    new NumberProperty("不透明度", 100.0, 100.0, 0.0),
                    new BooleanProperty("ネガポジ", false),
                    new SelectableProperty(
                        "反転",
                        Util.FindEnumDefaultValue(FlipTypes),
                        FlipTypeNames),
                    // 配置
                        new VertexProperty(
                            "配:基準点", basePos, double.MaxValue, double.MinValue),
                        new SelectableProperty(
                            "配:横基準", 1, new string[]{ "左", "中央", "右" }),
                        new SelectableProperty(
                            "配:縦基準", 1, new string[]{ "上", "中央", "下" }),
                        new VertexProperty(
                            "配:スケール",
                            new Size(100, 100),
                            double.MaxValue,
                            double.MinValue),
                    // 回転
                        new SelectableProperty(
                            "回:基準点",
                            Util.FindEnumDefaultValue(RotateBaseTypes),
                            RotateBaseTypeNames),
                        new VertexProperty(
                            "回:基準点指定", basePos, double.MaxValue, double.MinValue),
                        new RadianProperty("回:回転量", 0, 0.0),
                    // 塗り潰し
                        new BooleanProperty("塗:有効", false),
                        new ColorProperty("塗:色", Color.Black),
                        new NumberProperty("塗:不透明度", 100.0, 100.0, 0.0),
                        // グラデーション
                            new BooleanProperty("塗:グ:有効", false),
                            new ColorProperty("塗:グ:色", Color.Black),
                            new NumberProperty("塗:グ:不透明度", 100.0, 100.0, 0.0),
                            new SelectableProperty(
                                "塗:グ:方向",
                                Util.FindEnumDefaultValue(GradientDirs),
                                GradientDirNames),
                    // 時間指定
                        new SelectableProperty(
                            "時:指定方法",
                            Util.FindEnumDefaultValue(TimeDecideTypes),
                            TimeDecideTypeNames),
                        new NumberProperty(
                            "時:秒数", 0.0, double.MaxValue, double.MinValue),
                    // 品質
                        new BooleanProperty("品:補間処理", true),
                        new BooleanProperty("品:縮小フィルタ", false),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // コントロール配列作成
            PropertyEditControlBase[] controls = new PropertyEditControlBase[]
                {
                    new LayerSelectablePropertyEditControl(
                        "重ねるレイヤー", _layer.Composition, true, false, true, false),
                    new SelectablePropertyEditControl("ブレンド"),
                    new NumberPropertyEditControl(
                        "不透明度", 1.0, NumberPropertyEditControlType.Double),
                    new BooleanPropertyEditControl("ネガポジ"),
                    new SelectablePropertyEditControl("反転"),
                    new PropertyNestBeginControl("配置"),
                        new VertexPropertyEditControl(
                            "配:基準点", 1.0, VertexPropertyEditControlType.PointFOrSizeF),
                        new SelectablePropertyEditControl("配:横基準"),
                        new SelectablePropertyEditControl("配:縦基準"),
                        new VertexPropertyEditControl(
                            "配:スケール", 1.0, VertexPropertyEditControlType.PointFOrSizeF),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("回転"),
                        new SelectablePropertyEditControl("回:基準点"),
                        new VertexPropertyEditControl(
                            "回:基準点指定", 1.0, VertexPropertyEditControlType.PointFOrSizeF),
                        new RadianPropertyEditControl("回:回転量"),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("塗り潰し"),
                        new BooleanPropertyEditControl("塗:有効"),
                        new ColorPropertyEditControl("塗:色"),
                        new NumberPropertyEditControl(
                            "塗:不透明度", 1.0, NumberPropertyEditControlType.Double),
                        new PropertyNestBeginControl("グラデーション"),
                            new BooleanPropertyEditControl("塗:グ:有効"),
                            new ColorPropertyEditControl("塗:グ:色"),
                            new NumberPropertyEditControl(
                                "塗:グ:不透明度", 1.0, NumberPropertyEditControlType.Double),
                            new SelectablePropertyEditControl("塗:グ:方向"),
                        new PropertyNestEndControl(),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("時間指定"),
                        new SelectablePropertyEditControl("時:指定方法"),
                        new NumberPropertyEditControl(
                            "時:秒数", 1.0, NumberPropertyEditControlType.Double),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("品質"),
                        new BooleanPropertyEditControl("品:補間処理"),
                        new BooleanPropertyEditControl("品:縮小フィルタ"),
                    new PropertyNestEndControl(),
                };

            // ラベル文字列設定
            foreach (PropertyEditControlBase c in controls)
            {
                Util.SetPropertyEditControlLabelByName(c, ":");
            }

            return controls;
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            // 特に変更しない
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            int itemCode = ((LayerSelectableProperty)property["重ねるレイヤー"]).ItemCode;
            BlendType blendType =
                BlendTypes[((SelectableProperty)property["ブレンド"]).Selected];
            double alpha = ((NumberProperty)property["不透明度"]).DoubleValue;
            bool negaPosi = ((BooleanProperty)property["ネガポジ"]).Boolean;
            FlipType flipType = FlipTypes[((SelectableProperty)property["反転"]).Selected];
            PointF basePos = ((VertexProperty)property["配:基準点"]).PointFValue;
            BaseAlignment horzAlign =
                BaseAlignments[((SelectableProperty)property["配:横基準"]).Selected];
            BaseAlignment vertAlign =
                BaseAlignments[((SelectableProperty)property["配:縦基準"]).Selected];
            SizeF scale = ((VertexProperty)property["配:スケール"]).SizeFValue;
            RectangleAlignment? rotateType =
                RotateBaseTypes[((SelectableProperty)property["回:基準点"]).Selected];
            PointF rotatePos = ((VertexProperty)property["回:基準点指定"]).PointFValue;
            double rotateAngle = ((RadianProperty)property["回:回転量"]).Angle;
            bool fillEnabled = ((BooleanProperty)property["塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["塗:色"]).Color;
            double fillAlpha = ((NumberProperty)property["塗:不透明度"]).DoubleValue;
            bool fillGradEnabled = ((BooleanProperty)property["塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["塗:グ:色"]).Color;
            double fillGradAlpha =
                ((NumberProperty)property["塗:グ:不透明度"]).DoubleValue;
            GradientDirection fillGradDir =
                GradientDirs[((SelectableProperty)property["塗:グ:方向"]).Selected];
            TimeDecideType timeType =
                TimeDecideTypes[((SelectableProperty)property["時:指定方法"]).Selected];
            double timeVal = ((NumberProperty)property["時:秒数"]).DoubleValue;
            bool interEnabled = ((BooleanProperty)property["品:補間処理"]).Boolean;
            bool filterEnabled = ((BooleanProperty)property["品:縮小フィルタ"]).Boolean;

            // 描画不要ならばそのまま返す
            if (alpha == 0.0 || scale.Width == 0.0 || scale.Height == 0.0)
            {
                return image;
            }

            // ソースレイヤー取得
            ILayer srcLayer = Util.FindLayer(_layer.Composition, itemCode);
            if (srcLayer == null) { return image; }

            // 取得時間設定
            double t = timeVal;
            if (timeType != TimeDecideType.Fixed)
            {
                t = srcLayer.ToLocalTime(_layer.ToWorldTime(time));
                if (timeType == TimeDecideType.Offset)
                {
                    t += timeVal;
                }
            }

            // イメージバッファサイズを算出
            SizeF bmpSize = srcLayer.GetImageBounds(t).Size;
            long bmpBufLen =
                (long)((bmpSize.Width + 1.0) * 4 * (bmpSize.Height + 1.0));

            // キャッシュを確保してイメージを取得
            using (CacheLocker cacheLock = new CacheLocker(bmpBufLen))
            using (NBitmap srcBmp = srcLayer.GetSourceImage(t))
            {
                // ネガポジ反転
                if (negaPosi)
                {
                    ImageUtil.InvertImageColor(srcBmp);
                }

                // 描画パラメータ作成
                ImageBlendingParam param;
                param.blendType = blendType;
                param.alpha = alpha / 100.0;
                param.flipType = flipType;
                param.basePos = basePos;
                param.horzAlign = horzAlign;
                param.vertAlign = vertAlign;
                param.scale =
                    new SizeF(scale.Width / 100.0F, scale.Height / 100.0F);
                param.rotateBaseAlign = rotateType;
                param.rotateBasePos = rotatePos;
                param.rotateAngle = rotateAngle;
                param.fillEnabled = fillEnabled;
                param.fillColor = fillColor;
                param.fillAlpha = fillAlpha / 100.0;
                param.fillGradientEnabled = fillGradEnabled;
                param.fillGradientColor = fillGradColor;
                param.fillGradientAlpha = fillGradAlpha / 100.0;
                param.fillGradientDirection = fillGradDir;
                param.interpolateEnabled = interEnabled;
                param.filterEnabled = filterEnabled;

                // 描画
                ImageUtil.BlendImage(
                    image, srcBmp, param, roi, _layer.ResolutionRate);
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 呼ばれないはず
            throw new NotImplementedException();
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "ブレンド(詳細)"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "パラメータを細かく指定してブレンド処理を行います。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
