﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 画像取得時間の設定方法を表す列挙。
    /// </summary>
    internal enum TimeDecideType
    {
        /// <summary>
        /// 指定しない。
        /// </summary>
        [Description("指定しない")]
        [EnumDefaultValue]
        Default,

        /// <summary>
        /// 固定。
        /// </summary>
        [Description("固定")]
        Fixed,

        /// <summary>
        /// オフセット。
        /// </summary>
        [Description("オフセット")]
        Offset,
    }
}
