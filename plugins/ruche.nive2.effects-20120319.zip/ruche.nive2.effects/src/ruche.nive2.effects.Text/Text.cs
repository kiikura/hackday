﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// テキスト描画を行うNiVE2エフェクトクラス。
    /// </summary>
    [SimulationEffect]
    public class Text : EffectBase
    {
        /// <summary>
        /// 縦横基準に対応するアラインメント配列。
        /// </summary>
        private static readonly StringAlignment[] TextAlignments =
            new StringAlignment[]
                {
                    StringAlignment.Near,
                    StringAlignment.Center,
                    StringAlignment.Far,
                };

        /// <summary>
        /// 複合品質レベル配列。
        /// </summary>
        private static readonly CompositingQuality[] CompositingQualities =
            new CompositingQuality[]
                {
                    CompositingQuality.Default,
                    CompositingQuality.HighSpeed,
                    CompositingQuality.HighQuality,
                    CompositingQuality.AssumeLinear,
                    CompositingQuality.GammaCorrected,
                };

        /// <summary>
        /// 複合品質レベル名配列。
        /// </summary>
        private static readonly string[] CompositingQualityNames =
            new string[]
                {
                    "デフォルト",
                    "低品質",
                    "高品質",
                    "線形",
                    "ガンマ補正",
                };

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public Text()
        {
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "テキスト"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            return new PropertyBase[]
                {
                    new StringProperty("テキスト", ""),
                    new FontProperty(
                        "フォント", new Font(FontFamily.GenericSansSerif, 14.0F)),
                    new NumberProperty("不透明度", 100.0, 100.0, 0.0),
                    // 配置
                        new VertexProperty(
                            "配:基準点", Point.Empty, double.MaxValue, double.MinValue),
                        new SelectableProperty(
                            "配:横基準", 0, new string[]{ "左", "中央", "右" }),
                        new SelectableProperty(
                            "配:縦基準", 0, new string[]{ "上", "中央", "下" }),
                        new NumberProperty("配:行間", 100.0, 1000.0, 0.0),
                    // 塗り潰し
                        new BooleanProperty("塗:有効", true),
                        new ColorProperty("塗:色", Color.Black),
                        // グラデーション
                            new BooleanProperty("塗:グ:有効", false),
                            new ColorProperty("塗:グ:色", Color.Black),
                    // 縁取り
                        new BooleanProperty("縁:有効", false),
                        new NumberProperty("縁:太さ", 1.0, double.MaxValue, 0.0),
                        new ColorProperty("縁:色", Color.White),
                        // グラデーション
                            new BooleanProperty("縁:グ:有効", false),
                            new ColorProperty("縁:グ:色", Color.Black),
                    // 字送り
                        new NumberProperty("字:文字間隔[ms]", 0.0, 10000.0, 0.0),
                        new NumberProperty("字:改行間隔[ms]", 0.0, 10000.0, 0.0),
                        new NumberProperty("字:スキップ行数", 0, 100, 0),
                        new NumberProperty("字:スキップ文字数", 0, 1000, 0),
                        new BooleanProperty("字:前後余白スキップ", true),
                    // 品質
                        new BooleanProperty("品:アンチエイリアス", true),
                        new SelectableProperty(
                            "品:複合品質", 0, CompositingQualityNames),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // 配列作成
            PropertyEditControlBase[] controls = new PropertyEditControlBase[]
                {
                    new TextPropertyEditControl<StringProperty>("テキスト", true),
                    new FontPropertyEditControl("フォント"),
                    new NumberPropertyEditControl(
                        "不透明度", 1.0, NumberPropertyEditControlType.Double),
                    new PropertyNestBeginControl("配置"),
                        new VertexPropertyEditControl(
                            "配:基準点", 1.0, VertexPropertyEditControlType.PointFOrSizeF),
                        new SelectablePropertyEditControl("配:横基準"),
                        new SelectablePropertyEditControl("配:縦基準"),
                        new NumberPropertyEditControl(
                            "配:行間", 1.0, NumberPropertyEditControlType.Double),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("塗り潰し"),
                        new BooleanPropertyEditControl("塗:有効"),
                        new ColorPropertyEditControl("塗:色"),
                        new PropertyNestBeginControl("グラデーション"),
                            new BooleanPropertyEditControl("塗:グ:有効"),
                            new ColorPropertyEditControl("塗:グ:色"),
                        new PropertyNestEndControl(),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("縁取り"),
                        new BooleanPropertyEditControl("縁:有効"),
                        new NumberPropertyEditControl(
                            "縁:太さ", 1.0, NumberPropertyEditControlType.Double),
                        new ColorPropertyEditControl("縁:色"),
                        new PropertyNestBeginControl("グラデーション"),
                            new BooleanPropertyEditControl("縁:グ:有効"),
                            new ColorPropertyEditControl("縁:グ:色"),
                        new PropertyNestEndControl(),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("字送り"),
                        new NumberPropertyEditControl(
                            "字:文字間隔[ms]", 1.0, NumberPropertyEditControlType.Double),
                        new NumberPropertyEditControl(
                            "字:改行間隔[ms]", 1.0, NumberPropertyEditControlType.Double),
                        new NumberPropertyEditControl(
                            "字:スキップ行数", 1, NumberPropertyEditControlType.Int),
                        new NumberPropertyEditControl(
                            "字:スキップ文字数", 1, NumberPropertyEditControlType.Int),
                        new BooleanPropertyEditControl("字:前後余白スキップ"),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("品質"),
                        new BooleanPropertyEditControl("品:アンチエイリアス"),
                        new SelectablePropertyEditControl("品:複合品質"),
                    new PropertyNestEndControl(),
                };

            // ラベル文字列設定
            foreach (PropertyEditControlBase c in controls)
            {
                Util.SetPropertyEditControlLabelByName(c, ":");
            }

            return controls;
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            // 特に変更しない
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            FontProperty fontProp = (FontProperty)property["フォント"];
            double alpha = ((NumberProperty)property["不透明度"]).DoubleValue;
            PointF basePos = ((VertexProperty)property["配:基準点"]).PointFValue;
            int horzIndex = ((SelectableProperty)property["配:横基準"]).Selected;
            int vertIndex = ((SelectableProperty)property["配:縦基準"]).Selected;
            double heightRate = ((NumberProperty)property["配:行間"]).DoubleValue;
            bool fillEnabled = ((BooleanProperty)property["塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["塗:色"]).Color;
            bool fillGradEnabled = ((BooleanProperty)property["塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["塗:グ:色"]).Color;
            bool edgeEnabled = ((BooleanProperty)property["縁:有効"]).Boolean;
            double edgeWidth = ((NumberProperty)property["縁:太さ"]).DoubleValue;
            Color edgeColor = ((ColorProperty)property["縁:色"]).Color;
            bool edgeGradEnabled = ((BooleanProperty)property["縁:グ:有効"]).Boolean;
            Color edgeGradColor = ((ColorProperty)property["縁:グ:色"]).Color;
            double letterMs = ((NumberProperty)property["字:文字間隔[ms]"]).DoubleValue;
            double lineMs = ((NumberProperty)property["字:改行間隔[ms]"]).DoubleValue;
            int skipLine = ((NumberProperty)property["字:スキップ行数"]).Int32Value;
            int skipLetter = ((NumberProperty)property["字:スキップ文字数"]).Int32Value;
            bool skipBlank = ((BooleanProperty)property["字:前後余白スキップ"]).Boolean;
            bool antiAlias = ((BooleanProperty)property["品:アンチエイリアス"]).Boolean;
            int compoIndex = ((SelectableProperty)property["品:複合品質"]).Selected;

            // 描画する必要が無いならそのまま返す
            if (alpha <= 0.0 || (!fillEnabled && !edgeEnabled))
            {
                return image;
            }

            // 字送り処理を施した文字列取得
            string text = TextUtil.MakeEffectedTextPropertyValue(
                _layer,
                this,
                "テキスト",
                time,
                letterMs,
                lineMs,
                skipLine,
                skipLetter,
                skipBlank);
            if (text.Trim().Length == 0) { return image; }

            // 描画パラメータ作成
            TextRenderingParam param;
            param.fontFamily = fontProp.FontFamily;
            param.fontEmSize = fontProp.Size;
            param.fontStyle = fontProp.Style;
            param.alpha = alpha / 100.0;
            param.basePos = basePos;
            param.horzAlign = TextAlignments[horzIndex];
            param.vertAlign = TextAlignments[vertIndex];
            param.heightRate = heightRate / 100.0;
            param.fillEnabled = fillEnabled;
            param.fillColor = fillColor;
            param.fillGradientEnabled = fillGradEnabled;
            param.fillGradientColor = fillGradColor;
            param.edgeEnabled = edgeEnabled;
            param.edgeWidth = edgeWidth;
            param.edgeColor = edgeColor;
            param.edgeGradientEnabled = edgeGradEnabled;
            param.edgeGradientColor = edgeGradColor;
            param.antiAliasEnabled = antiAlias;
            param.compoQuality = CompositingQualities[compoIndex];

            // 描画
            TextUtil.RenderText(
                image, text, param, roi, _layer.ResolutionRate);

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 呼ばれないはず
            throw new NotImplementedException();
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "テキスト(詳細)"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "パラメータを細かく指定してテキストを描画します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
