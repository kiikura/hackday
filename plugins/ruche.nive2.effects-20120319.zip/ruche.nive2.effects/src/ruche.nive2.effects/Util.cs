﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.ComponentModel;
using System.Reflection;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 便利処理を定義する静的クラス。
    /// </summary>
    public static class Util
    {
        /// <summary>
        /// プロパティエディットコントロールのスプリッタ右端からの基準位置。
        /// </summary>
        public const int PropertyEditControlLeftDistance = 6;

        /// <summary>
        /// プロパティエディットコントロールがタイムラインに隠される右端幅。
        /// </summary>
        public const int PropertyEditControlHiddenWidth = 68;

        /// <summary>
        /// プロパティエディットコントロールの名前を分割文字列で分割し、
        /// 一番最後の文字列をラベル文字列に設定する。
        /// </summary>
        /// <param name="control">プロパティエディットコントロール。</param>
        /// <param name="splitter">分割文字列。</param>
        public static void SetPropertyEditControlLabelByName(
            PropertyEditControlBase control, string splitter)
        {
            int index = control.PropertyName.LastIndexOf(splitter);
            control.LabelName = (index < 0) ?
                control.PropertyName :
                control.PropertyName.Substring(index + splitter.Length);
        }

        /// <summary>
        /// 指定したアイテムコードのレイヤーを検索する。
        /// </summary>
        /// <param name="composition">コンポジション。</param>
        /// <param name="itemCode">アイテムコード。</param>
        /// <returns>レイヤー。見つからなかった場合は null 。</returns>
        public static ILayer FindLayer(IComposition composition, int itemCode)
        {
            foreach (ILayer l in composition.GetLayer())
            {
                if (l.ItemCode == itemCode)
                {
                    return l;
                }
            }
            return null;
        }

        /// <summary>
        /// 矩形領域内の指定した配置位置を取得する。
        /// </summary>
        /// <param name="rectangle">矩形領域。</param>
        /// <param name="alignment">配置。</param>
        /// <returns>配置位置。</returns>
        public static PointF GetAlignmentPoint(
            RectangleF rectangle, RectangleAlignment alignment)
        {
            PointF pt = PointF.Empty;

            // X位置
            switch (alignment)
            {
                case RectangleAlignment.TopLeft:
                case RectangleAlignment.MiddleLeft:
                case RectangleAlignment.BottomLeft:
                    pt.X = rectangle.Left;
                    break;

                case RectangleAlignment.TopCenter:
                case RectangleAlignment.MiddleCenter:
                case RectangleAlignment.BottomCenter:
                    pt.X = rectangle.Left + rectangle.Width / 2;
                    break;

                case RectangleAlignment.TopRight:
                case RectangleAlignment.MiddleRight:
                case RectangleAlignment.BottomRight:
                    pt.X = rectangle.Right;
                    break;
            }

            // Y位置
            switch (alignment)
            {
                case RectangleAlignment.TopLeft:
                case RectangleAlignment.TopCenter:
                case RectangleAlignment.TopRight:
                    pt.Y = rectangle.Top;
                    break;

                case RectangleAlignment.MiddleLeft:
                case RectangleAlignment.MiddleCenter:
                case RectangleAlignment.MiddleRight:
                    pt.Y = rectangle.Top + rectangle.Height / 2;
                    break;

                case RectangleAlignment.BottomLeft:
                case RectangleAlignment.BottomCenter:
                case RectangleAlignment.BottomRight:
                    pt.Y = rectangle.Bottom;
                    break;
            }

            return pt;
        }

        /// <summary>
        /// BaseAlignment.Near にあたる位置を取得する。
        /// </summary>
        /// <param name="p">位置。</param>
        /// <param name="size">サイズ。</param>
        /// <param name="alignment">BaseAlignment 。</param>
        /// <returns>BaseAlignment.Near にあたる位置。</returns>
        public static double GetNearPosition(
            double p,
            double size,
            BaseAlignment alignment)
        {
            switch (alignment)
            {
            case BaseAlignment.Center:
                p -= size / 2;
                break;

            case BaseAlignment.Far:
                p -= size;
                break;
            }

            return p;
        }

        /// <summary>
        /// 配列の全要素が等しいか否かを取得する。
        /// </summary>
        /// <typeparam name="T">要素型。</typeparam>
        /// <param name="array1">配列1。</param>
        /// <param name="array2">配列2。</param>
        /// <returns>
        /// 全要素が等しいならば true 。そうでなければ false 。
        /// </returns>
        public static bool EqualsArray<T>(T[] array1, T[] array2)
        {
            if (array1 == null || array2 == null)
            {
                return (array1 == array2);
            }
            if (array1.Length != array2.Length)
            {
                return false;
            }
            for (int i = 0; i < array1.Length; ++i)
            {
                if (!array1[i].Equals(array2[i]))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 複数の配列の要素を連結して1つの配列にする。
        /// </summary>
        /// <typeparam name="T">要素型。</typeparam>
        /// <param name="arrays">配列の配列。</param>
        /// <returns>要素を連結した配列。</returns>
        public static T[] JoinArrays<T>(params T[][] arrays)
        {
            // 全要素数分のサイズを持つ配列作成
            int length = 0;
            Array.ForEach(arrays, (ca) => { length += ca.Length; });
            var dest = new T[length];

            // 全要素をコピー
            int index = 0;
            Array.ForEach(
                arrays,
                (ca) =>
                {
                    ca.CopyTo(dest, index);
                    index += ca.Length;
                });

            return dest;
        }

        /// <summary>
        /// データとその文字列表現の配列からコンバータを作成する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="values">データ配列。</param>
        /// <param name="texts">文字列表現配列。</param>
        /// <returns>コンバータ。</returns>
        public static Converter<T, string> CreateValueTextConverter<T>(
            T[] values,
            string[] texts)
        {
            return (
                (v) =>
                {
                    int index = Array.IndexOf(values, v);
                    return (index < 0 || index >= texts.Length) ?
                        string.Empty :
                        texts[index];
                });
        }

        /// <summary>
        /// null 許容のキー値を基に null 許容のデータ値を取得する。
        /// </summary>
        /// <typeparam name="TKey">キー値型。</typeparam>
        /// <typeparam name="TValue">データ値型。</typeparam>
        /// <param name="key">キー値。</param>
        /// <param name="getter">データ値を取得するデリゲート。</param>
        /// <returns>
        /// キー値が null ならば null 。
        /// そうでなければ getter((TKey)key) の戻り値。
        /// </returns>
        public static TValue? GetNullableKeyValue<TKey, TValue>(
            TKey? key,
            Converter<TKey, TValue> getter)
            where TKey : struct
            where TValue : struct
        {
            return key.HasValue ? (TValue?)getter((TKey)key) : null;
        }

        #region 列挙値

        /// <summary>
        /// 列挙値とその説明のペアコレクションを取得する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <returns>列挙値とその説明のペアコレクション。</returns>
        public static Dictionary<ET, string> GetEnumDescriptions<ET>()
            where ET : struct, IConvertible
        {
            // 列挙型かチェック
            if (!typeof(ET).IsEnum)
            {
                throw new ArgumentException("ET must be enum type.");
            }

            Dictionary<ET, string> table = new Dictionary<ET, string>();

            // 列挙値ごとに処理
            FieldInfo[] infos =
                typeof(ET).GetFields(BindingFlags.Public | BindingFlags.Static);
            foreach (FieldInfo fi in infos)
            {
                // Description 属性があるなら文字列取得
                DescriptionAttribute attr =
                    Attribute.GetCustomAttribute(fi, typeof(DescriptionAttribute))
                        as DescriptionAttribute;
                string desc = (attr == null) ? null : attr.Description;

                // 追加
                table.Add((ET)Enum.Parse(typeof(ET), fi.Name), desc);
            }

            return table;
        }

        /// <summary>
        /// 列挙値とその説明の配列を取得する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <param name="values">列挙値配列の設定先。</param>
        /// <param name="descriptions">説明文字列配列の設定先。</param>
        public static void GetEnumDescriptions<ET>(
            out ET[] values,
            out string[] descriptions)
            where ET : struct, IConvertible
        {
            Dictionary<ET, string> dict = GetEnumDescriptions<ET>();
            values = new ET[dict.Count];
            descriptions = new string[dict.Count];
            dict.Keys.CopyTo(values, 0);
            dict.Values.CopyTo(descriptions, 0);
        }

        /// <summary>
        /// 列挙値配列に対応する説明を検索し、その配列を取得する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <param name="values">列挙値配列。</param>
        /// <returns>説明文字列配列。</returns>
        public static string[] FindEnumDescriptions<ET>(ET[] values)
            where ET : struct, IConvertible
        {
            string[] descs = null;

            if (values != null)
            {
                Dictionary<ET, string> dict = GetEnumDescriptions<ET>();
                descs = new string[values.Length];
                for (int i = 0; i < values.Length; ++i)
                {
                    if (!dict.TryGetValue(values[i], out descs[i]))
                    {
                        descs[i] = string.Empty;
                    }
                }
            }

            return descs;
        }

        /// <summary>
        /// 列挙の既定値を取得する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <returns>既定の列挙値。</returns>
        public static ET GetEnumDefaultValue<ET>()
            where ET : struct, IConvertible
        {
            // 列挙型かチェック
            if (!typeof(ET).IsEnum)
            {
                throw new ArgumentException("ET must be enum type.");
            }

            // 列挙値ごとにチェック
            FieldInfo[] infos =
                typeof(ET).GetFields(BindingFlags.Public | BindingFlags.Static);
            foreach (FieldInfo fi in infos)
            {
                // DefaultValue 属性があるならその値を返す
                Attribute attr = Attribute.GetCustomAttribute(
                    fi, typeof(EnumDefaultValueAttribute));
                if (attr != null)
                {
                    return (ET)Enum.Parse(typeof(ET), fi.Name);
                }
            }

            // 見つからなかったならば通常の既定値を返す
            return default(ET);
        }

        /// <summary>
        /// 列挙値配列から列挙の既定値を検索する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <param name="values">列挙値配列。</param>
        /// <returns>既定値のインデックス。見つからなかった場合は 0 。</returns>
        public static int FindEnumDefaultValue<ET>(ET[] values)
            where ET : struct, IConvertible
        {
            ET v = GetEnumDefaultValue<ET>();
            return Array.IndexOf(values, v);
        }

        /// <summary>
        /// 列挙値配列から列挙の既定値を検索する。
        /// </summary>
        /// <typeparam name="ET">列挙型。</typeparam>
        /// <param name="values">列挙値配列。</param>
        /// <returns>既定値のインデックス。見つからなかった場合は 0 。</returns>
        public static int FindEnumDefaultValue<ET>(ET?[] values)
            where ET : struct, IConvertible
        {
            ET v = GetEnumDefaultValue<ET>();
            return Array.IndexOf(values, v);
        }

        #endregion

        #region キーフレーム

        /// <summary>
        /// 指定した時刻以前で最も近いキーフレームを取得する。
        /// </summary>
        /// <param name="keyFrames">キーフレーム配列。</param>
        /// <param name="time">時刻。</param>
        /// <returns>
        /// 指定した時刻以前で最も近いキーフレーム。
        /// キーフレームが存在しない場合は null 。
        /// </returns>
        public static KeyFrame GetPrevKeyFrame(
            KeyFrame[] keyFrames,
            double time)
        {
            KeyFrame prevKey = null;
            foreach (KeyFrame key in keyFrames)
            {
                if (key.Time <= time)
                {
                    if (prevKey == null || key.Time > prevKey.Time)
                    {
                        prevKey = key;
                    }
                }
            }
            return prevKey;
        }

        /// <summary>
        /// 指定した時刻未満で最も近いキーフレームを取得する。
        /// </summary>
        /// <param name="keyFrames">キーフレーム配列。</param>
        /// <param name="time">時刻。</param>
        /// <returns>
        /// 指定した時刻未満で最も近いキーフレーム。
        /// キーフレームが存在しない場合は null 。
        /// </returns>
        public static KeyFrame GetBelowKeyFrame(
            KeyFrame[] keyFrames,
            double time)
        {
            KeyFrame prevKey = null;
            foreach (KeyFrame key in keyFrames)
            {
                if (key.Time < time)
                {
                    if (prevKey == null || key.Time > prevKey.Time)
                    {
                        prevKey = key;
                    }
                }
            }
            return prevKey;
        }

        /// <summary>
        /// 指定した時刻超で最も近いキーフレームを取得する。
        /// </summary>
        /// <param name="keyFrames">キーフレーム配列。</param>
        /// <param name="time">時刻。</param>
        /// <returns>
        /// 指定した時刻超で最も近いキーフレーム。
        /// キーフレームが存在しない場合は null 。
        /// </returns>
        public static KeyFrame GetAboveKeyFrame(
            KeyFrame[] keyFrames,
            double time)
        {
            KeyFrame nextKey = null;
            foreach (KeyFrame key in keyFrames)
            {
                if (key.Time > time)
                {
                    if (nextKey == null || key.Time < nextKey.Time)
                    {
                        nextKey = key;
                    }
                }
            }
            return nextKey;
        }

        /// <summary>
        /// 指定した時刻以前で最も近いキーフレームが存在すればそれを取得し、
        /// 存在しなければ指定した時刻超で最も近いキーフレームを取得する。
        /// </summary>
        /// <param name="keyFrames">キーフレーム配列。</param>
        /// <param name="time">時刻。</param>
        /// <returns>
        /// 指定した時刻以前で最も近いキーフレーム。
        /// それが存在しなければ指定した時刻超で最も近いキーフレーム。
        /// どちらも存在しなければ null 。
        /// </returns>
        public static KeyFrame GetFixedKeyFrame(
            KeyFrame[] keyFrames,
            double time)
        {
            KeyFrame key = GetPrevKeyFrame(keyFrames, time); 
            return key ?? GetAboveKeyFrame(keyFrames, time);
        }

        /// <summary>
        /// 指定した時刻以前で最も近いキーフレームからの経過秒数を取得する。
        /// </summary>
        /// <param name="keyFrames">キーフレーム配列。</param>
        /// <param name="time">時刻。</param>
        /// <returns>
        /// 指定した時刻以前で最も近いキーフレームからの経過秒数。
        /// キーフレームが存在しない場合は time の値をそのまま返す。
        /// </returns>
        public static double CalcElapsedTime(KeyFrame[] keyFrames, double time)
        {
            // 取得時刻以前で最も近いキーフレームを探す
            KeyFrame prevKey = GetPrevKeyFrame(keyFrames, time);

            // 経過秒数を返す
            return ((prevKey == null) ? time : (time - prevKey.Time));
        }

        #endregion
    }
}
