﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 整数値配列、有効状態、および直前のキーフレームからの経過秒数を保持する
    /// NiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class SwitchableIntArrayProperty
        :
        SwitchablePropertyBase<int[]>
    {
        /// <summary>
        /// 最大値。
        /// </summary>
        private int _maxValue = int.MaxValue;

        /// <summary>
        /// 最小値。
        /// </summary>
        private int _minValue = int.MinValue;

        /// <summary>
        /// 経過秒数。
        /// </summary>
        private double _elapsedTime = -1;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="values">
        /// 初期値配列。要素数は 1 以上でなければならない。
        /// </param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableIntArrayProperty(
            string name,
            int[] values,
            bool valid)
            : this(name, values, valid, int.MaxValue, int.MinValue)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="values">
        /// 初期値配列。要素数は 1 以上でなければならない。
        /// </param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="valueRange1">値範囲1。</param>
        /// <param name="valueRange2">値範囲2。</param>
        public SwitchableIntArrayProperty(
            string name,
            int[] values,
            bool valid,
            int valueRange1,
            int valueRange2)
            : base(name, values, valid)
        {
            if (values.Length == 0)
            {
                throw new ArgumentException("要素数が 0 です。", "values");
            }

            // 最大値と最小値設定
            _maxValue = Math.Max(valueRange1, valueRange2);
            _minValue = Math.Min(valueRange1, valueRange2);

            // 値補正のため再度設定
            OriginalValue = values;
        }

        /// <summary>
        /// 内部配列値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 取得時はクローンを返すため、返された配列の要素の値を変更しても
        /// 実際の値には反映されない。
        /// 
        /// null 値または要素数が 0 の配列を渡すと
        /// DefaultValues プロパティ値を用いる。
        /// </remarks>
        public new int[] OriginalValue
        {
            get { return (int[])base.OriginalValue.Clone(); }
            set { base.OriginalValue = value; }
        }

        /// <summary>
        /// 有効状態ならば内部配列値を、無効状態ならば null 値を取得する。
        /// </summary>
        /// <remarks>
        /// 取得時はクローンを返すため、返された配列の要素の値を変更しても
        /// 実際の値には反映されない。
        /// </remarks>
        public new int[] Value
        {
            get { return Valid ? OriginalValue : null; }
        }

        /// <summary>
        /// 配列の要素数を取得する。
        /// </summary>
        public int Length
        {
            get { return base.OriginalValue.Length; }
        }

        /// <summary>
        /// 設定可能な最大値を取得または設定する。
        /// </summary>
        public int MaxValue
        {
            get { return _maxValue; }
            set
            {
                _maxValue = value;
                if (_minValue > value)
                {
                    _minValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        /// <summary>
        /// 設定可能な最小値を取得または設定する。
        /// </summary>
        public int MinValue
        {
            get { return _minValue; }
            set
            {
                _minValue = value;
                if (_maxValue < value)
                {
                    _maxValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        /// <summary>
        /// キーフレームからの経過秒数を取得する。
        /// </summary>
        /// <remarks>
        /// 補間された場合は前方で最も近いキーフレームからの経過秒数を返す。
        /// 前方にキーフレームが無い場合はレイヤ開始時間からの経過秒数を返す。
        /// 
        /// 補間されていない場合は負数を返す。
        /// </remarks>
        public double ElapsedTime
        {
            get { return _elapsedTime; }
        }

        public override string ToString()
        {
            return string.Join(
                ",",
                Array.ConvertAll(base.OriginalValue, n => n.ToString()));
        }

        #region SwitchablePropertyBase<double[]> メンバ

        public override int[] DefaultValue
        {
            get { return new int[Length]; }
        }

        protected override bool ValidateValue(ref int[] values)
        {
            if (values.Length == 0)
            {
                return false;
            }

            for (int i = 0; i < values.Length; ++i)
            {
                values[i] = Math.Min(Math.Max(values[i], MinValue), MaxValue);
            }

            return true;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return new SwitchableIntArrayProperty(
                name,
                DefaultValue,
                false);
        }

        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchableIntArrayProperty)src;
            base.CopyFrom(prop);
            this._maxValue = prop.MaxValue;
            this._minValue = prop.MinValue;
            this._elapsedTime = prop.ElapsedTime;
        }

        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchableIntArrayProperty)other;
            if (base.IsValueEquals(prop) && Length == prop.Length)
            {
                int[] vals = OriginalValue;
                int[] propVals = prop.OriginalValue;
                for (int i = 0; i < Length; ++i)
                {
                    if (
                        vals[i] != propVals[i] ||
                        MaxValue != prop.MaxValue ||
                        MinValue != prop.MinValue)
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        #endregion

        #region PropertyBase メンバ

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            // ベースクラス処理
            PropertyBase propBase = base.Interpolation(keyFrame, time);
            SwitchableIntArrayProperty prop =
                (SwitchableIntArrayProperty)propBase.Copy();

            // 経過秒数設定
            prop._elapsedTime = Util.CalcElapsedTime(keyFrame, time);

            return prop;
        }

        #endregion
    }
}
