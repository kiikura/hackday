﻿using System;
using NiVE2.Utils.Cache;

namespace ruche.nive2.effects
{
    /// <summary>
    /// コンストラクタで Lock メソッドを呼び出し、 Dispose メソッド内で
    /// Unlock メソッドを呼び出す LockTemporalCache クラスの拡張クラス。
    /// </summary>
    /// <example>
    /// 基本的には次のサンプルコードのように using 句と共に用いる。
    /// <code>
    /// void DoSomething(NBitmap image)
    /// {
    ///     using (CacheLocker cacheLock = new CacheLocker(image.DataSize))
    ///     using (Bitmap bmp = image.ToBitmap())
    ///     {
    ///         // do something ...
    ///     }
    /// }
    /// </code>
    /// </example>
    public class CacheLocker : LockTemporalCache, IDisposable
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="dataSize">キャッシュサイズ。</param>
        public CacheLocker(long dataSize) : base(dataSize)
        {
            Lock();
        }

        /// <summary>
        /// デストラクタ。
        /// </summary>
        ~CacheLocker()
        {
            Dispose();
        }

        #region IDisposable メンバ

        public void Dispose()
        {
            Unlock();
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
