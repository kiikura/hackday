﻿using System;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 列挙型の既定値を表す属性。
    /// </summary>
    [AttributeUsage(AttributeTargets.Field)]
    public class EnumDefaultValueAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public EnumDefaultValueAttribute() { }
    }
}
