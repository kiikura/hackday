﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 矩形領域内の配置を表す列挙。
    /// </summary>
    public enum RectangleAlignment
    {
        /// <summary>
        /// 左上端。
        /// </summary>
        [Description("左上端")]
        TopLeft,

        /// <summary>
        /// 中央上端。
        /// </summary>
        [Description("中央上端")]
        TopCenter,

        /// <summary>
        /// 右上端。
        /// </summary>
        [Description("右上端")]
        TopRight,

        /// <summary>
        /// 左端中央。
        /// </summary>
        [Description("左端中央")]
        MiddleLeft,

        /// <summary>
        /// 中心。
        /// </summary>
        [Description("中心")]
        [EnumDefaultValue]
        MiddleCenter,

        /// <summary>
        /// 右端中央。
        /// </summary>
        [Description("右端中央")]
        MiddleRight,

        /// <summary>
        /// 左下端。
        /// </summary>
        [Description("左下端")]
        BottomLeft,

        /// <summary>
        /// 中央下端。
        /// </summary>
        [Description("中央下端")]
        BottomCenter,

        /// <summary>
        /// 右下端。
        /// </summary>
        [Description("右下端")]
        BottomRight,
    }
}
