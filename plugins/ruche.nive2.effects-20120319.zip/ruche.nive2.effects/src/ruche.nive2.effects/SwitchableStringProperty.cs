﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 文字列値とその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class SwitchableStringProperty : SwitchableValueProperty<string>
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableStringProperty(string name, string value, bool valid)
            : this(name, value, valid, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="defaultValue">
        /// 既定値。 null ならば空文字列を用いる。
        /// </param>
        public SwitchableStringProperty(
            string name,
            string value,
            bool valid,
            string defaultValue)
            : this(name, value, valid, defaultValue, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="defaultValue">
        /// 既定値。 null ならば空文字列を用いる。
        /// </param>
        /// <param name="valueValidater">
        /// 文字列値検証オブジェクト。不要ならば null 。
        /// シリアライズ可能である必要がある。
        /// </param>
        public SwitchableStringProperty(
            string name,
            string value,
            bool valid,
            string defaultValue,
            IValidater<string> valueValidater)
            :
            base(
                name,
                value ?? string.Empty,
                valid,
                defaultValue ?? string.Empty,
                valueValidater)
        {
        }

        /// <summary>
        /// 有効状態ならば文字列値を、無効状態ならば null 値を取得する。
        /// </summary>
        public new string Value
        {
            get { return Valid ? OriginalValue : null; }
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return true; }
        }

        public override object ScriptValue
        {
            get { return OriginalValue; }
            set { OriginalValue = (value ?? DefaultValue).ToString(); }
        }

        #endregion
    }
}
