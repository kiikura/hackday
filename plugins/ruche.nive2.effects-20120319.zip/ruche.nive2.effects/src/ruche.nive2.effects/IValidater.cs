﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ruche.nive2.effects
{
    /// <summary>
    /// データを検証する処理を提供するインタフェース。
    /// </summary>
    /// <typeparam name="T">データ型。</typeparam>
    public interface IValidater<T>
    {
        /// <summary>
        /// データを検証する。
        /// </summary>
        /// <param name="data">
        /// 検証するデータ。必要に応じて書き換えられる。
        /// </param>
        /// <returns>検証結果。</returns>
        bool Validate(ref T data);
    }
}
