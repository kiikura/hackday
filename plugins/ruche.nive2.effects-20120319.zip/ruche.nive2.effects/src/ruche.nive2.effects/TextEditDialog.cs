﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 文字列値を編集するコモンダイアログクラス。
    /// </summary>
    public class TextEditDialog : CommonDialog
    {
        /// <summary>
        /// 入力欄のフォント。
        /// </summary>
        private Font _font = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextEditDialog()
        {
            Reset();
        }

        /// <summary>
        /// 編集対象のテキストを取得または設定する。
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 入力可能な最大文字数を取得または設定する。 0 ならば無制限となる。
        /// </summary>
        public int MaxLength { get; set; }

        /// <summary>
        /// 入力欄のフォントを設定する。
        /// </summary>
        /// <param name="font">フォント。</param>
        public void SetEditFont(Font font)
        {
            if (font != _font)
            {
                if (_font != null)
                {
                    _font.Dispose();
                    _font = null;
                }
                if (font != null)
                {
                    _font = (Font)font.Clone();
                }
            }
        }

        #region CommonDialog メンバ

        public override void Reset()
        {
            this.Text = string.Empty;
            this.MaxLength = 0;
            SetEditFont(null);
        }

        protected override bool RunDialog(IntPtr hwndOwner)
        {
            bool result = false;

            using (TextEditWindow window = new TextEditWindow())
            {
                window.Value = this.Text;
                window.MaxLength = this.MaxLength;
                if (_font != null)
                {
                    window.SetEditFont(_font);
                }

                Control owner = Control.FromHandle(hwndOwner);
                if (window.ShowDialog(owner) == DialogResult.OK)
                {
                    this.Text = window.Value;
                    result = true;
                }
            }

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            SetEditFont(null);

            base.Dispose(disposing);
        }

        #endregion
    }
}
