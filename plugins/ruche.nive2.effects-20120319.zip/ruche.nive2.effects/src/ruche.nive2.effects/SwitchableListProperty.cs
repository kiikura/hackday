﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization.Formatters.Soap;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// シリアライズ可能なデータのリストとその選択インデックス、
    /// およびそれらの有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    /// <typeparam name="T">
    /// データ型。シリアライズ可能でなければならない。
    /// </typeparam>
    [Serializable]
    public class SwitchableListProperty<T> : SwitchablePropertyBase<int>
    {
        /// <summary>
        /// データリスト。
        /// </summary>
        private ReadOnlyCollection<T> _items = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="selectedIndex">初期選択インデックス。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="items">データリスト。</param>
        public SwitchableListProperty(
            string name,
            int selectedIndex,
            bool valid,
            IEnumerable<T> items)
            : base(name, selectedIndex, valid)
        {
            if (!typeof(T).IsDefined(typeof(SerializableAttribute), false))
            {
                throw new ArgumentException(
                    "型 " + typeof(T).FullName +
                    " はシリアライズ可能としてマークされていません。");
            }
            if (items == null)
            {
                throw new ArgumentNullException("items");
            }

            List<T> it = new List<T>(items);
            if (it.Count == 0)
            {
                throw new ArgumentException("items の要素数が 0 です。");
            }

            this._items = new ReadOnlyCollection<T>(it);

            // 値補正のため再度設定
            this.OriginalValue = selectedIndex;
        }

        /// <summary>
        /// 有効状態ならば選択インデックスを、無効状態ならば null 値を取得する。
        /// </summary>
        public new int? Value
        {
            get { return Valid ? (int?)OriginalValue : null; }
        }

        /// <summary>
        /// データリストを取得する。
        /// </summary>
        public ReadOnlyCollection<T> Items
        {
            get { return _items; }
        }

        #region SwitchablePropertyBase<int> メンバ

        protected override bool ValidateValue(ref int value)
        {
            value = Math.Max(value, 0);
            if (this.Items != null)
            {
                value = Math.Min(value, this.Items.Count - 1);
            }
            return true;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return new SwitchableListProperty<T>(
                name,
                DefaultValue,
                true,
                this.Items);
        }

        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchableListProperty<T>)src;
            base.CopyFrom(prop);
            this._items = new ReadOnlyCollection<T>(prop.Items);
        }

        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchableListProperty<T>)other;
            if (
                base.IsValueEquals(prop) &&
                this.Items.Count == prop.Items.Count)
            {
                for (int i = 0; i < this.Items.Count; ++i)
                {
                    if (!object.Equals(this.Items[i], prop.Items[i]))
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        #endregion
        
        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return true; }
        }

        public override object ScriptValue
        {
            get { return OriginalValue; }
            set { OriginalValue = (int)value; }
        }

        #endregion
    }
}
