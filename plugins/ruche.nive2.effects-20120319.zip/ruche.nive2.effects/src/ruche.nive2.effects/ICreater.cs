﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ruche.nive2.effects
{
    /// <summary>
    /// データの生成処理を提供するインタフェース。
    /// </summary>
    /// <typeparam name="T">データ型。</typeparam>
    public interface ICreater<T>
    {
        /// <summary>
        /// データを生成する。
        /// </summary>
        /// <returns>データ。</returns>
        T Create();
    }
}
