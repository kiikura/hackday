﻿using System;
using System.Collections.Generic;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 追加可能な変数プロパティセットを保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class AddableVariableProperty : AddablePropertyBase
    {
        /// <summary>
        /// 数値プリセット名と小数点以下桁数のテーブル。
        /// </summary>
        private static readonly Dictionary<string, int> NumberPresetDigitTable;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static AddableVariableProperty()
        {
            NumberPresetDigitTable = new Dictionary<string, int>(5);
            for (int i = 0; i <= 4; ++i)
            {
                NumberPresetDigitTable.Add(
                    "数値(小数点以下" + i + "桁)",
                    i);
            }
        }

        /// <summary>
        /// プロパティセット配列。
        /// </summary>
        private PropertySetBase[] _properties = new PropertySetBase[0];

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public AddableVariableProperty(string name) : base(name)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public AddableVariableProperty(
            AddableVariableProperty src)
            : this(src.PropertyName)
        {
            this.Properties = Array.ConvertAll(
                src.Properties,
                p => (PropertySetBase)p.Copy());
        }

        /// <summary>
        /// 指定した変数名に対応する変数値プロパティを取得するインデクサ。
        /// </summary>
        /// <param name="varName">変数名。</param>
        /// <returns>変数値プロパティ。存在しない場合は null 。</returns>
        public PropertyBase this[string varName]
        {
            get
            {
                VariablePropertySetBase vp = FindVarProperty(varName);
                return (vp == null) ? null : vp.VarValueProperty;
            }
        }

        /// <summary>
        /// 指定した変数名を持つ変数プロパティセットを検索する。
        /// </summary>
        /// <param name="varName">変数名。</param>
        /// <returns>変数プロパティセット。存在しない場合は null 。</returns>
        public VariablePropertySetBase FindVarProperty(string varName)
        {
            foreach (PropertySetBase prop in Properties)
            {
                VariablePropertySetBase vp = prop as VariablePropertySetBase;
                if (vp != null && vp.VarName == varName)
                {
                    return vp;
                }
            }
            return null;
        }

        /// <summary>
        /// 変数プロパティセットを取得する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>変数プロパティセット。</returns>
        public VariablePropertySetBase GetVarProperty(int index)
        {
            if (index < 0 || index >= Properties.Length)
            {
                throw new ArgumentOutOfRangeException(
                    "index", index, "インデックスが配列の範囲外です。");
            }

            return Properties[index] as VariablePropertySetBase;
        }

        /// <summary>
        /// 変数プロパティセット配列を取得する。
        /// </summary>
        /// <returns>変数プロパティセット配列。</returns>
        public VariablePropertySetBase[] GetVarProperties()
        {
            return Array.ConvertAll(
                Properties,
                p => (VariablePropertySetBase)p);
        }

        #region AddablePropertyBase メンバ

        public override Type[] PropertyTypes
        {
            get
            {
                return new Type[]
                    {
                        typeof(StringVariablePropertySet),
                        typeof(DecimalVariablePropertySet),
                    };
            }
        }

        public override PropertySetBase[] Properties
        {
            get { return _properties; }
            set { _properties = value ?? new PropertySetBase[0]; }
        }

        public override string[] PropertyPreset
        {
            get
            {
                return new List<string>(NumberPresetDigitTable.Keys).ToArray();
            }
        }

        public override PropertySetBase CreateProperty(Type propertyType)
        {
            PropertySetBase prop = null;

            if (propertyType == typeof(StringVariablePropertySet))
            {
                prop = new StringVariablePropertySet("文字列値");
            }
            else if (propertyType == typeof(DecimalVariablePropertySet))
            {
                prop = new DecimalVariablePropertySet("数値");
            }

            return prop;
        }

        public override PropertySetBase[] GetPropertyPreset(string presetName)
        {
            int digits;
            if (NumberPresetDigitTable.TryGetValue(presetName, out digits))
            {
                return new PropertySetBase[]
                    {
                        new DecimalVariablePropertySet(
                            "数値",
                            null,
                            0,
                            decimal.MinValue,
                            decimal.MaxValue,
                            digits,
                            1,
                            -1)
                    };
            }
            return null;
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase Copy()
        {
            return new AddableVariableProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            // 手抜き
            return ((object)this).Equals(obj);
        }

        #endregion
    }
}
