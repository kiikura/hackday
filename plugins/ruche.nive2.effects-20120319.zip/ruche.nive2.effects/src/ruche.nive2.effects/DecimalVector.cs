﻿using System;
using System.Drawing;
using NiVE2.Drawing;

namespace ruche.nive2.effects
{
    /// <summary>
    /// decimal 型の4次元ベクトル構造体。
    /// </summary>
    [Serializable]
    public struct DecimalVector
    {
        /// <summary>
        /// 文字列値を DecimalVector 値に変換する。
        /// </summary>
        /// <param name="s">文字列値。</param>
        /// <param name="result">DecimalVector 値の設定先。</param>
        /// <returns>成功した場合は true 。そうでなければ false 。</returns>
        public static bool TryParse(string s, out DecimalVector result)
        {
            result = new DecimalVector();

            if (string.IsNullOrEmpty(s))
            {
                return false;
            }

            string[] nums = s.Split(',');
            if (nums.Length <= 0 || nums.Length > 4)
            {
                return false;
            }

            var temp = new DecimalVector();
            decimal r = 0;
            for (int i = 0; i < nums.Length; ++i)
            {
                if (!decimal.TryParse(nums[i], out r))
                {
                    return false;
                }
                temp[i] = r;
            }
            result = temp;

            return true;
        }

        /// <summary>
        /// X値。
        /// </summary>
        private decimal _x;
        
        /// <summary>
        /// Y値。
        /// </summary>
        private decimal _y;
        
        /// <summary>
        /// Z値。
        /// </summary>
        private decimal _z;

        /// <summary>
        /// W値。
        /// </summary>
        private decimal _w;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="x">X値。</param>
        /// <param name="y">Y値。</param>
        public DecimalVector(decimal x, decimal y)
            : this(x, y, 0)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="x">X値。</param>
        /// <param name="y">Y値。</param>
        /// <param name="z">Z値。</param>
        public DecimalVector(decimal x, decimal y, decimal z)
            : this(x, y, z, 0)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="x">X値。</param>
        /// <param name="y">Y値。</param>
        /// <param name="z">Z値。</param>
        /// <param name="w">W値。</param>
        public DecimalVector(decimal x, decimal y, decimal z, decimal w)
        {
            _x = x;
            _y = y;
            _z = z;
            _w = w;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="point">Point 値。</param>
        public DecimalVector(Point point)
            : this(point.X, point.Y)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="point">PointF 値。</param>
        public DecimalVector(PointF point)
            : this((decimal)point.X, (decimal)point.Y)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="size">Size 値。</param>
        public DecimalVector(Size size)
            : this(size.Width, size.Height)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="size">SizeF 値。</param>
        public DecimalVector(SizeF size)
            : this((decimal)size.Width, (decimal)size.Height)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="vertex">頂点座標値。</param>
        public DecimalVector(Vertex vertex)
            : this((decimal)vertex.X, (decimal)vertex.Y, (decimal)vertex.Z)
        {
        }

        /// <summary>
        /// X値を取得または設定する。
        /// </summary>
        public decimal X
        {
            get { return _x; }
            set { _x = value; }
        }

        /// <summary>
        /// Y値を取得または設定する。
        /// </summary>
        public decimal Y
        {
            get { return _y; }
            set { _y = value; }
        }

        /// <summary>
        /// Z値を取得または設定する。
        /// </summary>
        public decimal Z
        {
            get { return _z; }
            set { _z = value; }
        }

        /// <summary>
        /// W値を取得または設定する。
        /// </summary>
        public decimal W
        {
            get { return _w; }
            set { _w = value; }
        }

        /// <summary>
        /// 値を取得また設定するインデクサ。
        /// </summary>
        /// <param name="index">インデックス。 0 ～ 3 。</param>
        /// <returns>
        /// インデックスが 0 ならばX値。
        /// インデックスが 1 ならばY値。
        /// インデックスが 2 ならばZ値。
        /// インデックスが 3 ならばW値。
        /// </returns>
        public decimal this[int index]
        {
            get
            {
                switch (index)
                {
                case 0: return X;
                case 1: return Y;
                case 2: return Z;
                case 3: return W;
                }
                throw new ArgumentOutOfRangeException(
                    "index", index, "インデックスが範囲外です。");
            }
            set
            {
                switch (index)
                {
                case 0: X = value; return;
                case 1: Y = value; return;
                case 2: Z = value; return;
                case 3: W = value; return;
                }
                throw new ArgumentOutOfRangeException(
                    "index", index, "インデックスが範囲外です。");
            }
        }

        /// <summary>
        /// 現在の値から配列を作成する。
        /// </summary>
        /// <returns>配列。</returns>
        public decimal[] ToArray()
        {
            return new decimal[] { X, Y, Z, W };
        }

        /// <summary>
        /// 現在の値から Point 値を作成する。
        /// </summary>
        /// <returns>PointF 値。</returns>
        public Point ToPoint()
        {
            return new Point((int)X, (int)Y);
        }

        /// <summary>
        /// 現在の値から PointF 値を作成する。
        /// </summary>
        /// <returns>PointF 値。</returns>
        public PointF ToPointF()
        {
            return new PointF((float)X, (float)Y);
        }

        /// <summary>
        /// 現在の値から Size 値を作成する。
        /// </summary>
        /// <returns>Size 値。</returns>
        public Size ToSize()
        {
            return new Size((int)X, (int)Y);
        }

        /// <summary>
        /// 現在の値から SizeF 値を作成する。
        /// </summary>
        /// <returns>SizeF 値。</returns>
        public SizeF ToSizeF()
        {
            return new SizeF((float)X, (float)Y);
        }

        /// <summary>
        /// 現在の値から頂点座標値を作成する。
        /// </summary>
        /// <returns>頂点座標値。</returns>
        public Vertex ToVertex()
        {
            return new Vertex((double)X, (double)Y, (double)Z);
        }

        public override string ToString()
        {
            return (X + "," + Y + "," + Z + "," + W);
        }
    }
}
