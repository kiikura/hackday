﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 数値配列とその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    /// <remarks>
    /// 最大値もしくは最小値の異なるプロパティ間の補間を行う場合、
    /// より大きい最大値およびより小さい最小値が用いられる。
    /// 
    /// 要素数の異なるプロパティ間の補間を行う場合、要素数の多い側を基準とし、
    /// 要素数の少ない側の不足要素には多い側の DefaultValue の対応する要素値が
    /// 設定されているものとして補間を行う。
    /// </remarks>
    [Serializable]
    public class SwitchableNumberArrayProperty
        :
        SwitchablePropertyBase<double[]>
    {
        /// <summary>
        /// 最大値。
        /// </summary>
        private double _maxValue = double.MaxValue;

        /// <summary>
        /// 最小値。
        /// </summary>
        private double _minValue = double.MinValue;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="values">
        /// 初期値配列。要素数は 1 以上でなければならない。
        /// </param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableNumberArrayProperty(
            string name,
            double[] values,
            bool valid)
            : this(name, values, valid, double.MaxValue, double.MinValue)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="values">
        /// 初期値配列。要素数は 1 以上でなければならない。
        /// </param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="valueRange1">値範囲1。</param>
        /// <param name="valueRange2">値範囲2。</param>
        public SwitchableNumberArrayProperty(
            string name,
            double[] values,
            bool valid,
            double valueRange1,
            double valueRange2)
            : base(name, values, valid)
        {
            if (values.Length == 0)
            {
                throw new ArgumentException("要素数が 0 です。", "values");
            }

            // 最大値と最小値設定
            _maxValue = Math.Max(valueRange1, valueRange2);
            _minValue = Math.Min(valueRange1, valueRange2);

            // 値補正のため再度設定
            OriginalValue = values;
        }

        /// <summary>
        /// 内部配列値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 取得時はクローンを返すため、返された配列の要素の値を変更しても
        /// 実際の値には反映されない。
        /// 
        /// null 値または要素数が 0 の配列を渡すと
        /// DefaultValues プロパティ値を用いる。
        /// </remarks>
        public new double[] OriginalValue
        {
            get { return (double[])base.OriginalValue.Clone(); }
            set { base.OriginalValue = value; }
        }

        /// <summary>
        /// 有効状態ならば内部配列値を、無効状態ならば null 値を取得する。
        /// </summary>
        /// <remarks>
        /// 取得時はクローンを返すため、返された配列の要素の値を変更しても
        /// 実際の値には反映されない。
        /// </remarks>
        public new double[] Value
        {
            get { return Valid ? OriginalValue : null; }
        }

        /// <summary>
        /// 配列の要素数を取得する。
        /// </summary>
        public int Length
        {
            get { return base.OriginalValue.Length; }
        }

        /// <summary>
        /// 設定可能な最大値を取得または設定する。
        /// </summary>
        public double MaxValue
        {
            get { return _maxValue; }
            set
            {
                _maxValue = value;
                if (_minValue > value)
                {
                    _minValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        /// <summary>
        /// 設定可能な最小値を取得または設定する。
        /// </summary>
        public double MinValue
        {
            get { return _minValue; }
            set
            {
                _minValue = value;
                if (_maxValue < value)
                {
                    _maxValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        public override string ToString()
        {
            return string.Join(
                ",",
                Array.ConvertAll(base.OriginalValue, (n) => n.ToString()));
        }

        #region SwitchablePropertyBase<double[]> メンバ

        public override double[] DefaultValue
        {
            get { return new double[Length]; }
        }

        protected override bool ValidateValue(ref double[] values)
        {
            if (values.Length == 0)
            {
                return false;
            }

            for (int i = 0; i < values.Length; ++i)
            {
                values[i] = Math.Min(Math.Max(values[i], MinValue), MaxValue);
            }

            return true;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return new SwitchableNumberArrayProperty(
                name,
                DefaultValue,
                false);
        }

        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchableNumberArrayProperty)src;
            base.CopyFrom(prop);
            this._maxValue = prop.MaxValue;
            this._minValue = prop.MinValue;
        }

        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchableNumberArrayProperty)other;
            if (base.IsValueEquals(prop) && Length == prop.Length)
            {
                double[] vals = OriginalValue;
                double[] propVals = prop.OriginalValue;
                for (int i = 0; i < Length; ++i)
                {
                    if (
                        vals[i] != propVals[i] ||
                        MaxValue != prop.MaxValue ||
                        MinValue != prop.MinValue)
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        #endregion

        #region PropertyBase メンバ

        public override PropertyInterpolationType SupportInterpolationType
        {
            get
            {
                return (
                    PropertyInterpolationType.Fixed |
                    PropertyInterpolationType.Liner |
                    PropertyInterpolationType.CatmullRom);
            }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            // 前方キーフレーム取得
            KeyFrame prevKey = Util.GetPrevKeyFrame(keyFrame, time);
            if (prevKey == null)
            {
                return Util.GetAboveKeyFrame(keyFrame, time).Property;
            }
            if (
                prevKey.Type == PropertyInterpolationType.Fixed ||
                prevKey.Time >= time)
            {
                return prevKey.Property;
            }

            // 後方キーフレーム取得
            KeyFrame nextKey = Util.GetAboveKeyFrame(keyFrame, time);
            if (nextKey == null)
            {
                return prevKey.Property;
            }

            // 補間処理
            var prevProp = (SwitchableNumberArrayProperty)prevKey.Property;
            var nextProp = (SwitchableNumberArrayProperty)nextKey.Property;
            var baseProp =
                (prevProp.Length < nextProp.Length) ? nextProp : prevProp;
            double[] prevVals = prevProp.OriginalValue;
            double[] nextVals = nextProp.OriginalValue;
            double[] baseVals = baseProp.DefaultValue;
            double[] values = (double[])baseVals.Clone();
            switch (prevKey.Type)
            {
            case PropertyInterpolationType.Liner:
                // リニア補間
                for (int i = 0; i < values.Length; ++i)
                {
                    values[i] = ValueInterpolationMethod.Linear(
                        prevKey.Time,
                        (i < prevVals.Length) ? prevVals[i] : baseVals[i],
                        nextKey.Time,
                        (i < nextVals.Length) ? nextVals[i] : baseVals[i],
                        time);
                }
                break;

            case PropertyInterpolationType.CatmullRom:
                // CatmullRom補間
                {
                    // 更に外のキーフレーム取得
                    KeyFrame prev2Key =
                        Util.GetBelowKeyFrame(keyFrame, prevKey.Time) ?? prevKey;
                    KeyFrame next2Key =
                        Util.GetAboveKeyFrame(keyFrame, nextKey.Time) ?? nextKey;
                    var prev2Prop =
                        (SwitchableNumberArrayProperty)prev2Key.Property;
                    var next2Prop =
                        (SwitchableNumberArrayProperty)next2Key.Property;
                    double[] prev2Vals = prev2Prop.OriginalValue;
                    double[] next2Vals = next2Prop.OriginalValue;

                    // 補間
                    for (int i = 0; i < values.Length; ++i)
                    {
                        double prevVal =
                            (i < prevVals.Length) ? prevVals[i] : baseVals[i];
                        double nextVal =
                            (i < nextVals.Length) ? nextVals[i] : baseVals[i];
                        values[i] = ValueInterpolationMethod.CatmullRom(
                            (i < prev2Vals.Length) ? prev2Vals[i] : prevVal,
                            prevVal,
                            nextVal,
                            (i < next2Vals.Length) ? next2Vals[i] : nextVal,
                            prevKey.Time,
                            nextKey.Time,
                            time);
                    }
                }
                break;
            }

            return new SwitchableNumberArrayProperty(
                prevProp.PropertyName,
                values,
                prevProp.Valid,
                Math.Min(prevProp.MinValue, nextProp.MinValue),
                Math.Max(prevProp.MaxValue, nextProp.MaxValue));
        }

        #endregion
    }
}
