﻿using System;
using System.Text.RegularExpressions;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 変数名と変数値のセットを保持するNiVE2プロパティセットの抽象基底クラス。
    /// </summary>
    [Serializable]
    public abstract class VariablePropertySetBase : PropertySetBase
    {
        /// <summary>
        /// 変数名を検証するクラス。
        /// </summary>
        [Serializable]
        private class NameValidater : IValidater<string>
        {
            /// <summary>
            /// 英数字とアンダーバー以外にマッチする正規表現。
            /// </summary>
            private static readonly Regex RegexNotNameChars =
                new Regex("[^a-zA-Z0-9_]+", RegexOptions.CultureInvariant);

            /// <summary>
            /// コンストラクタ。
            /// </summary>
            public NameValidater()
            {
            }

            #region IStringValidater メンバ

            public bool Validate(ref string value)
            {
                value = RegexNotNameChars.Replace(value, string.Empty);
                return true;
            }

            #endregion
        }

        /// <summary>
        /// 変数名プロパティを作成する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <returns>変数名プロパティ。</returns>
        private static SwitchableStringProperty CreateNameProperty(
            string name,
            string value)
        {
            return new SwitchableStringProperty(
                name,
                value,
                true,
                null,
                new NameValidater());
        }

        /// <summary>
        /// 変数名プロパティ。
        /// </summary>
        private SwitchableStringProperty _propName = null;

        /// <summary>
        /// 変数値プロパティ。
        /// </summary>
        private PropertyBase _propValue = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValueProperty">変数値プロパティ。</param>
        public VariablePropertySetBase(
            string name,
            string varName,
            PropertyBase varValueProperty)
            : base(name)
        {
            if (varValueProperty == null)
            {
                throw new ArgumentNullException("varValueProperty");
            }

            _propName = CreateNameProperty("variable.name", varName);
            _propValue = varValueProperty;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public VariablePropertySetBase(VariablePropertySetBase src)
            : base(src.PropertyName)
        {
            this._propName = (SwitchableStringProperty)src._propName.Copy();
            this._propValue = src._propValue.Copy();
        }

        /// <summary>
        /// 変数名を取得または設定する。
        /// </summary>
        public string VarName
        {
            get { return _propName.OriginalValue; }
            set { _propName.OriginalValue = value; }
        }

        /// <summary>
        /// 変数値プロパティを取得する。
        /// </summary>
        public PropertyBase VarValueProperty
        {
            get { return _propValue; }
        }

        /// <summary>
        /// 変数値を取得または設定する。
        /// </summary>
        public object VarValue
        {
            get { return _propValue.Value; }
            set { _propValue.Value = value; }
        }

        /// <summary>
        /// 変数値の文字列表現を取得する。
        /// </summary>
        /// <returns>変数値の文字列表現。</returns>
        public virtual string GetVarValueString()
        {
            return (VarValue == null) ? string.Empty : VarValue.ToString();
        }

        public override string ToString()
        {
            return (VarName + " : " + GetVarValueString());
        }

        /// <summary>
        /// 変数値プロパティを編集するコントロールを作成する。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <returns>プロパティコントロール。</returns>
        protected abstract PropertyEditControlBase CreateVarValueControl(
            string name);

        #region PropertySetBase メンバ

        public override PropertyBase[] Properties
        {
            get
            {
                return new PropertyBase[] { _propName, _propValue };
            }
            set
            {
                if (value != null && value.Length >= 2)
                {
                    if (value[0] != null && value[0] is SwitchableStringProperty)
                    {
                        _propName = (SwitchableStringProperty)value[0];
                    }
                    if (value[1] != null)
                    {
                        _propValue = value[1];
                    }
                }
            }
        }

        public override PropertyEditControlBase[] GetControl()
        {
            var varNameCtrl = new TextPropertyEditControl<SwitchableStringProperty>(
                _propName.PropertyName,
                false,
                256);
            varNameCtrl.LabelName = "変数名";
            varNameCtrl.CreatePropertyDelegate = CreateNameProperty;

            return new PropertyEditControlBase[]
                {
                    varNameCtrl,
                    CreateVarValueControl(VarValueProperty.PropertyName),
                };
        }

        public override void InitializeDefaultProperty()
        {
        }

        #endregion

        #region PropertyBase メンバ

        public override object Value
        {
            get { return null; }
            set { }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.None; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return null;
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            VariablePropertySetBase prop = obj as VariablePropertySetBase;
            if (prop != null)
            {
                return (
                    this.PropertyName == prop.PropertyName &&
                    this._propName.Equals(prop._propName) &&
                    this.VarValueProperty.Equals(prop.VarValueProperty));
            }
            return false;
        }

        #endregion
    }
}
