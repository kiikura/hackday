﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// テキストと直前のキーフレームからの経過秒数を保持する
    /// NiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class KeyFrameStringProperty : StringProperty
    {
        /// <summary>
        /// 経過秒数。
        /// </summary>
        private double _elapsedTime = -1;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="text">テキスト。</param>
        public KeyFrameStringProperty(string name, string text)
            : base(name, text)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">コピー元の StringProperty 。</param>
        public KeyFrameStringProperty(StringProperty src)
            : this(src.PropertyName, src.Text)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public KeyFrameStringProperty(KeyFrameStringProperty src)
            : this(src.PropertyName, src.Text)
        {
            _elapsedTime = src._elapsedTime;
        }

        /// <summary>
        /// キーフレームからの経過秒数を取得する。
        /// </summary>
        /// <remarks>
        /// 補間された場合は前方で最も近いキーフレームからの経過秒数を返す。
        /// 前方にキーフレームが無い場合はレイヤ開始時間からの経過秒数を返す。
        /// 
        /// 補間されていない場合は負数を返す。
        /// </remarks>
        public double ElapsedTime
        {
            get { return _elapsedTime; }
        }

        #region PropertyBase メンバ

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame, double time)
        {
            // ベースクラスの処理結果からインスタンス作成
            KeyFrameStringProperty property =
                new KeyFrameStringProperty(
                    (StringProperty)base.Interpolation(keyFrame, time));

            // 経過秒数設定
            property._elapsedTime = Util.CalcElapsedTime(keyFrame, time);

            return property;
        }

        public override PropertyBase Copy()
        {
            return new KeyFrameStringProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            if (obj != null && obj is KeyFrameStringProperty)
            {
                return (
                    base.Equals(obj) &&
                    ElapsedTime == ((KeyFrameStringProperty)obj).ElapsedTime);
            }
            return false;
        }

        #endregion
    }
}
