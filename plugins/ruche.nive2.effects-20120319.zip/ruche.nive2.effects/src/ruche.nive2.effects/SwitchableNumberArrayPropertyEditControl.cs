﻿using System;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 数値配列プロパティを編集するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class SwitchableNumberArrayPropertyEditControl
        :
        SwitchablePropertyEditControlBase
    {
        /// <summary>
        /// 数値入力欄の最大数。
        /// </summary>
        public const int MaxTextBoxCount = 4;

        /// <summary>
        /// 区切りラベルの最大数。
        /// </summary>
        public const int MaxSplitterCount = MaxTextBoxCount - 1;

        /// <summary>
        /// 数値ラベルの配置開始X位置。
        /// </summary>
        private const int NumberLabelBeginX = 1;

        /// <summary>
        /// 数値ラベルの最小幅。
        /// </summary>
        private const int NumberLabelMinWidth = 11;

        /// <summary>
        /// テキストボックスの追加幅。
        /// </summary>
        private const int TextBoxAppendWidth = 12;

        /// <summary>
        /// 数値ラベル用フォント。
        /// </summary>
        private Font _fontNumLabel = null;

        /// <summary>
        /// 数値ラベル配列。
        /// </summary>
        private Label[] _labelNumbers = null;

        /// <summary>
        /// 数値入力欄配列。
        /// </summary>
        private TextBox[] _textNumbers = null;

        /// <summary>
        /// 単位ラベル配列。
        /// </summary>
        private Label[] _labelUnits = null;

        /// <summary>
        /// スプリッタラベル配列。
        /// </summary>
        private Label[] _labelSplits = null;

        /// <summary>
        /// インクリメント幅。
        /// </summary>
        private double _increment = 1;

        /// <summary>
        /// 小数部の表示桁数。
        /// </summary>
        private int _decimalPlaces = 0;

        /// <summary>
        /// 編集中入力欄インデックス。
        /// </summary>
        private int _editIndex = -1;

        /// <summary>
        /// マウス左ボタン投下中インデックス。
        /// </summary>
        private int _mousePushIndex = -1;

        /// <summary>
        /// マウスカーソルが左ボタン投下後に動いたか否か。
        /// </summary>
        private bool _mouseMoved = false;

        /// <summary>
        /// マウスの左ボタン投下時のカーソルX位置。
        /// </summary>
        private int _baseX = 0;

        /// <summary>
        /// マウスの左ボタン投下後の直前のカーソルX位置。
        /// </summary>
        private int _prevX = 0;

        /// <summary>
        /// マウスの左ボタン投下時の数値。
        /// </summary>
        private double _baseValue = 0;

        /// <summary>
        /// マウスで増減させた数値。
        /// </summary>
        private double _curValue = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">値のインクリメント幅。</param>
        /// <param name="unit">
        /// 単位ラベル文字列。 null ならば空文字列が設定される。
        /// </param>
        /// <param name="splitter">
        /// 区切りラベル文字列。 null ならば "," が設定される。
        /// </param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableNumberArrayPropertyEditControl(
            string name,
            double increment,
            string unit,
            string splitter,
            bool switchable,
            bool alwaysEditable)
            : this(name, increment, unit, splitter, - 1, switchable, alwaysEditable)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">値のインクリメント幅。</param>
        /// <param name="unit">
        /// 単位ラベル文字列。 null ならば空文字列が設定される。
        /// </param>
        /// <param name="splitter">
        /// 区切りラベル文字列。 null ならば "," が設定される。
        /// </param>
        /// <param name="decimalPlaces">
        /// 小数部の表示桁数。 -1 ならば表示桁数を操作しない。
        /// </param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableNumberArrayPropertyEditControl(
            string name,
            double increment,
            string unit,
            string splitter,
            int decimalPlaces,
            bool switchable,
            bool alwaysEditable)
            : base(name, switchable, alwaysEditable)
        {
            this.Increment = increment;
            this.DecimalPlaces = decimalPlaces;

            InitializeComponent();
            InitializeControls();

            SetUnit(unit);
            SetSplitter(splitter);
        }

        /// <summary>
        /// ドラッグ時のインクリメント幅を取得または設定する。
        /// </summary>
        public double Increment
        {
            get { return _increment; }
            set { _increment = value; }
        }

        /// <summary>
        /// 小数部の表示桁数を取得または設定する。
        /// -1 ならば表示桁数を操作しない。
        /// </summary>
        public int DecimalPlaces
        {
            get { return _decimalPlaces; }
            set { _decimalPlaces = Math.Min(Math.Max(value, -1), 99); }
        }

        /// <summary>
        /// テキスト編集中であるか否かを取得する。
        /// </summary>
        private bool IsEditing
        {
            get
            {
                return (_editIndex >= 0 && _textNumbers[_editIndex].Visible);
            }
        }

        /// <summary>
        /// 単位ラベル文字列を取得する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>単位ラベル文字列。</returns>
        public string GetUnit(int index)
        {
            if (index >= MaxTextBoxCount)
            {
                throw new ArgumentOutOfRangeException(
                    "index",
                    index,
                    "index が単位ラベルの最大数を超えています。");
            }

            return _labelUnits[index].Text;
        }

        /// <summary>
        /// 単位ラベル文字列を設定する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <param name="unit">
        /// 単位ラベル文字列。 null ならば空文字列が設定される。
        /// </param>
        public void SetUnit(int index, string unit)
        {
            if (index >= MaxTextBoxCount)
            {
                throw new ArgumentOutOfRangeException(
                    "index",
                    index,
                    "index が単位ラベルの最大数を超えています。");
            }

            _labelUnits[index].Text = unit ?? string.Empty;
        }

        /// <summary>
        /// すべての単位ラベル文字列を設定する。
        /// </summary>
        /// <param name="unit">
        /// 単位ラベル文字列。 null ならば空文字列が設定される。
        /// </param>
        public void SetUnit(string unit)
        {
            for (int i = 0; i < MaxTextBoxCount; ++i)
            {
                SetUnit(i, unit);
            }
        }

        /// <summary>
        /// 区切りラベル文字列を取得する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>区切りラベル文字列。</returns>
        public string GetSplitter(int index)
        {
            if (index >= MaxSplitterCount)
            {
                throw new ArgumentOutOfRangeException(
                    "index",
                    index,
                    "index が区切りラベルの最大数を超えています。");
            }

            return _labelSplits[index].Text;
        }

        /// <summary>
        /// 区切りラベル文字列を設定する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <param name="splitter">
        /// 区切りラベル文字列。 null ならば "," が設定される。
        /// </param>
        public void SetSplitter(int index, string splitter)
        {
            if (index >= MaxSplitterCount)
            {
                throw new ArgumentOutOfRangeException(
                    "index",
                    index,
                    "index が区切りラベルの最大数を超えています。");
            }

            _labelSplits[index].Text = splitter ?? ",";
        }

        /// <summary>
        /// すべての区切りラベル文字列を設定する。
        /// </summary>
        /// <param name="splitter">
        /// 区切りラベル文字列。 null ならば "," が設定される。
        /// </param>
        public void SetSplitter(string splitter)
        {
            for (int i = 0; i < MaxSplitterCount; ++i)
            {
                SetSplitter(i, splitter);
            }
        }

        /// <summary>
        /// コントロールを初期化する。
        /// </summary>
        private void InitializeControls()
        {
            // 数値ラベル用フォント作成
            _fontNumLabel =
                new Font(this.panelClient.Font, FontStyle.Underline);

            this.panelClient.SuspendLayout();
            try
            {
                // コントロール作成
                _labelNumbers = new Label[MaxTextBoxCount];
                _textNumbers = new TextBox[MaxTextBoxCount];
                _labelUnits = new Label[MaxTextBoxCount];
                _labelSplits = new Label[MaxSplitterCount];
                for (int i = 0; i < MaxTextBoxCount; ++i)
                {
                    // 数値ラベル
                    _labelNumbers[i] = new Label();
                    this.panelClient.Controls.Add(_labelNumbers[i]);
                    SetupNumberLabel(
                        _labelNumbers[i],
                        "labelNumber" + (i + 1),
                        i * 4);
                    _labelNumbers[i].Tag = i;

                    // 数値入力欄
                    _textNumbers[i] = new TextBox();
                    this.panelClient.Controls.Add(_textNumbers[i]);
                    SetupNumberTextBox(
                        _textNumbers[i],
                        "textNumber" + (i + 1),
                        i * 4 + 1);

                    // 単位ラベル
                    _labelUnits[i] = new Label();
                    this.panelClient.Controls.Add(_labelUnits[i]);
                    SetupUnitLabel(
                        _labelUnits[i],
                        "labelUnit" + (i + 1),
                        i * 4 + 2);

                    if (i < MaxSplitterCount)
                    {
                        // 区切りラベル
                        _labelSplits[i] = new Label();
                        this.panelClient.Controls.Add(_labelSplits[i]);
                        SetupSplitterLabel(
                            _labelSplits[i],
                            "labelSplit" + (i + 1),
                            i * 4 + 3);
                    }
                }

                // 数値入力欄を最前面へ移動
                for (int i = MaxTextBoxCount - 1; i >= 0; --i)
                {
                    _textNumbers[i].BringToFront();
                }

                // 位置合わせ
                AdjustControls();
            }
            finally
            {
                this.panelClient.ResumeLayout(false);
            }
        }

        /// <summary>
        /// 数値ラベルを設定する。
        /// </summary>
        /// <param name="src">設定するラベル。</param>
        /// <param name="name">コントロール名。</param>
        /// <param name="tabIndex">タブインデックス。</param>
        private void SetupNumberLabel(Label src, string name, int tabIndex)
        {
            src.AutoEllipsis = true;
            src.AutoSize = false;
            src.Cursor = Cursors.SizeWE;
            src.Font = _fontNumLabel;
            src.Name = name;
            src.Size = new Size(11, 12);
            src.TabIndex = tabIndex;
            src.Text = "0";
            src.TextAlign = ContentAlignment.MiddleLeft;
            src.MouseMove += this.labelNumber_MouseMove;
            src.MouseDown += this.labelNumber_MouseDown;
            src.MouseUp += this.labelNumber_MouseUp;
        }

        /// <summary>
        /// 数値入力欄を設定する。
        /// </summary>
        /// <param name="src">設定するテキストボックス。</param>
        /// <param name="name">コントロール名。</param>
        /// <param name="tabIndex">タブインデックス。</param>
        private void SetupNumberTextBox(TextBox src, string name, int tabIndex)
        {
            src.BorderStyle = BorderStyle.None;
            src.Font = null;
            src.Name = name;
            src.Size = new Size(20, 12);
            src.TabIndex = tabIndex;
            src.Text = "0";
            src.Visible = false;
            src.KeyDown += this.textNumber_KeyDown;
            src.Leave += this.textNumber_Leave;
            src.KeyPress += this.textNumber_KeyPress;
        }

        /// <summary>
        /// 単位ラベルを設定する。
        /// </summary>
        /// <param name="src">設定するラベル。</param>
        /// <param name="name">コントロール名。</param>
        /// <param name="tabIndex">タブインデックス。</param>
        private void SetupUnitLabel(Label src, string name, int tabIndex)
        {
            src.AutoSize = true;
            src.Font = null;
            src.Name = name;
            src.TabIndex = tabIndex;
            src.Text = string.Empty;
            src.TextAlign = ContentAlignment.MiddleLeft;
        }

        /// <summary>
        /// スプリッタラベルを設定する。
        /// </summary>
        /// <param name="src">設定するラベル。</param>
        /// <param name="name">コントロール名。</param>
        /// <param name="tabIndex">タブインデックス。</param>
        private void SetupSplitterLabel(Label src, string name, int tabIndex)
        {
            src.AutoSize = true;
            src.Font = null;
            src.Name = name;
            src.TabIndex = tabIndex;
            src.Text = ",";
            src.TextAlign = ContentAlignment.MiddleLeft;
        }

        /// <summary>
        /// テキスト編集を開始する。
        /// </summary>
        private void BeginEdit(int index)
        {
            if (!IsEditing)
            {
                // 編集モード開始
                _editIndex = index;
                _labelNumbers[index].Visible = false;
                _textNumbers[index].Visible = true;

                // 全選択してフォーカス
                _textNumbers[index].SelectAll();
                _textNumbers[index].Focus();
            }
        }

        /// <summary>
        /// テキスト編集を完了する。
        /// </summary>
        private void EndEdit()
        {
            if (IsEditing)
            {
                int index = _editIndex;

                if (_textNumbers[index].Text != _labelNumbers[index].Text)
                {
                    // 値が変わっていたらプロパティ更新
                    NotifyPropertyChanged();
                }

                // 編集モード終了
                _editIndex = -1;
                _textNumbers[index].Visible = false;
                _labelNumbers[index].Visible = true;
                _labelNumbers[index].Focus();
            }
        }

        /// <summary>
        /// テキスト編集をキャンセルする。
        /// </summary>
        private void CancelEdit()
        {
            if (IsEditing)
            {
                int index = _editIndex;

                // ラベルのテキストに戻す
                _textNumbers[index].Text = _labelNumbers[index].Text;

                // 編集モード終了
                _editIndex = -1;
                _textNumbers[index].Visible = false;
                _labelNumbers[index].Visible = true;
                _labelNumbers[index].Focus();
            }
        }

        /// <summary>
        /// コントロールの位置とサイズを補正する。
        /// </summary>
        private void AdjustControls()
        {
            var propDef = DefaultProperty as SwitchableNumberArrayProperty;
            if (
                propDef != null &&
                _labelNumbers != null &&
                _textNumbers != null &&
                _labelUnits != null &&
                _labelSplits != null)
            {
                int count = Math.Min(propDef.Length, MaxTextBoxCount);

                // 単位ラベルとスプリッタラベルの幅取得
                var unitWidthes = Array.ConvertAll(_labelUnits, c => c.Width);
                var splitWidthes =
                    Array.ConvertAll(_labelSplits, c => c.Width);

                // 数値ラベルの適正幅取得
                var labelWidthes =
                    Array.ConvertAll(_labelNumbers, c => c.PreferredWidth);
                for (int i = 0; i < MaxTextBoxCount; ++i)
                {
                    if (i >= count)
                    {
                        labelWidthes[i] = 0;
                    }
                }

                // テキストボックス幅決定
                var textWidthes = Array.ConvertAll(
                    labelWidthes,
                    w => (w == 0) ? 0 : (w + TextBoxAppendWidth));

                // 左詰めした場合の合計幅算出
                int width = NumberLabelBeginX;
                for (int i = 0; i < count; ++i)
                {
                    width += labelWidthes[i] + unitWidthes[i];
                    if (i + 1 < count)
                    {
                        width += splitWidthes[i];
                    }
                }

                // パネル幅を超えている場合は縮める
                int exWidth = width - this.ClientPanelSize.Width;
                if (exWidth > 0)
                {
                    // 数値ラベルインデックス初期化
                    var indices = new int[count];
                    for (int i = 0; i < count; ++i)
                    {
                        indices[i] = i;
                    }

                    // 数値ラベルインデックスを幅の大きい順に並べる
                    Array.Sort(
                        indices,
                        (i1, i2) => (labelWidthes[i2] - labelWidthes[i1]));

                    // 何個目までをリサイズすべきか調べる
                    int tc = 0, w = 0;
                    for (tc = 0; tc < indices.Length - 1 && w < exWidth; ++tc)
                    {
                        w +=
                            (labelWidthes[indices[tc]] -
                             labelWidthes[indices[tc + 1]]) *
                            (tc + 1);
                    }
                    tc = Math.Max(tc, 1);

                    // リサイズ対象の幅を揃える
                    w = labelWidthes[indices[tc - 1]];
                    for (int i = 0; i < tc; ++i)
                    {
                        exWidth -= labelWidthes[indices[i]] - w;
                        labelWidthes[indices[i]] = w;
                    }

                    // 残りの幅を均等に減らす
                    w = (exWidth + tc - 1) / tc;
                    for (int i = 0; i < tc; ++i)
                    {
                        labelWidthes[indices[i]] = Math.Max(
                            labelWidthes[indices[i]] - w,
                            NumberLabelMinWidth);
                    }
                }

                // 実際に左詰めで配置                
                this.panelClient.SuspendLayout();
                try
                {
                    Rectangle bounds;
                    int x = NumberLabelBeginX;
                    for (int i = 0; i < count; ++i)
                    {
                        // 数値ラベル
                        if (labelWidthes[i] > 0)
                        {
                            bounds = _labelNumbers[i].Bounds;
                            bounds.X = x;
                            bounds.Width = labelWidthes[i];
                            _labelNumbers[i].Bounds = bounds;
                        }

                        // テキストボックス
                        if (textWidthes[i] > 0)
                        {
                            bounds = _textNumbers[i].Bounds;
                            bounds.X = x + 2;
                            bounds.Width = textWidthes[i];
                            _textNumbers[i].Bounds = bounds;
                        }

                        x += labelWidthes[i];

                        // 単位ラベル
                        _labelUnits[i].Left = x;

                        x += unitWidthes[i];

                        if (i + 1 < count)
                        {
                            // スプリッタラベル
                            _labelSplits[i].Left = x;

                            x += splitWidthes[i];
                        }
                    }
                }
                finally
                {
                    this.panelClient.ResumeLayout(true);
                }
            }
        }

        /// <summary>
        /// double 値から文字列を作成する。
        /// </summary>
        /// <param name="value">double 値。</param>
        /// <returns>文字列。</returns>
        private string MakeDoubleString(double value)
        {
            string format = (this.DecimalPlaces < 0) ?
                "{0}" : ("{0:f" + this.DecimalPlaces + "}");
            return string.Format(format, value);
        }

        #region SwitchablePropertyEditControlBase メンバ

        protected override SwitchablePropertyBase CreateProperty()
        {
            SwitchableNumberArrayProperty prop = null;

            var propDef = DefaultProperty as SwitchableNumberArrayProperty;
            if (propDef != null)
            {
                // 値作成
                double[] vals = propDef.DefaultValue;
                int count = Math.Min(vals.Length, MaxTextBoxCount);
                for (int i = 0; i < count; ++i)
                {
                    if (_mousePushIndex == i)
                    {
                        // マウス編集値
                        vals[i] = _curValue;
                    }
                    else
                    {
                        // テキスト値
                        string tboxText = _textNumbers[i].Text;
                        string labelText = _labelNumbers[i].Text;
                        if (
                            !double.TryParse(tboxText, out vals[i]) &&
                            !double.TryParse(labelText, out vals[i]))
                        {
                            vals[i] = 0;
                        }
                    }
                }

                // プロパティ作成
                prop = (SwitchableNumberArrayProperty)propDef.Copy();
                prop.OriginalValue = vals;
                prop.Valid = this.PropertyValid;
            }

            return prop;
        }

        protected override void UpdateControls(
            SwitchablePropertyBase property)
        {
            var prop = property as SwitchableNumberArrayProperty;
            if (prop != null)
            {
                var vals = prop.OriginalValue;
                for (int i = 0; i < MaxTextBoxCount; ++i)
                {
                    bool enable = (i < vals.Length);

                    // 文字列設定
                    string valText =
                        MakeDoubleString(enable ? vals[i] : 0);
                    _textNumbers[i].Text = valText;
                    _labelNumbers[i].Text = valText;

                    // 表示設定
                    if (!enable)
                    {
                        _labelNumbers[i].Visible = false;
                        _textNumbers[i].Visible = false;
                        if (i > 0)
                        {
                            _labelSplits[i - 1].Visible = false;
                        }
                    }
                }

                // コントロールリサイズ
                AdjustControls();
            }
        }

        protected override void OnClientPanelSizeChanged(EventArgs e)
        {
            // コントロールリサイズ
            AdjustControls();

            base.OnClientPanelSizeChanged(e);
        }

        public override Type UseProperetyType()
        {
            return typeof(SwitchableNumberArrayProperty);
        }

        #endregion

        #region PropertyEditControlBase メンバ

        protected override void Dispose(bool disposing)
        {
            this.panelClient.Controls.Clear();
            if (_labelSplits != null)
            {
                Array.ForEach(_labelSplits, c => c.Dispose());
                _labelSplits = null;
            }
            if (_labelUnits != null)
            {
                Array.ForEach(_labelUnits, c => c.Dispose());
                _labelUnits = null;
            }
            if (_textNumbers != null)
            {
                Array.ForEach(_textNumbers, c => c.Dispose());
                _textNumbers = null;
            }
            if (_labelNumbers != null)
            {
                Array.ForEach(
                    _labelNumbers,
                    c =>
                    {
                        c.Font = null;
                        c.Dispose();
                    });
                _labelNumbers = null;
            }
            if (_fontNumLabel != null)
            {
                _fontNumLabel.Dispose();
                _fontNumLabel = null;
            }

            base.Dispose(disposing);
        }

        #endregion

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // panelClient
            // 
            this.panelClient.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panelClient.Location = new System.Drawing.Point(129, 3);
            this.panelClient.Size = new System.Drawing.Size(92, 12);
            // 
            // SwitchableNumberArrayPropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Name = "SwitchableNumberArrayPropertyEditControl";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelNumber_MouseDown(object sender, MouseEventArgs e)
        {
            var ctrl = sender as Control;
            if (
                e.Button == MouseButtons.Left &&
                ctrl != null &&
                ctrl.Tag is int &&
                !ControlUpdating &&
                double.TryParse(ctrl.Text, out _baseValue))
            {
                // 編集中なら終了
                if (IsEditing)
                {
                    EndEdit();
                }

                // 左ボタン投下
                _mousePushIndex = (int)ctrl.Tag;
                _mouseMoved = false;
                _baseX = e.X;
                _prevX = _baseX;
            }
        }

        private void labelNumber_MouseMove(object sender, MouseEventArgs e)
        {
            if (_mousePushIndex >= 0)
            {
                if (e.X != _prevX)
                {
                    // X位置更新
                    _prevX = e.X;

                    // ドラッグしたことにする
                    _mouseMoved = true;

                    // 値計算
                    _curValue = _baseValue + (e.X - _baseX) * _increment;

                    // プロパティ更新
                    NotifyPropertyChanged();
                }
            }
        }

        private void labelNumber_MouseUp(object sender, MouseEventArgs e)
        {
            var ctrl = sender as Control;
            if (
                e.Button == MouseButtons.Left &&
                ctrl != null &&
                ctrl.Tag is int &&
                _mousePushIndex >= 0)
            {
                // 左ボタン投下完了
                _mousePushIndex = -1;

                if (
                    !_mouseMoved &&
                    e.X >= 0 && e.X < ctrl.Width &&
                    e.Y >= 0 && e.Y < ctrl.Height)
                {
                    // ドラッグしておらず範囲内なら編集モード開始
                    BeginEdit((int)ctrl.Tag);
                }
            }
        }

        private void textNumber_Leave(object sender, EventArgs e)
        {
            if (IsEditing)
            {
                // フォーカスが離れたら編集完了
                EndEdit();
            }
        }

        private void textNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (IsEditing)
            {
                switch (e.KeyCode)
                {
                case Keys.Enter:
                    // Enterキー投下で編集完了
                    EndEdit();
                    break;

                case Keys.Escape:
                    // Escキー投下で編集キャンセル
                    CancelEdit();
                    break;
                }
            }
        }

        private void textNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 編集終了済みならキー入力を受け付けない
            if (!IsEditing)
            {
                e.Handled = true;
            }
        }
    }
}
