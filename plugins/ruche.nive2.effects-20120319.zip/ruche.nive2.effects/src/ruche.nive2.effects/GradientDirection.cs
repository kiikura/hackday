﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// グラデーション方向を表す列挙。
    /// </summary>
    public enum GradientDirection
    {
        /// <summary>
        /// 上から下。
        /// </summary>
        [Description("上から下")]
        [EnumDefaultValue]
        TopToBottom,

        /// <summary>
        /// 左から右。
        /// </summary>
        [Description("左から右")]
        LeftToRight,

        /// <summary>
        /// 左上から右下。
        /// </summary>
        [Description("左上から右下")]
        TopLeftToBottomRight,

        /// <summary>
        /// 右上から左下。
        /// </summary>
        [Description("右上から左下")]
        TopRightToBottomLeft,
    }
}
