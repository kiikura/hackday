﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Text;

namespace ruche.nive2.effects
{
    /// <summary>
    /// フォントファミリ名の読み取り専用配列クラス。
    /// </summary>
    [Serializable]
    public class FontFamilyNameCollection : ReadOnlyCollection<string>
    {
        /// <summary>
        /// フォントファミリ名配列を作成する。
        /// </summary>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        /// <param name="sorter">
        /// ソート用デリゲート。 null ならば既定の並び順になる。
        /// </param>
        /// <returns>フォントファミリ名配列。</returns>
        private static string[] MakeFontFamilyNames(
            Predicate<FontFamily> match,
            Comparison<FontFamily> sorter)
        {
            string[] names = null;

            using (var fc = new InstalledFontCollection())
            {
                var families =
                    Array.FindAll(fc.Families, match ?? ((ff) => true));
                if (sorter != null)
                {
                    Array.Sort(families, sorter);
                }
                names = Array.ConvertAll(families, (ff) => ff.Name);
            }

            return names;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <remarks>
        /// FontStyle.Regular をサポートするフォントファミリのみ選択される。
        /// </remarks>
        public FontFamilyNameCollection() : this(FontStyle.Regular)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="matchStyles">
        /// 選択条件スタイル。
        /// いずれかのスタイルをサポートするフォントファミリのみ選択される。
        /// </param>
        public FontFamilyNameCollection(params FontStyle[] matchStyles)
            : this(
                (ff) => (matchStyles == null) ?
                    false :
                    Array.Exists(
                        matchStyles,
                        (fs) => ff.IsStyleAvailable(fs)))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        public FontFamilyNameCollection(Predicate<FontFamily> match)
            : this(match, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        /// <param name="sorter">
        /// ソート用デリゲート。 null ならば既定の並び順になる。
        /// </param>
        public FontFamilyNameCollection(
            Predicate<FontFamily> match,
            Comparison<FontFamily> sorter)
            : base(MakeFontFamilyNames(match, sorter))
        {
        }

        /// <summary>
        /// フォントファミリを作成する。
        /// </summary>
        /// <param name="index">インデックス。</param>
        /// <returns>フォントファミリ。</returns>
        public FontFamily CreateFontFamily(int index)
        {
            return new FontFamily(this[index]);
        }

        /// <summary>
        /// フォントファミリ名リストに変換する。
        /// </summary>
        /// <returns>フォントファミリ名リスト。</returns>
        public List<string> ToList()
        {
            return ToList(null, null);
        }

        /// <summary>
        /// フォントファミリ名リストに変換する。
        /// </summary>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        /// <returns>フォントファミリ名リスト。</returns>
        public List<string> ToList(Predicate<string> match)
        {
            return ToList(match, null);
        }

        /// <summary>
        /// フォントファミリ名リストに変換する。
        /// </summary>
        /// <param name="sorter">
        /// ソート用デリゲート。 null ならば既定の並び順になる。
        /// </param>
        /// <returns>フォントファミリ名リスト。</returns>
        public List<string> ToList(Comparison<string> sorter)
        {
            return ToList(null, sorter);
        }

        /// <summary>
        /// フォントファミリ名リストに変換する。
        /// </summary>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        /// <param name="sorter">
        /// ソート用デリゲート。 null ならば既定の並び順になる。
        /// </param>
        /// <returns>フォントファミリ名リスト。</returns>
        public List<string> ToList(
            Predicate<string> match,
            Comparison<string> sorter)
        {
            var names = new List<string>(this);
            if (match != null)
            {
                names = names.FindAll(match);
            }
            if (sorter != null)
            {
                names.Sort(sorter);
            }
            return names;
        }
    }
}
