﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ruche.nive2.effects
{
    /// <summary>
    /// データとその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    /// <typeparam name="T">データ型。</typeparam>
    /// <remarks>
    /// このクラスから派生する場合、第1引数にプロパティ名、第2引数に初期値、
    /// 第3引数に値有効フラグを受け取るパブリックなコンストラクタを定義するか、
    /// CreateInstance メソッドをオーバライドすること。
    /// </remarks>
    [Serializable]
    public class SwitchableValueProperty<T> : SwitchablePropertyBase<T>
    {
        /// <summary>
        /// 値検証オブジェクト。
        /// </summary>
        private IValidater<T> _valueValidater = null;

        /// <summary>
        /// 既定値。
        /// </summary>
        private T _defaultValue = default(T);

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableValueProperty(string name, T value, bool valid)
            : this(name, value, valid, default(T))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="defaultValue">
        /// 既定値。既定のコンストラクタを用いるならば null 。
        /// </param>
        public SwitchableValueProperty(
            string name,
            T value,
            bool valid,
            T defaultValue)
            : this(name, value, valid, defaultValue, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="defaultValue">
        /// 既定値。既定のコンストラクタを用いるならば null 。
        /// </param>
        /// <param name="valueValidater">
        /// 値検証オブジェクト。不要ならば null 。
        /// シリアライズ可能でなければならない。
        /// </param>
        public SwitchableValueProperty(
            string name,
            T value,
            bool valid,
            T defaultValue,
            IValidater<T> valueValidater)
            :
            base(
                name,
                object.Equals(value, null) ? defaultValue : value,
                valid)
        {
            if (object.Equals(defaultValue, null))
            {
                _defaultValue = Activator.CreateInstance<T>();
            }
            else
            {
                _defaultValue = defaultValue;
            }
            _valueValidater = valueValidater;

            // 値補正のため再度設定
            OriginalValue = value;
        }

        /// <summary>
        /// 値検証オブジェクトを取得する。
        /// </summary>
        public IValidater<T> ValueValidater
        {
            get { return _valueValidater; }
        }

        #region SwitchablePropertyBase<T> メンバ

        public override sealed T DefaultValue
        {
            get { return _defaultValue; }
        }

        protected override sealed bool ValidateValue(ref T value)
        {
            bool result = true;
            if (ValueValidater != null)
            {
                result = ValueValidater.Validate(ref value);
            }
            return result;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return (SwitchableValueProperty<T>)Activator.CreateInstance(
                GetType(),
                name,
                DefaultValue,
                true);
        }

        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchableValueProperty<T>)src;
            base.CopyFrom(prop);
            this._defaultValue = prop._defaultValue;
            this._valueValidater = prop.ValueValidater;
        }

        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchableValueProperty<T>)other;
            var validaterComp = EqualityComparer<IValidater<T>>.Default;
            return (
                base.IsValueEquals(prop) &&
                ValueComparer.Equals(this.DefaultValue, prop.DefaultValue) &&
                validaterComp.Equals(this.ValueValidater, prop.ValueValidater));
        }

        #endregion
    }
}
