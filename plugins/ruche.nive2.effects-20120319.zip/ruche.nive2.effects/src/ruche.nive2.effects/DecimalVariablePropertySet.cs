﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 変数名と decimal 型変数値のセットを保持するNiVE2プロパティセットクラス。
    /// </summary>
    [Serializable]
    public class DecimalVariablePropertySet : VariablePropertySetBase
    {
        /// <summary>
        /// インクリメント幅。
        /// </summary>
        private decimal _increment = 1;

        /// <summary>
        /// 編集時の小数点以下桁数。
        /// </summary>
        private int _editDecimalPlaces = -1;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        public DecimalVariablePropertySet(string name)
            : this(name, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        public DecimalVariablePropertySet(string name, string varName)
            : this(name, varName, 0, decimal.MaxValue, decimal.MinValue)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValue">変数値。</param>
        /// <param name="varValueRange1">変数値の値範囲1。</param>
        /// <param name="varValueRange2">変数値の値範囲2。</param>
        public DecimalVariablePropertySet(
            string name,
            string varName,
            decimal varValue,
            decimal varValueRange1,
            decimal varValueRange2)
            :
            this(
                name,
                varName,
                varValue,
                varValueRange1,
                varValueRange2,
                1)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValue">変数値。</param>
        /// <param name="varValueRange1">変数値の値範囲1。</param>
        /// <param name="varValueRange2">変数値の値範囲2。</param>
        /// <param name="varIncrement">変数値のインクリメント幅。</param>
        public DecimalVariablePropertySet(
            string name,
            string varName,
            decimal varValue,
            decimal varValueRange1,
            decimal varValueRange2,
            decimal varIncrement)
            :
            this(
                name,
                varName,
                varValue,
                varValueRange1,
                varValueRange2,
                -1,
                varIncrement,
                -1)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValue">変数値。</param>
        /// <param name="varValueRange1">変数値の値範囲1。</param>
        /// <param name="varValueRange2">変数値の値範囲2。</param>
        /// <param name="varDecimalPlaces">
        /// 変数値の小数部桁数。負数ならば補正しない。
        /// </param>
        /// <param name="varIncrement">変数値のインクリメント幅。</param>
        /// <param name="editDecimalPlaces">
        /// 変数値の編集時の小数点以下桁数。 -1 ならば指定しない。
        /// </param>
        public DecimalVariablePropertySet(
            string name,
            string varName,
            decimal varValue,
            decimal varValueRange1,
            decimal varValueRange2,
            int varDecimalPlaces,
            decimal varIncrement,
            int editDecimalPlaces)
            :
            this(
                name,
                varName,
                new SwitchableDecimalProperty(
                    "variable.value",
                    varValue,
                    true,
                    varValueRange1,
                    varValueRange2,
                    varDecimalPlaces),
                varIncrement,
                editDecimalPlaces)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValueProperty">変数値プロパティ。</param>
        /// <param name="varIncrement">変数値のインクリメント幅。</param>
        /// <param name="editDecimalPlaces">
        /// 変数値の編集時の小数点以下桁数。 -1 ならば指定しない。
        /// </param>
        public DecimalVariablePropertySet(
            string name,
            string varName,
            SwitchableDecimalProperty varValueProperty,
            decimal varIncrement,
            int editDecimalPlaces)
            : base(name, varName, varValueProperty)
        {
            _increment = varIncrement;
            _editDecimalPlaces = editDecimalPlaces;
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public DecimalVariablePropertySet(DecimalVariablePropertySet src)
            : base(src)
        {
            _increment = src._increment;
            _editDecimalPlaces = src._editDecimalPlaces;
        }

        /// <summary>
        /// decimal 型変数値プロパティを取得する。
        /// </summary>
        public SwitchableDecimalProperty VarValueDecimalProperty
        {
            get { return (SwitchableDecimalProperty)VarValueProperty; }
        }

        /// <summary>
        /// 変数値を Decimal 型として取得または設定する。
        /// </summary>
        public new decimal VarValue
        {
            get { return VarValueDecimalProperty.OriginalValue; }
            set { VarValueDecimalProperty.OriginalValue = value; }
        }

        /// <summary>
        /// 変数値を Double 型として取得または設定する。
        /// </summary>
        public double VarDoubleValue
        {
            get { return VarValueDecimalProperty.OriginalDoubleValue; }
            set { VarValueDecimalProperty.OriginalDoubleValue = value; }
        }

        /// <summary>
        /// 変数値を Single 型として取得または設定する。
        /// </summary>
        public float VarSingleValue
        {
            get { return VarValueDecimalProperty.OriginalSingleValue; }
            set { VarValueDecimalProperty.OriginalSingleValue = value; }
        }

        /// <summary>
        /// 変数値を Int32 型として取得または設定する。
        /// </summary>
        public int VarInt32Value
        {
            get { return VarValueDecimalProperty.OriginalInt32Value; }
            set { VarValueDecimalProperty.OriginalInt32Value = value; }
        }

        #region VariablePropertySetBase メンバ

        protected override PropertyEditControlBase CreateVarValueControl(
            string name)
        {
            var ctrl = new SwitchableDecimalPropertyEditControl(
                name,
                _increment,
                null,
                _editDecimalPlaces,
                false,
                true);
            ctrl.LabelName = "数値";

            return ctrl;
        }

        #endregion

        #region PropertyBase メンバ

        public override PropertyBase Copy()
        {
            return new DecimalVariablePropertySet(this);
        }

        #endregion
    }
}
