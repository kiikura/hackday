﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;

namespace ruche.nive2.effects
{
    /// <summary>
    /// SwitchablePropertyBase&lt;T&gt; クラスの派生プロパティクラスを
    /// 編集するNiVE2プロパティコントロールの基底クラス。
    /// </summary>
    /// <remarks>
    /// 派生クラスでは少なくとも CreateProperty メソッドと
    /// UsePropertyType メソッドをオーバライドして実装する必要がある。
    /// これらのメソッドでは基底クラスの実装を呼び出してはならない。
    /// </remarks>
    public class SwitchablePropertyEditControlBase : PropertyEditControlBase
    {
        protected Panel panelClient;
        private CheckBox checkValid;

        /// <summary>
        /// 既定のプロパティ値。
        /// </summary>
        private SwitchablePropertyBase _defaultProp = null;

        /// <summary>
        /// ChangeProperty メソッドによるコントロール更新中フラグ。
        /// </summary>
        private bool _ctrlUpdating = true;

        /// <summary>
        /// 無効状態時に編集不可にするか否かのフラグ。
        /// </summary>
        private bool _alwaysEditable = false;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        protected SwitchablePropertyEditControlBase(string name)
        {
            this.PropertyName = name;
            this.LabelName = name;

            // 最初の ChangeProperty 呼び出しまで編集不可に
            _ctrlUpdating = true;

            InitializeComponent();
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        protected SwitchablePropertyEditControlBase(
            string name,
            bool switchable,
            bool alwaysEditable)
            : this(name)
        {
            this.Switchable = switchable;
            this.AlwaysEditable = alwaysEditable;
        }

        /// <summary>
        /// デザイナ用コンストラクタ。
        /// </summary>
        private SwitchablePropertyEditControlBase()
        {
            InitializeComponent();
        }

        /// <summary>
        /// プロパティ値の有効状態を切り替え可能とするか否かを取得または設定する。
        /// </summary>
        [Browsable(true)]
        [Description(
            "プロパティ値の有効状態を切り替え可能とするか否かを設定する。" +
            "チェックボックスの表示状態と連動する。")]
        [DefaultValue(true)]
        public bool Switchable
        {
            get { return checkValid.Visible; }
            set
            {
                checkValid.Visible = value;
                AdjustControls();
            }
        }

        /// <summary>
        /// プロパティ値の有効状態に関わらずコントロールによる編集を
        /// 可能とするか否かを取得または設定する。
        /// </summary>
        [Browsable(true)]
        [Description(
            "プロパティ値の有効状態に関わらずコントロールによる編集を" +
            "可能とするか否かを設定する。")]
        [DefaultValue(false)]
        public bool AlwaysEditable
        {
            get { return _alwaysEditable; }
            set
            {
                _alwaysEditable = value;
                panelClient.Enabled = _alwaysEditable ? true : PropertyValid;
            }
        }

        /// <summary>
        /// 既定のプロパティ値を取得する。
        /// </summary>
        public SwitchablePropertyBase DefaultProperty
        {
            get { return _defaultProp; }
        }

        /// <summary>
        /// プロパティ値の有効状態を表す値を取得または設定する。
        /// </summary>
        [Browsable(false)]
        public bool PropertyValid
        {
            get { return checkValid.Checked; }
            set { checkValid.Checked = value; }
        }

        /// <summary>
        /// クライアントパネルのサイズを取得する。
        /// </summary>
        [Browsable(false)]
        public Size ClientPanelSize
        {
            get { return panelClient.ClientSize; }
        }

        /// <summary>
        /// プロパティ値変更によるコントロール更新中か否かを取得する。
        /// </summary>
        [Browsable(false)]
        public bool ControlUpdating
        {
            get { return _ctrlUpdating; }
        }

        /// <summary>
        /// プロパティ値に関わるコントロール状態の変更を通知する。
        /// </summary>
        /// <remarks>
        /// ControlUpdating プロパティが false である場合、このメソッドは
        /// CreateProperty メソッドにより生成したプロパティを設定する。
        /// 
        /// ControlUpdating プロパティが true である場合、
        /// または CreateProperty メソッドが null 値を返した場合、
        /// このメソッドは何も行わない。
        /// </remarks>
        protected void NotifyPropertyChanged()
        {
            if (!this.ControlUpdating)
            {
                var prop = CreateProperty();
                if (prop != null)
                {
                    prop.Valid = PropertyValid;
                    SetProperty(prop);
                }
            }
        }

        /// <summary>
        /// 現在のコントロール状態を基に新しいプロパティを生成する。
        /// </summary>
        /// <returns>新しいプロパティ。生成できない状態ならば null 。</returns>
        /// <remarks>
        /// 派生先クラスで必ずオーバライドすること。
        /// 
        /// インスタンスの型は UseProperetyType メソッドが返す型であること。
        /// インスタンスを生成できない状態の場合は null 値を返すこと。
        /// </remarks>
        protected virtual SwitchablePropertyBase CreateProperty()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 指定されたプロパティ値を基にコントロール状態を更新する。
        /// </summary>
        /// <param name="property">ソースとなるプロパティ。</param>
        /// <remarks>
        /// チェックボックス状態は基底クラスで設定される。
        /// このメソッドでは主にクライアントパネル上に配置したコントロールの
        /// 状態変更を行う。
        /// 
        /// なお、このメソッドの呼び出し時は ControlUpdating プロパティが
        /// true であるため、 NotifyPropertyChanged メソッドを呼び出しても
        /// 新しいプロパティの設定は行われない。
        /// </remarks>
        protected virtual void UpdateControls(SwitchablePropertyBase property)
        {
        }

        /// <summary>
        /// Switchable プロパティ値の変更時に呼び出される。
        /// </summary>
        /// <param name="e">イベントパラメータ。</param>
        protected virtual void OnSwitchableChanged(EventArgs e)
        {
            if (this.SwitchableChanged != null)
            {
                this.SwitchableChanged(this, e);
            }
        }

        /// <summary>
        /// PropertyValid プロパティ値の変更時に呼び出される。
        /// </summary>
        /// <param name="e">イベントパラメータ。</param>
        protected virtual void OnPropertyValidChanged(EventArgs e)
        {
            if (this.PropertyValidChanged != null)
            {
                this.PropertyValidChanged(this, e);
            }
        }

        /// <summary>
        /// クライアントパネルのサイズ変更時に呼び出される。
        /// </summary>
        /// <param name="e">イベントパラメータ。</param>
        protected virtual void OnClientPanelSizeChanged(EventArgs e)
        {
            if (this.ClientPanelSizeChanged != null)
            {
                this.ClientPanelSizeChanged(this, e);
            }
        }

        /// <summary>
        /// コントロール配置を更新する。
        /// </summary>
        private void AdjustControls()
        {
            checkValid.Left =
                this.SpliterDistance + Util.PropertyEditControlLeftDistance;

            Rectangle panelBounds = panelClient.Bounds;

            Rectangle bounds = panelBounds;
            bounds.X = this.Switchable ? checkValid.Right : checkValid.Left;
            bounds.Width =
                this.Width -
                this.SpliterDistance -
                Util.PropertyEditControlHiddenWidth;
            if (this.Switchable)
            {
                bounds.Width -= checkValid.Width;
            }

            if (bounds != panelBounds)
            {
                panelClient.Bounds = bounds;
            }
        }

        /// <summary>
        /// PropertyEditControlBase.SetProperty メソッドを隠蔽する。
        /// </summary>
        /// <param name="property">設定するプロパティ。</param>
        private new void SetProperty(PropertyBase property)
        {
            base.SetProperty(property);
        }

        /// <summary>
        /// Switchable プロパティ値の変更時に呼び出されるイベント。
        /// </summary>
        public event EventHandler SwitchableChanged;

        /// <summary>
        /// PropertyValid プロパティ値の変更時に呼び出されるイベント。
        /// </summary>
        public event EventHandler PropertyValidChanged;

        /// <summary>
        /// クライアントパネルのサイズ変更時に呼び出されるイベント。
        /// </summary>
        public event EventHandler ClientPanelSizeChanged;

        #region PropertyEditControlBase メンバ

        public override sealed int SpliterDistance
        {
            get { return base.SpliterDistance; }
            set
            {
                base.SpliterDistance = value;
                AdjustControls();
            }
        }

        public override Type UseProperetyType()
        {
            throw new NotImplementedException();
        }

        public override sealed void ChangeProperty(PropertyBase property)
        {
            var prop = property as SwitchablePropertyBase;
            if (prop != null)
            {
                _defaultProp = (SwitchablePropertyBase)prop.Copy();

                try
                {
                    _ctrlUpdating = true;

                    PropertyValid = prop.Valid;
                    UpdateControls(prop);
                }
                finally
                {
                    _ctrlUpdating = false;
                }
            }

            base.ChangeProperty(property);
        }

        public override void SetDefaultProperty(PropertyBase property)
        {
            var prop = property as SwitchablePropertyBase;
            if (prop != null)
            {
                _defaultProp = (SwitchablePropertyBase)prop.Copy();
            }

            base.SetDefaultProperty(property);
        }

        #endregion

        private void InitializeComponent()
        {
            this.checkValid = new System.Windows.Forms.CheckBox();
            this.panelClient = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // checkValid
            // 
            this.checkValid.AutoSize = true;
            this.checkValid.Checked = true;
            this.checkValid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkValid.Location = new System.Drawing.Point(114, 3);
            this.checkValid.Name = "checkValid";
            this.checkValid.Size = new System.Drawing.Size(15, 14);
            this.checkValid.TabIndex = 2;
            this.checkValid.UseVisualStyleBackColor = true;
            this.checkValid.VisibleChanged += new System.EventHandler(this.checkValid_VisibleChanged);
            this.checkValid.CheckedChanged += new System.EventHandler(this.checkValid_CheckedChanged);
            // 
            // panelClient
            // 
            this.panelClient.Location = new System.Drawing.Point(135, 0);
            this.panelClient.Name = "panelClient";
            this.panelClient.Size = new System.Drawing.Size(86, 18);
            this.panelClient.TabIndex = 3;
            this.panelClient.SizeChanged += new System.EventHandler(this.panelClient_SizeChanged);
            // 
            // SwitchablePropertyEditControlBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.panelClient);
            this.Controls.Add(this.checkValid);
            this.Name = "SwitchablePropertyEditControlBase";
            this.Load += new System.EventHandler(this.SwitchablePropertyEditControlBase_Load);
            this.SizeChanged += new System.EventHandler(this.SwitchablePropertyEditControlBase_SizeChanged);
            this.Controls.SetChildIndex(this.checkValid, 0);
            this.Controls.SetChildIndex(this.panelClient, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void clientCtrlInfo_ValueChanged(object sender, EventArgs e)
        {
            NotifyPropertyChanged();
        }

        private void SwitchablePropertyEditControlBase_Load(
            object sender,
            EventArgs e)
        {
            AdjustControls();
        }

        private void SwitchablePropertyEditControlBase_SizeChanged(
            object sender,
            EventArgs e)
        {
            AdjustControls();
        }

        private void checkValid_CheckedChanged(object sender, EventArgs e)
        {
            if (!AlwaysEditable)
            {
                panelClient.Enabled = checkValid.Checked;
            }
            NotifyPropertyChanged();
            OnPropertyValidChanged(e);
        }

        private void checkValid_VisibleChanged(object sender, EventArgs e)
        {
            OnSwitchableChanged(e);
        }

        private void panelClient_SizeChanged(object sender, EventArgs e)
        {
            OnClientPanelSizeChanged(e);
        }
    }
}
