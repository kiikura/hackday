﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ruche.nive2.effects
{
    /// <summary>
    /// ドラッグによる増減および直接入力が可能な数値入力ボックスクラス。
    /// </summary>
    [Description(
        "ドラッグによる増減および直接入力が可能な数値入力ボックスです。")]
    [DefaultEvent("ValueChanged")]
    public partial class NumericDragBox : UserControl
    {
        /// <summary>
        /// 小数点以下桁数の最大値。
        /// </summary>
        [Browsable(false)]
        public const int MaxDecimalPlaces = 24;

        /// <summary>
        /// 値。
        /// </summary>
        private decimal _value = 0;

        /// <summary>
        /// 最小値。
        /// </summary>
        private decimal _minimum = -99999999;

        /// <summary>
        /// 最大値。
        /// </summary>
        private decimal _maximum = 99999999;

        /// <summary>
        /// インクリメント幅。
        /// </summary>
        private decimal _increment = 1;

        /// <summary>
        /// 小数点以下桁数。
        /// </summary>
        private int _decimalPlaces = -1;

        /// <summary>
        /// 入力ボックス表示時に拡張するコントロール幅。
        /// </summary>
        private int _expandWidth = 0;

        /// <summary>
        /// ドラッグラベルの背景色。
        /// </summary>
        private Color _labelBackColor = SystemColors.Control;

        /// <summary>
        /// ドラッグ中であるか否か。
        /// </summary>
        private bool _dragging = false;

        /// <summary>
        /// マウスカーソルが左ボタン投下後に動いたか否か。
        /// </summary>
        private bool _dragged = false;

        /// <summary>
        /// マウスの左ボタン投下時のカーソルX位置。
        /// </summary>
        private int _baseX = 0;

        /// <summary>
        /// マウスの左ボタン投下後の直前のカーソルX位置。
        /// </summary>
        private int _prevX = 0;

        /// <summary>
        /// マウスの左ボタン投下時の数値。
        /// </summary>
        private decimal _baseValue = 0;

        /// <summary>
        /// 編集開始直前のコントロール幅。
        /// </summary>
        private int _originalWidth = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public NumericDragBox()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 値を取得または設定する。
        /// </summary>
        [Description("このコントロールの現在の値です。")]
        [DefaultValue(typeof(decimal), "0")]
        public decimal Value
        {
            get { return _value; }
            set
            {
                decimal v = Math.Min(Math.Max(value, Minimum), Maximum);
                if (DecimalPlaces >= 0)
                {
                    // 多い桁を削る
                    v = decimal.Round(v, DecimalPlaces);

                    // 足りない桁を付け足す
                    string valStr = v.ToString();
                    int digits = valStr.IndexOf('.');
                    digits = (digits < 0) ? 0 : (valStr.Length - digits - 1);
                    for (; digits < DecimalPlaces; ++digits)
                    {
                        v *= 1.0m;
                    }
                }

                string vs = v.ToString();
                if (_value.ToString() != vs)
                {
                    this.SuspendLayout();
                    try
                    {
                        // 値変更
                        _value = v;
                        labelBox.Text = vs;
                        if (IsEditing)
                        {
                            textBox.Text = vs;
                        }

                        // コントロールサイズ更新
                        FixControlSizes();
                    }
                    finally
                    {
                        this.ResumeLayout(true);
                    }

                    // イベント発生
                    OnValueChanged(EventArgs.Empty);
                }
            }
        }

        /// <summary>
        /// 設定可能な最小値を取得または設定する。
        /// </summary>
        [Description("このコントロールに設定可能な値の最小値です。")]
        [DefaultValue(typeof(decimal), "-99999999")]
        public decimal Minimum
        {
            get { return _minimum; }
            set
            {
                if (_minimum != value)
                {
                    _minimum = value;
                    if (value > _maximum)
                    {
                        _maximum = value;
                    }

                    // 値補正
                    Value = _value;
                }
            }
        }

        /// <summary>
        /// 設定可能な最大値を取得または設定する。
        /// </summary>
        [Description("このコントロールに設定可能な値の最大値です。")]
        [DefaultValue(typeof(decimal), "99999999")]
        public decimal Maximum
        {
            get { return _maximum; }
            set
            {
                if (_maximum != value)
                {
                    _maximum = value;
                    if (value < _minimum)
                    {
                        _minimum = value;
                    }

                    // 値補正
                    Value = _value;
                }
            }
        }

        /// <summary>
        /// ドラッグ時のインクリメント幅を取得または設定する。
        /// </summary>
        [Description("コントロールをドラッグした時の値のインクリメント幅です。")]
        [DefaultValue(typeof(decimal), "1")]
        public decimal Increment
        {
            get { return _increment; }
            set { _increment = value; }
        }

        /// <summary>
        /// 小数点以下の桁数を取得または設定する。 -1 ならば制御しない。
        /// </summary>
        [Description("小数点以下の桁数です。 -1 ならば制御しません。")]
        [DefaultValue(-1)]
        public int DecimalPlaces
        {
            get { return _decimalPlaces; }
            set
            {
                int place = Math.Min(Math.Max(value, -1), MaxDecimalPlaces);
                if (_decimalPlaces != place)
                {
                    _decimalPlaces = place;

                    // 値補正
                    Value = _value;
                }
            }
        }

        /// <summary>
        /// 入力ボックスの表示時に拡張するコントロール幅を取得または設定する。
        /// </summary>
        [Description("入力ボックスの表示時に拡張するコントロール幅です。")]
        [DefaultValue(0)]
        public int ExpandWidth
        {
            get { return _expandWidth; }
            set { _expandWidth = Math.Max(value, 0); }
        }

        /// <summary>
        /// コントロールを自動リサイズするか否かを取得または設定する。
        /// </summary>
        [DefaultValue(true)]
        public override bool AutoSize
        {
            get { return base.AutoSize; }
            set
            {
                labelBox.AutoSize = value;
                base.AutoSize = value;

                FixControlSizes();
            }
        }

        /// <summary>
        /// コントロールの境界線種別を取得または設定する。
        /// </summary>
        [Description("コントロールの境界線種別です。")]
        [Browsable(true)]
        [DefaultValue(BorderStyle.Fixed3D)]
        public new BorderStyle BorderStyle
        {
            get { return base.BorderStyle; }
            set { base.BorderStyle = value; }
        }

        /// <summary>
        /// このコントロールの値を表すテキストを取得または設定する。
        /// </summary>
        [Browsable(false)]
        public override string Text
        {
            get { return Value.ToString(); }
            set
            {
                decimal v;
                if (decimal.TryParse(value, out v))
                {
                    Value = v;
                }
            }
        }

        /// <summary>
        /// テキストの水平方向の配置を取得または設定する。
        /// </summary>
        [Description("テキストの水平方向の配置です。")]
        [DefaultValue(typeof(HorizontalAlignment), "Left")]
        public HorizontalAlignment TextAlign
        {
            get { return textBox.TextAlign; }
            set
            {
                textBox.TextAlign = value;

                switch (value)
                {
                case HorizontalAlignment.Left:
                    labelBox.TextAlign = ContentAlignment.MiddleLeft;
                    break;

                case HorizontalAlignment.Center:
                    labelBox.TextAlign = ContentAlignment.MiddleCenter;
                    break;

                case HorizontalAlignment.Right:
                    labelBox.TextAlign = ContentAlignment.MiddleRight;
                    break;
                }
            }
        }

        /// <summary>
        /// ドラッグラベル上でのカーソル種別を取得または設定する。
        /// </summary>
        [Description("ドラッグラベル上でのカーソル種別です。")]
        [DefaultValue(typeof(Cursor), "SizeWE")]
        public Cursor LabelCursor
        {
            get { return labelBox.Cursor; }
            set { labelBox.Cursor = value; }
        }

        /// <summary>
        /// ドラッグラベルの背景色を取得または設定する。
        /// </summary>
        [Description("ドラッグラベルの背景色です。")]
        [DefaultValue(typeof(Color), "Control")]
        public Color LabelBackColor
        {
            get { return _labelBackColor; }
            set
            {
                _labelBackColor = value;
                if (!IsEditing)
                {
                    base.BackColor = value;
                }
            }
        }

        /// <summary>
        /// ドラッグラベルの前景色を取得または設定する。
        /// </summary>
        [Description("ドラッグラベルの前景色です。")]
        [DefaultValue(typeof(Color), "ControlText")]
        public Color LabelForeColor
        {
            get { return labelBox.ForeColor; }
            set { labelBox.ForeColor = value; }
        }

        /// <summary>
        /// 入力ボックス上でのカーソル種別を取得または設定する。
        /// </summary>
        [Description("入力ボックス上でのカーソル種別です。")]
        [DefaultValue(typeof(Cursor), "IBeam")]
        public Cursor EditCursor
        {
            get { return textBox.Cursor; }
            set { textBox.Cursor = value; }
        }

        /// <summary>
        /// 入力ボックスの背景色を取得または設定する。
        /// </summary>
        [Description("入力ボックスの背景色です。")]
        [DefaultValue(typeof(Color), "Window")]
        public Color EditBackColor
        {
            get { return textBox.BackColor; }
            set
            {
                textBox.BackColor = value;
                if (IsEditing)
                {
                    base.BackColor = value;
                }
            }
        }

        /// <summary>
        /// 入力ボックスの前景色を取得または設定する。
        /// </summary>
        [Description("入力ボックスの前景色です。")]
        [DefaultValue(typeof(Color), "WindowText")]
        public Color EditForeColor
        {
            get { return textBox.ForeColor; }
            set { textBox.ForeColor = value; }
        }

        /// <summary>
        /// ドラッグ中であるか否かを取得する。
        /// </summary>
        [Browsable(false)]
        public bool IsDragging
        {
            get { return _dragging; }
        }

        /// <summary>
        /// 入力ボックス表示中であるか否かを取得する。
        /// </summary>
        [Browsable(false)]
        public bool IsEditing
        {
            get { return textBox.Visible; }
        }

        /// <summary>
        /// Value プロパティの値が変更されたときに発生するイベント。
        /// </summary>
        [Description("Value プロパティの値が変更されたときに発生します。")]
        public event EventHandler ValueChanged;

        /// <summary>
        /// Value プロパティの値が変更されたときに呼び出される。
        /// </summary>
        /// <param name="e">空のイベントデータ。</param>
        protected virtual void OnValueChanged(EventArgs e)
        {
            if (ValueChanged != null)
            {
                ValueChanged(this, e);
            }
        }

        /// <summary>
        /// 入力ボックスによる編集を開始する。
        /// </summary>
        public void BeginEdit()
        {
            if (!IsEditing)
            {
                CancelDrag();
                CancelEdit();

                this.SuspendLayout();
                try
                {
                    // 編集モード開始
                    textBox.Text = labelBox.Text;
                    labelBox.Visible = false;
                    textBox.Visible = true;
                    base.BackColor = EditBackColor;

                    // コントロール幅拡張
                    _originalWidth = this.Width;
                    this.Width += ExpandWidth;

                    // 全選択してフォーカス
                    textBox.SelectAll();
                    textBox.Focus();

                    FixControlSizes();
                }
                finally
                {
                    this.ResumeLayout(true);
                }
            }
        }

        /// <summary>
        /// 入力ボックスによる編集を完了させる。
        /// </summary>
        public void EndEdit()
        {
            if (IsEditing)
            {
                // 値更新
                this.Text = textBox.Text;

                CancelEdit();
            }
        }

        /// <summary>
        /// 入力ボックスによる編集をキャンセルする。
        /// </summary>
        public void CancelEdit()
        {
            if (IsEditing)
            {
                this.SuspendLayout();
                try
                {
                    // コントロール幅を戻す
                    this.Width = _originalWidth;

                    // 編集モード終了
                    textBox.Visible = false;
                    labelBox.Visible = true;
                    labelBox.Focus();
                    base.BackColor = LabelBackColor;

                    FixControlSizes();
                }
                finally
                {
                    this.ResumeLayout(true);
                }
            }
        }

        /// <summary>
        /// ドラッグを開始する。
        /// </summary>
        /// <param name="x">開始X位置。</param>
        private void BeginDrag(int x)
        {
            CancelEdit();
            CancelDrag();

            _dragging = true;
            _dragged = false;
            _baseX = x;
            _prevX = x;
            _baseValue = Value;
        }

        /// <summary>
        /// ドラッグを更新する。
        /// </summary>
        /// <param name="x">更新X位置。</param>
        private void UpdateDrag(int x)
        {
            if (IsDragging && x != _prevX)
            {
                _prevX = x;
                _dragged = true;
                Value = _baseValue + (x - _baseX) * Increment;
            }
        }

        /// <summary>
        /// ドラッグを完了させる。
        /// </summary>
        /// <returns>
        /// 一度でも更新されたならば true 。そうでなければ false 。
        /// </returns>
        private bool EndDrag()
        {
            if (IsDragging)
            {
                _dragging = false;
            }
            else
            {
                _dragged = false;
            }

            return _dragged;
        }

        /// <summary>
        /// ドラッグをキャンセルする。
        /// </summary>
        private void CancelDrag()
        {
            if (IsDragging)
            {
                _dragging = false;
                Value = _baseValue;
            }
        }

        /// <summary>
        /// コントロールのサイズを補正する。
        /// </summary>
        private void FixControlSizes()
        {
            if (IsEditing)
            {
                Size s = ClientSize;
                Padding pad = Padding;
                s.Width -= pad.Left + pad.Right;
                s.Height -= pad.Top + pad.Bottom;

                Rectangle textBounds = textBox.Bounds;
                Rectangle bounds = textBounds;
                bounds.X = pad.Left;
                bounds.Y = pad.Top + (s.Height - bounds.Height) / 2;
                bounds.Width = s.Width;
                if (bounds != textBounds)
                {
                    textBox.Bounds = bounds;
                }
            }
            else
            {
                if (AutoSize)
                {
                    Size s = labelBox.Size;
                    Padding pad = Padding;
                    s.Width += pad.Left + pad.Right;
                    s.Height += pad.Top + pad.Bottom;

                    this.ClientSize = s;
                }
            }
        }

        private void NumericDragBox_Load(object sender, EventArgs e)
        {
            base.BackColor = LabelBackColor;

            FixControlSizes();
        }

        private void NumericDragBox_SizeChanged(object sender, EventArgs e)
        {
            FixControlSizes();
        }

        private void labelBox_MouseDown(object sender, MouseEventArgs e)
        {
            labelBox.Focus();

            switch (e.Button)
            {
            case MouseButtons.Left:
                if (!IsEditing && !IsDragging)
                {
                    // ドラッグ開始
                    BeginDrag(e.X);
                }
                break;

            case MouseButtons.Right:
                if (IsDragging)
                {
                    // ドラッグキャンセル
                    CancelDrag();
                }
                break;
            }
        }

        private void labelBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsDragging)
            {
                // ドラッグ更新
                UpdateDrag(e.X);
            }
        }

        private void labelBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsDragging && e.Button == MouseButtons.Left)
            {
                // ドラッグ完了
                if (!EndDrag())
                {
                    // ドラッグしておらず範囲内ならば編集開始
                    if (
                        e.X >= 0 && e.X < labelBox.Width &&
                        e.Y >= 0 && e.Y < labelBox.Height)
                    {
                        BeginEdit();
                    }
                }
            }
        }

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (IsEditing)
            {
                switch (e.KeyCode)
                {
                case Keys.Enter:
                    // Enterキー投下で編集完了
                    EndEdit();
                    break;

                case Keys.Escape:
                    // Escキー投下で編集キャンセル
                    CancelEdit();
                    break;
                }
            }
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 編集終了済みならキー入力を受け付けない
            if (!IsEditing)
            {
                e.Handled = true;
            }
        }

        private void textBox_Leave(object sender, EventArgs e)
        {
            if (IsEditing)
            {
                // フォーカスが離れたら編集完了
                EndEdit();
            }
        }

        #region 非使用の UserControl プロパティ

        [Browsable(false)]
        [DefaultValue(false)]
        public override bool AutoScroll
        {
            get { return false; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(typeof(Size), "0,0")]
        public new Size AutoScrollMargin
        {
            get { return base.AutoScrollMargin; }
            set { base.AutoScrollMargin = value; }
        }

        [Browsable(false)]
        [DefaultValue(typeof(Size), "0,0")]
        public new Size AutoScrollMinSize
        {
            get { return base.AutoScrollMinSize; }
            set { base.AutoScrollMinSize = value; }
        }

        [Browsable(false)]
        [DefaultValue(typeof(AutoSizeMode), "GrowAndShrink")]
        public new AutoSizeMode AutoSizeMode
        {
            get { return AutoSizeMode.GrowAndShrink; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(typeof(Color), "Control")]
        public override Color BackColor
        {
            get { return base.BackColor; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(null)]
        public override Image BackgroundImage
        {
            get { return null; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(typeof(ImageLayout), "None")]
        public override ImageLayout BackgroundImageLayout
        {
            get { return ImageLayout.None; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(typeof(Cursor), "Default")]
        public override Cursor Cursor
        {
            get { return Cursors.Default; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(typeof(Cursor), "ControlText")]
        public override Color ForeColor
        {
            get { return base.ForeColor; }
            set { base.ForeColor = value; }
        }

        #endregion
    }
}
