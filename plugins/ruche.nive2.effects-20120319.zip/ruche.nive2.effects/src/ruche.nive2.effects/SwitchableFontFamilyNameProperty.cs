﻿using System;
using System.Drawing;

namespace ruche.nive2.effects
{
    /// <summary>
    /// フォントファミリ名とその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class SwitchableFontFamilyNameProperty : SwitchableStringProperty
    {
        /// <summary>
        /// フォントファミリ名の検証クラス。
        /// </summary>
        [Serializable]
        private sealed class Validater : IValidater<string>
        {
            /// <summary>
            /// コンストラクタ。
            /// </summary>
            public Validater()
            {
            }

            #region IValidater<string> メンバ

            public bool Validate(ref string value)
            {
                try
                {
                    using (var family = new FontFamily(value))
                    {
                        value = family.Name;
                    }
                }
                catch
                {
                    return false;
                }
                return true;
            }

            #endregion
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableFontFamilyNameProperty(
            string name,
            string value,
            bool valid)
            :
            base(
                name,
                value,
                valid,
                FontFamily.GenericSansSerif.Name,
                new Validater())
        {
        }

        /// <summary>
        /// フォントファミリを作成する。
        /// </summary>
        /// <returns>フォントファミリ。</returns>
        public FontFamily CreateFontFamily()
        {
            return new FontFamily(OriginalValue);
        }
    }
}
