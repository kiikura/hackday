﻿namespace ruche.nive2.effects
{
    partial class NumericDragBox
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナで生成されたコード

        /// <summary> 
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.labelBox = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox.Location = new System.Drawing.Point(0, 0);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(146, 12);
            this.textBox.TabIndex = 1;
            this.textBox.Text = "0";
            this.textBox.Visible = false;
            this.textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            this.textBox.Leave += new System.EventHandler(this.textBox_Leave);
            this.textBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // labelBox
            // 
            this.labelBox.AutoSize = true;
            this.labelBox.BackColor = System.Drawing.Color.Transparent;
            this.labelBox.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.labelBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelBox.Location = new System.Drawing.Point(0, 0);
            this.labelBox.Name = "labelBox";
            this.labelBox.Size = new System.Drawing.Size(11, 12);
            this.labelBox.TabIndex = 0;
            this.labelBox.Text = "0";
            this.labelBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.labelBox_MouseMove);
            this.labelBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.labelBox_MouseDown);
            this.labelBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.labelBox_MouseUp);
            // 
            // NumericDragBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.labelBox);
            this.Controls.Add(this.textBox);
            this.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.Name = "NumericDragBox";
            this.Size = new System.Drawing.Size(149, 15);
            this.Load += new System.EventHandler(this.NumericDragBox_Load);
            this.SizeChanged += new System.EventHandler(this.NumericDragBox_SizeChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Label labelBox;
    }
}
