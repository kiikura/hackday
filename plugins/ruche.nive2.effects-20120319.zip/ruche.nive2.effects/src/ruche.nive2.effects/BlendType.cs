﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// イメージのブレンド方法を表す列挙。
    /// </summary>
    public enum BlendType
    {
        /// <summary>
        /// 通常。
        /// </summary>
        [Description("通常")]
        [EnumDefaultValue]
        Normal = 0,

        /// <summary>
        /// 置換。
        /// </summary>
        [Description("置換")]
        Copy,

        /// <summary>
        /// 加算。
        /// </summary>
        [Description("加算")]
        Add,

        /// <summary>
        /// 減算。
        /// </summary>
        [Description("減算")]
        Subtract,

        /// <summary>
        /// 乗算。
        /// </summary>
        [Description("乗算")]
        Multiply,

        /// <summary>
        /// スクリーン。
        /// </summary>
        [Description("スクリーン")]
        Screen,

        /// <summary>
        /// オーバーレイ。
        /// </summary>
        [Description("オーバーレイ")]
        Overlay,

        /// <summary>
        /// ハードライト。
        /// </summary>
        [Description("ハードライト")]
        HardLight,

        /// <summary>
        /// ソフトライト。
        /// </summary>
        [Description("ソフトライト")]
        SoftLight,

        /// <summary>
        /// ビビッドライト。
        /// </summary>
        [Description("ビビッドライト")]
        VividLight,

        /// <summary>
        /// リニアライト。
        /// </summary>
        [Description("リニアライト")]
        LinearLight,

        /// <summary>
        /// ピンライト。
        /// </summary>
        [Description("ピンライト")]
        PinLight,

        /// <summary>
        /// 覆い焼き(カラー)。
        /// </summary>
        [Description("覆い焼き(カラー)")]
        ColorDodge,

        /// <summary>
        /// 覆い焼き(リニア)。
        /// </summary>
        [Description("覆い焼き(リニア)")]
        LinearDodge,

        /// <summary>
        /// 焼き込み(カラー)。
        /// </summary>
        [Description("焼き込み(カラー)")]
        ColorBurn,

        /// <summary>
        /// 焼き込み(リニア)。
        /// </summary>
        [Description("焼き込み(リニア)")]
        LinearBurn,

        /// <summary>
        /// 比較(暗)。
        /// </summary>
        [Description("比較(暗)")]
        Darken,

        /// <summary>
        /// 比較(明)。
        /// </summary>
        [Description("比較(明)")]
        Lighten,

        /// <summary>
        /// 差の絶対値。
        /// </summary>
        [Description("差の絶対値")]
        Difference,

        /// <summary>
        /// 除外。
        /// </summary>
        [Description("除外")]
        Exclusion,

        /// <summary>
        /// 色相。
        /// </summary>
        [Description("色相")]
        Hue,

        /// <summary>
        /// 彩度。
        /// </summary>
        [Description("彩度")]
        Saturation,

        /// <summary>
        /// カラー。
        /// </summary>
        [Description("カラー")]
        Color,

        /// <summary>
        /// 明度。
        /// </summary>
        [Description("明度")]
        Brightness,
    }
}
