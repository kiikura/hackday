﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 文字列値を編集するダイアログクラス。
    /// </summary>
    /// <remarks>
    /// このクラスの Text プロパティはダイアログのキャプション文字列を表す。
    /// 編集対象の文字列は Value プロパティで取得または設定する。
    /// </remarks>
    internal partial class TextEditWindow : Form
    {
        /// <summary>
        /// ダイアログサイズ情報の保存キー名。
        /// </summary>
        private static readonly string SizeKeyName =
            typeof(TextEditWindow).Name + ":Size";

        /// <summary>
        /// 入力欄フォント情報の保存キー名。
        /// </summary>
        private static readonly string EditFontKeyName =
            typeof(TextEditWindow).Name + ":EditFont";

        /// <summary>
        /// 右端折り返し情報の保存キー名。
        /// </summary>
        private static readonly string WordWrapKeyName =
            typeof(TextEditWindow).Name + ":WordWrap";

        /// <summary>
        /// 文字列値。
        /// </summary>
        private string _value = string.Empty;

        /// <summary>
        /// フォント。
        /// </summary>
        private Font _font = null;

        /// <summary>
        /// Ctrl投下時に押されたキー。
        /// </summary>
        private Keys _ctrlKey = Keys.None;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TextEditWindow()
        {
            InitializeComponent();

            // ダイアログ破棄時のイベントハンドラ設定
            this.Disposed += new EventHandler(TextEditWindow_Disposed);

            // 設定読み込み
            if (LibraryConfig.Datas.Load())
            {
                if (
                    LibraryConfig.Datas.ContainsKey(SizeKeyName) &&
                    LibraryConfig.Datas[SizeKeyName] is Size)
                {
                    this.Size = (Size)LibraryConfig.Datas[SizeKeyName];
                }
                if (LibraryConfig.Datas.ContainsKey(EditFontKeyName))
                {
                    SetEditFont(
                        LibraryConfig.Datas[EditFontKeyName] as Font);
                }
                if (LibraryConfig.Datas.ContainsKey(WordWrapKeyName))
                {
                    checkWrap.Checked =
                        (bool)LibraryConfig.Datas[WordWrapKeyName];
                }
            }
        }

        /// <summary>
        /// 文字列値を取得または設定する。
        /// </summary>
        public string Value
        {
            get { return _value; }
            set { _value = value ?? string.Empty; }
        }

        /// <summary>
        /// 入力可能な最大文字数を取得または設定する。
        /// </summary>
        public int MaxLength
        {
            get { return textValue.MaxLength; }
            set { textValue.MaxLength = value; }
        }

        /// <summary>
        /// 入力欄のフォントを設定する。
        /// </summary>
        /// <param name="font">フォント。</param>
        public void SetEditFont(Font font)
        {
            if (font != _font)
            {
                // 既存フォントの破棄
                if (_font != null)
                {
                    if (textValue != null)
                    {
                        textValue.Font = null;
                    }
                    _font.Dispose();
                    _font = null;
                }

                // 新しいフォントの設定
                if (font != null)
                {
                    _font = (Font)font.Clone();
                    if (textValue != null)
                    {
                        textValue.Font = _font;
                    }

                    // 現在のフォントを保存
                    LibraryConfig.Datas[EditFontKeyName] = _font;
                    LibraryConfig.Datas.Save();
                }
            }
        }

        private void TextEditWindow_Load(object sender, EventArgs e)
        {
            textValue.Text = this.Value;
        }

        private void TextEditWindow_SizeChanged(object sender, EventArgs e)
        {
            // 現在のサイズを保存
            LibraryConfig.Datas[SizeKeyName] = this.Size;
            LibraryConfig.Datas.Save();
        }

        private void TextEditWindow_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.DialogResult == DialogResult.OK)
            {
                this.Value = textValue.Text;
            }
        }

        private void TextEditWindow_Disposed(object sender, EventArgs e)
        {
            SetEditFont(null);
        }

        private void buttonFont_Click(object sender, EventArgs e)
        {
            using (Font fontTemp = (Font)(_font ?? DefaultFont).Clone())
            using (FontDialog dialog = new FontDialog())
            {
                dialog.Font = fontTemp;
                dialog.AllowVerticalFonts = false;
                dialog.FontMustExist = true;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    SetEditFont(dialog.Font);
                }
            }
        }

        private void textValue_KeyDown(object sender, KeyEventArgs e)
        {
            // Ctrl+？
            _ctrlKey = Keys.None;
            if (e.Modifiers == Keys.Control)
            {
                _ctrlKey = e.KeyCode;
            }
        }

        private void textValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (_ctrlKey)
            {
            case Keys.Enter:
                // Ctrl+EnterでOK投下
                this.DialogResult = DialogResult.OK;
                e.Handled = true;
                break;

            case Keys.A:
                // Ctrl+Aで全選択
                textValue.SelectAll();
                e.Handled = true;
                break;
            }
        }

        private void checkWrap_CheckedChanged(object sender, EventArgs e)
        {
            // 折り返し設定
            if (checkWrap.Checked)
            {
                textValue.WordWrap = true;
                textValue.ScrollBars = ScrollBars.Vertical;
            }
            else
            {
                textValue.WordWrap = false;
                textValue.ScrollBars = ScrollBars.Both;
            }

            // 現在のチェック状態を保存
            LibraryConfig.Datas[WordWrapKeyName] = checkWrap.Checked;
            LibraryConfig.Datas.Save();
        }
    }
}
