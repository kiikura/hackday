﻿using System;
using System.Globalization;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 時刻を格納するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class TimeProperty : PropertyBase
    {
        /// <summary>
        /// 時刻値。
        /// </summary>
        private double _time = 0.0;

        /// <summary>
        /// 時刻の最大値。
        /// </summary>
        private double _maxTime = double.MaxValue;

        /// <summary>
        /// 時刻の最小値。
        /// </summary>
        private double _minTime = double.MinValue;

        /// <summary>
        /// "H:M:S:F" 形式の時刻文字列値とフレームレートから時刻値を作成する。
        /// </summary>
        /// <param name="value">"H:M:S:F" 形式の時刻文字列値。</param>
        /// <param name="frameRate">フレームレート。</param>
        /// <returns>時刻値。</returns>
        public static double ParseToTime(string value, double frameRate)
        {
            if (frameRate <= 0.0)
            {
                throw new ArgumentOutOfRangeException(
                    "frameRate", frameRate, "frameRate が 0.0 以下です。");
            }

            // null もしくは空文字列ならば 0 を返す
            if (value == null) { return 0.0; }
            value = value.Trim();
            if (value == "" || value == "-") { return 0.0; }

            // 先頭に "-" が付いている場合は負数と判断して取り除く
            bool minus = value.StartsWith("-");
            if (minus) { value = value.Substring(1); }

            // 各時刻値取得
            int[] tvals = { 0, 0, 0, 0 }; // frame, second, minute, hour
            string[] values = value.Split(':');
            Array.Reverse(values);
            int count = Math.Min(tvals.Length, values.Length);
            for (int i = 0; i < count; ++i)
            {
                try
                {
                    tvals[i] = int.Parse(
                        values[i],
                        NumberStyles.AllowLeadingWhite |
                        NumberStyles.AllowTrailingWhite);
                }
                catch
                {
                    tvals[i] = 0;
                }
            }

            // 時刻値算出
            double time = (
                tvals[3] * 3600.0 +
                tvals[2] * 60.0 +
                tvals[1] +
                tvals[0] / frameRate);
            if (minus) { time = -time; }

            return time;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="time">既定の時刻値。</param>
        /// <param name="maxTime">時刻の最大値。</param>
        /// <param name="minTime">時刻の最小値。</param>
        public TimeProperty(
            string name, double time, double maxTime, double minTime)
            : base(name)
        {
            _maxTime = maxTime;
            _minTime = Math.Min(minTime, maxTime);
            Time = time;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="time">既定の時刻値。</param>
        public TimeProperty(string name, double time)
            : this(name, time, double.MaxValue, double.MinValue)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public TimeProperty(TimeProperty src)
            : this(src.PropertyName, src.Time, src.Max, src.Min)
        {
        }

        /// <summary>
        /// 時刻値を最小値および最大値で補正する。
        /// </summary>
        /// <param name="time">時刻値。</param>
        /// <returns>補正された時刻値。</returns>
        private double FixTime(double time)
        {
            return Math.Min(Math.Max(time, _minTime), _maxTime);
        }

        /// <summary>
        /// 時刻値を取得または設定する。
        /// </summary>
        public double Time
        {
            get { return _time; }
            set { _time = FixTime(value); }
        }

        /// <summary>
        /// 時刻の最大値を取得または設定する。
        /// </summary>
        public double Max
        {
            get { return _maxTime; }
            set
            {
                // 最大値設定
                _maxTime = value;
                if (_minTime > value)
                {
                    _minTime = value;
                }

                // 値を補正
                Time = FixTime(Time);
            }
        }

        /// <summary>
        /// 時刻の最小値を取得または設定する。
        /// </summary>
        public double Min
        {
            get { return _minTime; }
            set
            {
                // 最小値設定
                _minTime = value;
                if (_maxTime < value)
                {
                    _maxTime = value;
                }

                // 値を補正
                Time = FixTime(Time);
            }
        }

        /// <summary>
        /// "H:M:S:F" 形式の時刻文字列値を取得する。
        /// </summary>
        /// <param name="frameRate">フレームレート。</param>
        /// <returns>"H:M:S:F" 形式の時刻文字列値。</returns>
        public string GetStringTime(double frameRate)
        {
            if (frameRate <= 0.0)
            {
                throw new ArgumentOutOfRangeException(
                    "frameRate", frameRate, "frameRate が 0.0 以下です。");
            }

            double time = Time;
            bool minus = (time < 0.0);

            time = Math.Abs(time);
            int hour = (int)(time / 3600.0);
            time -= hour * 3600.0;
            int minute = (int)(time / 60.0);
            time -= minute * 60.0;
            int second = (int)time;
            time -= second;
            int frame = (int)(time * frameRate + 0.5);

            return (
                (minus ? "-" : "") +
                hour + ":" + minute + ":" + second + ":" + frame);
        }

        /// <summary>
        /// "H:M:S:F" 形式の文字列値から時刻値を設定する。
        /// </summary>
        /// <param name="value">"H:M:S:F" 形式の時刻文字列値。</param>
        /// <param name="frameRate">フレームレート。</param>
        public void SetStringTime(string value, double frameRate)
        {
            Time = ParseToTime(value, frameRate);
        }

        public override string ToString()
        {
            return Time.ToString();
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return true; }
        }

        public override object Value
        {
            get { return Time; }
            set { Time = (double)value; }
        }

        public override object ScriptValue
        {
            get { return Time; }
            set { Time = (double)value; }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.Fixed; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame, double time)
        {
            // 取得時刻以前で最も近いキーフレームを探す
            KeyFrame prevKey = Util.GetPrevKeyFrame(keyFrame, time);

            // プロパティ値作成
            TimeProperty property = new TimeProperty(this);
            if (prevKey == null)
            {
                // 取得時刻をそのまま設定
                property.Time = time;
            }
            else
            {
                // キーフレーム値＋そこからの経過時間を設定
                property.Time =
                    ((TimeProperty)prevKey.Property).Time +
                    (time - prevKey.Time);
            }

            return property;
        }

        public override PropertyBase Copy()
        {
            return new TimeProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            if (obj is TimeProperty)
            {
                return (Time == ((TimeProperty)obj).Time);
            }
            return false;
        }

        #endregion
    }
}
