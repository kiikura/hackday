﻿using System;
using System.Collections;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Windows.Forms;

namespace ruche.nive2.effects
{
    /// <summary>
    /// このライブラリの設定の保存と読み込みを行うシングルトンクラス。
    /// </summary>
    public sealed class LibraryConfig
    {
        /// <summary>
        /// 唯一のインスタンス。
        /// </summary>
        private static LibraryConfig _instance;

        /// <summary>
        /// 設定ファイルのパス。
        /// </summary>
        private string _configFilePath;

        /// <summary>
        /// 保存対象のデータ。
        /// </summary>
        private Hashtable _datas = new Hashtable();

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        private LibraryConfig()
        {
            // 設定ファイルのパス設定
            _configFilePath = Environment.GetFolderPath(
                Environment.SpecialFolder.LocalApplicationData);
            _configFilePath = Path.Combine(
                _configFilePath,
                @"ruche-home\" +
                typeof(LibraryConfig).Namespace + @"\" +
                typeof(LibraryConfig).Namespace + @".dll.config");
        }

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static LibraryConfig()
        {
            _instance = new LibraryConfig();
        }

        /// <summary>
        /// 唯一のインスタンスを取得する。
        /// </summary>
        public static LibraryConfig Datas
        {
            get { return _instance; }
        }

        /// <summary>
        /// 設定保存先ファイルのパスを取得する。
        /// </summary>
        public string ConfigFilePath
        {
            get { return _configFilePath; }
        }

        /// <summary>
        /// 設定情報を取得または設定する。
        /// </summary>
        /// <param name="key">設定情報のキー。</param>
        /// <returns>設定情報。</returns>
        public object this[object key]
        {
            get { return _datas[key]; }
            set { _datas[key] = value; }
        }

        /// <summary>
        /// 指定したキーの情報が存在するか否かを取得する。
        /// </summary>
        /// <param name="key">キー。</param>
        /// <returns>存在する場合は true 。そうでなければ false 。</returns>
        public bool ContainsKey(object key)
        {
            return _datas.ContainsKey(key);
        }

        /// <summary>
        /// 指定したキーの情報を破棄します。
        /// </summary>
        /// <param name="key">キー。</param>
        public void Remove(object key)
        {
            _datas.Remove(key);
        }

        /// <summary>
        /// 設定のロードを行う。
        /// </summary>
        /// <returns>
        /// ロードが行われた場合は true 。そうでなければ false 。
        /// </returns>
        public bool Load()
        {
            bool result = false;

            if (File.Exists(ConfigFilePath))
            {
                SoapFormatter formatter = new SoapFormatter();
                try
                {
                    using (
                        FileStream fs = new FileStream(
                            ConfigFilePath, FileMode.Open, FileAccess.Read))
                    {
                        // デシリアライズする
                        object obj = formatter.Deserialize(fs);
                        fs.Close();

                        // キャストして取得
                        if (!(obj is Hashtable))
                        {
                            throw new ApplicationException(
                                "設定ファイルの内容が不正です。");
                        }
                        _datas = obj as Hashtable;

                        result = true;
                    }
                }
                catch
                {
                    result = false;
                }
            }

            return result;
        }

        /// <summary>
        /// 設定のセーブを行う。
        /// </summary>
        public void Save()
        {
            try
            {
                // ディレクトリが存在しなければ作成
                string dirPath = Path.GetDirectoryName(ConfigFilePath);
                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }

                // シリアライズする
                SoapFormatter formatter = new SoapFormatter();
                using (
                    FileStream fs = new FileStream(
                        ConfigFilePath, FileMode.Create, FileAccess.Write))
                {
                    formatter.Serialize(fs, _datas);
                    fs.Close();
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                MessageBox.Show(
                    ex.Message + "\n\n" + ex.StackTrace, ex.GetType().FullName,
                    MessageBoxButtons.OK);
#endif

                throw ex;
            }
        }
    }
}
