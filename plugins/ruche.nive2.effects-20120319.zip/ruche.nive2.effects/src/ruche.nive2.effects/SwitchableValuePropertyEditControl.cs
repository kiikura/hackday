﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 項目選択によるデータプロパティ設定を行う
    /// NiVE2プロパティエディットコントロールクラス。
    /// </summary>
    /// <typeparam name="T">データ型。</typeparam>
    public class SwitchableValuePropertyEditControl<T>
        :
        SwitchableSelectionPropertyEditControlBase
    {
        /// <summary>
        /// アイテム配列。
        /// </summary>
        private List<T> _items;

        /// <summary>
        /// アイテム表示名コンバータ。
        /// </summary>
        private Converter<T, string> _itemConverter = null;

        /// <summary>
        /// アイテム比較オブジェクト。
        /// </summary>
        private IEqualityComparer<T> _itemComparer = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        /// <param name="items">アイテム列挙。</param>
        public SwitchableValuePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox,
            IEnumerable<T> items)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                useComboBox,
                items,
                i => object.Equals(i, null) ? string.Empty : i.ToString())
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        /// <param name="items">アイテム列挙。</param>
        /// <param name="itemConverter">アイテム表示名コンバータ。</param>
        public SwitchableValuePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox,
            IEnumerable<T> items,
            Converter<T, string> itemConverter)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                useComboBox,
                items,
                itemConverter,
                EqualityComparer<T>.Default)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        /// <param name="items">アイテム列挙。</param>
        /// <param name="itemConverter">アイテム表示名コンバータ。</param>
        /// <param name="itemComparer">アイテム比較オブジェクト。</param>
        public SwitchableValuePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox,
            IEnumerable<T> items,
            Converter<T, string> itemConverter,
            IEqualityComparer<T> itemComparer)
            : base(name, switchable, alwaysEditable, useComboBox)
        {
            if (items == null)
            {
                throw new ArgumentNullException("items");
            }
            if (itemConverter == null)
            {
                throw new ArgumentNullException("itemConverter");
            }
            if (itemComparer == null)
            {
                throw new ArgumentNullException("itemConverter");
            }

            _items = new List<T>(items);
            if (_items.Count == 0)
            {
                throw new ArgumentException(
                    "items の要素数が 0 です。",
                    "items");
            }
            _itemConverter = itemConverter;
            _itemComparer = itemComparer;

            //InitializeComponent();
        }

        /// <summary>
        /// アイテム配列を取得する。
        /// </summary>
        public ReadOnlyCollection<T> Items
        {
            get { return _items.AsReadOnly(); }
        }

        /// <summary>
        /// コンボボックスを使用するか否かを取得または設定する。
        /// </summary>
        public new bool UseComboBox
        {
            get { return base.UseComboBox; }
            set { base.UseComboBox = value; }
        }

        #region SwitchableSelectionPropertyEditControlBase メンバ

        protected override IEnumerable<string> CreateItems()
        {
            return _items.ConvertAll(_itemConverter);
        }

        protected override SwitchablePropertyBase CreateProperty(int index)
        {
            var prop = DefaultProperty as SwitchableValueProperty<T>;
            if (prop != null)
            {
                prop = (SwitchableValueProperty<T>)prop.Copy();
                prop.OriginalValue = _items[index];
                prop.Valid = PropertyValid;
            }

            return prop;
        }

        protected override int IndexOfProperty(SwitchablePropertyBase property)
        {
            int index = -1;

            var prop = property as SwitchableValueProperty<T>;
            if (prop != null)
            {
                T value = prop.OriginalValue;
                index = _items.FindIndex(i => _itemComparer.Equals(i, value));
            }

            return index;
        }

        #endregion

        #region SwitchablePropertyEditControlBase メンバ

        public override Type UseProperetyType()
        {
            return typeof(SwitchableValueProperty<T>);
        }

        #endregion
    }
}
