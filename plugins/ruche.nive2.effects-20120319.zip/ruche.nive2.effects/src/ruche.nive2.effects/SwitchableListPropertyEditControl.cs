﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;

namespace ruche.nive2.effects
{
    /// <summary>
    /// データ選択プロパティを編集するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    /// <typeparam name="T">データ型。</typeparam>
    public class SwitchableListPropertyEditControl<T>
        :
        SwitchableSelectionPropertyEditControlBase
    {
        /// <summary>
        /// アイテム表示名コンバータ。
        /// </summary>
        private Converter<T, string> _itemConverter = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        public SwitchableListPropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                useComboBox,
                (i) => object.Equals(i, null) ? string.Empty : i.ToString())
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        /// <param name="itemConverter">アイテム表示名コンバータ。</param>
        public SwitchableListPropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox,
            Converter<T, string> itemConverter)
            : base(name, switchable, alwaysEditable, useComboBox)
        {
            if (itemConverter == null)
            {
                throw new ArgumentNullException("itemConverter");
            }
            this._itemConverter = itemConverter;

            //InitializeComponent();
        }

        /// <summary>
        /// コンボボックスを使用するか否かを取得または設定する。
        /// </summary>
        public new bool UseComboBox
        {
            get { return base.UseComboBox; }
            set { base.UseComboBox = value; }
        }

        #region SwitchableSelectionPropertyEditControlBase メンバ

        protected override IEnumerable<string> CreateItems()
        {
            IEnumerable<string> items = null;

            var prop = DefaultProperty as SwitchableListProperty<T>;
            if (prop != null)
            {
                items = new List<T>(prop.Items).ConvertAll(_itemConverter);
            }

            return items;
        }

        protected override SwitchablePropertyBase CreateProperty(int index)
        {
            var prop = DefaultProperty as SwitchableListProperty<T>;
            if (prop != null)
            {
                prop = (SwitchableListProperty<T>)prop.Copy();
                prop.OriginalValue = index;
                prop.Valid = PropertyValid;
            }

            return prop;
        }

        protected override int IndexOfProperty(SwitchablePropertyBase property)
        {
            var prop = property as SwitchableListProperty<T>;
            return (prop == null) ? -1 : prop.OriginalValue;
        }

        #endregion

        #region SwitchablePropertyEditControlBase メンバ

        public override Type UseProperetyType()
        {
            return typeof(SwitchableListProperty<T>);
        }

        #endregion
    }
}
