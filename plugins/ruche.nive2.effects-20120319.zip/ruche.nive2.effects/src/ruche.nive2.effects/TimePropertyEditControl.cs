﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 時刻プロパティ値を設定するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class TimePropertyEditControl : PropertyEditControlBase
    {
        private TextBox textTime;
        private Label labelTime;

        /// <summary>
        /// 対象コンポジション。
        /// </summary>
        private IComposition _composition;

        /// <summary>
        /// 時間値のインクリメント幅。
        /// </summary>
        private double _increment;

        /// <summary>
        /// 既定のプロパティ値。
        /// </summary>
        private TimeProperty _defaultProp;

        /// <summary>
        /// マウスの左ボタンが投下中であるか否か。
        /// </summary>
        private bool _mousePushing = false;

        /// <summary>
        /// マウスカーソルが左ボタン投下後に動いたか否か。
        /// </summary>
        private bool _mouseMoved = false;

        /// <summary>
        /// マウスの左ボタン投下時のカーソルX位置。
        /// </summary>
        private int _baseX = 0;

        /// <summary>
        /// マウスの左ボタン投下後の直前のカーソルX位置。
        /// </summary>
        private int _prevX = 0;

        /// <summary>
        /// マウスの左ボタン投下時の時刻値。
        /// </summary>
        private double _baseTime = 0.0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="composition">
        /// 対象コンポジション。フレームレート取得に用いられる。
        /// </param>
        /// <param name="increment">時刻値のインクリメント幅。</param>
        public TimePropertyEditControl(
            string name, IComposition composition, double increment)
        {
            if (composition == null)
            {
                throw new ArgumentNullException("composition");
            }

            PropertyName = name;
            LabelName = name;
            _composition = composition;
            _increment = increment;

            InitializeComponent();
        }

        /// <summary>
        /// フレームレートを取得する。
        /// </summary>
        private double FrameRate
        {
            get { return _composition.FrameRate; }
        }

        /// <summary>
        /// テキスト編集中であるか否かを取得する。
        /// </summary>
        private bool IsEditing
        {
            get { return textTime.Visible; }
        }

        /// <summary>
        /// 新しい時刻プロパティインスタンスを作成する。
        /// </summary>
        /// <returns>時刻プロパティインスタンス。</returns>
        private TimeProperty CreateProperty()
        {
            return ((_defaultProp == null) ?
                (new TimeProperty(PropertyName, 0.0)) :
                ((TimeProperty)_defaultProp.Copy()));
        }

        /// <summary>
        /// 時刻値の編集を開始する。
        /// </summary>
        private void BeginEdit()
        {
            if (!IsEditing)
            {
                // 編集モード開始
                labelTime.Visible = false;
                textTime.Visible = true;

                // 全選択してフォーカス
                textTime.SelectAll();
                textTime.Focus();
            }
        }

        /// <summary>
        /// 時刻値の編集を完了する。
        /// </summary>
        private void EndEdit()
        {
            if (IsEditing)
            {
                if (textTime.Text != labelTime.Text)
                {
                    // 値が変わっていたらプロパティ更新
                    TimeProperty prop = CreateProperty();
                    prop.Time =
                        TimeProperty.ParseToTime(textTime.Text, FrameRate);
                    SetProperty(prop);
                }

                // 編集モード終了
                textTime.Visible = false;
                labelTime.Visible = true;
                labelTime.Focus();
            }
        }

        /// <summary>
        /// 時刻値の編集をキャンセルする。
        /// </summary>
        private void CancelEdit()
        {
            if (IsEditing)
            {
                // ラベルのテキストに戻す
                textTime.Text = labelTime.Text;

                // 編集モード終了
                textTime.Visible = false;
                labelTime.Visible = true;
                labelTime.Focus();
            }
        }

        #region PropertyEditControlBase メンバ

        public override int SpliterDistance
        {
            get
            {
                return base.SpliterDistance;
            }
            set
            {
                base.SpliterDistance = value;

                // コントロールの位置合わせを行う
                textTime.Left = value + Util.PropertyEditControlLeftDistance;
                labelTime.Left = textTime.Left;
            }
        }

        public override Type UseProperetyType()
        {
            return typeof(TimeProperty);
        }

        public override void ChangeProperty(PropertyBase property)
        {
            TimeProperty prop = property as TimeProperty;
            if (prop != null)
            {
                // 表示文字列更新
                string timeText =
                    prop.GetStringTime(_composition.FrameRate);
                textTime.Text = timeText;
                labelTime.Text = timeText;
            }

            base.ChangeProperty(property);
        }

        public override void SetDefaultProperty(PropertyBase property)
        {
            if (property is TimeProperty)
            {
                // 既定のプロパティ値設定
                _defaultProp = (TimeProperty)property.Copy();
            }

            base.SetDefaultProperty(property);
        }

        #endregion

        private void InitializeComponent()
        {
            this.textTime = new System.Windows.Forms.TextBox();
            this.labelTime = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textTime
            // 
            this.textTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTime.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textTime.Location = new System.Drawing.Point(115, 3);
            this.textTime.Name = "textTime";
            this.textTime.Size = new System.Drawing.Size(100, 12);
            this.textTime.TabIndex = 2;
            this.textTime.Text = "0:0:0:0";
            this.textTime.Visible = false;
            this.textTime.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textTime_KeyDown);
            this.textTime.Leave += new System.EventHandler(this.textTime_Leave);
            this.textTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textTime_KeyPress);
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.labelTime.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelTime.Location = new System.Drawing.Point(114, 3);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(47, 12);
            this.labelTime.TabIndex = 3;
            this.labelTime.Text = "0:0:0:0";
            this.labelTime.MouseMove += new System.Windows.Forms.MouseEventHandler(this.labelTime_MouseMove);
            this.labelTime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.labelTime_MouseDown);
            this.labelTime.MouseUp += new System.Windows.Forms.MouseEventHandler(this.labelTime_MouseUp);
            // 
            // TimePropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.textTime);
            this.Controls.Add(this.labelTime);
            this.Name = "TimePropertyEditControl";
            this.Controls.SetChildIndex(this.labelTime, 0);
            this.Controls.SetChildIndex(this.textTime, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelTime_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !IsEditing)
            {
                // 左ボタン投下
                _mousePushing = true;
                _mouseMoved = false;
                _baseX = e.X;
                _prevX = _baseX;
                _baseTime =
                    TimeProperty.ParseToTime(labelTime.Text, FrameRate);
            }
        }

        private void labelTime_MouseMove(object sender, MouseEventArgs e)
        {
            if (_mousePushing)
            {
                if (e.X != _prevX)
                {
                    // X位置更新
                    _prevX = e.X;

                    // ドラッグしたことにする
                    _mouseMoved = true;

                    // プロパティ設定
                    TimeProperty prop = CreateProperty();
                    prop.Time = _baseTime + ((e.X - _baseX) * _increment);
                    SetProperty(prop);
                }
            }
        }

        private void labelTime_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && _mousePushing)
            {
                // 左ボタン投下完了
                _mousePushing = false;

                if (
                    !_mouseMoved &&
                    e.X >= 0 && e.X < labelTime.Width &&
                    e.Y >= 0 && e.Y < labelTime.Height)
                {
                    // ドラッグしておらず範囲内なら編集モード開始
                    BeginEdit();
                }
            }
        }

        private void textTime_Leave(object sender, EventArgs e)
        {
            if (IsEditing)
            {
                // フォーカスが離れたら編集完了
                EndEdit();
            }
        }

        private void textTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (IsEditing)
            {
                switch (e.KeyCode)
                {
                    case Keys.Enter:
                        // Enterキー投下で編集完了
                        EndEdit();
                        break;

                    case Keys.Escape:
                        // Escキー投下で編集キャンセル
                        CancelEdit();
                        break;
                }
            }
        }

        private void textTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 編集終了済みならキー入力を受け付けない
            if (!IsEditing)
            {
                e.Handled = true;
            }
        }
    }
}
