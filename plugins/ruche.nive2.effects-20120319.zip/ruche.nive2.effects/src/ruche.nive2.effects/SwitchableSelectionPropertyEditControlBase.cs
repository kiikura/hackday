﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 項目選択によるプロパティ設定を行う
    /// NiVE2プロパティエディットコントロールの基底クラス。
    /// </summary>
    public class SwitchableSelectionPropertyEditControlBase
        :
        SwitchablePropertyEditControlBase
    {
        private Label labelItem;
        private ComboBox comboItem;

        /// <summary>
        /// 項目名のリスト。
        /// </summary>
        List<string> _items = null;

        /// <summary>
        /// コンボボックス使用フラグ。
        /// </summary>
        bool _useComboBox = false;

        /// <summary>
        /// メニュー。
        /// </summary>
        private ContextMenuStrip _menu = null;

        /// <summary>
        /// 現在選択されているインデックス。
        /// </summary>
        private int _index = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableSelectionPropertyEditControlBase(
            string name,
            bool switchable,
            bool alwaysEditable)
            : base(name, switchable, alwaysEditable)
        {
            InitializeComponent();
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="useComboBox">コンボボックス使用フラグ。</param>
        public SwitchableSelectionPropertyEditControlBase(
            string name,
            bool switchable,
            bool alwaysEditable,
            bool useComboBox)
            : this(name, switchable, alwaysEditable)
        {
            this.UseComboBox = useComboBox;
        }

        /// <summary>
        /// デザイナ用コンストラクタ。
        /// </summary>
        private SwitchableSelectionPropertyEditControlBase()
            : base(string.Empty)
        {
            InitializeComponent();
        }

        /// <summary>
        /// コンボボックスを使用するか否かを取得または設定する。
        /// </summary>
        [Browsable(true)]
        [Description("コンボボックスを使用するか否かを設定する。")]
        [DefaultValue(false)]
        protected bool UseComboBox
        {
            get { return _useComboBox; }
            set { _useComboBox = value; }
        }

        /// <summary>
        /// 項目名のリストを取得する。
        /// </summary>
        /// <returns>項目名のリスト。取得できない状態ならば null 。</returns>
        /// <remarks>
        /// CreateItems メソッドが null を返す間は null を返す。
        /// CreateItems メソッドが null 以外の値を返した場合はその値を保存し、
        /// 以降の呼び出しではその値を返す。
        /// </remarks>
        protected List<string> GetItems()
        {
            if (_items == null)
            {
                var items = CreateItems();
                if (items != null)
                {
                    _items = new List<string>(items);
                    if (_items.Count <= 0)
                    {
                        throw new InvalidOperationException(
                            "項目数が 0 です。");
                    }
                }
            }
            return _items;
        }

        /// <summary>
        /// 項目名のリストを作成する。
        /// </summary>
        /// <returns>項目名のリスト。作成できない状態ならば null 。</returns>
        /// <remarks>
        /// 派生先クラスで必ずオーバライドすること。
        /// 
        /// 要素数 0 のリストを返すと呼び出し元で
        /// InvalidOperationException 例外が送出される。
        /// </remarks>
        protected virtual IEnumerable<string> CreateItems()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 現在のコントロール状態を基に新しいプロパティを生成する。
        /// </summary>
        /// <param name="index">選択項目のインデックス。</param>
        /// <returns>新しいプロパティ。生成できない状態ならば null 。</returns>
        /// <remarks>
        /// 派生先クラスで必ずオーバライドすること。
        /// 
        /// インスタンスの型は UseProperetyType メソッドが返す型であること。
        /// インスタンスを生成できない状態の場合は null 値を返すこと。
        /// </remarks>
        protected virtual SwitchablePropertyBase CreateProperty(int index)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// プロパティから項目のインデックスを検索する。
        /// </summary>
        /// <param name="property">プロパティ。</param>
        /// <returns>インデックス。見つからない場合は -1 。</returns>
        /// <remarks>派生先クラスで必ずオーバライドすること。</remarks>
        protected virtual int IndexOfProperty(SwitchablePropertyBase property)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// メニューを取得する。
        /// </summary>
        /// <returns>メニュー。まだ使えない状態ならば null 。</returns>
        private ContextMenuStrip GetMenu()
        {
            // メニュー初期化
            if (_menu == null)
            {
                var items = GetItems();
                if (items != null)
                {
                    _menu = new ContextMenuStrip();
                    _menu.SuspendLayout();
                    try
                    {
                        // 項目登録(Tag にインデックスを設定)
                        for (int i = 0; i < items.Count; ++i)
                        {
                            var item = new ToolStripMenuItem(items[i]);
                            item.Tag = i;
                            _menu.Items.Add(item);
                        }

                        // アイテムクリックイベント登録
                        _menu.ItemClicked += menu_ItemClicked;
                    }
                    finally
                    {
                        _menu.ResumeLayout(false);
                    }
                }
            }

            return _menu;
        }

        /// <summary>
        /// コンボボックスを取得する。
        /// </summary>
        /// <returns>コンボボックス。まだ使えない状態ならば null 。</returns>
        private ComboBox GetComboBox()
        {
            if (comboItem.Items.Count <= 0)
            {
                // 項目名取得
                var items = GetItems();
                if (items == null)
                {
                    return null;
                }

                // 項目設定
                comboItem.Items.AddRange(items.ToArray());
            }

            return comboItem;
        }

        #region SwitchablePropertyEditControlBase メンバ

        protected override sealed SwitchablePropertyBase CreateProperty()
        {
            return CreateProperty(_index);
        }

        protected override sealed void UpdateControls(
            SwitchablePropertyBase property)
        {
            int index = IndexOfProperty(property);
            var items = GetItems();
            if (index >= 0 && items != null)
            {
                // インデックス保存
                _index = index;

                // メニューの選択項目をチェック状態にする
                var menu = GetMenu();
                if (menu != null)
                {
                    menu.SuspendLayout();
                    try
                    {
                        for (int i = 0; i < menu.Items.Count; ++i)
                        {
                            var item = menu.Items[i] as ToolStripMenuItem;
                            if (item != null)
                            {
                                item.Checked = (i == index);
                            }
                        }
                    }
                    finally
                    {
                        menu.ResumeLayout(false);
                    }
                }

                // コンボボックス項目を選択する
                var combo = GetComboBox();
                if (combo != null)
                {
                    combo.SelectedIndex = index;
                }

                // ラベル文字列設定
                labelItem.Text = index + ": " + items[index];
            }
        }

        #endregion

        private void InitializeComponent()
        {
            this.labelItem = new System.Windows.Forms.Label();
            this.comboItem = new System.Windows.Forms.ComboBox();
            this.panelClient.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelClient
            // 
            this.panelClient.Controls.Add(this.comboItem);
            this.panelClient.Controls.Add(this.labelItem);
            this.panelClient.Location = new System.Drawing.Point(129, 0);
            this.panelClient.Size = new System.Drawing.Size(78, 18);
            // 
            // labelItem
            // 
            this.labelItem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelItem.Location = new System.Drawing.Point(0, 0);
            this.labelItem.Name = "labelItem";
            this.labelItem.Size = new System.Drawing.Size(78, 18);
            this.labelItem.TabIndex = 2;
            this.labelItem.Text = "item";
            this.labelItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelItem.Click += new System.EventHandler(this.labelItem_Click);
            // 
            // comboItem
            // 
            this.comboItem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboItem.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboItem.FormattingEnabled = true;
            this.comboItem.ItemHeight = 12;
            this.comboItem.Location = new System.Drawing.Point(0, 0);
            this.comboItem.Name = "comboItem";
            this.comboItem.Size = new System.Drawing.Size(78, 18);
            this.comboItem.TabIndex = 3;
            this.comboItem.Visible = false;
            this.comboItem.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboItem_DrawItem);
            this.comboItem.SelectionChangeCommitted += new System.EventHandler(this.comboItem_SelectionChangeCommitted);
            this.comboItem.DropDownClosed += new System.EventHandler(this.comboItem_DropDownClosed);
            // 
            // SwitchableSelectionPropertyEditControlBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Name = "SwitchableSelectionPropertyEditControlBase";
            this.panelClient.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelItem_Click(object sender, EventArgs e)
        {
            if (UseComboBox)
            {
                // ラベル非表示
                labelItem.Visible = false;

                // コンボボックス表示＆ドロップダウン
                var combo = GetComboBox();
                if (combo != null)
                {
                    combo.Visible = true;
                    combo.Focus();
                    combo.DroppedDown = true;
                }
            }
            else
            {
                // メニュー表示
                var menu = GetMenu();
                if (menu != null)
                {
                    menu.Show(
                        labelItem,
                        labelItem.PointToClient(Cursor.Position));
                }
            }
        }

        private void menu_ItemClicked(
            object sender,
            ToolStripItemClickedEventArgs e)
        {
            // 選択項目のインデックスでプロパティ更新
            if (e.ClickedItem.Tag is int)
            {
                _index = (int)e.ClickedItem.Tag;
                NotifyPropertyChanged();
            }
        }

        private void comboItem_SelectionChangeCommitted(
            object sender,
            EventArgs e)
        {
            var combo = sender as ComboBox;
            if (combo != null)
            {
                // 選択項目のインデックスでプロパティ更新
                if (!ControlUpdating && combo.SelectedIndex >= 0)
                {
                    _index = combo.SelectedIndex;
                    NotifyPropertyChanged();
                }
            }
        }

        private void comboItem_DropDownClosed(object sender, EventArgs e)
        {
            var combo = sender as ComboBox;
            if (combo != null)
            {
                // コンボボックス非表示＆ラベル表示
                combo.Visible = false;
                labelItem.Visible = true;
                labelItem.Focus();
            }
        }

        private void comboItem_DrawItem(object sender, DrawItemEventArgs e)
        {
            // 背景描画
            e.DrawBackground();

            ComboBox combo = sender as ComboBox;
            if (combo != null && e.Index >= 0)
            {
                // 表示文字列取得
                string text = combo.Items[e.Index].ToString();

                // Yマージン算出
                float textHeight =
                    e.Graphics.MeasureString(text, combo.Font).Height;
                float marginY = (e.Bounds.Height - textHeight) / 2;

                // 文字列描画
                e.Graphics.DrawString(
                    text,
                    combo.Font,
                    Brushes.Black,
                    e.Bounds.X,
                    e.Bounds.Y + marginY);
            }

            // フォーカス描画
            e.DrawFocusRectangle();
        }
    }
}
