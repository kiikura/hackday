﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace ruche.nive2.effects
{
    /// <summary>
    /// テキスト描画パラメータ構造体。
    /// </summary>
    public struct TextRenderingParam
    {
        /// <summary>
        /// フォントファミリー。
        /// </summary>
        public string fontFamily;

        /// <summary>
        /// フォントのemサイズ。
        /// </summary>
        public float fontEmSize;

        /// <summary>
        /// フォントスタイル。
        /// </summary>
        public FontStyle fontStyle;

        /// <summary>
        /// 不透明度。 0.0 ～ 1.0 。
        /// </summary>
        public double alpha;

        /// <summary>
        /// 基準点。
        /// </summary>
        public PointF basePos;

        /// <summary>
        /// 横配置基準。
        /// </summary>
        public StringAlignment horzAlign;

        /// <summary>
        /// 縦配置基準。
        /// </summary>
        public StringAlignment vertAlign;

        /// <summary>
        /// 行間割合。 1.0 が標準。
        /// </summary>
        public double heightRate;

        /// <summary>
        /// 塗り潰し有効フラグ。
        /// </summary>
        public bool fillEnabled;

        /// <summary>
        /// 塗り潰し色。
        /// </summary>
        public Color fillColor;

        /// <summary>
        /// 塗り潰しグラデーション有効フラグ。
        /// </summary>
        public bool fillGradientEnabled;

        /// <summary>
        /// 塗り潰しグラデーション色。
        /// </summary>
        public Color fillGradientColor;

        /// <summary>
        /// 縁取り有効フラグ。
        /// </summary>
        public bool edgeEnabled;

        /// <summary>
        /// 縁取り幅。
        /// </summary>
        public double edgeWidth;

        /// <summary>
        /// 縁取り色。
        /// </summary>
        public Color edgeColor;

        /// <summary>
        /// 縁取りグラデーション有効フラグ。
        /// </summary>
        public bool edgeGradientEnabled;

        /// <summary>
        /// 縁取りグラデーション色。
        /// </summary>
        public Color edgeGradientColor;

        /// <summary>
        /// アンチエイリアス有効フラグ。
        /// </summary>
        public bool antiAliasEnabled;

        /// <summary>
        /// 複合品質。
        /// </summary>
        public CompositingQuality compoQuality;
    }
}
