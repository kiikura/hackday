﻿using System;
using System.Drawing;

namespace ruche.nive2.effects
{
    /// <summary>
    /// イメージブレンドパラメータ構造体。
    /// </summary>
    public struct ImageBlendingParam
    {
        /// <summary>
        /// ブレンド方法。
        /// </summary>
        public BlendType blendType;

        /// <summary>
        /// 不透明度。 0.0 ～ 1.0 。
        /// </summary>
        public double alpha;

        /// <summary>
        /// 座標反転種別。
        /// </summary>
        public FlipType flipType;

        /// <summary>
        /// 基準点。
        /// </summary>
        public PointF basePos;

        /// <summary>
        /// 横配置基準。
        /// </summary>
        public BaseAlignment horzAlign;

        /// <summary>
        /// 縦配置基準。
        /// </summary>
        public BaseAlignment vertAlign;

        /// <summary>
        /// スケール。 1.0 が標準。
        /// </summary>
        public SizeF scale;

        /// <summary>
        /// 回転基準点配置。 rotateBasePos を使う場合は null 。
        /// </summary>
        public RectangleAlignment? rotateBaseAlign;

        /// <summary>
        /// 回転基準点。 rotateBaseAlign が null の場合のみ有効。
        /// </summary>
        public PointF rotateBasePos;

        /// <summary>
        /// 回転角度。
        /// </summary>
        public double rotateAngle;

        /// <summary>
        /// 塗り潰し有効フラグ。
        /// </summary>
        public bool fillEnabled;

        /// <summary>
        /// 塗り潰し色。
        /// </summary>
        public Color fillColor;

        /// <summary>
        /// 塗り潰し不透明度。 0.0 ～ 1.0 。
        /// </summary>
        public double fillAlpha;

        /// <summary>
        /// 塗り潰しグラデーション有効フラグ。
        /// </summary>
        public bool fillGradientEnabled;

        /// <summary>
        /// 塗り潰しグラデーション色。
        /// </summary>
        public Color fillGradientColor;

        /// <summary>
        /// 塗り潰しグラデーション不透明度。 0.0 ～ 1.0 。
        /// </summary>
        public double fillGradientAlpha;

        /// <summary>
        /// 塗り潰しグラデーション方向。
        /// </summary>
        public GradientDirection fillGradientDirection;

        /// <summary>
        /// 補間処理有効フラグ。
        /// </summary>
        public bool interpolateEnabled;

        /// <summary>
        /// 縮小フィルタ有効フラグ。
        /// </summary>
        public bool filterEnabled;
    }
}
