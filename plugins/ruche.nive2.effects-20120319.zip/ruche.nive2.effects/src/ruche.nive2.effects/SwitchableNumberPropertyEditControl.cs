﻿using System;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 数値プロパティを編集するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class SwitchableNumberPropertyEditControl
        :
        SwitchablePropertyEditControlBase
    {
        private Label labelValue;
        private TextBox textValue;
        private Label labelUnit;

        /// <summary>
        /// テキストボックスの追加幅。
        /// </summary>
        private const int TextBoxAppendWidth = 12;

        /// <summary>
        /// インクリメント幅。
        /// </summary>
        private double _increment = 1;

        /// <summary>
        /// 小数部の表示桁数。
        /// </summary>
        private int _decimalPlaces = 0;

        /// <summary>
        /// マウスの左ボタンが投下中であるか否か。
        /// </summary>
        private bool _mousePushing = false;

        /// <summary>
        /// マウスカーソルが左ボタン投下後に動いたか否か。
        /// </summary>
        private bool _mouseMoved = false;

        /// <summary>
        /// マウスの左ボタン投下時のカーソルX位置。
        /// </summary>
        private int _baseX = 0;

        /// <summary>
        /// マウスの左ボタン投下後の直前のカーソルX位置。
        /// </summary>
        private int _prevX = 0;

        /// <summary>
        /// マウスの左ボタン投下時の数値。
        /// </summary>
        private double _baseValue = 0;

        /// <summary>
        /// マウスで増減させた数値。
        /// </summary>
        private double _curValue = 0;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">値のインクリメント幅。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableNumberPropertyEditControl(
            string name,
            double increment,
            bool switchable,
            bool alwaysEditable)
            : this(name, increment, null, switchable, alwaysEditable)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">値のインクリメント幅。</param>
        /// <param name="unit">単位文字列。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableNumberPropertyEditControl(
            string name,
            double increment,
            string unit,
            bool switchable,
            bool alwaysEditable)
            : this(name, increment, unit, -1, switchable, alwaysEditable)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="increment">値のインクリメント幅。</param>
        /// <param name="unit">単位文字列。</param>
        /// <param name="decimalPlaces">
        /// 小数部の表示桁数。 -1 ならば表示桁数を操作しない。
        /// </param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        public SwitchableNumberPropertyEditControl(
            string name,
            double increment,
            string unit,
            int decimalPlaces,
            bool switchable,
            bool alwaysEditable)
            : base(name, switchable, alwaysEditable)
        {
            this.Increment = increment;
            this.DecimalPlaces = decimalPlaces;

            InitializeComponent();

            this.Unit = unit;
        }

        /// <summary>
        /// ドラッグ時のインクリメント幅を取得または設定する。
        /// </summary>
        public double Increment
        {
            get { return _increment; }
            set { _increment = value; }
        }

        /// <summary>
        /// 単位文字列を取得または設定する。
        /// </summary>
        public string Unit
        {
            get { return labelUnit.Text; }
            set { labelUnit.Text = value ?? string.Empty; }
        }

        /// <summary>
        /// 小数部の表示桁数を取得または設定する。
        /// -1 ならば表示桁数を操作しない。
        /// </summary>
        public int DecimalPlaces
        {
            get { return _decimalPlaces; }
            set { _decimalPlaces = Math.Min(Math.Max(value, -1), 99); }
        }

        /// <summary>
        /// テキスト編集中であるか否かを取得する。
        /// </summary>
        private bool IsEditing
        {
            get { return textValue.Visible; }
        }

        /// <summary>
        /// テキスト編集を開始する。
        /// </summary>
        private void BeginEdit()
        {
            if (!IsEditing)
            {
                // 編集モード開始
                labelValue.Visible = false;
                textValue.Visible = true;

                // 全選択してフォーカス
                textValue.SelectAll();
                textValue.Focus();
            }
        }

        /// <summary>
        /// テキスト編集を完了する。
        /// </summary>
        private void EndEdit()
        {
            if (IsEditing)
            {
                if (textValue.Text != labelValue.Text)
                {
                    // 値が変わっていたらプロパティ更新
                    NotifyPropertyChanged();
                }

                // 編集モード終了
                textValue.Visible = false;
                labelValue.Visible = true;
                labelValue.Focus();
            }
        }

        /// <summary>
        /// テキスト編集をキャンセルする。
        /// </summary>
        private void CancelEdit()
        {
            if (IsEditing)
            {
                // ラベルのテキストに戻す
                textValue.Text = labelValue.Text;

                // 編集モード終了
                textValue.Visible = false;
                labelValue.Visible = true;
                labelValue.Focus();
            }
        }

        /// <summary>
        /// コントロールの位置とサイズを補正する。
        /// </summary>
        private void AdjustControls()
        {
            if (
                labelValue != null &&
                textValue != null &&
                labelUnit != null)
            {
                Size panelSize = this.ClientPanelSize;
                Rectangle valueBounds = labelValue.Bounds;
                Rectangle unitBounds = labelUnit.Bounds;
                Rectangle textBounds = textValue.Bounds;

                // 数値ラベルの幅決定(パネル幅で補正)
                int valueWidth = Math.Min(
                    labelValue.PreferredWidth,
                    Math.Max(8, panelSize.Width - unitBounds.Width));

                // 単位ラベルのX位置決定
                int unitX = valueBounds.Left + valueWidth;

                // テキストボックス幅決定
                int textWidth = Math.Min(
                    valueWidth + TextBoxAppendWidth,
                    Math.Max(8, panelSize.Width - textBounds.Left));

                // 補正処理
                if (
                    valueBounds.Width != valueWidth ||
                    unitBounds.Left != unitX ||
                    textBounds.Width != textWidth)
                {
                    this.panelClient.SuspendLayout();
                    try
                    {
                        labelValue.Width = valueWidth;
                        labelUnit.Left = unitX;
                        textValue.Width = textWidth;
                    }
                    finally
                    {
                        this.panelClient.ResumeLayout(true);
                    }
                }
            }
        }

        /// <summary>
        /// double 値から文字列を作成する。
        /// </summary>
        /// <param name="value">double 値。</param>
        /// <returns>文字列。</returns>
        private string MakeDoubleString(double value)
        {
            string format = (this.DecimalPlaces < 0) ?
                "{0}" : ("{0:f" + this.DecimalPlaces + "}");
            return string.Format(format, value);
        }

        #region SwitchablePropertyEditControlBase メンバ

        protected override SwitchablePropertyBase CreateProperty()
        {
            SwitchableNumberProperty prop = null;

            var propDef = DefaultProperty as SwitchableNumberProperty;
            if (propDef != null)
            {
                // 値作成
                double value = 0;
                if (_mousePushing)
                {
                    // マウス編集値
                    value = _curValue;
                }
                else
                {
                    // テキスト編集値
                    if (
                        !double.TryParse(textValue.Text, out value) &&
                        !double.TryParse(labelValue.Text, out value))
                    {
                        value = 0;
                    }
                }

                // プロパティ作成
                prop = (SwitchableNumberProperty)propDef.Copy();
                prop.OriginalValue = value;
                prop.Valid = this.PropertyValid;
            }

            return prop;
        }

        protected override void UpdateControls(
            SwitchablePropertyBase property)
        {
            var prop = property as SwitchableNumberProperty;
            if (prop != null)
            {
                // 文字列作成
                string valueText = MakeDoubleString(prop.OriginalValue);

                // 設定
                labelValue.Text = valueText;
                textValue.Text = valueText;

                // コントロールリサイズ
                AdjustControls();
            }
        }

        protected override void OnClientPanelSizeChanged(EventArgs e)
        {
            // コントロールリサイズ
            AdjustControls();

            base.OnClientPanelSizeChanged(e);
        }

        public override Type UseProperetyType()
        {
            return typeof(SwitchableNumberProperty);
        }

        #endregion

        private void InitializeComponent()
        {
            this.labelValue = new System.Windows.Forms.Label();
            this.textValue = new System.Windows.Forms.TextBox();
            this.labelUnit = new System.Windows.Forms.Label();
            this.panelClient.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelClient
            // 
            this.panelClient.Controls.Add(this.textValue);
            this.panelClient.Controls.Add(this.labelUnit);
            this.panelClient.Controls.Add(this.labelValue);
            this.panelClient.Location = new System.Drawing.Point(129, 0);
            this.panelClient.Size = new System.Drawing.Size(78, 18);
            // 
            // labelValue
            // 
            this.labelValue.AutoEllipsis = true;
            this.labelValue.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.labelValue.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelValue.Location = new System.Drawing.Point(1, 3);
            this.labelValue.Name = "labelValue";
            this.labelValue.Size = new System.Drawing.Size(11, 12);
            this.labelValue.TabIndex = 0;
            this.labelValue.Text = "0";
            this.labelValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelValue.MouseMove += new System.Windows.Forms.MouseEventHandler(this.labelValue_MouseMove);
            this.labelValue.MouseDown += new System.Windows.Forms.MouseEventHandler(this.labelValue_MouseDown);
            this.labelValue.MouseUp += new System.Windows.Forms.MouseEventHandler(this.labelValue_MouseUp);
            // 
            // textValue
            // 
            this.textValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textValue.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textValue.Location = new System.Drawing.Point(3, 3);
            this.textValue.Name = "textValue";
            this.textValue.Size = new System.Drawing.Size(40, 12);
            this.textValue.TabIndex = 1;
            this.textValue.Visible = false;
            this.textValue.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textValue_KeyDown);
            this.textValue.Leave += new System.EventHandler(this.textValue_Leave);
            this.textValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textValue_KeyPress);
            // 
            // labelUnit
            // 
            this.labelUnit.AutoSize = true;
            this.labelUnit.Location = new System.Drawing.Point(50, 3);
            this.labelUnit.Name = "labelUnit";
            this.labelUnit.Size = new System.Drawing.Size(0, 12);
            this.labelUnit.TabIndex = 2;
            this.labelUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SwitchableNumberPropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Name = "SwitchableNumberPropertyEditControl";
            this.panelClient.ResumeLayout(false);
            this.panelClient.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelValue_MouseDown(object sender, MouseEventArgs e)
        {
            if (
                e.Button == MouseButtons.Left &&
                !IsEditing &&
                !ControlUpdating &&
                double.TryParse(labelValue.Text, out _baseValue))
            {
                // 左ボタン投下
                _mousePushing = true;
                _mouseMoved = false;
                _baseX = e.X;
                _prevX = _baseX;
            }
        }

        private void labelValue_MouseMove(object sender, MouseEventArgs e)
        {
            if (_mousePushing)
            {
                if (e.X != _prevX)
                {
                    // X位置更新
                    _prevX = e.X;

                    // ドラッグしたことにする
                    _mouseMoved = true;

                    // 値計算
                    _curValue = _baseValue + (e.X - _baseX) * _increment;

                    // プロパティ更新
                    NotifyPropertyChanged();
                }
            }
        }

        private void labelValue_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && _mousePushing)
            {
                // 左ボタン投下完了
                _mousePushing = false;

                if (
                    !_mouseMoved &&
                    e.X >= 0 && e.X < labelValue.Width &&
                    e.Y >= 0 && e.Y < labelValue.Height)
                {
                    // ドラッグしておらず範囲内なら編集モード開始
                    BeginEdit();
                }
            }
        }

        private void textValue_Leave(object sender, EventArgs e)
        {
            if (IsEditing)
            {
                // フォーカスが離れたら編集完了
                EndEdit();
            }
        }

        private void textValue_KeyDown(object sender, KeyEventArgs e)
        {
            if (IsEditing)
            {
                switch (e.KeyCode)
                {
                case Keys.Enter:
                    // Enterキー投下で編集完了
                    EndEdit();
                    break;

                case Keys.Escape:
                    // Escキー投下で編集キャンセル
                    CancelEdit();
                    break;
                }
            }
        }

        private void textValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 編集終了済みならキー入力を受け付けない
            if (!IsEditing)
            {
                e.Handled = true;
            }
        }
    }
}
