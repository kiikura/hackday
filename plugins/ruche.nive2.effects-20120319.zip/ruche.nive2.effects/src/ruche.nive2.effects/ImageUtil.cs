﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using NiVE2.Utils.Threading;

namespace ruche.nive2.effects
{
    /// <summary>
    /// イメージ関連の処理を定義する静的クラス。
    /// </summary>
    public static class ImageUtil
    {
        /// <summary>
        /// 赤の明るさの割合。
        /// </summary>
        public const double BrightnessRateRed = 0.299;
        
        /// <summary>
        /// 緑の明るさの割合。
        /// </summary>
        public const double BrightnessRateGreen = 0.587;

        /// <summary>
        /// 青の明るさの割合。
        /// </summary>
        public const double BrightnessRateBlue = 0.114;

        /// <summary>
        /// 色の明るさを算出する。
        /// </summary>
        /// <param name="color">色。</param>
        /// <returns>
        /// 色の明るさ。 0.0 ～ 1.0 。数値が大きいほど明るい。
        /// </returns>
        public static double CalcBrightness(Color color)
        {
            return (
                color.R * BrightnessRateRed +
                color.G * BrightnessRateGreen +
                color.B * BrightnessRateBlue) / 255.0;
        }

        /// <summary>
        /// 画像の不透明度、明度、彩度を一度に変更する。
        /// </summary>
        /// <param name="image">対象画像。</param>
        /// <param name="alpha">不透明度。 0.0 ～ 1.0 。</param>
        /// <param name="brightness">明度。 0.0 ～ 1.0 。</param>
        /// <param name="saturation">彩度。 0.0 ～ 1.0 。</param>
        public static void ConvertImageColor(
            NBitmap image,
            double alpha,
            double brightness,
            double saturation)
        {
            bool chgAlpha = (alpha < 1.0);
            bool chgBright = (brightness < 1.0);
            bool chgSaturate = (saturation < 1.0 && brightness > 0.0);

            if (chgAlpha || chgBright || chgSaturate)
            {
                alpha = Math.Max(alpha, 0.0);
                brightness = Math.Max(brightness, 0.0);
                saturation = Math.Max(saturation, 0.0);
                double invSat = 1.0 - saturation;

                byte[] data = image.GetData();
                Parallel.ForStep4(0, data.Length, (i) =>
                {
                    // 不透明度変更
                    if (chgAlpha)
                    {
                        data[i + 3] = (byte)(data[i + 3] * alpha + 0.5);
                    }

                    // 明度変更
                    if (chgBright)
                    {
                        data[i] = (byte)(data[i] * brightness + 0.5);
                        data[i + 1] = (byte)(data[i + 1] * brightness + 0.5);
                        data[i + 2] = (byte)(data[i + 2] * brightness + 0.5);
                    }

                    // 彩度変更
                    if (chgSaturate)
                    {
                        double gray =
                            data[i] * BrightnessRateBlue +
                            data[i + 1] * BrightnessRateGreen +
                            data[i + 2] * BrightnessRateRed;
                        gray *= invSat;
                        data[i] = (byte)(gray + data[i] * saturation + 0.5);
                        data[i + 1] = (byte)(gray + data[i + 1] * saturation + 0.5);
                        data[i + 2] = (byte)(gray + data[i + 2] * saturation + 0.5);
                    }
                });
            }
        }

        /// <summary>
        /// 画像の色を反転させる。
        /// </summary>
        /// <param name="image">対象画像。</param>
        public static void InvertImageColor(NBitmap image)
        {
            byte[] data = image.GetData();
            Parallel.ForStep4(0, data.Length, (i) =>
            {
                data[i] = (byte)(255 - data[i]);
                data[i + 1] = (byte)(255 - data[i + 1]);
                data[i + 2] = (byte)(255 - data[i + 2]);
            });
        }

        /// <summary>
        /// 画像の特定領域を切り取る。
        /// </summary>
        /// <param name="src">元画像。</param>
        /// <param name="x">X位置。</param>
        /// <param name="y">Y位置。</param>
        /// <param name="width">幅。</param>
        /// <param name="height">高さ。</param>
        /// <returns>切り取られた画像。</returns>
        /// <remarks>
        /// NiVE 2.13 までの NBitmap.Copy メソッドにはY位置を 1 以上にすると
        /// 結果画像の下側が透明になってしまうバグがあるため、その代替用。
        /// </remarks>
        public static NBitmap CutImage(
            NBitmap src,
            int x,
            int y,
            int width,
            int height)
        {
            NBitmap dest = new NBitmap(width, height);

            int srcLen = src.Width * 4;
            int destLen = dest.Width * 4;

            int syBegin = Math.Max(y, 0);
            int dyBegin = Math.Max(-y, 0);
            int dh = Math.Min(src.Height - syBegin, height - dyBegin);
            int sxBegin = Math.Max(x, 0);
            int dxBegin = Math.Max(-x, 0);
            int dw = Math.Min(src.Width - sxBegin, width - dxBegin);

            byte[] s = src.GetData();
            byte[] d = dest.GetData();
            int sxBeginB = sxBegin * 4;
            int dxBeginB = dxBegin * 4;
            int dwB = dw * 4;

            Parallel.For(0, dh, i =>
            {
                Buffer.BlockCopy(
                    s,
                    srcLen * (syBegin + i) + sxBeginB,
                    d,
                    destLen * (dyBegin + i) + dxBeginB,
                    dwB);
            });

            return dest;
        }

        /// <summary>
        /// 画像をブレンド描画する。
        /// </summary>
        /// <param name="destImage">描画先画像。</param>
        /// <param name="srcImage">描画元画像。</param>
        /// <param name="position">描画基準位置。</param>
        /// <param name="blendType">ブレンド種別。</param>
        /// <param name="interpolation">補間処理有効フラグ。</param>
        /// <param name="filterEnabled">縮小フィルタ有効フラグ。</param>
        public static void BlendImage(
            NBitmap destImage,
            NBitmap srcImage,
            PointF position,
            BlendType blendType,
            bool interpolation,
            bool filterEnabled)
        {
            BlendImage(
                destImage,
                srcImage,
                position,
                blendType,
                new Rectangle(Point.Empty, destImage.Size),
                new Matrix3D(),
                interpolation,
                filterEnabled);
        }

        /// <summary>
        /// 画像をブレンド描画する。
        /// </summary>
        /// <param name="destImage">描画先画像。</param>
        /// <param name="srcImage">描画元画像。</param>
        /// <param name="position">描画基準位置。</param>
        /// <param name="blendType">ブレンド種別。</param>
        /// <param name="clip">クリッピング領域。</param>
        /// <param name="transform">変換行列。</param>
        /// <param name="interpolation">補間処理有効フラグ。</param>
        /// <param name="filterEnabled">縮小フィルタ有効フラグ。</param>
        public static void BlendImage(
            NBitmap destImage,
            NBitmap srcImage,
            PointF position,
            BlendType blendType,
            Rectangle clip,
            Matrix3D transform,
            bool interpolation,
            bool filterEnabled)
        {
            // BlendableGraphics はα値が 0 のピクセルを無視する仕様のため
            // 置換にはそのまま使えない。
            // そのため置換の場合はまず置換先を完全透明色で上書きする。

            // 置換の特殊処理
            if (blendType == BlendType.Copy)
            {
                using (
                    CacheLocker destLock = new CacheLocker(destImage.DataSize))
                using (Bitmap dest = destImage.ToBitmap())
                {
                    // 完全透明の四角形で描画先を上書き
                    using (Graphics g = Graphics.FromImage(dest))
                    {
                        g.CompositingMode = CompositingMode.SourceCopy;
                        g.SetClip(clip);
                        g.Transform = new Matrix(
                            transform.M11, transform.M21,
                            transform.M12, transform.M22,
                            transform.M13, transform.M23);

                        // この辺のモードは適当…
                        g.InterpolationMode = interpolation ?
                            InterpolationMode.HighQualityBicubic :
                            InterpolationMode.NearestNeighbor;
                        g.SmoothingMode = interpolation ?
                            SmoothingMode.AntiAlias :
                            SmoothingMode.None;
                        g.PixelOffsetMode = interpolation ?
                            PixelOffsetMode.HighQuality :
                            PixelOffsetMode.None;

                        g.FillRectangle(
                            Brushes.Transparent,
                            position.X,
                            position.Y,
                            srcImage.Width,
                            srcImage.Height);
                    }

                    // NBitmap に書き戻す
                    byte[] orgData = destImage.GetData();
                    BitmapData bmpData = dest.LockBits(
                        new Rectangle(Point.Empty, dest.Size),
                        ImageLockMode.ReadOnly,
                        PixelFormat.Format32bppArgb);
                    Marshal.Copy(bmpData.Scan0, orgData, 0, orgData.Length);
                    dest.UnlockBits(bmpData);
                    bmpData = null;
                }
            }

            // 共通の処理
            {
                BlendableGraphics g = new BlendableGraphics(destImage);

                // パラメータ設定
                g.BlendMethod = (int)blendType;
                g.Clip = clip;
                g.Transform = transform;
                g.Interpolation = interpolation;

                // 描画
                if (filterEnabled)
                {
                    g.FilteredDrawImage(srcImage, position);
                }
                else
                {
                    g.DrawImage(srcImage, position);
                }
            }
        }

        /// <summary>
        /// 画像をブレンド描画する。描画元画像も変更される場合がある。
        /// </summary>
        /// <param name="destImage">描画先画像。</param>
        /// <param name="srcImage">描画元画像。</param>
        /// <param name="param">描画パラメータ。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="resolutionRate">解像度。</param>
        public static void BlendImage(
            NBitmap destImage,
            NBitmap srcImage,
            ImageBlendingParam param,
            Roi roi,
            double resolutionRate)
        {
            // 描画不要ならばそのまま返す
            if (param.alpha <= 0.0 || resolutionRate == 0.0)
            {
                return;
            }

            // 描画元画像サイズに依存しない座標に解像度を適用
            float resoRate = (float)resolutionRate;
            PointF basePos = new PointF(
                param.basePos.X * resoRate,
                param.basePos.Y * resoRate);
            PointF rotatePos = new PointF(
                param.rotateBasePos.X * resoRate,
                param.rotateBasePos.Y * resoRate);

            // ROIによる座標補正
            // ROIの座標は解像度変換後の座標であることに注意！
            basePos.X += roi.ImageX;
            basePos.Y += roi.ImageY;
            rotatePos.X += roi.ImageX;
            rotatePos.Y += roi.ImageY;

            // 塗り潰し処理
            if (param.fillEnabled)
            {
                if (param.fillGradientEnabled)
                {
                    FillImageByGradientColor(
                        srcImage,
                        param.fillColor,
                        param.fillAlpha,
                        param.fillGradientColor,
                        param.fillGradientAlpha,
                        param.fillGradientDirection);
                }
                else
                {
                    FillImageBySolidColor(
                        srcImage, param.fillColor, param.fillAlpha);
                }
            }

            // 不透明度補正
            if (param.alpha < 1.0)
            {
                byte[] data = srcImage.GetData();
                Parallel.ForStep4(3, data.Length, (i) =>
                {
                    data[i] = (byte)(data[i] * param.alpha + 0.5);
                });
            }

            // 行列設定
            Matrix3D mat = new Matrix3D();
            {
                float halfW = srcImage.Width * 0.5F;
                float halfH = srcImage.Height * 0.5F;

                // 中心を基準点にして反転設定
                mat.Translate(-halfW, -halfH);
                switch (param.flipType)
                {
                    case FlipType.Horizontal:
                        mat.Scale(-1.0F, 1.0F);
                        break;

                    case FlipType.Vertical:
                        mat.Scale(1.0F, -1.0F);
                        break;

                    case FlipType.Both:
                        mat.Scale(-1.0F, -1.0F);
                        break;
                }

                // 配置の縦横基準位置を適用
                float tx = 0.0F, ty = 0.0F;
                switch (param.horzAlign)
                {
                    case BaseAlignment.Near:
                        tx = halfW;
                        break;

                    case BaseAlignment.Far:
                        tx = -halfW;
                        break;
                }
                switch (param.vertAlign)
                {
                    case BaseAlignment.Near:
                        ty = halfH;
                        break;

                    case BaseAlignment.Far:
                        ty = -halfH;
                        break;
                }
                mat.Translate(tx, ty);

                // スケール設定
                mat.Scale(param.scale.Width, param.scale.Height);

                // 配置の基準点位置へ移動
                mat.Translate(basePos.X, basePos.Y);

                // 回転
                if (param.rotateAngle != 0.0)
                {
                    // 回転の基準点位置を決定
                    PointF rp = rotatePos;
                    if (param.rotateBaseAlign.HasValue)
                    {
                        float dx = (tx - halfW) * param.scale.Width;
                        float dy = (ty - halfH) * param.scale.Height;
                        RectangleF rect = new RectangleF(
                            basePos.X + dx,
                            basePos.Y + dy,
                            srcImage.Width * param.scale.Width,
                            srcImage.Height * param.scale.Height);
                        rp = Util.GetAlignmentPoint(
                            rect, param.rotateBaseAlign.Value);
                    }

                    // 回転設定
                    mat.RotateAt(rp.X, rp.Y, (float)param.rotateAngle);
                }
            }

            // 描画
            BlendImage(
                destImage,
                srcImage,
                PointF.Empty,
                param.blendType,
                roi.Interest,
                mat,
                param.interpolateEnabled,
                param.filterEnabled);
        }

        /// <summary>
        /// 画像の不透明度情報を保持したまま単色で塗り潰す。
        /// </summary>
        /// <param name="target">画像。</param>
        /// <param name="color">色。</param>
        /// <param name="alpha">色の不透明度。</param>
        public static void FillImageBySolidColor(
            NBitmap target,
            Color color,
            double alpha)
        {
            byte[] data = target.GetData();

            alpha = Math.Min(Math.Max(alpha, 0.0), 1.0);
            if (alpha == 1.0)
            {
                // 完全不透明
                Parallel.ForStep4(0, data.Length, (i) =>
                {
                    data[i] = color.B;
                    data[i + 1] = color.G;
                    data[i + 2] = color.R;
                });
            }
            else if (alpha > 0.0)
            {
                // 半透明
                double invAlpha = 1.0 - alpha;
                Parallel.ForStep4(0, data.Length, (i) =>
                {
                    data[i] = (byte)(color.B * alpha + data[i] * invAlpha + 0.5);
                    data[i + 1] = (byte)(color.G * alpha + data[i + 1] * invAlpha + 0.5);
                    data[i + 2] = (byte)(color.R * alpha + data[i + 2] * invAlpha + 0.5);
                });
            }
        }

        /// <summary>
        /// 画像の不透明度情報を保持したままグラデーション色で塗り潰す。
        /// </summary>
        /// <param name="target">画像。</param>
        /// <param name="baseColor">ベース色。</param>
        /// <param name="baseAlpha">ベース不透明度。</param>
        /// <param name="gradientColor">グラデーション色。</param>
        /// <param name="gradientAlpha">グラデーション不透明度。</param>
        /// <param name="gradientDir">グラデーション方向。</param>
        public static void FillImageByGradientColor(
            NBitmap target,
            Color baseColor,
            double baseAlpha,
            Color gradientColor,
            double gradientAlpha,
            GradientDirection gradientDir)
        {
            // グラデーションの開始位置と終端位置を設定
            Point begPos = Point.Empty, endPos = Point.Empty;
            switch (gradientDir)
            {
                case GradientDirection.TopToBottom:
                    endPos.Y = target.Height - 1;
                    break;

                case GradientDirection.LeftToRight:
                    endPos.X = target.Width - 1;
                    break;

                case GradientDirection.TopLeftToBottomRight:
                    endPos.X = target.Width - 1;
                    endPos.Y = target.Height - 1;
                    break;

                case GradientDirection.TopRightToBottomLeft:
                    begPos.X = target.Width - 1;
                    endPos.Y = target.Height - 1;
                    break;
            }

            // 塗り潰し
            byte[] data = target.GetData();
            int lenX = target.Width * 4;
            baseAlpha = Math.Min(Math.Max(baseAlpha, 0.0), 1.0);
            gradientAlpha = Math.Min(Math.Max(gradientAlpha, 0.0), 1.0);
            if (baseAlpha == 1.0 && gradientAlpha == 1.0)
            {
                // 完全不透明
                Parallel.For(0, target.Height, (y) =>
                {
                    double gradRace, revRate;

                    Point p = new Point(0, y);
                    int bi = lenX * y;
                    for (p.X = 0; p.X < target.Width; ++p.X, bi += 4)
                    {
                        // グラデーション割合算出
                        gradRace = CalcGradientRate(p, begPos, endPos, gradientDir);
                        revRate = 1.0 - gradRace;

                        // 距離割合から色決定
                        data[bi] = (byte)(
                            baseColor.B * revRate + gradientColor.B * gradRace + 0.5);
                        data[bi + 1] = (byte)(
                            baseColor.G * revRate + gradientColor.G * gradRace + 0.5);
                        data[bi + 2] = (byte)(
                            baseColor.R * revRate + gradientColor.R * gradRace + 0.5);
                    }
                });
            }
            else if (baseAlpha > 0.0 || gradientAlpha > 0.0)
            {
                // 半透明
                Parallel.For(0, target.Height, (y) =>
                {
                    byte b, g, r;
                    double alpha, invAlpha, gradRace, revRate;

                    Point p = new Point(0, y);
                    int bi = lenX * y;
                    for (p.X = 0; p.X < target.Width; ++p.X, bi += 4)
                    {
                        // グラデーション割合算出
                        gradRace = CalcGradientRate(p, begPos, endPos, gradientDir);
                        revRate = 1.0 - gradRace;

                        // 距離割合から色と不透明度決定
                        b = (byte)(
                            baseColor.B * revRate + gradientColor.B * gradRace + 0.5);
                        g = (byte)(
                            baseColor.G * revRate + gradientColor.G * gradRace + 0.5);
                        r = (byte)(
                            baseColor.R * revRate + gradientColor.R * gradRace + 0.5);
                        alpha = baseAlpha * revRate + gradientAlpha * gradRace;
                        invAlpha = 1.0 - alpha;

                        // 色算出
                        data[bi] =
                            (byte)(b * alpha + data[bi] * invAlpha + 0.5);
                        data[bi + 1] =
                            (byte)(g * alpha + data[bi + 1] * invAlpha + 0.5);
                        data[bi + 2] =
                            (byte)(r * alpha + data[bi + 2] * invAlpha + 0.5);
                    }
                });
            }
        }

        /// <summary>
        /// 現在位置のグラデーション割合を算出する。
        /// </summary>
        /// <param name="pos">現在位置。</param>
        /// <param name="beginPos">グラデーション開始位置。</param>
        /// <param name="endPos">グラデーション終了位置。</param>
        /// <param name="gradientDir">グラデーション方向。</param>
        /// <returns>
        /// グラデーション割合。 0.0 ～ 1.0 。終了位置に近いほど値が大きくなる。
        /// </returns>
        private static double CalcGradientRate(
            Point pos,
            Point beginPos,
            Point endPos,
            GradientDirection gradientDir)
        {
            // 開始点および終了点からの距離算出
            double beginDist, endDist;
            switch (gradientDir)
            {
                case GradientDirection.TopToBottom:
                    beginDist = Math.Abs(beginPos.Y - pos.Y);
                    endDist = Math.Abs(endPos.Y - pos.Y);
                    break;

                case GradientDirection.LeftToRight:
                    beginDist = Math.Abs(beginPos.X - pos.X);
                    endDist = Math.Abs(endPos.X - pos.X);
                    break;

                case GradientDirection.TopLeftToBottomRight:
                case GradientDirection.TopRightToBottomLeft:
                default:
                    beginDist = CalcDistance(beginPos, pos);
                    endDist = CalcDistance(endPos, pos);
                    break;
            }

            // 割合算出
            return (beginDist / (beginDist + endDist));
        }

        /// <summary>
        /// 2点間の距離を算出する。
        /// </summary>
        /// <param name="pos1">点1の位置。</param>
        /// <param name="pos2">点2の位置。</param>
        /// <returns>2点間の距離。</returns>
        private static double CalcDistance(Point pos1, Point pos2)
        {
            double dx = pos1.X - pos2.X;
            double dy = pos1.Y - pos2.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}
