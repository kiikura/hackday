﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 変数名と文字列型変数値のセットを保持するNiVE2プロパティセットクラス。
    /// </summary>
    [Serializable]
    public class StringVariablePropertySet : VariablePropertySetBase
    {
        /// <summary>
        /// 変数値プロパティを作成する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <returns>変数名プロパティ。</returns>
        private static SwitchableStringProperty CreateValueProperty(
            string name,
            string value)
        {
            return new SwitchableStringProperty(name, value, true);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        public StringVariablePropertySet(string name)
            : this(name, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        public StringVariablePropertySet(string name, string varName)
            : this(name, varName, string.Empty)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValue">変数値。</param>
        public StringVariablePropertySet(
            string name,
            string varName,
            string varValue)
            : this(
                name,
                varName,
                CreateValueProperty("variable.value", varValue))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティセット名。</param>
        /// <param name="varName">変数名。</param>
        /// <param name="varValueProperty">変数値プロパティ。</param>
        public StringVariablePropertySet(
            string name,
            string varName,
            SwitchableStringProperty varValueProperty)
            : base(name, varName, varValueProperty)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public StringVariablePropertySet(StringVariablePropertySet src)
            : base(src)
        {
        }

        /// <summary>
        /// 文字列型変数値プロパティを取得する。
        /// </summary>
        public SwitchableStringProperty VarValueStringProperty
        {
            get { return (SwitchableStringProperty)VarValueProperty; }
        }

        /// <summary>
        /// 変数値を文字列型として取得または設定する。
        /// </summary>
        public new string VarValue
        {
            get { return VarValueStringProperty.OriginalValue; }
            set { VarValueStringProperty.OriginalValue = value; }
        }

        #region VariablePropertySetBase メンバ

        protected override PropertyEditControlBase CreateVarValueControl(
            string name)
        {
            var ctrl = new TextPropertyEditControl<SwitchableStringProperty>(
                name,
                true);
            ctrl.LabelName = "文字列値";
            ctrl.CreatePropertyDelegate = CreateValueProperty;

            return ctrl;
        }

        #endregion

        #region PropertyBase メンバ

        public override PropertyBase Copy()
        {
            return new StringVariablePropertySet(this);
        }

        #endregion
    }
}
