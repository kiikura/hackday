﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 直前のキーフレームからの経過秒数を保持するNiVE2プロパティクラス。
    /// </summary>
    [Serializable]
    public class KeyFrameProperty : PropertyBase
    {
        /// <summary>
        /// 経過秒数。
        /// </summary>
        private double _elapsedTime = -1;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        public KeyFrameProperty(string name) : base(name)
        {
        }

        /// <summary>
        /// コピーコンストラクタ。
        /// </summary>
        /// <param name="src">コピー元。</param>
        public KeyFrameProperty(KeyFrameProperty src)
            : this(src.PropertyName)
        {
            _elapsedTime = src._elapsedTime;
        }

        /// <summary>
        /// キーフレームからの経過秒数を取得する。
        /// </summary>
        /// <remarks>
        /// 補間された場合は前方で最も近いキーフレームからの経過秒数を返す。
        /// 前方にキーフレームが無い場合はレイヤ開始時間からの経過秒数を返す。
        /// 
        /// 補間されていない場合は負数を返す。
        /// </remarks>
        public double ElapsedTime
        {
            get { return _elapsedTime; }
        }

        public override string ToString()
        {
            return _elapsedTime.ToString();
        }

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return false; }
        }

        public override object Value
        {
            get { return _elapsedTime; }
            set { ; }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.Fixed; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame, double time)
        {
            KeyFrameProperty property = new KeyFrameProperty(this);

            // 経過秒数設定
            property._elapsedTime = Util.CalcElapsedTime(keyFrame, time);

            return property;
        }

        public override PropertyBase Copy()
        {
            return new KeyFrameProperty(this);
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override bool Equals(PropertyBase obj)
        {
            if (obj != null && obj is KeyFrameProperty)
            {
                return (ElapsedTime == ((KeyFrameProperty)obj).ElapsedTime);
            }
            return false;
        }

        #endregion
    }
}
