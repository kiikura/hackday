﻿using System;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 基準点に対する配置を表す列挙。
    /// </summary>
    public enum BaseAlignment
    {
        /// <summary>
        /// 左もしくは上。
        /// </summary>
        Near,

        /// <summary>
        /// 中央。
        /// </summary>
        Center,

        /// <summary>
        /// 右もしくは下。
        /// </summary>
        Far,
    }
}
