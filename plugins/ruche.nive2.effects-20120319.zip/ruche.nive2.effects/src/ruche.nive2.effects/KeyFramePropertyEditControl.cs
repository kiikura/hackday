﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// キーフレームを設定するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class KeyFramePropertyEditControl : PropertyEditControlBase
    {
        private Button buttonKey;

        /// <summary>
        /// 既定のプロパティ値。
        /// </summary>
        private KeyFrameProperty _defaultProp;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        public KeyFramePropertyEditControl(string name)
        {
            PropertyName = name;
            LabelName = name;

            InitializeComponent();
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="buttonText">ボタンのラベル文字列。</param>
        public KeyFramePropertyEditControl(
            string name, string buttonText)
            : this(name)
        {
            ButtonText = buttonText;
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="buttonText">ボタンのラベル文字列。</param>
        /// <param name="buttonWidth">ボタンの横幅。</param>
        public KeyFramePropertyEditControl(
            string name, string buttonText, int buttonWidth)
            : this(name, buttonText)
        {
            ButtonWidth = buttonWidth;
        }

        /// <summary>
        /// ボタンのラベル文字列を取得または設定する。
        /// </summary>
        public string ButtonText
        {
            get { return buttonKey.Text; }
            set { buttonKey.Text = value; }
        }

        /// <summary>
        /// ボタンの横幅を取得または設定する。
        /// </summary>
        public int ButtonWidth
        {
            get { return buttonKey.Width; }
            set { buttonKey.Width = value; }
        }

        #region PropertyEditControlBase メンバ

        public override int SpliterDistance
        {
            get
            {
                return base.SpliterDistance;
            }
            set
            {
                base.SpliterDistance = value;

                // コントロールの位置合わせを行う
                buttonKey.Left = value + Util.PropertyEditControlLeftDistance;
            }
        }

        public override Type UseProperetyType()
        {
            return typeof(KeyFrameProperty);
        }

        public override void SetDefaultProperty(PropertyBase property)
        {
            if (property is KeyFrameProperty)
            {
                // 既定のプロパティ値設定
                _defaultProp = (KeyFrameProperty)property.Copy();
            }

            base.SetDefaultProperty(property);
        }

        #endregion

        private void InitializeComponent()
        {
            this.buttonKey = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonKey
            // 
            this.buttonKey.AutoEllipsis = true;
            this.buttonKey.Font = new System.Drawing.Font("MS UI Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.buttonKey.Location = new System.Drawing.Point(115, 0);
            this.buttonKey.Name = "buttonKey";
            this.buttonKey.Size = new System.Drawing.Size(100, 18);
            this.buttonKey.TabIndex = 2;
            this.buttonKey.Text = "キーフレーム設定";
            this.buttonKey.UseVisualStyleBackColor = true;
            this.buttonKey.Click += new System.EventHandler(this.buttonKey_Click);
            // 
            // KeyFramePropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.buttonKey);
            this.Name = "KeyFramePropertyEditControl";
            this.Controls.SetChildIndex(this.buttonKey, 0);
            this.ResumeLayout(false);

        }

        private void buttonKey_Click(object sender, EventArgs e)
        {
            // キーフレーム作成ONにする
            this.MakeKeyFrame = true;

            // プロパティ設定
            SetProperty(new KeyFrameProperty(PropertyName));
        }
    }
}
