﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// テキスト描画関連の処理を定義する静的クラス。
    /// </summary>
    public static class TextUtil
    {
        /// <summary>
        /// ベースとなる文字列描画フォーマット。
        /// </summary>
        private static readonly StringFormat BaseStringFormat =
            new StringFormat(
                StringFormatFlags.DisplayFormatControl |
                StringFormatFlags.MeasureTrailingSpaces |
                StringFormatFlags.NoClip |
                StringFormatFlags.NoWrap);

        /// <summary>
        /// 指定した時間のテキストプロパティ値を取得する。
        /// </summary>
        /// <param name="layer">対象レイヤー。</param>
        /// <param name="effect">対象エフェクト。</param>
        /// <param name="propertyName">テキストプロパティ名。</param>
        /// <param name="time">表示時間(ローカル)。</param>
        /// <returns>テキストプロパティ値。取得できない場合は null 。</returns>
        public static string GetTextPropertyValue(
            ILayer layer, EffectBase effect, string propertyName, double time)
        {
            // 引数チェック
            if (layer == null || effect == null || propertyName == null)
            {
                return null;
            }

            // プロパティ一覧取得
            ReadOnlyDictionary<string, PropertyBase> props =
                layer.GetEffectProperty(effect, layer.ToWorldTime(time));
            if (props == null || !props.Keys.Contains(propertyName))
            {
                return null;
            }

            // テキストプロパティ取得。
            StringProperty prop = props[propertyName] as StringProperty;
            if (prop == null) { return null; }

            return prop.Text;
        }

        /// <summary>
        /// 字送りを適用したテキストプロパティ値を作成する。
        /// </summary>
        /// <param name="layer">対象レイヤー。</param>
        /// <param name="effect">対象エフェクト。</param>
        /// <param name="propertyName">テキストプロパティ名。</param>
        /// <param name="time">表示時間(ローカル)。</param>
        /// <param name="letterSpanMs">文字間隔ミリ秒数。</param>
        /// <param name="lineSpanMs">改行間隔ミリ秒数。</param>
        /// <param name="skipLine">スキップ行数。</param>
        /// <param name="skipLetter">スキップ文字数。</param>
        /// <param name="skipBlank">
        /// 前後空白をスキップするならば true 。
        /// </param>
        /// <returns>字送りを適用した文字列。</returns>
        public static string MakeEffectedTextPropertyValue(
            ILayer layer,
            EffectBase effect,
            string propertyName,
            double time,
            double letterSpanMs,
            double lineSpanMs,
            int skipLine,
            int skipLetter,
            bool skipBlank)
        {
            // 文字列取得
            string text =
                GetTextPropertyValue(layer, effect, propertyName, time);
            if (text == null) { return ""; }

            // 表示文字無しor時間間隔無しなら変更する必要無し
            if (
                text.Trim().Length == 0 ||
                (letterSpanMs <= 0.0 && lineSpanMs <= 0.0))
            {
                return text;
            }

            // 行ごとに区切る
            List<string> lines = new List<string>();
            StringReader sr = new StringReader(text);
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                lines.Add(line);
            }
            if (lines.Count <= skipLine) { return text; }

            // 引数修正
            if (letterSpanMs < 0.0) { letterSpanMs = 0.0; }
            if (lineSpanMs < 0.0) { lineSpanMs = 0.0; }
            if (skipLine < 0) { skipLine = 0; }
            if (skipLetter < 0) { skipLetter = 0; }

            // 総所要時間算出
            double totalMs = (lines.Count - skipLine - 1) * lineSpanMs;
            for (int i = skipLine; i < lines.Count; ++i)
            {
                line = lines[i];
                if (skipBlank) { line = line.Trim(); }
                StringInfo si = new StringInfo(line);
                totalMs += si.LengthInTextElements * letterSpanMs;
            }
            totalMs -= letterSpanMs * skipLetter;
            if (totalMs <= 0.0) { return text; }

            // 文字列末尾から順に表示済みの時間かどうか判定
            while (lines.Count > skipLine)
            {
                // 最終行取得
                int index = lines.Count - 1;
                line = lines[index];
                if (skipBlank) { line = line.TrimEnd(); }

                // 行の各文字を末尾から順にチェック
                bool finish = false; // 表示位置確定フラグ
                bool lineAll = true; // 1行完全表示フラグ
                while ((skipBlank ? line.TrimStart() : line).Length > 0)
                {
                    double compTime = time - totalMs / 1000.0;
                    if (compTime >= 0.0)
                    {
                        // テキストプロパティ値を取得して比較
                        string compText = GetTextPropertyValue(
                            layer, effect, propertyName, compTime);
                        if (compText == text)
                        {
                            // 等しかったのでここまで表示済みと判断して抜ける
                            finish = true;
                            break;
                        }
                    }
                    lineAll = false;

                    // 文字間隔が 0 ならこれ以上調べても無駄なので抜ける
                    if (letterSpanMs <= 0.0) { break; }

                    // 1文字削除してその分の時間を減算
                    StringInfo si = new StringInfo(line);
                    line = si.SubstringByTextElements(
                        0, si.LengthInTextElements - 1);
                    totalMs -= letterSpanMs;
                }

                // 表示位置確定なら行を上書きして抜ける
                if (finish)
                {
                    if (!lineAll) { lines[index] = line; }
                    break;
                }

                // 最終行を削除してその分の時間を減算
                lines.RemoveAt(index);
                totalMs -= lineSpanMs;
            }

            // 文字列作成
            return string.Join("\n", lines.ToArray());
        }

        /// <summary>
        /// 文字列を描画する。
        /// </summary>
        /// <param name="image">描画先イメージ。</param>
        /// <param name="text">描画する文字列。</param>
        /// <param name="param">描画パラメータ。</param>
        /// <param name="roi">ROI。</param>
        /// <param name="resolutionRate">解像度。</param>
        public static void RenderText(
            NBitmap image,
            string text,
            TextRenderingParam param,
            Roi roi,
            double resolutionRate)
        {
            // 描画する必要が無いならそのまま返す
            if (
                text.Trim().Length == 0 ||
                param.alpha <= 0.0 ||
                (!param.fillEnabled && !param.edgeEnabled) ||
                resolutionRate == 0.0)
            {
                return;
            }

            // ROIによる座標補正
            // ROIの座標は解像度変換後の座標であることに注意！
            param.basePos.X += (float)(roi.ImageX / resolutionRate);
            param.basePos.Y += (float)(roi.ImageY / resolutionRate);

            // 文字列を行単位に分割
            // 行間設定、および末尾の改行を描画しないため
            List<string> lines = new List<string>();
            StringReader sr = new StringReader(text);
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                lines.Add(line);
            }

            // フォントを作成(ピクセル単位)
            Font font = new Font(
                param.fontFamily,
                param.fontEmSize,
                param.fontStyle,
                GraphicsUnit.Pixel);

            // 高さ算出(最後の余白は含まない)
            float fontHeight = font.Height;
            double lineHeight = fontHeight * param.heightRate;
            double allHeight =
                lineHeight * lines.Count - (lineHeight - fontHeight);

            // 文字列描画フォーマットを作成
            StringFormat format = BaseStringFormat.Clone() as StringFormat;
            format.Alignment = param.horzAlign;
            //format.LineAlignment = vertAlign; // 縦方向の配置は自前で行う

            // 描画開始Y位置算出
            double beginY = param.basePos.Y;
            switch (param.vertAlign)
            {
                case StringAlignment.Center:
                    beginY -= allHeight * 0.5;
                    break;

                case StringAlignment.Far:
                    beginY -= allHeight;
                    break;
            }

            // 不透明度を 0 ～ 255 にする
            int alphaVal = (int)(param.alpha * 255.0 + 0.5);

            // キャッシュを確保してBitmapを取得
            using (CacheLocker cacheLock = new CacheLocker(image.DataSize))
            using (Bitmap bmp = image.ToBitmap())
            {
                // 描画
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    // 描画設定
                    g.SmoothingMode = param.antiAliasEnabled ?
                        SmoothingMode.AntiAlias : SmoothingMode.Default;
                    g.TextRenderingHint = param.antiAliasEnabled ?
                        TextRenderingHint.AntiAlias :
                        TextRenderingHint.SystemDefault;
                    g.CompositingMode = CompositingMode.SourceOver;
                    g.CompositingQuality = param.compoQuality;

                    // ROIでクリッピング
                    g.SetClip(roi.Interest);

                    // スケールマトリクス設定
                    g.ScaleTransform(
                        (float)resolutionRate,
                        (float)resolutionRate,
                        MatrixOrder.Append);

                    // 以下の理由により、行ごとに描画する
                    // - 全行一度にパス追加すると改行文字も描画されてしまうため
                    // - グラデーションを綺麗に出すため
                    for (int i = 0; i < lines.Count; ++i)
                    {
                        line = lines[i];
                        if (line.Trim().Length == 0) { continue; }

                        double y = beginY + (lineHeight * i);

                        using (GraphicsPath gpath = new GraphicsPath())
                        {
                            // パス追加
                            gpath.AddString(
                                line,
                                font.FontFamily,
                                (int)font.Style,
                                font.SizeInPoints * g.DpiY / 72.0F,
                                new PointF(param.basePos.X, (float)y),
                                format);

                            // 縁取り
                            if (param.edgeEnabled)
                            {
                                // ブラシからペン作成
                                using (
                                    Brush brush = CreateBrush(
                                        param.edgeColor,
                                        alphaVal,
                                        param.edgeGradientEnabled,
                                        (float)y,
                                        (float)fontHeight,
                                        param.edgeGradientColor))
                                using (
                                    Pen pen = new Pen(brush, (float)param.edgeWidth))
                                {
                                    // 描画
                                    g.DrawPath(pen, gpath);
                                }
                            }

                            // 塗り潰し
                            if (param.fillEnabled)
                            {
                                // ブラシ作成
                                using (
                                    Brush brush = CreateBrush(
                                        param.fillColor,
                                        alphaVal,
                                        param.fillGradientEnabled,
                                        (float)y,
                                        (float)fontHeight,
                                        param.fillGradientColor))
                                {
                                    // 描画
                                    g.FillPath(brush, gpath);
                                }
                            }
                        }
                    }
                }

                // 元画像を上書き
                byte[] dest = image.GetData();
                BitmapData bmpData = bmp.LockBits(
                    new Rectangle(Point.Empty, bmp.Size),
                    ImageLockMode.ReadOnly,
                    PixelFormat.Format32bppArgb);
                Marshal.Copy(bmpData.Scan0, dest, 0, dest.Length);
                bmp.UnlockBits(bmpData);
                bmpData = null;
            }
        }

        /// <summary>
        /// ブラシを作成する。
        /// </summary>
        /// <param name="baseColor">基本色。</param>
        /// <param name="alpha">不透明度。 0 ～ 255 。</param>
        /// <param name="gradation">
        /// グラデーションするならば true 。しないならば false 。
        /// </param>
        /// <param name="gradationBaseY">グラデーションの基準Y位置。</param>
        /// <param name="gradationHeight">グラデーションの高さ。</param>
        /// <param name="gradationColor">グラデーションの終端色。</param>
        /// <returns>ブラシ。</returns>
        private static Brush CreateBrush(
            Color baseColor,
            int alpha,
            bool gradation,
            float gradationBaseY,
            float gradationHeight,
            Color gradationColor)
        {
            Brush brush = null;

            baseColor = Color.FromArgb(alpha, baseColor);

            if (gradation)
            {
                gradationColor = Color.FromArgb(alpha, gradationColor);
                brush = new LinearGradientBrush(
                    new PointF(0.0F, gradationBaseY),
                    new PointF(0.0F, gradationBaseY + gradationHeight),
                    baseColor,
                    gradationColor);
            }
            else
            {
                brush = new SolidBrush(baseColor);
            }

            return brush;
        }
    }
}
