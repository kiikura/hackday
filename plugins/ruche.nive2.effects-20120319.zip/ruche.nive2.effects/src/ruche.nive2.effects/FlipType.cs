﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 反転の種別を表す列挙。
    /// </summary>
    public enum FlipType
    {
        /// <summary>
        /// 反転しない。
        /// </summary>
        [Description("反転しない")]
        [EnumDefaultValue]
        None,

        /// <summary>
        /// 左右反転。
        /// </summary>
        [Description("左右反転")]
        Horizontal,

        /// <summary>
        /// 上下反転。
        /// </summary>
        [Description("上下反転")]
        Vertical,

        /// <summary>
        /// 左右反転＆上下反転。
        /// </summary>
        [Description("左右反転＆上下反転")]
        Both,
    }
}
