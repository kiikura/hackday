﻿using System;
using System.Collections.Generic;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 値とその有効状態を保持するNiVE2プロパティの抽象基底クラス。
    /// </summary>
    [Serializable]
    public abstract class SwitchablePropertyBase : PropertyBase
    {
        /// <summary>
        /// 値有効フラグ。
        /// </summary>
        private bool _valid;

        public SwitchablePropertyBase(string name, bool valid)
            : base(name)
        {
            Valid = valid;
        }

        /// <summary>
        /// 値有効フラグを取得または設定する。
        /// </summary>
        public bool Valid
        {
            get { return _valid; }
            set { _valid = value; }
        }

        /// <summary>
        /// 派生クラスで派生型のインスタンスを生成する。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <returns>派生型のインスタンス。</returns>
        protected abstract SwitchablePropertyBase CreateInstance(
            string name);

        /// <summary>
        /// 他のプロパティからこのプロパティへ内容をコピーする。
        /// </summary>
        /// <param name="src">
        /// コピー元。派生クラスの場合は派生先の型となる。
        /// </param>
        protected abstract void CopyFrom(SwitchablePropertyBase src);

        /// <summary>
        /// このプロパティと他のプロパティの値が等しいか否かを取得する。
        /// </summary>
        /// <param name="other">
        /// プロパティ。派生クラスの場合は派生先の型となる。
        /// </param>
        /// <returns>等しければ true 。そうでなければ false 。</returns>
        protected abstract bool IsValueEquals(SwitchablePropertyBase other);

        #region PropertyBase メンバ

        public override PropertyInterpolationType SupportInterpolationType
        {
            get { return PropertyInterpolationType.Fixed; }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            return Util.GetFixedKeyFrame(keyFrame, time).Property;
        }

        public override PropertyBase PasteProperty(PropertyBase property)
        {
            return property;
        }

        public override PropertyBase[] PasteProperty(PropertyBase[] property)
        {
            return property;
        }

        public override sealed PropertyBase Copy()
        {
            var prop = CreateInstance(PropertyName);
            prop.CopyFrom(this);
            return prop;
        }

        public override sealed bool Equals(PropertyBase obj)
        {
            var prop = obj as SwitchablePropertyBase;
            if (prop != null && GetType() == obj.GetType())
            {
                return (
                    this.PropertyName == prop.PropertyName &&
                    IsValueEquals(prop));
            }
            return false;
        }

        #endregion
    }

    /// <summary>
    /// 値とその有効状態を保持するNiVE2プロパティの抽象基底クラス。
    /// </summary>
    /// <typeparam name="T">値型。</typeparam>
    [Serializable]
    public abstract class SwitchablePropertyBase<T> : SwitchablePropertyBase
    {
        /// <summary>
        /// 値比較オブジェクト。
        /// </summary>
        protected static readonly EqualityComparer<T> ValueComparer =
            EqualityComparer<T>.Default;

        /// <summary>
        /// 値。
        /// </summary>
        private T _value;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">値。非 null 値でなければならない。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchablePropertyBase(string name, T value, bool valid)
            : base(name, valid)
        {
            if (object.Equals(value, null))
            {
                throw new ArgumentNullException("value");
            }

            OriginalValue = value;
        }

        /// <summary>
        /// 値を取得または設定する。
        /// </summary>
        /// <remarks>
        /// 必ず非 null 値となる。
        /// 
        /// null 値を渡すと DefaultValue プロパティ値を用いる。
        /// DefaultValue プロパティ値も null 値であった場合は
        /// NotImplementedException 例外を送出する。
        /// 
        /// 非 null 値を渡した場合、実際に値を設定する前に
        /// ValidateValue メソッドを呼び出し、結果として true が返された
        /// 場合のみ値を設定する。
        /// このメソッドが null 値を設定して true を返した場合は
        /// InvalidOperationException 例外を送出する。
        /// </remarks>
        public T OriginalValue
        {
            get { return _value; }
            set
            {
                T v = value;

                if (object.Equals(v, null))
                {
                    v = DefaultValue;
                    if (object.Equals(v, null))
                    {
                        throw new NotImplementedException(
                            "DefaultValue プロパティが非 null 値を返す" +
                            "実装になっていません。");
                    }
                }
                else if (ValidateValue(ref v))
                {
                    if (object.Equals(v, null))
                    {
                        throw new InvalidOperationException(
                            "ValidateValue メソッドが null 値を設定する" +
                            "実装になっています。");
                    }
                }
                else
                {
                    return;
                }

                _value = v;
            }
        }

        /// <summary>
        /// 既定値を取得する。
        /// </summary>
        /// <remarks>
        /// null 値を返してはならない。
        /// 
        /// 既定では default(T) を取得し、その値が非 null 値ならばそれを返す。
        /// null 値であった場合は NotImplementedException 例外を送出する。
        /// </remarks>
        public virtual T DefaultValue
        {
            get
            {
                T data = default(T);
                if (object.Equals(data, null))
                {
                    throw new NotImplementedException(
                        "DefaultValue プロパティが非 null 値を返す実装に" +
                        "なっていません。");
                }
                return data;
            }
        }

        public override string ToString()
        {
            return OriginalValue.ToString();
        }

        /// <summary>
        /// OriginalValue プロパティへの入力値を検証する。
        /// </summary>
        /// <param name="value">
        /// 入力値。必ず非 null 値となる。必要に応じて書き換えられる。
        /// </param>
        /// <returns>検証結果。</returns>
        /// <remarks>
        /// false を返した場合、値の設定は行われない。
        /// 既定では何も行わずに true を返す。
        /// 
        /// このメソッドをオーバライドする場合、 value に null 値を設定して
        /// true を返してはならない。
        /// そのような実装を行った場合、呼び出し元の OriginalValue から
        /// InvalidOperationException 例外が送出される。
        /// </remarks>
        protected virtual bool ValidateValue(ref T value)
        {
            return true;
        }

        #region SwitchablePropertyBase メンバ

        /// <summary>
        /// 他のプロパティからこのプロパティへ内容をコピーする。
        /// </summary>
        /// <param name="src">
        /// コピー元。派生クラスの場合は派生先の型となる。
        /// </param>
        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchablePropertyBase<T>)src;
            OriginalValue = prop.OriginalValue;
            Valid = prop.Valid;
        }

        /// <summary>
        /// このプロパティと他のプロパティの値が等しいか否かを取得する。
        /// </summary>
        /// <param name="other">
        /// プロパティ。派生クラスの場合は派生先の型となる。
        /// </param>
        /// <returns>等しければ true 。そうでなければ false 。</returns>
        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchablePropertyBase<T>)other;
            return (
                Valid == prop.Valid &&
                ValueComparer.Equals(OriginalValue, prop.OriginalValue));
        }

        #endregion

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return false; }
        }

        public override sealed object Value
        {
            get { return Valid ? (object)OriginalValue : null; }
            set
            {
                Valid = !object.Equals(value, null);
                if (Valid)
                {
                    OriginalValue = (T)value;
                }
            }
        }

        #endregion
    }
}
