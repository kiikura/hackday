﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 項目選択によるフォントファミリ名プロパティ設定を行う
    /// NiVE2プロパティエディットコントロールクラス。
    /// </summary>
    public class SwitchableFontFamilyNamePropertyEditControl
        :
        SwitchableSelectionPropertyEditControlBase
    {
        /// <summary>
        /// フォントファミリ名配列。
        /// </summary>
        private readonly FontFamilyNameCollection _fontFamilyNames;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <remarks>
        /// FontStyle.Regular をサポートするフォントファミリのみ選択される。
        /// </remarks>
        public SwitchableFontFamilyNamePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                new FontFamilyNameCollection())
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="matchStyles">
        /// 選択条件スタイル。
        /// いずれかのスタイルをサポートするフォントファミリのみ選択される。
        /// </param>
        public SwitchableFontFamilyNamePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            params FontStyle[] matchStyles)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                new FontFamilyNameCollection(matchStyles))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        public SwitchableFontFamilyNamePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            Predicate<FontFamily> match)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                new FontFamilyNameCollection(match))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="match">
        /// 選択条件デリゲート。 null ならばすべて選択される。
        /// </param>
        /// <param name="sorter">
        /// ソート用デリゲート。 null ならば既定の並び順になる。
        /// </param>
        public SwitchableFontFamilyNamePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            Predicate<FontFamily> match,
            Comparison<FontFamily> sorter)
            :
            this(
                name,
                switchable,
                alwaysEditable,
                new FontFamilyNameCollection(match, sorter))
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対象プロパティ名。</param>
        /// <param name="switchable">有効状態切り替え可能フラグ。</param>
        /// <param name="alwaysEditable">常時編集可能フラグ。</param>
        /// <param name="fontFamilyNames">フォントファミリ名配列。</param>
        public SwitchableFontFamilyNamePropertyEditControl(
            string name,
            bool switchable,
            bool alwaysEditable,
            FontFamilyNameCollection fontFamilyNames)
            : base(name, switchable, alwaysEditable, true)
        {
            if (fontFamilyNames == null)
            {
                throw new ArgumentNullException("fontFamilyNames");
            }
            if (fontFamilyNames.Count <= 0)
            {
                throw new ArgumentException(
                    "fontFamilyNames の要素数が 0 です。",
                    "fontFamilyNames");
            }
            _fontFamilyNames = fontFamilyNames;

            //InitializeComponent();
        }

        /// <summary>
        /// フォントファミリ名配列を取得する。
        /// </summary>
        public FontFamilyNameCollection FontFamilyNames
        {
            get { return _fontFamilyNames; }
        }

        #region SwitchableSelectionPropertyEditControlBase メンバ

        protected override IEnumerable<string> CreateItems()
        {
            return FontFamilyNames;
        }

        protected override SwitchablePropertyBase CreateProperty(int index)
        {
            var prop = DefaultProperty as SwitchableFontFamilyNameProperty;
            if (prop != null)
            {
                prop = (SwitchableFontFamilyNameProperty)prop.Copy();
                prop.OriginalValue = FontFamilyNames[index];
                prop.Valid = PropertyValid;
            }

            return prop;
        }

        protected override int IndexOfProperty(SwitchablePropertyBase property)
        {
            int index = -1;

            var prop = property as SwitchableFontFamilyNameProperty;
            if (prop != null)
            {
                // フォントファミリ名として有効でもコントロール側のリストに
                // 含まれていない場合があるので注意
                index = FontFamilyNames.IndexOf(prop.OriginalValue);
                if (index < 0)
                {
                    index = Math.Max(
                        FontFamilyNames.IndexOf(prop.DefaultValue),
                        0);
                }
            }

            return index;
        }

        #endregion

        #region SwitchablePropertyEditControlBase メンバ

        public override Type UseProperetyType()
        {
            return typeof(SwitchableFontFamilyNameProperty);
        }

        #endregion
    }
}
