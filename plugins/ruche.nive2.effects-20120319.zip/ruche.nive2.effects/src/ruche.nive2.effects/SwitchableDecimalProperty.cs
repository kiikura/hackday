﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// decimal 値とその有効状態を保持するNiVE2プロパティクラス。
    /// </summary>
    /// <remarks>
    /// 最大値もしくは最小値の異なるプロパティ間の補間を行う場合、
    /// より大きい最大値およびより小さい最小値が用いられる。
    /// </remarks>
    [Serializable]
    public class SwitchableDecimalProperty : SwitchablePropertyBase<decimal>
    {
        /// <summary>
        /// 小数部桁数の最大値。
        /// </summary>
        public const int MaxDecimalPlaces = 28;

        /// <summary>
        /// 最大値。
        /// </summary>
        private decimal _maxValue = decimal.MaxValue;

        /// <summary>
        /// 最小値。
        /// </summary>
        private decimal _minValue = decimal.MinValue;

        /// <summary>
        /// 小数部最大桁数。
        /// </summary>
        private int _decimalPlaces = -1;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        public SwitchableDecimalProperty(string name, decimal value, bool valid)
            : this(name, value, valid, decimal.MinValue, decimal.MaxValue)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="valueRange1">値範囲1。</param>
        /// <param name="valueRange2">値範囲2。</param>
        public SwitchableDecimalProperty(
            string name,
            decimal value,
            bool valid,
            decimal valueRange1,
            decimal valueRange2)
            : this(name, value, valid, valueRange1, valueRange2, -1)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">プロパティ名。</param>
        /// <param name="value">初期値。</param>
        /// <param name="valid">値有効フラグ。</param>
        /// <param name="valueRange1">値範囲1。</param>
        /// <param name="valueRange2">値範囲2。</param>
        /// <param name="decimalPlaces">
        /// 小数部の桁数。負数ならば補正しない。
        /// </param>
        public SwitchableDecimalProperty(
            string name,
            decimal value,
            bool valid,
            decimal valueRange1,
            decimal valueRange2,
            int decimalPlaces)
            : base(name, value, valid)
        {
            // 最大値と最小値設定
            _maxValue = Math.Max(valueRange1, valueRange2);
            _minValue = Math.Min(valueRange1, valueRange2);

            // 小数点以下桁数設定
            _decimalPlaces =
                Math.Min(Math.Max(decimalPlaces, -1), MaxDecimalPlaces);

            // 値補正のため再度設定
            OriginalValue = value;
        }

        /// <summary>
        /// 内部値を double 値で取得または設定する。
        /// </summary>
        public double OriginalDoubleValue
        {
            get { return (double)OriginalValue; }
            set { OriginalValue = (decimal)value; }
        }

        /// <summary>
        /// 内部値を float 値で取得または設定する。
        /// </summary>
        public float OriginalSingleValue
        {
            get { return (float)OriginalValue; }
            set { OriginalValue = (decimal)value; }
        }

        /// <summary>
        /// 内部値を int 値で取得または設定する。
        /// </summary>
        public int OriginalInt32Value
        {
            get { return (int)OriginalValue; }
            set { OriginalValue = value; }
        }

        /// <summary>
        /// 有効状態ならば内部値を、無効状態ならば null 値を取得する。
        /// </summary>
        public new decimal? Value
        {
            get { return Valid ? (decimal?)OriginalValue : null; }
        }

        /// <summary>
        /// 有効状態ならば double 値を、無効状態ならば null 値を取得する。
        /// </summary>
        public double? DoubleValue
        {
            get { return Valid ? (double?)OriginalDoubleValue : null; }
        }

        /// <summary>
        /// 有効状態ならば float 値を、無効状態ならば null 値を取得する。
        /// </summary>
        public float? SingleValue
        {
            get { return Valid ? (float?)OriginalSingleValue : null; }
        }

        /// <summary>
        /// 有効状態ならば int 値を、無効状態ならば null 値を取得する。
        /// </summary>
        public int? Int32Value
        {
            get { return Valid ? (int?)OriginalInt32Value : null; }
        }

        /// <summary>
        /// 設定可能な最大値を取得または設定する。
        /// </summary>
        public decimal MaxValue
        {
            get { return _maxValue; }
            set
            {
                _maxValue = value;
                if (_minValue > value)
                {
                    _minValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        /// <summary>
        /// 設定可能な最小値を取得または設定する。
        /// </summary>
        public decimal MinValue
        {
            get { return _minValue; }
            set
            {
                _minValue = value;
                if (_maxValue < value)
                {
                    _maxValue = value;
                }

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        /// <summary>
        /// 小数部の桁数を取得または設定する。補正しないならば負数となる。
        /// </summary>
        public int DecimalPlaces
        {
            get { return _decimalPlaces; }
            set
            {
                _decimalPlaces =
                    Math.Min(Math.Max(value, -1), MaxDecimalPlaces);

                // 値補正
                OriginalValue = OriginalValue;
            }
        }

        #region SwitchablePropertyBase<double> メンバ

        protected override bool ValidateValue(ref decimal value)
        {
            value = Math.Min(Math.Max(value, this.MinValue), this.MaxValue);
            if (this.DecimalPlaces >= 0)
            {
                // 多い桁を削る
                value = decimal.Round(value, this.DecimalPlaces);

                // 足りない桁を付け足す
                string valStr = value.ToString();
                int digits = valStr.IndexOf('.');
                digits = (digits < 0) ? 0 : (valStr.Length - digits - 1);
                for (; digits < this.DecimalPlaces; ++digits)
                {
                    value *= 1.0m;
                }
            }
            return true;
        }

        protected override SwitchablePropertyBase CreateInstance(string name)
        {
            return new SwitchableDecimalProperty(name, DefaultValue, false);
        }

        protected override void CopyFrom(SwitchablePropertyBase src)
        {
            var prop = (SwitchableDecimalProperty)src;
            base.CopyFrom(prop);
            this._maxValue = prop.MaxValue;
            this._minValue = prop.MinValue;
            this._decimalPlaces = prop.DecimalPlaces;
        }

        protected override bool IsValueEquals(SwitchablePropertyBase other)
        {
            var prop = (SwitchableDecimalProperty)other;
            return (
                base.IsValueEquals(prop) &&
                this.MaxValue == prop.MaxValue &&
                this.MinValue == prop.MinValue &&
                this.DecimalPlaces == prop.DecimalPlaces);
        }

        #endregion

        #region PropertyBase メンバ

        public override bool CanUseScript
        {
            get { return true; }
        }

        public override object ScriptValue
        {
            get { return (double)OriginalValue; }
            set { OriginalValue = (decimal)value; }
        }

        public override PropertyInterpolationType SupportInterpolationType
        {
            get
            {
                return (
                    PropertyInterpolationType.Fixed |
                    PropertyInterpolationType.Liner |
                    PropertyInterpolationType.CatmullRom);
            }
        }

        public override PropertyBase Interpolation(
            KeyFrame[] keyFrame,
            double time)
        {
            // 前方キーフレーム取得
            KeyFrame prevKey = Util.GetPrevKeyFrame(keyFrame, time);
            if (prevKey == null)
            {
                return Util.GetAboveKeyFrame(keyFrame, time).Property;
            }
            if (
                prevKey.Type == PropertyInterpolationType.Fixed ||
                prevKey.Time >= time)
            {
                return prevKey.Property;
            }

            // 後方キーフレーム取得
            KeyFrame nextKey = Util.GetAboveKeyFrame(keyFrame, time);
            if (nextKey == null)
            {
                return prevKey.Property;
            }

            // 補間処理
            var prevProp = (SwitchableDecimalProperty)prevKey.Property;
            var nextProp = (SwitchableDecimalProperty)nextKey.Property;
            decimal value = prevProp.OriginalValue;
            switch (prevKey.Type)
            {
            case PropertyInterpolationType.Liner:
                // リニア補間
                value = (decimal)ValueInterpolationMethod.Linear(
                    prevKey.Time,
                    (double)prevProp.OriginalValue,
                    nextKey.Time,
                    (double)nextProp.OriginalValue,
                    time);
                break;

            case PropertyInterpolationType.CatmullRom:
                // CatmullRom補間
                {
                    // 更に外のキーフレーム取得
                    KeyFrame prev2Key =
                        Util.GetBelowKeyFrame(keyFrame, prevKey.Time) ?? prevKey;
                    KeyFrame next2Key =
                        Util.GetAboveKeyFrame(keyFrame, nextKey.Time) ?? nextKey;
                    var prev2Prop = (SwitchableDecimalProperty)prev2Key.Property;
                    var next2Prop = (SwitchableDecimalProperty)next2Key.Property;

                    // 補間
                    value = (decimal)ValueInterpolationMethod.CatmullRom(
                        (double)prev2Prop.OriginalValue,
                        (double)prevProp.OriginalValue,
                        (double)nextProp.OriginalValue,
                        (double)next2Prop.OriginalValue,
                        prevKey.Time,
                        nextKey.Time,
                        time);
                }
                break;
            }

            return new SwitchableDecimalProperty(
                prevProp.PropertyName,
                value,
                prevProp.Valid,
                Math.Min(prevProp.MinValue, nextProp.MinValue),
                Math.Max(prevProp.MaxValue, nextProp.MaxValue));
        }

        #endregion
    }
}
