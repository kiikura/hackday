﻿using System;
using System.Drawing;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Utils;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 文字列を保持するプロパティを生成するデリゲート。
    /// </summary>
    /// <typeparam name="PropertyType">プロパティの型。</typeparam>
    /// <param name="name">プロパティ名。</param>
    /// <param name="value">文字列値。</param>
    /// <returns>生成されたプロパティ。</returns>
    public delegate PropertyType CreateTextPropertyDelegate<PropertyType>(
        string name,
        string value);

    /// <summary>
    /// 文字列を保持するプロパティから文字列値を取得するデリゲート。
    /// </summary>
    /// <typeparam name="PropertyType">プロパティの型。</typeparam>
    /// <param name="property">プロパティ。</param>
    /// <returns>文字列値。</returns>
    public delegate string GetTextPropertyValueDelegate<PropertyType>(
        PropertyType property);

    /// <summary>
    /// 文字列を保持するプロパティをテキストボックスまたは文字列編集ダイアログで
    /// 設定するNiVE2プロパティエディットコントロールクラス。
    /// </summary>
    /// <typeparam name="PropertyType">
    /// プロパティの型。
    /// この型には、第1引数にプロパティ名、第2引数に文字列値を受け取る
    /// パブリックなコンストラクタが定義されている必要がある。
    /// 定義されていない場合は実行時に例外が送出される。
    /// ただし CreatePropertyDelegate プロパティに有効なデリゲートが
    /// 設定されている場合は該当のコンストラクタが定義されている必要はない。
    /// </typeparam>
    public class TextPropertyEditControl<PropertyType> : PropertyEditControlBase
        where PropertyType : PropertyBase
    {
        private TextBox editText;
        private Label labelText;

        /// <summary>
        /// 文字列が空であることを示すラベル表示テキスト。
        /// </summary>
        private const string BlankLabelText = "<空のテキスト>";

        /// <summary>
        /// 文字列が複数行であることを示すラベル表示フォーマット。
        /// {0} に1行目の文字列を、 {1} に行数を受け取る。
        /// </summary>
        private const string MultilineLabelFormat = "{0}...<{1}行>";

        /// <summary>
        /// 現在のテキスト。
        /// </summary>
        private string _text = string.Empty;

        /// <summary>
        /// ラベル用フォント。
        /// </summary>
        private Font _fontLabel = null;

        /// <summary>
        /// テキストボックス用フォント。
        /// </summary>
        private Font _fontBox = null;

        /// <summary>
        /// プロパティを生成するデリゲート。
        /// </summary>
        private CreateTextPropertyDelegate<PropertyType> _createDelegate = null;

        /// <summary>
        /// プロパティから文字列値を得るデリゲート。
        /// </summary>
        private GetTextPropertyValueDelegate<PropertyType> _getValueDelegate = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        public TextPropertyEditControl(string name)
            : this(name, true)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="multiline">複数行編集するならば true 。</param>
        public TextPropertyEditControl(string name, bool multiline)
            : this(name, multiline, 0)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="multiline">複数行編集するならば true 。</param>
        /// <param name="maxLength">最大文字数。 0 ならば無制限。</param>
        public TextPropertyEditControl(
            string name, bool multiline, int maxLength)
            : this(name, multiline, maxLength, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="multiline">複数行編集するならば true 。</param>
        /// <param name="fontFamily">
        /// ラベルおよびテキストボックスのフォントファミリ。
        /// null ならば既定のフォントファミリを用いる。
        /// </param>
        public TextPropertyEditControl(
            string name, bool multiline, FontFamily fontFamily)
            : this(name, multiline, 0, fontFamily)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="name">対応するプロパティ名。</param>
        /// <param name="multiline">複数行編集するならば true 。</param>
        /// <param name="maxLength">最大文字数。 0 ならば無制限。</param>
        /// <param name="fontFamily">
        /// ラベルおよびテキストボックスのフォントファミリ。
        /// null ならば既定のフォントファミリを用いる。
        /// </param>
        public TextPropertyEditControl(
            string name,
            bool multiline,
            int maxLength,
            FontFamily fontFamily)
        {
            PropertyName = name;
            LabelName = name;

            // コントロール設定
            InitializeComponent();

            Multiline = multiline;
            MaxLength = maxLength;

            // フォント設定
            _fontBox = new Font(
                fontFamily ?? DefaultFont.FontFamily, 9F, GraphicsUnit.Point);
            _fontLabel = new Font(_fontBox, FontStyle.Underline);
            editText.Font = _fontBox;
            labelText.Font = _fontLabel;
        }

        /// <summary>
        /// 複数行編集を行うか否かを取得または設定する。既定では true 。
        /// </summary>
        public bool Multiline
        {
            get { return editText.Multiline; }
            set { editText.Multiline = value; }
        }

        /// <summary>
        /// 入力可能な最大文字数を取得または設定する。 0 ならば無制限となる。
        /// </summary>
        public int MaxLength
        {
            get { return editText.MaxLength; }
            set { editText.MaxLength = value; }
        }

        /// <summary>
        /// テキストボックスによる編集中であるか否かを取得する。
        /// </summary>
        public bool IsLineEditing
        {
            get { return editText.Visible; }
        }

        /// <summary>
        /// プロパティを生成するデリゲートを取得または設定する。既定では null 。
        /// </summary>
        public CreateTextPropertyDelegate<PropertyType> CreatePropertyDelegate
        {
            get { return _createDelegate; }
            set { _createDelegate = value; }
        }

        /// <summary>
        /// プロパティから文字列値を取得するデリゲートを取得または設定する。
        /// 既定では null 。
        /// </summary>
        public GetTextPropertyValueDelegate<PropertyType> GetPropertyValueDelegate
        {
            get { return _getValueDelegate; }
            set { _getValueDelegate = value; }
        }

        /// <summary>
        /// 新しいプロパティを作成する。
        /// </summary>
        /// <param name="value">文字列値。</param>
        /// <returns>プロパティ。</returns>
        /// <remarks>
        /// CreatePropertyDelegate プロパティに有効なデリゲートが設定されている
        /// 場合はそれを呼び出す。
        /// そうでない場合、第1引数にプロパティ名、第2引数に文字列値を受け取る
        /// PropertyType のパブリックなコンストラクタを呼び出す。
        /// 該当するコンストラクタが定義されていない場合は例外が送出される。
        /// 
        /// このメソッドで作成されたプロパティを引数にして
        /// SetProperty メソッドが呼び出される。
        /// </remarks>
        private PropertyType CreateProperty(string value)
        {
            PropertyType prop;

            if (this.CreatePropertyDelegate == null)
            {
                prop = (PropertyType)Activator.CreateInstance(
                    typeof(PropertyType),
                    PropertyName,
                    value);
            }
            else
            {
                prop = this.CreatePropertyDelegate(PropertyName, value);
            }

            return prop;
        }

        /// <summary>
        /// プロパティから文字列値を取得する。
        /// </summary>
        /// <param name="property">プロパティ。</param>
        /// <returns>文字列値。</returns>
        /// <remarks>
        /// GetPropertyValueDelegate プロパティに有効なデリゲートが
        /// 設定されている場合はそれを呼び出す。
        /// そうでない場合は PropertyType.Value プロパティの値を string 型に
        /// キャストする。
        /// 
        /// いずれの場合も、結果として null を取得した場合は空文字列値を返す。
        /// </remarks>
        private string GetPropertyText(PropertyType property)
        {
            string value;

            if (this.GetPropertyValueDelegate == null)
            {
                value = (string)property.Value;
            }
            else
            {
                value = this.GetPropertyValueDelegate(property);
            }

            return value ?? string.Empty;
        }

        /// <summary>
        /// 文字列値を指定して文字列プロパティを設定する。
        /// </summary>
        /// <param name="value">文字列値。</param>
        public void SetStringProperty(string value)
        {
            SetProperty(CreateProperty(value));
        }

        /// <summary>
        /// テキストボックスによる文字列の編集を開始する。
        /// </summary>
        private void BeginLineEdit()
        {
            if (!IsLineEditing)
            {
                // 編集モード開始
                labelText.Visible = false;
                editText.Visible = true;

                // 全選択してフォーカス
                editText.SelectAll();
                editText.Focus();
            }
        }

        /// <summary>
        /// テキストボックスによる文字列の編集を完了する。
        /// </summary>
        private void EndLineEdit()
        {
            if (IsLineEditing)
            {
                if (editText.Text != _text)
                {
                    // 値が変わっていたらプロパティ更新
                    SetStringProperty(editText.Text);
                }

                // 編集モード終了
                editText.Visible = false;
                labelText.Visible = true;
                labelText.Focus();
            }
        }

        /// <summary>
        /// テキストボックスによる文字列の編集をキャンセルする。
        /// </summary>
        private void CancelLineEdit()
        {
            if (IsLineEditing)
            {
                // 編集前のテキストに戻す
                editText.Text = _text;

                // 編集モード終了
                editText.Visible = false;
                labelText.Visible = true;
                labelText.Focus();
            }
        }

        #region PropertyEditControlBase メンバ

        public override int SpliterDistance
        {
            get
            {
                return base.SpliterDistance;
            }
            set
            {
                base.SpliterDistance = value;

                // コントロールの位置合わせを行う
                int x = value + Util.PropertyEditControlLeftDistance;
                int w = Math.Max(
                    this.Width - value - Util.PropertyEditControlHiddenWidth,
                    20);
                Rectangle bounds = labelText.Bounds;
                if (bounds.X != x || bounds.Width != w)
                {
                    bounds.X = x;
                    bounds.Width = w;
                    labelText.Bounds = bounds;
                }
                bounds = editText.Bounds;
                if (bounds.X != x || bounds.Width != w)
                {
                    bounds.X = x;
                    bounds.Width = w;
                    editText.Bounds = bounds;
                }
            }
        }

        public override Type UseProperetyType()
        {
            return typeof(PropertyType);
        }

        public override void ChangeProperty(PropertyBase property)
        {
            // 表示文字列更新
            var prop = property as PropertyType;
            if (prop != null)
            {
                _text = GetPropertyText(prop);
                editText.Text = _text;
                if (string.IsNullOrEmpty(_text))
                {
                    labelText.Text = BlankLabelText;
                }
                else
                {
                    string[] lines = _text.Split(
                        new string[] { "\r\n", "\r", "\n" },
                        StringSplitOptions.None);
                    switch (lines.Length)
                    {
                    case 0:
                        labelText.Text = BlankLabelText;
                        break;
                    case 1:
                        labelText.Text = lines[0];
                        break;
                    default:
                        labelText.Text = string.Format(
                            MultilineLabelFormat,
                            lines[0],
                            lines.Length);
                        break;
                    }
                }
            }

            base.ChangeProperty(property);
        }

        protected override void Dispose(bool disposing)
        {
            if (_fontLabel != null)
            {
                _fontLabel.Dispose();
                _fontLabel = null;
            }
            if (_fontBox != null)
            {
                _fontBox.Dispose();
                _fontBox = null;
            }

            base.Dispose(disposing);
        }

        #endregion

        private void InitializeComponent()
        {
            this.editText = new System.Windows.Forms.TextBox();
            this.labelText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // editText
            // 
            this.editText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.editText.Location = new System.Drawing.Point(115, 3);
            this.editText.Name = "editText";
            this.editText.Size = new System.Drawing.Size(100, 12);
            this.editText.TabIndex = 2;
            this.editText.Visible = false;
            this.editText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.editText_KeyDown);
            this.editText.Leave += new System.EventHandler(this.editText_Leave);
            this.editText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editText_KeyPress);
            // 
            // labelText
            // 
            this.labelText.Location = new System.Drawing.Point(114, 3);
            this.labelText.Name = "labelText";
            this.labelText.Size = new System.Drawing.Size(101, 12);
            this.labelText.TabIndex = 3;
            this.labelText.Click += new System.EventHandler(this.labelText_Click);
            // 
            // TextPropertyEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.editText);
            this.Controls.Add(this.labelText);
            this.Name = "TextPropertyEditControl";
            this.SizeChanged += new System.EventHandler(this.TextPropertyEditControl_SizeChanged);
            this.Controls.SetChildIndex(this.labelText, 0);
            this.Controls.SetChildIndex(this.editText, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelText_Click(object sender, EventArgs e)
        {
            labelText.Focus();

            if (Multiline)
            {
                // 編集ダイアログ表示
                using (TextEditDialog dialog = new TextEditDialog())
                {
                    dialog.Text = _text;
                    dialog.MaxLength = this.MaxLength;
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        // プロパティ更新
                        SetStringProperty(dialog.Text);
                    }
                }
            }
            else if (!IsLineEditing)
            {
                // 編集モード開始
                BeginLineEdit();
            }
        }

        private void editText_Leave(object sender, EventArgs e)
        {
            if (IsLineEditing)
            {
                // フォーカスが離れたら編集完了
                EndLineEdit();
            }
        }

        private void editText_KeyDown(object sender, KeyEventArgs e)
        {
            if (IsLineEditing)
            {
                switch (e.KeyCode)
                {
                    case Keys.Enter:
                        // Enterキー投下で編集完了
                        EndLineEdit();
                        break;

                    case Keys.Escape:
                        // Escキー投下で編集キャンセル
                        CancelLineEdit();
                        break;
                }
            }
        }

        private void editText_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 編集終了済みならキー入力を受け付けない
            if (!IsLineEditing)
            {
                e.Handled = true;
            }
        }

        private void TextPropertyEditControl_SizeChanged(object sender, EventArgs e)
        {
            // AddablePropertyEditControl に追加された時に
            // 子コントロールの配置がずれることへの対策。
            this.SpliterDistance = this.SpliterDistance;
        }
    }
}
