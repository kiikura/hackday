﻿using System;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using NiVE2.Utils;

namespace ruche.nive2.effects.wpf
{
    /// <summary>
    /// WPFブラシプロパティを提供するNiVE2エフェクトクラス。
    /// </summary>
    public class ExpressionBrush : EffectBase
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public ExpressionBrush()
        {
            // ベーススレッド通知
            SafeInvoker.NotifyBaseThread();
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "エクスプレッション制御"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            // 何もしない
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            return new PropertyBase[]
                {
                    new BrushProperty("Brush"),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            return new PropertyEditControlBase[]
                {
                    new BrushPropertyEditControl("Brush"),
                };
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // 何もしない
            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 何もしない
            return audio;
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "WPFブラシ制御"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "WPFブラシプロパティを提供します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
