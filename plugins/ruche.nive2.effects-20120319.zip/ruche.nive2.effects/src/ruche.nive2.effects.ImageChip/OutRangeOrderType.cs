﻿using System;
using System.ComponentModel;

namespace ruche.nive2.effects
{
    /// <summary>
    /// 範囲外の番号指定に対する処理方法を表す列挙。
    /// </summary>
    internal enum OutRangeOrderType
    {
        [Description("なし")]
        [EnumDefaultValue]
        None,

        [Description("ループ")]
        Loop,

        [Description("範囲内に丸める")]
        Round,
    }
}
