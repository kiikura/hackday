﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Property;
using NiVE2.Plugin.Controls;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using NiVE2.Utils;

namespace ruche.nive2.effects
{
    /// <summary>
    /// レイヤーを分割して番号指定で描画するNiVE2エフェクトクラス。
    /// </summary>
    [SimulationEffect]
    [UseLayer]
    public class ImageChip : EffectBase
    {
        /// <summary>
        /// ブレンド種別配列。
        /// </summary>
        private static readonly BlendType[] BlendTypes;

        /// <summary>
        /// ブレンド種別名配列。
        /// </summary>
        private static readonly string[] BlendTypeNames;

        /// <summary>
        /// 反転種別配列。
        /// </summary>
        private static readonly FlipType[] FlipTypes;

        /// <summary>
        /// 反転種別名配列。
        /// </summary>
        private static readonly string[] FlipTypeNames;

        /// <summary>
        /// 各桁チップの追加方向配列。
        /// </summary>
        private static readonly Keys[] ChipDrawDirections =
            new Keys[]
                {
                    Keys.Right,
                    Keys.Down,
                    Keys.Left,
                    Keys.Up,
                };

        /// <summary>
        /// 各桁チップの追加方向名配列。
        /// </summary>
        private static readonly string[] ChipDrawDirectionNames =
            new string[]
                {
                    "→",
                    "↓",
                    "←",
                    "↑",
                };

        /// <summary>
        /// 基準点に対する配置の配列。
        /// </summary>
        private static readonly BaseAlignment[] BaseAlignments =
            new BaseAlignment[]
                {
                    BaseAlignment.Near,
                    BaseAlignment.Center,
                    BaseAlignment.Far,
                };

        /// <summary>
        /// 範囲外番号処理種別配列。
        /// </summary>
        private static readonly OutRangeOrderType[] OutRangeOrderTypes;

        /// <summary>
        /// 範囲外番号処理種別名配列。
        /// </summary>
        private static readonly string[] OutRangeOrderTypeNames;

        /// <summary>
        /// 回転の基準点種別配列。直接指定の場合は null 。
        /// </summary>
        private static readonly RectangleAlignment?[] RotateBaseTypes;

        /// <summary>
        /// 回転の基準点種別名配列。
        /// </summary>
        private static readonly string[] RotateBaseTypeNames;

        /// <summary>
        /// グラデーション方向配列。
        /// </summary>
        private static readonly GradientDirection[] GradientDirs;

        /// <summary>
        /// グラデーション方向名配列。
        /// </summary>
        private static readonly string[] GradientDirNames;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static ImageChip()
        {
            // ブレンドの種別配列とその名前配列初期化
            Util.GetEnumDescriptions(out BlendTypes, out BlendTypeNames);

            // 反転の種別配列とその名前配列初期化
            Util.GetEnumDescriptions(out FlipTypes, out FlipTypeNames);

            // 範囲外番号処理種別配列とその名前配列初期化
            Util.GetEnumDescriptions(
                out OutRangeOrderTypes,
                out OutRangeOrderTypeNames);

            // 回転の基準点種別配列とその名前配列初期化
            {
                IDictionary<RectangleAlignment, string> dict =
                    Util.GetEnumDescriptions<RectangleAlignment>();

                List<RectangleAlignment?> types =
                    new List<RectangleAlignment?>(dict.Count + 1);
                List<string> names = new List<string>(types.Capacity);

                types.Add(null);
                names.Add("直接指定");
                foreach (KeyValuePair<RectangleAlignment, string> v in dict)
                {
                    types.Add(v.Key);
                    names.Add("元レイヤーの" + v.Value);
                }

                RotateBaseTypes = types.ToArray();
                RotateBaseTypeNames = names.ToArray();
            }

            // グラデーションの配列とその名前配列初期化
            Util.GetEnumDescriptions(out GradientDirs, out GradientDirNames);
        }

        /// <summary>
        /// 番号からチップのX,Yインデックス位置を算出する。
        /// </summary>
        /// <param name="index">番号。</param>
        /// <param name="startIndex">開始番号。</param>
        /// <param name="countX">横方向のチップ数。</param>
        /// <param name="countY">縦方向のチップ数。</param>
        /// <param name="vertical">番号割り振りが縦方向ならば true 。</param>
        /// <returns>
        /// チップのX,Yインデックス位置。範囲外ならば new Point(-1, -1) 。
        /// </returns>
        private static Point CalcChipPosition(
            int index,
            int startIndex,
            int countX,
            int countY,
            bool vertical)
        {
            index -= startIndex;
            if (index < 0 || index >= countX * countY)
            {
                return new Point(-1, -1);
            }
            return vertical ?
                new Point(index / countY, index % countY) :
                new Point(index % countX, index / countX);
        }

        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public ImageChip()
        {
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "チャンネル"; }
        }

        public override bool IsAudioEffect
        {
            get { return false; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            SizeF size = _layer.GetImageBounds(0.0).Size;
            PointF basePos = new PointF(size.Width * 0.5F, size.Height * 0.5F);

            return new PropertyBase[]
                {
                    new SwitchableIntArrayProperty(
                        "番号列", new int[] { 0 }, true),
                    new SwitchableNumberArrayProperty(
                        "各表示秒数",
                        new double[] { 0.5 },
                        true,
                        0,
                        double.MaxValue),
                    new SelectableProperty(
                        "ブレンド",
                        Util.FindEnumDefaultValue(BlendTypes),
                        BlendTypeNames),
                    new NumberProperty("不透明度", 100.0, 100.0, 0.0),
                    new BooleanProperty("ネガポジ", false),
                    new SelectableProperty(
                        "反転",
                        Util.FindEnumDefaultValue(FlipTypes),
                        FlipTypeNames),
                    // チップ
                        new LayerSelectableProperty("レイヤー"),
                        new VertexProperty(
                            "分割開始位置",
                            Point.Empty,
                            double.MaxValue,
                            double.MinValue),
                        new VertexProperty(
                            "分割サイズ",
                            new Size(32, 32),
                            double.MaxValue,
                            0),
                        new VertexProperty(
                            "最大分割個数",
                            new Size(1000, 1000),
                            int.MaxValue,
                            1),
                        new NumberProperty(
                            "開始番号", 0, int.MaxValue, int.MinValue),
                        new SelectableProperty(
                            "番号割り振り",
                            0,
                            new string[]{ "横方向", "縦方向" }),
                        new SelectableProperty(
                            "範囲外番号処理",
                            Util.FindEnumDefaultValue(OutRangeOrderTypes),
                            OutRangeOrderTypeNames),
                    // 各桁描画
                        new BooleanProperty("各:有効", false),
                        new SelectableProperty(
                            "各:チップ追加方向", 0, ChipDrawDirectionNames),
                    // 配置
                        new VertexProperty(
                            "配:基準点",
                            basePos,
                            double.MaxValue,
                            double.MinValue),
                        new SelectableProperty(
                            "配:横基準", 1, new string[]{ "左", "中央", "右" }),
                        new SelectableProperty(
                            "配:縦基準", 1, new string[]{ "上", "中央", "下" }),
                        new VertexProperty(
                            "配:スケール",
                            new Size(100, 100),
                            double.MaxValue,
                            double.MinValue),
                    // 回転
                        new SelectableProperty(
                            "回:基準点",
                            Util.FindEnumDefaultValue(RotateBaseTypes),
                            RotateBaseTypeNames),
                        new VertexProperty(
                            "回:基準点指定",
                            basePos,
                            double.MaxValue,
                            double.MinValue),
                        new RadianProperty("回:回転量", 0, 0.0),
                    // 塗り潰し
                        new BooleanProperty("塗:有効", false),
                        new ColorProperty("塗:色", Color.Black),
                        new NumberProperty("塗:不透明度", 100.0, 100.0, 0.0),
                        // グラデーション
                            new BooleanProperty("塗:グ:有効", false),
                            new ColorProperty("塗:グ:色", Color.Black),
                            new NumberProperty("塗:グ:不透明度", 100.0, 100.0, 0.0),
                            new SelectableProperty(
                                "塗:グ:方向",
                                Util.FindEnumDefaultValue(GradientDirs),
                                GradientDirNames),
                    // 品質
                        new BooleanProperty("品:補間処理", true),
                        new BooleanProperty("品:縮小フィルタ", false),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            // 配列作成
            PropertyEditControlBase[] controls = new PropertyEditControlBase[]
                {
                    new SwitchableIntListPropertyEditControl(
                        "番号列", 1, false, true),
                    new SwitchableNumberListPropertyEditControl(
                        "各表示秒数", 1, false, true),
                    new SelectablePropertyEditControl("ブレンド"),
                    new NumberPropertyEditControl(
                        "不透明度", 1.0, NumberPropertyEditControlType.Double),
                    new BooleanPropertyEditControl("ネガポジ"),
                    new SelectablePropertyEditControl("反転"),
                    new PropertyNestBeginControl("チップ"),
                        new LayerSelectablePropertyEditControl(
                            "レイヤー",
                            _layer.Composition,
                            true,
                            false,
                            true,
                            false),
                        new VertexPropertyEditControl(
                            "分割開始位置",
                            1,
                            VertexPropertyEditControlType.PointFOrSizeF),
                        new VertexPropertyEditControl(
                            "分割サイズ",
                            1,
                            VertexPropertyEditControlType.PointFOrSizeF),
                        new VertexPropertyEditControl(
                            "最大分割個数",
                            1,
                            VertexPropertyEditControlType.PointOrSize),
                        new NumberPropertyEditControl(
                            "開始番号", 1, NumberPropertyEditControlType.Int),
                        new SelectablePropertyEditControl("番号割り振り"),
                        new SelectablePropertyEditControl("範囲外番号処理"),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("各桁描画"),
                        new BooleanPropertyEditControl("各:有効"),
                        new SelectablePropertyEditControl("各:チップ追加方向"),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("配置"),
                        new VertexPropertyEditControl(
                            "配:基準点",
                            1,
                            VertexPropertyEditControlType.PointFOrSizeF),
                        new SelectablePropertyEditControl("配:横基準"),
                        new SelectablePropertyEditControl("配:縦基準"),
                        new VertexPropertyEditControl(
                            "配:スケール",
                            1,
                            VertexPropertyEditControlType.PointFOrSizeF),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("回転"),
                        new SelectablePropertyEditControl("回:基準点"),
                        new VertexPropertyEditControl(
                            "回:基準点指定",
                            1,
                            VertexPropertyEditControlType.PointFOrSizeF),
                        new RadianPropertyEditControl("回:回転量"),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("塗り潰し"),
                        new BooleanPropertyEditControl("塗:有効"),
                        new ColorPropertyEditControl("塗:色"),
                        new NumberPropertyEditControl(
                            "塗:不透明度", 1.0, NumberPropertyEditControlType.Double),
                        new PropertyNestBeginControl("グラデーション"),
                            new BooleanPropertyEditControl("塗:グ:有効"),
                            new ColorPropertyEditControl("塗:グ:色"),
                            new NumberPropertyEditControl(
                                "塗:グ:不透明度", 1.0, NumberPropertyEditControlType.Double),
                            new SelectablePropertyEditControl("塗:グ:方向"),
                        new PropertyNestEndControl(),
                    new PropertyNestEndControl(),
                    new PropertyNestBeginControl("品質"),
                        new BooleanPropertyEditControl("品:補間処理"),
                        new BooleanPropertyEditControl("品:縮小フィルタ"),
                    new PropertyNestEndControl(),
                };

            // ラベル文字列設定
            foreach (PropertyEditControlBase c in controls)
            {
                Util.SetPropertyEditControlLabelByName(c, ":");
            }

            return controls;
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            // 特に変更しない
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            var indicesProp = (SwitchableIntArrayProperty)property["番号列"];
            double[] timeSpans =
                ((SwitchableNumberArrayProperty)property["各表示秒数"])
                    .OriginalValue;
            BlendType blendType =
                BlendTypes[((SelectableProperty)property["ブレンド"]).Selected];
            double alpha = ((NumberProperty)property["不透明度"]).DoubleValue;
            bool negaPosi = ((BooleanProperty)property["ネガポジ"]).Boolean;
            FlipType flipType =
                FlipTypes[((SelectableProperty)property["反転"]).Selected];
            int itemCode =
                ((LayerSelectableProperty)property["レイヤー"]).ItemCode;
            PointF splitPos =
                ((VertexProperty)property["分割開始位置"]).PointFValue;
            SizeF splitSize =
                ((VertexProperty)property["分割サイズ"]).SizeFValue;
            Size splitCounts =
                ((VertexProperty)property["最大分割個数"]).SizeValue;
            int startIndex = ((NumberProperty)property["開始番号"]).Int32Value;
            bool vertOrder =
                (((SelectableProperty)property["番号割り振り"]).Selected != 0);
            OutRangeOrderType outType = OutRangeOrderTypes[
                ((SelectableProperty)property["範囲外番号処理"]).Selected];
            bool digitEnabled = ((BooleanProperty)property["各:有効"]).Boolean;
            Keys digitDir = ChipDrawDirections[
                ((SelectableProperty)property["各:チップ追加方向"]).Selected];
            PointF basePos = ((VertexProperty)property["配:基準点"]).PointFValue;
            BaseAlignment horzAlign = BaseAlignments[
                ((SelectableProperty)property["配:横基準"]).Selected];
            BaseAlignment vertAlign = BaseAlignments[
                ((SelectableProperty)property["配:縦基準"]).Selected];
            SizeF scale = ((VertexProperty)property["配:スケール"]).SizeFValue;
            RectangleAlignment? rotateType = RotateBaseTypes[
                ((SelectableProperty)property["回:基準点"]).Selected];
            PointF rotatePos =
                ((VertexProperty)property["回:基準点指定"]).PointFValue;
            double rotateAngle = ((RadianProperty)property["回:回転量"]).Angle;
            bool fillEnabled = ((BooleanProperty)property["塗:有効"]).Boolean;
            Color fillColor = ((ColorProperty)property["塗:色"]).Color;
            double fillAlpha =
                ((NumberProperty)property["塗:不透明度"]).DoubleValue;
            bool fillGradEnabled =
                ((BooleanProperty)property["塗:グ:有効"]).Boolean;
            Color fillGradColor = ((ColorProperty)property["塗:グ:色"]).Color;
            double fillGradAlpha =
                ((NumberProperty)property["塗:グ:不透明度"]).DoubleValue;
            GradientDirection fillGradDir = GradientDirs[
                ((SelectableProperty)property["塗:グ:方向"]).Selected];
            bool interEnabled =
                ((BooleanProperty)property["品:補間処理"]).Boolean;
            bool filterEnabled =
                ((BooleanProperty)property["品:縮小フィルタ"]).Boolean;

            // 描画不要ならばそのまま返す
            if (alpha == 0.0 || scale.Width == 0.0 || scale.Height == 0.0)
            {
                return image;
            }

            // レイヤー取得
            ILayer srcLayer = Util.FindLayer(_layer.Composition, itemCode);
            if (srcLayer == null) { return image; }

            // 取得時間設定
            double t = srcLayer.ToLocalTime(_layer.ToWorldTime(time));

            // ソースレイヤーによる座標値補正
            SizeF srcSize = srcLayer.GetImageBounds(t).Size;
            float srcReso = (float)srcLayer.ResolutionRate;
            splitPos.X *= srcReso;
            splitPos.Y *= srcReso;
            splitSize.Width = Math.Min(
                splitSize.Width * srcReso,
                srcSize.Width - splitPos.X);
            splitSize.Height = Math.Min(
                splitSize.Height * srcReso,
                srcSize.Height - splitPos.Y);
            if (splitSize.Width <= 0 || splitSize.Height <= 0)
            {
                return image;
            }

            // 分割個数決定
            int countX = (int)((srcSize.Width - splitPos.X) / splitSize.Width);
            int countY = (int)((srcSize.Height - splitPos.Y) / splitSize.Height);
            countX = Math.Min(countX, splitCounts.Width);
            countY = Math.Min(countY, splitCounts.Height);
            int count = countX * countY;
            if (count <= 0) { return image; }

            // 番号決定
            int[] indices = indicesProp.OriginalValue;
            if (indices.Length >= 2)
            {
                // 表示秒数配列の要素数を揃える
                if (timeSpans.Length < indices.Length)
                {
                    // 足りない分に末尾の秒数を適用
                    var spans = timeSpans;
                    timeSpans = new double[indices.Length];
                    for (int i = 0; i < timeSpans.Length; ++i)
                    {
                        timeSpans[i] = (i < spans.Length) ?
                            spans[i] :
                            spans[spans.Length - 1];
                    }
                }
                else if (timeSpans.Length > indices.Length)
                {
                    // 余分な分をカット
                    var spans = timeSpans;
                    timeSpans = new double[indices.Length];
                    Array.Copy(spans, timeSpans, timeSpans.Length);
                }

                // キーフレームからの経過秒数取得
                double et = indicesProp.ElapsedTime;
                if (et < 0) { et = time; }

                // 番号列から対象を選択
                double totalSpan = 0;
                Array.ForEach(timeSpans, s => totalSpan += s);
                int pos = 0;
                if (totalSpan > 0)
                {
                    et -= Math.Floor(et / totalSpan) * totalSpan;
                    pos = Array.FindIndex(
                        timeSpans,
                        s => ((et -= s) <= 0 && s > 0));
                    if (pos < 0) { pos = 0; }
                }
                indices = new int[] { indices[pos] };
            }
            if (digitEnabled)
            {
                // 各桁描画用に配列入れ直し
                List<int> idxs = new List<int>();
                for (int n = indices[0]; n > 0; n /= 10)
                {
                    idxs.Insert(0, n % 10);
                }
                if (idxs.Count > 0)
                {
                    indices = idxs.ToArray();
                }
            }

            // 番号修正
            switch (outType)
            {
            case OutRangeOrderType.Loop:
                // ループ
                indices = Array.ConvertAll(
                    indices,
                    i =>
                    {
                        while (i < startIndex)
                        {
                            i += count;
                        }
                        while (i >= startIndex + count)
                        {
                            i -= count;
                        }
                        return i;
                    });
                break;

            case OutRangeOrderType.Round:
                // 丸める
                indices = Array.ConvertAll(
                    indices,
                    i => Math.Min(
                        Math.Max(i, startIndex),
                        startIndex + count - 1));
                break;

            case OutRangeOrderType.None:
            default:
                // 範囲内が1つも無ければ描画しない
                {
                    int pos = Array.FindIndex(
                        indices,
                        i => (i >= startIndex && i < startIndex + count));
                    if (pos < 0) { return image; }
                }
                break;
            }

            // チップ追加方向別の処理
            SizeF destSize = splitSize;
            bool destVert = false;
            switch (digitDir)
            {
            case Keys.Up:
                // 番号列を反転させて下方向として扱う
                Array.Reverse(indices);
                goto case Keys.Down;

            case Keys.Down:
                // イメージサイズ修正
                destSize.Height *= indices.Length;
                destVert = true;
                break;

            case Keys.Left:
                // 番号列を反転させて右方向として扱う
                Array.Reverse(indices);
                goto case Keys.Right;

            case Keys.Right:
            default:
                // イメージサイズ修正
                destSize.Width *= indices.Length;
                destVert = false;
                break;
            }

            // 必要なイメージバッファサイズを算出
            long bmpBufLen =
                (long)((srcSize.Width + 1.0) * 4 * (srcSize.Height + 1.0)) +
                (long)((destSize.Width + 1.0) * 4 * (destSize.Height + 1.0)) +
                (long)((splitSize.Width + 1.0) * 4 * (splitSize.Height + 1.0));

            // キャッシュを確保して描画イメージ作成
            using (CacheLocker cacheLock = new CacheLocker(bmpBufLen))
            using (
                NBitmap destBmp =
                    new NBitmap((int)destSize.Width, (int)destSize.Height))
            {
                // レイヤー画像取得
                using (NBitmap srcBmp = srcLayer.GetSourceImage(t))
                {
                    double dx = 0, dy = 0;
                    foreach (var i in indices)
                    {
                        // 番号からチップ位置算出
                        Point pos = CalcChipPosition(
                            i, startIndex, countX, countY, destVert);
                        if (pos.X >= 0 && pos.Y >= 0)
                        {
                            // 貼り付け元切り取り
                            double sx = splitPos.X + splitSize.Width * pos.X;
                            double sy = splitPos.Y + splitSize.Height * pos.Y;
                            using (
                                NBitmap temp = ImageUtil.CutImage(
                                    srcBmp,
                                    (int)(sx + 0.5),
                                    (int)(sy + 0.5),
                                    (int)(splitSize.Width + 1),
                                    (int)(splitSize.Height + 1)))
                            {
                                // 貼り付け先へ描画
                                ImageUtil.BlendImage(
                                    destBmp,
                                    temp,
                                    new PointF((float)dx, (float)dy),
                                    BlendType.Normal,
                                    interEnabled,
                                    false);
                            }
                        }

                        // 貼り付け先座標更新
                        if (destVert)
                        {
                            dy += splitSize.Height;
                        }
                        else
                        {
                            dx += splitSize.Width;
                        }
                    }
                }

                // ネガポジ反転
                if (negaPosi)
                {
                    ImageUtil.InvertImageColor(destBmp);
                }

                // 描画パラメータ作成
                ImageBlendingParam param;
                param.blendType = blendType;
                param.alpha = alpha / 100.0;
                param.flipType = flipType;
                param.basePos = basePos;
                param.horzAlign = horzAlign;
                param.vertAlign = vertAlign;
                param.scale =
                    new SizeF(scale.Width / 100.0F, scale.Height / 100.0F);
                param.rotateBaseAlign = rotateType;
                param.rotateBasePos = rotatePos;
                param.rotateAngle = rotateAngle;
                param.fillEnabled = fillEnabled;
                param.fillColor = fillColor;
                param.fillAlpha = fillAlpha / 100.0;
                param.fillGradientEnabled = fillGradEnabled;
                param.fillGradientColor = fillGradColor;
                param.fillGradientAlpha = fillGradAlpha / 100.0;
                param.fillGradientDirection = fillGradDir;
                param.interpolateEnabled = interEnabled;
                param.filterEnabled = filterEnabled;

                // 描画
                ImageUtil.BlendImage(
                    image, destBmp, param, roi, _layer.ResolutionRate);
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 呼ばれないはず
            throw new NotImplementedException();
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "イメージチップ"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "レイヤーを分割して番号指定で描画します。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
