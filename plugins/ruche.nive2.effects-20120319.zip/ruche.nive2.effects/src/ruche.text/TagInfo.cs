﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ruche.text
{
    /// <summary>
    /// タグの名前と属性情報を保持するクラス。
    /// </summary>
    [Serializable]
    public class TagInfo
        :
        IEnumerable<KeyValuePair<string, string>>,
        IEquatable<TagInfo>
    {
        /// <summary>
        /// タグ名。
        /// </summary>
        private string _tagName;

        /// <summary>
        /// 属性テーブル。
        /// </summary>
        private Dictionary<string, string> _attrTable;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        public TagInfo(string tagName)
            : this(tagName, (IDictionary<string, string>)null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <param name="attrTable">属性テーブル。</param>
        public TagInfo(string tagName, IDictionary<string, string> attrTable)
        {
            if (tagName == null)
            {
                throw new ArgumentNullException("tagName");
            }

            _tagName = tagName;
            _attrTable = (attrTable == null) ?
                new Dictionary<string, string>(0) :
                new Dictionary<string, string>(attrTable);
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <param name="attrSrc">属性テーブルのソース。</param>
        public TagInfo(string tagName, TagInfo attrSrc)
            : this(tagName, attrSrc._attrTable)
        {
        }

        /// <summary>
        /// タグ名を取得する。
        /// </summary>
        public string TagName
        {
            get { return _tagName; }
        }

        /// <summary>
        /// 属性数を取得する。
        /// </summary>
        public int AttrCount
        {
            get { return _attrTable.Count; }
        }

        /// <summary>
        /// 属性名コレクションを取得する。
        /// </summary>
        public ICollection<string> AttrNames
        {
            get { return _attrTable.Keys; }
        }

        /// <summary>
        /// 属性値を取得するインデクサ。
        /// </summary>
        /// <param name="attrName">属性名。</param>
        /// <returns>属性値。</returns>
        public string this[string attrName]
        {
            get { return _attrTable[attrName]; }
        }

        /// <summary>
        /// 指定した名前の属性を含むか否かを取得する。
        /// </summary>
        /// <param name="attrName">属性名。</param>
        /// <returns>含むならば true 。含まないならば false 。</returns>
        public bool ContainsAttr(string attrName)
        {
            return _attrTable.ContainsKey(attrName);
        }

        /// <summary>
        /// 属性名と値のテーブルを取得する。
        /// </summary>
        /// <returns>属性名と値のテーブル。</returns>
        public Dictionary<string, string> GetAttrTable()
        {
            return new Dictionary<string, string>(_attrTable);
        }

        #region Object メンバ

        public override string ToString()
        {
            string text = "<" + TagName;
            foreach (var kv in _attrTable)
            {
                text += " " + kv.Key + "=" + kv.Value;
            }
            text += " />";

            return text;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as TagInfo);
        }

        public override int GetHashCode()
        {
            return ToString().GetHashCode();
        }

        #endregion

        #region IEnumerable<KeyValuePair<string,string>> メンバ

        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            return _attrTable.GetEnumerator();
        }

        #endregion

        #region IEnumerable メンバ

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion

        #region IEquatable<TagInfo> メンバ

        public bool Equals(TagInfo other)
        {
            if (this == other)
            {
                return true;
            }

            if (
                other != null &&
                this.TagName == other.TagName &&
                this.AttrCount == other.AttrCount)
            {
                string value;
                foreach (var kv in this._attrTable)
                {
                    if (
                        !other._attrTable.TryGetValue(kv.Key, out value) ||
                        kv.Value != value)
                    {
                        return false;
                    }
                }
                return true;
            }

            return false;
        }

        #endregion
    }
}
