﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ruche.text
{
    /// <summary>
    /// タグ情報のコレクションクラス。
    /// </summary>
    [Serializable]
    public class TagInfoCollection : ReadOnlyCollection<TagInfo>
    {
        /// <summary>
        /// タグ名のコレクション。
        /// </summary>
        private ReadOnlyCollection<string> _tagNames;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TagInfoCollection() : this(new TagInfo[0])
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">基となるタグ情報列挙。</param>
        public TagInfoCollection(IEnumerable<TagInfo> src)
            : base(new List<TagInfo>(src))
        {
            List<string> names = new List<string>(Count);
            foreach (var ti in src)
            {
                if (ti == null)
                {
                    throw new ArgumentException(
                        "src の要素に null が含まれています。",
                        "src");
                }
                names.Add(ti.TagName);
            }
            _tagNames = new ReadOnlyCollection<string>(names);
        }

        /// <summary>
        /// タグ名のコレクションを取得する。
        /// </summary>
        public ReadOnlyCollection<string> TagNames
        {
            get { return _tagNames; }
        }

        /// <summary>
        /// 指定したタグ名のタグ情報の個数を取得する。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <returns>個数。</returns>
        public int GetCount(string tagName)
        {
            int count = 0;
            foreach (string name in _tagNames)
            {
                if (name == tagName)
                {
                    ++count;
                }
            }
            return count;
        }

        /// <summary>
        /// 指定したタグ名のタグ情報を検索する。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <returns>位置。見つからなかった場合は -1 。</returns>
        public int IndexOf(string tagName)
        {
            return IndexOf(tagName, 0);
        }

        /// <summary>
        /// 指定したタグ名のタグ情報を検索する。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <param name="startIndex">検索開始位置。</param>
        /// <returns>位置。見つからなかった場合は -1 。</returns>
        public int IndexOf(string tagName, int startIndex)
        {
            if (startIndex < 0)
            {
                throw new ArgumentOutOfRangeException(
                    "startIndex",
                    startIndex,
                    "startIndex の値が 0 未満です。");
            }

            for (int i = startIndex; i < _tagNames.Count; ++i)
            {
                if (_tagNames[i] == tagName)
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// 指定したタグ名のタグ情報が含まれているか否かを取得する。
        /// </summary>
        /// <param name="tagName">タグ名。</param>
        /// <returns>
        /// 含まれているならば true 。含まれていないならば false 。
        /// </returns>
        public bool Contains(string tagName)
        {
            return _tagNames.Contains(tagName);
        }
    }
}
