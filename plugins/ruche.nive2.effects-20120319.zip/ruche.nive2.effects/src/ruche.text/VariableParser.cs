﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ruche.text
{
    /// <summary>
    /// 変数文字列を変数値に変換する文字列パーサクラス。
    /// </summary>
    /// <remarks>
    /// 次のような形式の変数文字列を対応する変数値に置換する。
    /// 変数名が定義されていない場合は空文字列に置換する。
    /// 
    /// <list type="bullet">
    /// <item><description>$Name</description></item>
    /// <item>
    /// <description>$(Name[,Width[.Digits][,PadChar]])</description>
    /// </item>
    /// <item>
    /// <description>${Name[,Width[.Digits][,PadChar]]}</description>
    /// </item>
    /// </list>
    /// 
    /// '$' は Header プロパティで取得および設定可能な変数ヘッダを表す。
    /// 
    /// 'Name' は変数名を表し、英数字およびアンダーバーで構成される。
    /// 括弧で括られている場合、変数名の前後に空白を設けることができる。
    /// 
    /// 省略可能な 'Width' は展開される文字列の最小文字数を表す10進数値である。
    /// この値の絶対値よりも展開される文字列の文字数が少ない場合、
    /// 値が正ならば右詰めされ、値が負ならば左詰めされる。
    /// 
    /// 省略可能な 'Digits' は小数部の桁数を表す符号なしの10進数値である。
    /// この値が指定されると文字列は数値として解釈され、 'Width' は整数部の
    /// 桁数を表すようになる。
    /// 'Digits' の値が MaxDigits よりも大きい場合、
    /// または文字列を数値として解釈できなかった場合、この値は無視される。
    /// 
    /// 省略可能な 'PadChar' は 'Width' により文字列が拡張される場合の
    /// 拡張部分を埋める文字である。
    /// 指定しなかった場合、拡張部分は半角スペースで埋められる。
    /// 
    /// 変数名に変数自体を用いたり、変数値に変数文字列を入れることで
    /// 変数をネストすることもできる。
    /// 例えば $$Name と記述した場合、まず $Name が展開され、
    /// その値が "Foo" であった場合は次に $Foo が展開される。
    /// 更にその値が "$Var" であった場合は続けて $Var が展開される。
    /// ただし変数のネスト回数が MaxNest プロパティ値を超えた場合は
    /// VariableParser.NestException 例外が送出される。
    /// また、 MaxNest プロパティに -1 を設定するとこの処理を無効化する。
    /// </remarks>
    public class VariableParser
        :
        StringParserBase,
        IDictionary<string, string>
    {
        /// <summary>
        /// 変数のネスト回数が許容回数を超えた場合に送出される例外。
        /// </summary>
        public sealed class NestException : ArgumentException
        {
            /// <summary>
            /// コンストラクタ。
            /// </summary>
            /// <param name="paramName">対象パラメータ。</param>
            public NestException(string paramName)
                : base("変数のネスト回数が多すぎます。", paramName)
            {
            }
        }

        /// <summary>
        /// 既定の変数ヘッダ。
        /// </summary>
        public static readonly string DefaultHeader = "$";

        /// <summary>
        /// 既定の最大ネスト許容回数。
        /// </summary>
        public static readonly int DefaultMaxNest = 10;

        /// <summary>
        /// 小数部の最大桁数。
        /// </summary>
        public static readonly int MaxDigits = 15;

        /// <summary>
        /// 開始文字列を除く変数名の構成文字1文字にマッチする正規表現。
        /// </summary>
        public static readonly Regex RegexNameLetter;

        /// <summary>
        /// 開始文字列を除く変数名で始まる文字列にマッチする正規表現。
        /// </summary>
        protected static readonly Regex RegexName;

        /// <summary>
        /// 開始文字列を除く変数名に完全マッチする正規表現。
        /// </summary>
        protected static readonly Regex RegexCompleteName;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static VariableParser()
        {
            // 正規表現作成
            RegexNameLetter =
                new Regex(@"[a-zA-Z0-9_]", RegexOptions.CultureInvariant);
            RegexName = new Regex(
                @"^(" +
                    @"(?<Name>" + RegexNameLetter.ToString() + @"+)" +
                @"|" +
                    @"\(\s*" +
                        @"(?<Name>" + RegexNameLetter.ToString() + @"+)" +
                        @"(" +
                            @"\s*,\s*(?<Width>[\+\-]?[0-9]+)" +
                            @"(\s*\.\s*(?<Digits>[0-9]+))?" +
                            @"(\s*,\s*(?<PadChar>[^\)\$]))?" +
                        @")?" +
                    @"\s*\)" +
                @"|" +
                    @"\{\s*" +
                        @"(?<Name>" + RegexNameLetter.ToString() + @"+)" +
                        @"(" +
                            @"\s*,\s*(?<Width>[\+\-]?[0-9]+)" +
                            @"(\s*\.\s*(?<Digits>[0-9]+))?" +
                            @"(\s*,\s*(?<PadChar>[^\}\$]))?" +
                        @")?" +
                    @"\s*\}" +
                @")",
                RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture);
            RegexCompleteName = new Regex(
                RegexName.ToString() + @"$",
                RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture);
        }

        /// <summary>
        /// インスタンスを生成する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="variables">変数テーブル。</param>
        /// <returns>インスタンス。</returns>
        /// <remarks>
        /// 値は T.ToString を用いて文字列に変換される。
        /// </remarks>
        public static VariableParser Create<T>(
            IDictionary<string, T> variables)
        {
            return Create(variables, null);
        }

        /// <summary>
        /// インスタンスを生成する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="variables">変数テーブル。</param>
        /// <param name="valueConverter">
        /// 値のコンバータ。標準の変換処理を用いるならば null 。
        /// </param>
        /// <returns>インスタンス。</returns>
        /// <remarks>
        /// 標準では値は T.ToString を用いて文字列に変換される。
        /// </remarks>
        public static VariableParser Create<T>(
            IDictionary<string, T> variables,
            Converter<T, string> valueConverter)
        {
            var dest = new VariableParser(0);
            dest.InitializeVariables(variables, valueConverter);
            return dest;
        }

        /// <summary>
        /// 変数値文字列と正規表現マッチ結果を元に表示文字列を作成する。
        /// </summary>
        /// <param name="value">変数値文字列。</param>
        /// <param name="m">正規表現マッチ結果。</param>
        /// <returns>表示文字列。</returns>
        private static string MakeValueText(string value, Match m)
        {
            var gWidth = m.Groups["Width"];
            if (gWidth.Success)
            {
                int width = int.Parse(gWidth.Value);

                // 小数部処理
                var gDigits = m.Groups["Digits"];
                if (gDigits.Success)
                {
                    int digits = int.Parse(gDigits.Value);
                    if (digits >= 0 && digits <= MaxDigits)
                    {
                        decimal dval;
                        if (decimal.TryParse(value, out dval))
                        {
                            try
                            {
                                value = dval.ToString("F" + digits);
                            }
                            catch { }
                        }
                    }
                }

                // 埋め文字
                var gPadChar = m.Groups["PadChar"];
                char padChar = gPadChar.Success ? gPadChar.Value[0] : ' ';

                value = (width < 0) ?
                    value.PadRight(-width, padChar) :
                    value.PadLeft(width, padChar);
            }

            return value;
        }

        /// <summary>
        /// 変数テーブル。
        /// </summary>
        private Dictionary<string, string> _variables = null;

        /// <summary>
        /// 変数ヘッダ。
        /// </summary>
        private string _header = DefaultHeader;

        /// <summary>
        /// 変数の最大ネスト許容回数。 -1 ならばネストしない。
        /// </summary>
        private int _maxNest = DefaultMaxNest;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public VariableParser()
        {
            InitializeVariables(new Dictionary<string, string>(), null);
        }

        /// <summary>
        /// 静的生成メソッドのためのダミーコンストラクタ。
        /// </summary>
        /// <param name="dummy">ダミー引数。</param>
        private VariableParser(int dummy)
        {
        }

        /// <summary>
        /// 変数の個数を取得する。
        /// </summary>
        public int Count
        {
            get { return _variables.Count; }
        }

        /// <summary>
        /// 変数名のコレクションを取得する。
        /// </summary>
        public ICollection<string> Names
        {
            get { return _variables.Keys; }
        }

        /// <summary>
        /// 変数ヘッダを取得または設定する。
        /// null および空文字列は設定できない。
        /// </summary>
        public string Header
        {
            get { return _header; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value");
                }
                if (value.Length <= 0)
                {
                    throw new ArgumentException(
                        "変数ヘッダを空の文字列にはできません。",
                        "value");
                }

                _header = value;
            }
        }

        /// <summary>
        /// 変数の最大ネスト許容回数を取得または設定する。
        /// -1 ならばネスト処理を行わない。
        /// </summary>
        public int MaxNest
        {
            get { return _maxNest; }
            set { _maxNest = Math.Max(value, -1); }
        }

        /// <summary>
        /// 変数値を取得または設定するインデクサ。
        /// </summary>
        /// <param name="name">変数名。</param>
        /// <returns>変数値。存在しない場合は null 。</returns>
        public string this[string name]
        {
            get
            {
                string value;
                if (!_variables.TryGetValue(name, out value))
                {
                    value = null;
                }
                return value;
            }
            set
            {
                CheckVariableName(name);
                CheckVariableValue(value);

                _variables[name] = value;
            }
        }

        /// <summary>
        /// 指定した名前の変数が設定されているか否かを取得する。
        /// </summary>
        /// <param name="name">変数名。</param>
        /// <returns>
        /// 設定されているならば true 。そうでなければ false 。
        /// </returns>
        public bool Contains(string name)
        {
            return _variables.ContainsKey(name);
        }

        /// <summary>
        /// 変数を追加する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="name">変数名。</param>
        /// <param name="value">変数値データ。</param>
        public void Add<T>(string name, T value)
        {
            Add(name, value, null);
        }

        /// <summary>
        /// 変数を追加する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="name">変数名。</param>
        /// <param name="value">変数値データ。</param>
        /// <param name="valueConverter">
        /// 値のコンバータ。標準の変換処理を用いるならば null 。
        /// </param>
        public void Add<T>(
            string name,
            T value,
            Converter<T, string> valueConverter)
        {
            if (Contains(name))
            {
                throw new ArgumentException(
                    "変数名 " + name + " は既に存在します。",
                    "name");
            }

            SetValue(name, value, valueConverter);
        }

        /// <summary>
        /// 変数値を設定する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="name">変数名。存在しない場合は追加される。</param>
        /// <param name="value">変数値データ。</param>
        public void SetValue<T>(string name, T value)
        {
            SetValue(name, value, null);
        }

        /// <summary>
        /// 変数値を設定する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="name">変数名。存在しない場合は追加される。</param>
        /// <param name="value">変数値データ。</param>
        /// <param name="valueConverter">
        /// 値のコンバータ。標準の変換処理を用いるならば null 。
        /// </param>
        public void SetValue<T>(
            string name,
            T value,
            Converter<T, string> valueConverter)
        {
            this[name] = (valueConverter == null) ?
                value.ToString() :
                valueConverter(value);
        }

        /// <summary>
        /// 変数を削除する。
        /// </summary>
        /// <param name="name">変数名。</param>
        /// <returns>削除されたならば true 。そうでなければ false 。</returns>
        public bool Remove(string name)
        {
            return _variables.Remove(name);
        }

        /// <summary>
        /// 変数をクリアする。
        /// </summary>
        public void Clear()
        {
            _variables.Clear();
        }

        /// <summary>
        /// 有効な変数名であるか否かを調べる。
        /// </summary>
        /// <param name="name">変数名。</param>
        /// <returns>有効な変数名ならば true 。そうでなければ false 。</returns>
        public bool IsValidName(string name)
        {
            return (CheckVariableNameCore(name) == null);
        }

        /// <summary>
        /// 変数名と変数値の列挙子を取得する。
        /// </summary>
        /// <returns>変数名と変数値の列挙子。</returns>
        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            return _variables.GetEnumerator();
        }

        /// <summary>
        /// _variables メンバを初期化する。
        /// </summary>
        /// <typeparam name="T">データ型。</typeparam>
        /// <param name="variables">変数テーブル。</param>
        /// <param name="valueConverter">
        /// 値のコンバータ。標準の変換処理を用いるならば null 。
        /// </param>
        protected void InitializeVariables<T>(
            IDictionary<string, T> variables,
            Converter<T, string> valueConverter)
        {
            if (variables == null)
            {
                throw new ArgumentNullException("variables");
            }

            _variables = new Dictionary<string, string>(variables.Count);
            foreach (var kv in variables)
            {
                SetValue(kv.Key, kv.Value, valueConverter);
            }
        }

        /// <summary>
        /// 変数名をチェックし、不正である場合は例外を送出する。
        /// </summary>
        /// <param name="name">変数名。</param>
        protected void CheckVariableName(string name)
        {
            var ex = CheckVariableNameCore(name);
            if (ex != null)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 変数名をチェックし、不正である場合は例外値を返す。
        /// </summary>
        /// <param name="name">変数名。</param>
        /// <returns>不正ならば例外値。そうでなければ null 。</returns>
        protected virtual Exception CheckVariableNameCore(string name)
        {
            if (name == null)
            {
                return new ArgumentNullException(
                    "変数名を null にはできません。",
                    "name");
            }
            if (name.Length <= 0)
            {
                return new ArgumentException(
                    "変数名を空文字列にはできません。",
                    "name");
            }
            if (!RegexCompleteName.IsMatch(name))
            {
                return new ArgumentException(
                    name + " は有効な変数名ではありません。",
                    "name");
            }
            return null;
        }

        /// <summary>
        /// 変数値をチェックし、不正である場合は例外を送出する。
        /// </summary>
        /// <param name="value">変数値。</param>
        /// <remarks>既定では null を許容しない。</remarks>
        protected virtual void CheckVariableValue(string value)
        {
            if (value == null)
            {
                throw new ArgumentNullException(
                    "変数値を null にはできません。",
                    "value");
            }
        }

        #region StringParserBase メンバ

        protected override string ParseCore(string text)
        {
            StringBuilder dest = new StringBuilder(text.Length);

            // 最大ネスト許容回数までループ
            // (実ネスト回数 + 2) 回ループする
            for (int i = MaxNest + 2; i > 0 || MaxNest < 0; --i)
            {
                // 変換前テキスト保存
                string orgText = text;

                // 変換
                dest.Remove(0, dest.Length);
                while (true)
                {
                    int pos = text.IndexOf(Header);
                    if (pos >= 0)
                    {
                        // 変数の前までを追加
                        dest.Append(text, 0, pos);
                        text = text.Substring(pos + Header.Length);

                        // マッチング
                        Match m = RegexName.Match(text);
                        if (m.Success)
                        {
                            // 値を追加
                            // 定義されていなければ空文字列値とする
                            string value =
                                this[m.Groups["Name"].Value] ?? string.Empty;
                            dest.Append(MakeValueText(value, m));

                            text = text.Substring(m.Length);
                        }
                        else
                        {
                            // 変数ではないのでヘッダ文字列を追加して次へ
                            dest.Append(Header);
                        }
                    }
                    else
                    {
                        // 残りを追加して終了
                        dest.Append(text);
                        break;
                    }
                }

                // 変換前テキストと変わらないorネスト無効ならば完了
                text = dest.ToString();
                if (MaxNest < 0 || text == orgText)
                {
                    return text;
                }
            }

            // ネスト回数オーバー
            throw new NestException("text");
        }

        #endregion

        #region IDictionary<string,string> メンバ

        ICollection<string> IDictionary<string, string>.Keys
        {
            get { return this.Names; }
        }

        ICollection<string> IDictionary<string, string>.Values
        {
            get { return _variables.Values; }
        }

        string IDictionary<string, string>.this[string key]
        {
            get { return this[key]; }
            set { this[key] = value; }
        }

        void IDictionary<string, string>.Add(string key, string value)
        {
            this.Add(key, value);
        }

        bool IDictionary<string, string>.ContainsKey(string key)
        {
            return this.Contains(key);
        }

        bool IDictionary<string, string>.Remove(string key)
        {
            return this.Remove(key);
        }

        bool IDictionary<string, string>.TryGetValue(
            string key,
            out string value)
        {
            value = this[key];
            return (value != null);
        }

        #endregion

        #region ICollection<KeyValuePair<string,string>> メンバ

        void ICollection<KeyValuePair<string, string>>.Add(
            KeyValuePair<string, string> item)
        {
            this.Add(item.Key, item.Value);
        }

        void ICollection<KeyValuePair<string, string>>.Clear()
        {
            this.Clear();
        }

        bool ICollection<KeyValuePair<string, string>>.Contains(
            KeyValuePair<string, string> item)
        {
            var c = (ICollection<KeyValuePair<string, string>>)_variables;
            return c.Contains(item);
        }

        void ICollection<KeyValuePair<string, string>>.CopyTo(
            KeyValuePair<string, string>[] array,
            int arrayIndex)
        {
            var c = (ICollection<KeyValuePair<string, string>>)_variables;
            c.CopyTo(array, arrayIndex);
        }

        int ICollection<KeyValuePair<string, string>>.Count
        {
            get { return this.Count; }
        }

        bool ICollection<KeyValuePair<string, string>>.IsReadOnly
        {
            get { return false; }
        }

        bool ICollection<KeyValuePair<string, string>>.Remove(
            KeyValuePair<string, string> item)
        {
            var c = (ICollection<KeyValuePair<string, string>>)_variables;
            return c.Remove(item);
        }

        #endregion

        #region IEnumerable<KeyValuePair<string,string>> メンバ

        IEnumerator<KeyValuePair<string, string>>
            IEnumerable<KeyValuePair<string, string>>.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion

        #region IEnumerable メンバ

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
    }
}
