﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ruche.text
{
    /// <summary>
    /// タグテキストのパーサクラス。
    /// </summary>
    /// <remarks>
    /// &lt;TagName[ AttrName="AttrValue"[...]]&gt;Text&lt;/TagName&gt;
    /// もしくは &lt;TagName[ AttrName="AttrValue"[...]]/&gt; の形式で表される
    /// タグを含む文字列をタグテキストコレクションに変換する。
    /// </remarks>
    public class TaggedTextParser : IParser<TaggedTextCollection>
    {
        /// <summary>
        /// タグ種別を表す列挙。
        /// </summary>
        protected enum TagType
        {
            /// <summary>
            /// 独立タグ。
            /// </summary>
            Single,

            /// <summary>
            /// 開始タグ。
            /// </summary>
            Begin,

            /// <summary>
            /// 終端タグ。
            /// </summary>
            End,
        }

        /// <summary>
        /// タグデータ構造体。
        /// </summary>
        protected struct TagData
        {
            /// <summary>
            /// 種別。
            /// </summary>
            public TagType Type;

            /// <summary>
            /// タグ文字列長。
            /// </summary>
            public int Length;

            /// <summary>
            /// 名前。
            /// </summary>
            public string Name;

            /// <summary>
            /// 属性テーブル。
            /// </summary>
            public Dictionary<string, string> AttrTable;
        }

        /// <summary>
        /// タグ名の構成文字1文字にマッチする正規表現。
        /// </summary>
        public static readonly Regex RegexTagNameLetter;

        /// <summary>
        /// タグ属性名の構成文字1文字にマッチする正規表現。
        /// </summary>
        public static readonly Regex RegexAttrNameLetter;

        /// <summary>
        /// 独立タグで始まる文字列にマッチする正規表現。
        /// </summary>
        protected static readonly Regex RegexSingleTag;

        /// <summary>
        /// 包括開始タグで始まる文字列にマッチする正規表現。
        /// </summary>
        protected static readonly Regex RegexBeginTag;

        /// <summary>
        /// 包括終端タグで始まる文字列にマッチする正規表現。
        /// </summary>
        protected static readonly Regex RegexEndTag;

        /// <summary>
        /// 静的コンストラクタ。
        /// </summary>
        static TaggedTextParser()
        {
            // タグ名、タグ属性名の構成文字を表す正規表現
            RegexTagNameLetter = new Regex(
                @"[\w" + Regex.Escape(@"-.:!@") + @"]",
                RegexOptions.CultureInvariant);
            RegexAttrNameLetter = new Regex(
                @"[\w" + Regex.Escape(@"-.:") + @"]",
                RegexOptions.CultureInvariant);

            // タグ内の属性単体を表す正規表現
            string attrReg =
                @"(?<AttrName>" +
                RegexAttrNameLetter.ToString() +
                @"+)\s*=\s*" +
                @"(""(?<AttrValue>[^""]*)""|(?<AttrValue>[^\s>]+))";

            // 正規表現作成(いい加減に記述されていてもそれなりに解釈する)
            RegexSingleTag = new Regex(
                @"^<(?<TagName>" +
                RegexTagNameLetter.ToString() +
                @"+)[^>]*?(" + attrReg + @"[^>]*?)*/>",
                RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture);
            RegexBeginTag = new Regex(
                @"^<(?<TagName>" +
                RegexTagNameLetter.ToString() +
                @"+)[^>]*?(" + attrReg + @"[^>]*?)*(?<!/)>",
                RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture);
            RegexEndTag = new Regex(
                @"^</(?<TagName>" +
                RegexTagNameLetter.ToString() +
                @"+)\s*(?<!/)>",
                RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture);
        }

        /// <summary>
        /// 平文に対して適用する文字列パーサ。
        /// </summary>
        private IParser<string> _textParser;

        /// <summary>
        /// タグ属性内容に対して適用する文字列パーサ。
        /// </summary>
        private IParser<string> _attrValueParser;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TaggedTextParser()
            : this(null, null)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="textParser">
        /// 平文に対して適用する文字列パーサ。 null ならば適用しない。
        /// </param>
        /// <param name="attrValueParser">
        /// タグ属性内容に対して適用する文字列パーサ。 null ならば適用しない。
        /// </param>
        public TaggedTextParser(
            IParser<string> textParser,
            IParser<string> attrValueParser)
        {
            _textParser = textParser;
            _attrValueParser = attrValueParser;
        }

        /// <summary>
        /// 平文に対して適用する文字列パーサを取得または設定する。
        /// null ならば適用しない。
        /// </summary>
        public IParser<string> TextParser
        {
            get { return _textParser; }
            set { _textParser = value; }
        }

        /// <summary>
        /// タグ属性内容に対して適用する文字列パーサを取得または設定する。
        /// null ならば適用しない。
        /// </summary>
        public IParser<string> AttrValueParser
        {
            get { return _attrValueParser; }
            set { _attrValueParser = value; }
        }

        /// <summary>
        /// 文字列がタグで始まっているか調べる。
        /// また、タグで始まっている場合はタグデータを取得する。
        /// </summary>
        /// <param name="text">文字列。</param>
        /// <param name="data">タグデータの設定先。</param>
        /// <returns>
        /// タグで始まっている場合は true 。そうでなければ false 。
        /// </returns>
        protected bool StartsWithTag(string text, out TagData data)
        {
            // タグで始まっているかチェック
            TagType type = TagType.Single;
            Match m = RegexSingleTag.Match(text);
            if (!m.Success)
            {
                type = TagType.Begin;
                m = RegexBeginTag.Match(text);
                if (!m.Success)
                {
                    type = TagType.End;
                    m = RegexEndTag.Match(text);
                    if (!m.Success)
                    {
                        data = new TagData();
                        return false;
                    }
                }
            }

            // タグ属性キャプチャ取得
            var attrNames = m.Groups["AttrName"].Captures;
            var attrValues = m.Groups["AttrValue"].Captures;

            // タグデータ作成
            data.Type = type;
            data.Length = m.Length;
            data.Name = m.Groups["TagName"].Value;
            data.AttrTable = new Dictionary<string, string>(attrNames.Count);
            for (int i = 0; i < attrNames.Count; ++i)
            {
                string attrName = attrNames[i].Value;
                if (!data.AttrTable.ContainsKey(attrName))
                {
                    data.AttrTable.Add(
                        attrName,
                        ParseAttrValue(attrValues[i].Value));
                }
            }

            return true;
        }

        /// <summary>
        /// 平文をパースする。
        /// </summary>
        /// <param name="text">平文。</param>
        /// <returns>パースされた平文。</returns>
        protected string ParseText(string text)
        {
            return (TextParser == null) ? text : TextParser.Parse(text);
        }

        /// <summary>
        /// タグ属性内容をパースする。
        /// </summary>
        /// <param name="attrValue">タグ属性内容。</param>
        /// <returns>パースされたタグ属性内容。</returns>
        protected string ParseAttrValue(string attrValue)
        {
            return (AttrValueParser == null) ?
                attrValue :
                AttrValueParser.Parse(attrValue);
        }

        #region IParser<TaggedTextCollection> メンバ

        public virtual TaggedTextCollection Parse(string text)
        {
            if (text == null)
            {
                return null;
            }
            if (text.Length <= 0)
            {
                return new TaggedTextCollection(
                    new TaggedText[] { new TaggedText(text) });
            }

            List<TaggedText> dests = new List<TaggedText>();
            List<TagInfo> tags = new List<TagInfo>();

            TagData data;
            bool prevBegin = false;
            int startIndex = 0;
            while (true)
            {
                int pos = text.IndexOf('<', startIndex);
                if (pos >= 0)
                {
                    if (StartsWithTag(text.Substring(pos), out data))
                    {
                        // タグより前を追加
                        // 空文字列かつ開始タグと終了タグで囲まれていないなら除外
                        string t = text.Substring(0, pos);
                        if (
                            t != string.Empty ||
                            (prevBegin && data.Type == TagType.End))
                        {
                            dests.Add(new TaggedText(ParseText(t), tags));
                        }

                        // タグ種別による処理
                        switch (data.Type)
                        {
                        case TagType.Single:
                            {
                                // タグ情報を一時的に追加
                                tags.Add(new TagInfo(data.Name, data.AttrTable));

                                // テキスト無しのタグテキストを追加
                                dests.Add(new TaggedText(tags));

                                // タグ情報を削除
                                tags.RemoveAt(tags.Count - 1);
                            }
                            break;

                        case TagType.Begin:
                            // タグ情報を追加
                            tags.Add(new TagInfo(data.Name, data.AttrTable));
                            prevBegin = true;
                            break;

                        case TagType.End:
                            // 対応する開始タグをタグ情報から削除
                            for (int ti = tags.Count - 1; ti >= 0; --ti)
                            {
                                if (tags[ti].TagName == data.Name)
                                {
                                    tags.RemoveAt(ti);
                                    break;
                                }
                            }
                            prevBegin = false;
                            break;
                        }

                        // タグ終端以降を抜き出し
                        text = text.Substring(pos + data.Length);

                        // 検索開始位置をリセット
                        startIndex = 0;
                    }
                    else
                    {
                        // 検索開始位置を変更
                        startIndex = pos + 1;
                    }
                }
                else
                {
                    // 残りを追加して終了
                    if (text != string.Empty || tags.Count > 0)
                    {
                        dests.Add(new TaggedText(ParseText(text), tags));
                    }
                    break;
                }
            }

            return new TaggedTextCollection(dests);
        }

        #endregion
    }
}
