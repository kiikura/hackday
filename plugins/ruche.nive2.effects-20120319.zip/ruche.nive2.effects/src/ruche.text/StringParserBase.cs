﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ruche.text
{
    /// <summary>
    /// 文字列変換を行うパーサの抽象基底クラス。
    /// </summary>
    public abstract class StringParserBase : IParser<string>
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public StringParserBase()
        {
        }

        /// <summary>
        /// 文字列の変換を行う。
        /// </summary>
        /// <param name="text">文字列。</param>
        /// <returns>変換された文字列。</returns>
        /// <remarks>
        /// text が null もしくは空文字列である場合、 text の値をそのまま返す。
        /// それ以外の場合、 ParseCore メソッド実装を呼び出し、その結果を返す。
        /// </remarks>
        public string Parse(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return text;
            }
            return this.ParseCore(text);
        }

        /// <summary>
        /// 文字列変換の実処理を行う。
        /// </summary>
        /// <param name="text">
        /// 文字列。必ず非 null かつ 1 文字以上。
        /// </param>
        /// <returns>変換された文字列。</returns>
        protected abstract string ParseCore(string text);

        #region IParser<string> メンバ

        string IParser<string>.Parse(string text)
        {
            return this.Parse(text);
        }

        #endregion
    }
}
