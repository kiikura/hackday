﻿using System;

namespace ruche.text
{
    /// <summary>
    /// パーサの基本機能を提供するインタフェース。
    /// </summary>
    public interface IParser<T>
    {
        /// <summary>
        /// テキストをパースする。
        /// </summary>
        /// <param name="text">テキスト。</param>
        /// <returns>パースされた値。</returns>
        T Parse(string text);
    }
}
