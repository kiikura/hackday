﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace ruche.text
{
    /// <summary>
    /// 複数の文字列パーサを適用するパーサグループクラス。
    /// </summary>
    public class StringParserGroup
        :
        Collection<IParser<string>>,
        IParser<string>
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public StringParserGroup()
            : this(new IParser<string>[0])
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src"></param>
        public StringParserGroup(IEnumerable<IParser<string>> src)
            : base(new List<IParser<string>>(src))
        {
            foreach (var p in src)
            {
                if (p == null)
                {
                    throw new ArgumentException(
                        "src の要素に null が含まれています。",
                        "src");
                }
            }
        }

        #region Collection<IParser<T>> メンバ

        protected override void InsertItem(int index, IParser<string> item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            base.InsertItem(index, item);
        }

        protected override void SetItem(int index, IParser<string> item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            base.SetItem(index, item);
        }

        #endregion

        #region IParser<T> メンバ

        public string Parse(string text)
        {
            foreach (var p in this)
            {
                text = p.Parse(text);
            }
            return text;
        }

        #endregion
    }
}
