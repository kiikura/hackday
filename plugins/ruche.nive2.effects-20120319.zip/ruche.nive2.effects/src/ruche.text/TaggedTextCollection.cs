﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ruche.text
{
    /// <summary>
    /// タグテキストコレクションクラス。
    /// </summary>
    [Serializable]
    public class TaggedTextCollection : ReadOnlyCollection<TaggedText>
    {
        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TaggedTextCollection()
            : this(new TaggedText[0])
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="src">基となるタグテキスト列挙。</param>
        public TaggedTextCollection(IEnumerable<TaggedText> src)
            : base(new List<TaggedText>(src))
        {
            foreach (var tt in src)
            {
                if (tt == null)
                {
                    throw new ArgumentException(
                        "src の要素に null が含まれています。",
                        "src");
                }
            }
        }
    }
}
