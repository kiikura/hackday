﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ruche.text
{
    /// <summary>
    /// テキストとそれに付随するタグ情報コレクションを保持するクラス。
    /// </summary>
    [Serializable]
    public class TaggedText
    {
        /// <summary>
        /// テキスト。
        /// </summary>
        private string _text;

        /// <summary>
        /// タグ情報コレクション。
        /// </summary>
        private TagInfoCollection _tagInfos;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="text">テキスト。テキスト無しならば null 。</param>
        /// <remarks>空のタグ情報列挙で初期化する。</remarks>
        public TaggedText(string text)
            : this(text, new TagInfo[0])
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="tagInfos">タグ情報列挙。</param>
        /// <remarks>テキスト無しとして初期化する。</remarks>
        public TaggedText(IEnumerable<TagInfo> tagInfos)
            : this(null, tagInfos)
        {
        }

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        /// <param name="text">テキスト。テキスト無しならば null 。</param>
        /// <param name="tagInfos">タグ情報列挙。</param>
        public TaggedText(string text, IEnumerable<TagInfo> tagInfos)
        {
            if (tagInfos == null)
            {
                throw new ArgumentNullException("tagInfos");
            }

            _text = text;
            _tagInfos = new TagInfoCollection(tagInfos);
        }

        /// <summary>
        /// テキストを取得する。テキスト無しならば null が返る。
        /// </summary>
        public string Text
        {
            get { return _text; }
        }

        /// <summary>
        /// テキストを含んでいるか否かを取得する。
        /// </summary>
        public bool HasText
        {
            get { return (_text != null); }
        }

        /// <summary>
        /// タグ情報コレクションを取得する。
        /// </summary>
        public TagInfoCollection TagInfos
        {
            get { return _tagInfos; }
        }
    }
}
