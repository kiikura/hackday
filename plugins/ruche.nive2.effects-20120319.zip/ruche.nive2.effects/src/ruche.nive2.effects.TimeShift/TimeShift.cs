﻿using System;
using System.Drawing;
using NiVE2.Plugin.Interface;
using NiVE2.Plugin.Utils;
using NiVE2.Drawing;
using NiVE2.Drawing.Drawing2D;
using NiVE2.Utils;
using NiVE2.Utils.Threading;

namespace ruche.nive2.effects
{
    /// <summary>
    /// タイムシフトを行うNiVE2エフェクトクラス。
    /// </summary>
    public class TimeShift : EffectBase
    {
        /// <summary>
        /// 対象レイヤ。
        /// </summary>
        private ILayer _layer = null;

        /// <summary>
        /// コンストラクタ。
        /// </summary>
        public TimeShift()
        {
        }

        #region EffectBase メンバ

        public override string Category
        {
            get { return "時間"; }
        }

        public override bool IsAudioEffect
        {
            get { return true; }
        }

        public override bool IsVideoEffect
        {
            get { return true; }
        }

        public override void Initialize(ILayer layer)
        {
            _layer = layer;
        }

        public override object SaveInnerData()
        {
            return null;
        }

        public override void LoadInnerData(object data)
        {
        }

        public override PropertyBase[] GetDefaultProperty()
        {
            return new PropertyBase[]
                {
                    new TimeProperty("時刻", 0.0),
                };
        }

        public override PropertyEditControlBase[] GetControl()
        {
            return new PropertyEditControlBase[]
                {
                    new TimePropertyEditControl("時刻", _layer.Composition, 1.0),
                };
        }

        public override Roi CheckRoi(
            Roi roi,
            ReadOnlyDictionary<string, PropertyBase> property,
            double time)
        {
            return roi;
        }

        public override NBitmap ProcessingImage(
            NBitmap image,
            ReadOnlyDictionary<string, PropertyBase> property,
            Roi roi,
            double time)
        {
            // プロパティ取得
            double t = ((TimeProperty)property["時刻"]).Time;

            // 実時刻と同じなら上書き不要
            if (t == time) { return image; }

            // イメージバッファサイズ算出
            SizeF bmpSize = _layer.GetImageBounds(t).Size;
            long bmpBufLen =
                (long)((bmpSize.Width + 1.0) * 4 * (bmpSize.Height + 1.0));

            // イメージ取得
            using (CacheLocker cacheLock = new CacheLocker(bmpBufLen))
            using (NBitmap srcBmp = _layer.GetSourceImage(t))
            {
                // 描画
                ImageUtil.BlendImage(
                    image,
                    srcBmp,
                    roi.Image.Location,
                    BlendType.Copy,
                    roi.Interest,
                    new Matrix3D(),
                    false,
                    false);
            }

            return image;
        }

        public override byte[] ProcessingAudio(
            byte[] audio,
            ReadOnlyDictionary<string, PropertyBase>[] property,
            double time)
        {
            // 1サンプルあたりの秒数
            double sampleTime = 1.0 / ReferenceData.WaveFormat.nSamplesPerSec;

            // 1秒あたりのバイト数
            uint secLen =
                ReferenceData.WaveFormat.nSamplesPerSec *
                ReferenceData.WaveFormat.nBlockAlign;

            for (
                int f = 0, dpos = 0, fcount = 0;
                f < property.Length && dpos < audio.Length;
                f += fcount)
            {
                // フレーム数初期化
                fcount = 1;
                double span = fcount / _layer.Composition.FrameRate;

                // プロパティ取得
                double startTime = ((TimeProperty)property[f]["時刻"]).Time;

                // 1フレームずつ処理しようとすると、ソースが48kHzでない場合に
                // 音がブツブツと途切れてしまう。
                // そのため、時刻的に連続しているフレームは一気に処理する。
                while (f + fcount < property.Length)
                {
                    // 連続しているかチェック(1サンプル時間未満の誤差を許容)
                    double t =
                        ((TimeProperty)property[f + fcount]["時刻"]).Time;
                    double diff = t - startTime;
                    if (diff <= span - sampleTime || diff >= span + sampleTime)
                    {
                        // 連続していないので抜ける
                        break;
                    }

                    // 連続しているのでフレーム数を加算する
                    ++fcount;
                    span = fcount / _layer.Composition.FrameRate;
                }

                // キャッシュを確保
                long bufLen = (long)((span + sampleTime) * secLen);
                using (CacheLocker cacheLock = new CacheLocker(bufLen))
                {
                    // オーディオを取得
                    byte[] src = _layer.GetSourceAudio(startTime, span);

                    // 上書き
                    int dlen = Math.Min(src.Length, audio.Length - dpos);
                    Buffer.BlockCopy(src, 0, audio, dpos, dlen);
                    dpos += dlen;
                }
            }

            return audio;
        }

        #endregion

        #region PluginBase メンバ

        public override string PluginName
        {
            get { return "タイムシフト"; }
        }

        public override string Author
        {
            get { return "ルーチェ"; }
        }

        public override string InfoLink
        {
            get { return "http://www.ruche-home.net/"; }
        }

        public override string Description
        {
            get
            {
                return "ビデオやオーディオの再生時刻をシフトします。";
            }
        }

        #endregion

        #region IDisposable メンバ

        public override void Dispose()
        {
            // 何もしない
        }

        #endregion
    }
}
